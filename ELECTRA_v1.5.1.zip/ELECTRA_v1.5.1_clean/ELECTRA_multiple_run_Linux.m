function ELECTRA_multiple_run_Linux(material_names_file)

run([material_names_file,'.m'])

nm = max(size(materials_list));
if exist('alat','var') 
    if max(size(alat)) ~= nm %#ok<NODEF>
        disp(' .mat type Ek files assumed')
        alat = ones(size(materials_list,1),size(materials_list,2));
    end
else
    alat = ones(size(materials_list,1),size(materials_list,2));
end

addpath('code/','-end');
disp('running the main function'); disp(' ');

materials_data.list = materials_list;
materials_data.alat = alat;
for id_m = 1:nm
    main_ELECTRA_multiple_Linux( materials_data, id_m ) ;
end

addpath('code/','-frozen');
end