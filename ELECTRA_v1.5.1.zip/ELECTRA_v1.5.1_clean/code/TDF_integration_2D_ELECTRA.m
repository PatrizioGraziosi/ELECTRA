% Copyright 2022 Patrizio Graziosi  and Neophytos Neophytou               %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source and the author when publishing results      %
% obtained  using the present  code                                       %
%                                                                         %
% ----------------------------------------------------------------------- %


% this code computes the TE properties

% in the first dimension, the E values run, 
% in the second dimension, the EF values run,
% in the third dimension, the T values run

% NOTE 
% on 08/05/2019 I added some lines to consider the EF shift imposing that 
% EF_array becomes the EF_matrix column that corresponds at each 
% temperature, and other lines to consider that the maximum EF can be in the gap


function [sigma, sigma_ph, sigma_sep, S, S_ph, S_sep, PF, PF_ph, PF_sep, ke, ke_ph, ke_sep, mu, mu_ph, mu_sep, n_carrier, n_carrier_ph, EF_matrix_ph, N_imp_matrix_ph] = ...
    TDF_integration_2D_ELECTRA(E_array, T_array, TDF, TDF_ph, TDF_sep, EF_matrix, DOS_tot, WorkSpace4, Ek) %#codegen
        
EF_array = EF_matrix(:,1)';

FD=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
dfdE=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));



integrand_sigma_xx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_sigma_yy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
integrand_sigma_xy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_sigma_yx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));

integrand_S_xx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_S_yy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
integrand_S_xy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_S_yx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));

integrand_k_e_xx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_k_e_yy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
integrand_k_e_xy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_k_e_yx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));

integrand_n_carrier=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));



ADP = WorkSpace4.ADP ;                          % scattering instructions
ADP_IVS = WorkSpace4.ADP_IVS ;
Alloy = WorkSpace4.Alloy ;
ODP = WorkSpace4.ODP ;
POP = WorkSpace4.POP ;
screening_POP = WorkSpace4.screening_POP ;
IVS = WorkSpace4.IVS ;
% IIS = WorkSpace4.IIS ;
carriers = WorkSpace4.carriers ;
bands_transp = WorkSpace4.bands_transp ;
bipolar_transport = WorkSpace4.bipolar_transport ;
Fermi_shift_flag = WorkSpace4.Fermi_shift_flag ;
semimetal = WorkSpace4.semimetal ;
if strcmp(semimetal,'yes') 
    pseudovalence_bands = WorkSpace4.pseudovalence_bands ;
    if any(pseudovalence_bands(:) == bands_transp(in) ) 
        carriers = 'holes';
    end
end

sd = WorkSpace4.sd ;
kx_matrix = WorkSpace4.kx_matrix ;
ky_matrix = WorkSpace4.ky_matrix ;
% Ek = WorkSpace4.Ek ;
if strcmp(carriers,'holes')
    carrier_sign = -1;
    Ek = -Ek;
else 
    carrier_sign = 1;
end
[~, ~, Ek] = shifting_bands_2D_ELECTRA(Ek) ;


q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]



sigma = struct();
S = struct();
PF = struct();
mu = struct();
ke = struct();

sigma_sep = struct();
S_sep = struct();
PF_sep = struct();
mu_sep = struct();
ke_sep = struct();

sigma_ph = struct();
S_ph = struct();
PF_ph = struct();
mu_ph = struct();
ke_ph = struct();

if strcmp(bipolar_transport,'yes')
    E_array_minority = WorkSpace4.E_array_minority;
    E_array_majority = WorkSpace4.E_array_majority;
    DOS_tot_majority=WorkSpace4.DOS_tot_majority;
    DOS_tot_minority=WorkSpace4.DOS_tot_minority;
    nE_M = size(E_array_majority,2); nEF = size(EF_matrix,1); nT = size(EF_matrix,2);
    integrand_n_carrier_majority = zeros(nE_M,nEF,nT);
    nE_m = size(E_array_minority,2);
    integrand_n_carrier_minority = zeros(nE_m,nEF,nT);
    FD_majority = zeros(nE_M,nEF,nT);
    FD_minority = zeros(nE_m,nEF,nT);
    for iEF = size(EF_array,2):-1:1
        for iT = 1:size(T_array,2)
            EF_array = EF_matrix(:,iT)' ;

            dfdE(:,iEF,iT)=-1./(kB*T_array(iT)/q0).*exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1).^2;
            
            FD_majority(:,iEF,iT) = 1./(exp((E_array_majority-EF_array(iEF))./(kB*T_array(iT)/q0))+1);
            FD_minority(:,iEF,iT) = 1-1./(exp((-E_array_minority-EF_array(iEF))./(kB*T_array(iT)/q0))+1);

        end
    end
    
else % unipolar
    for iEF = size(EF_array,2):-1:1
        for iT = 1:size(T_array,2)
            EF_array = EF_matrix(:,iT)' ;

            FD(:,iEF,iT)=1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1);

            dfdE(:,iEF,iT)=-1./(kB*T_array(iT)/q0).*exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1).^2;        

        end
    end
end









%calculation of the Transport Density Fnction, 1D array with the TDF values,
%the size is the same of the E_array
% if strcmp(dimensionality,'3D')
    
    % Initialization of the TDFs
    TDF_xx = TDF.xx; TDF_yy = TDF.yy; TDF_xy = TDF.xy; TDF_yx = TDF.yx;
        
    
% calculation of the TE coefficients
% 1) integrands, depend on the dimensionality
%
        for iEF = size(EF_matrix,1):-1:1
            for iT = size(T_array,2):-1:1
                EF_array = EF_matrix(:,iT)';

                
                    % integral arguments for electr. conductivity
                    integrand_sigma_xx(:,iEF,iT) = TDF_xx(:,iEF,iT) .* (dfdE(:,iEF,iT));
                    integrand_sigma_yy(:,iEF,iT) = TDF_yy(:,iEF,iT) .* (dfdE(:,iEF,iT));
                    integrand_sigma_xy(:,iEF,iT) = TDF_xy(:,iEF,iT) .* (dfdE(:,iEF,iT));
                    integrand_sigma_yx(:,iEF,iT) = TDF_yx(:,iEF,iT) .* (dfdE(:,iEF,iT));
                       
                    
                    % integral argument for Seebeck coeff.
                    integrand_S_xx(:,iEF,iT) = integrand_sigma_xx(:,iEF,iT) .* (E_array'-EF_array(iEF))*q0/(kB*T_array(iT));
                    integrand_S_yy(:,iEF,iT) = integrand_sigma_yy(:,iEF,iT) .* (E_array'-EF_array(iEF))*q0/(kB*T_array(iT));
                    integrand_S_xy(:,iEF,iT) = integrand_sigma_xy(:,iEF,iT) .* (E_array'-EF_array(iEF))*q0/(kB*T_array(iT));
                    integrand_S_yx(:,iEF,iT) = integrand_sigma_yx(:,iEF,iT) .* (E_array'-EF_array(iEF))*q0/(kB*T_array(iT));
                    
                     % integral argument for k_e
                    integrand_k_e_xx(:,iEF,iT) = integrand_sigma_xx(:,iEF,iT) .* ((E_array'-EF_array(iEF))*q0).^2;
                    integrand_k_e_yy(:,iEF,iT) = integrand_sigma_yy(:,iEF,iT) .* ((E_array'-EF_array(iEF))*q0).^2;
                    integrand_k_e_xy(:,iEF,iT) = integrand_sigma_xy(:,iEF,iT) .* ((E_array'-EF_array(iEF))*q0).^2;
                    integrand_k_e_yx(:,iEF,iT) = integrand_sigma_yx(:,iEF,iT) .* ((E_array'-EF_array(iEF))*q0).^2;
                    
            end
        end
        
        % charge carrier concentration relevant to the transport, in m^(-3)
        % DOS_tot already contains the 2/8pi^3, dSk and BZ_factor elements
        if strcmp(bipolar_transport,'yes')
            for iEF = size(EF_array,2):-1:1
                for iT = size(T_array,2):-1:1
                    
                    integrand_n_carrier_majority(:,iEF,iT)=DOS_tot_majority'.*FD_majority(:,iEF,iT) ;
                    integrand_n_carrier_minority(:,iEF,iT)=DOS_tot_minority'.*FD_minority(:,iEF,iT) ; 
                    
                end
            end
            n_majority = squeeze( trapz( E_array_majority,integrand_n_carrier_majority,1) );
            n_minority = squeeze( trapz( E_array_minority,integrand_n_carrier_minority,1) );  % charge carrier concentration in m^(-3) 
            n_carrier = (n_majority + n_minority) ; % see line 255 in TDF_integrals_bipolar_VOMBATO_v4
            
        else  % unipolar
            for iEF = size(EF_array,2):-1:1
                for iT = size(T_array,2):-1:1
                    
                    integrand_n_carrier(:,iEF,iT)=DOS_tot'.*FD(:,iEF,iT);
                    
                end
            end
            n_carrier = ( squeeze(trapz(E_array,integrand_n_carrier,1) ) );  % charge carrier concentration in m^(-3) 
            
        end

%
% calculation of the TE coefficients
% 2) integration over the energy

sigma_xx = squeeze(-q0*trapz(E_array,integrand_sigma_xx,1)); % integral over the Energy, first dimension
sigma_yy = squeeze(-q0*trapz(E_array,integrand_sigma_yy,1));
sigma_xy = squeeze(-q0*trapz(E_array,integrand_sigma_xy,1));
sigma_yx = squeeze(-q0*trapz(E_array,integrand_sigma_yx,1));

sigma_average = ( sigma_xx + sigma_yy ) / 2;


mu_xx = sigma_xx./n_carrier/q0;
mu_yy = sigma_yy./n_carrier/q0;
mu_xy = sigma_xy./n_carrier/q0;
mu_yx = sigma_yx./n_carrier/q0;

mu_average = (mu_xx+mu_yy )/2;

%Seebeck coefficients
S_xx = carrier_sign .* kB./sigma_xx.* squeeze(trapz(E_array,integrand_S_xx,1));
S_yy = carrier_sign .* kB./sigma_yy.* squeeze(trapz(E_array,integrand_S_yy,1));
S_xy = carrier_sign .* kB./sigma_xy.* squeeze(trapz(E_array,integrand_S_xy,1));
S_yx = carrier_sign .* kB./sigma_yx.* squeeze(trapz(E_array,integrand_S_yx,1));

S_average = (sigma_xx.*S_xx + sigma_yy.*S_yy )./...
    (sigma_xx + sigma_yy);

% Power Factor
PF_xx = sigma_xx .* S_xx.^2;
PF_yy = sigma_yy .* S_yy.^2;
PF_xy = sigma_xy .* S_xy.^2;
PF_yx = sigma_xy .* S_yx.^2;

PF_average = sigma_average.*S_average.^2 ; % ( PF_xx + PF_yy ) / 2;

% electron thermal conductivity
k_e_xx = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx,1)) - sigma_xx .* S_xx.^2 .* T_array ;
k_e_yy = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy,1)) - sigma_yy .* S_yy.^2 .* T_array ;
k_e_xy = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy,1)) - sigma_xy .* S_xy.^2 .* T_array ;
k_e_yx = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx,1)) - sigma_yx .* S_yx.^2 .* T_array ;

k_e_average = (k_e_xx + k_e_yy ) / 2;



% save into structures
sigma.xx = sigma_xx; sigma.xy = sigma_xy;
sigma.yx = sigma_yx; sigma.yy = sigma_yy; 
sigma.average = sigma_average;

mu.xx = mu_xx; mu.xy = mu_xy;
mu.yx = mu_yx; mu.yy = mu_yy;
mu.average = mu_average;

S.xx = S_xx; S.xy = S_xy; 
S.yx = S_yx; S.yy = S_yy; 
S.average = S_average;

PF.xx = PF_xx; PF.xy = PF_xy;
PF.yx = PF_yx; PF.yy = PF_yy;
PF.average = PF_average;

ke.xx = k_e_xx; ke.xy = k_e_xy;
ke.yx = k_e_yx; ke.yy = k_e_yy;
ke.average = k_e_average;

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------


% ------------------------------------------------------------------------
% for the calculations without impurities I use a different Fermi array
   

    EF_array = EF_matrix(:,1);

    EF_array_ph = min(EF_array):(abs(max(EF_array)-min(EF_array)))/200:max(EF_array);
    
    FD_ph = zeros(size(E_array,2),201,size(T_array,2));
    dfdE_ph = zeros(size(E_array,2),201,size(T_array,2));
    integrand_n_carrier_ph = zeros(size(E_array,2),201,size(T_array,2));
    integrand_n_imp = zeros(size(E_array,2),201,size(T_array,2));

    if strcmp(bipolar_transport,'no') 
        if strcmp(Fermi_shift_flag,'yes')
            if strcmp(semimetal,'no')    
                [EF_matrix_ph, N_imp_matrix_ph] = Fermi_interpolation_unipolar_2D_ELECTRA( EF_matrix, EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, sd, bands_transp) ;
            elseif strcmp(semimetal,'yes') % this flag should not be here anymore, semimetal are like normal bipolar rather than special unipolar
                pseudoconduction_bands = WorkSpace4.pseudoconduction_bands ;
                pseudovalence_bands = WorkSpace4.pseudovalence_bands ;
                [EF_matrix_ph, N_imp_matrix_ph] = Fermi_interpolation_bipolar_2D_ELECTRA( EF_matrix, EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, sd, pseudoconduction_bands, pseudovalence_bands ) ;
            end
        elseif strcmp(Fermi_shift_flag,'no')
            EF_matrix_ph = zeros(size(EF_array_ph,2),size(T_array,2));
            for iT = size(T_array,2) : -1 : 1
                EF_matrix_ph(:,iT) = EF_array_ph';                
                for iEF = size(EF_array_ph,2):-1:1
                    FD_ph(:,iEF,iT)=1./(exp((E_array-EF_array_ph(iEF))./(kB*T_array(iT)/q0))+1);
                    integrand_n_imp(:,iEF,iT)=DOS_tot.*FD_ph(:,iEF,iT)';
                end
                N_imp_matrix_ph = squeeze(trapz(E_array,integrand_n_imp,1));  % total charge carrier concentration in m^(-3) for ph.limited transport, maybe useless
            end
        end
    % calculation ot the Fermi array at each temperature (Fermi shift upon T)
    % considering the carriers' density to be constant, i.e. in the extrinsic
    % region
    elseif strcmp(bipolar_transport,'yes')
        if strcmp(Fermi_shift_flag,'yes')
            pseudoconduction_bands = WorkSpace4.pseudoconduction_bands ;
            pseudovalence_bands = WorkSpace4.pseudovalence_bands ;
            [EF_matrix_ph, N_imp_matrix_ph] = Fermi_interpolation_bipolar_2D_ELECTRA( EF_matrix, EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, sd, pseudoconduction_bands, pseudovalence_bands ) ;
            % same as above but considering both CBs and VBs
    %         an intrinsic semiconductor has the same number of thermally
    %         generated electrons and holes so that the intrinsic Fermi level
    %         can be not in the midgap.
        elseif strcmp(Fermi_shift_flag,'no')
            EF_matrix_ph = zeros(size(EF_array_ph,2),size(T_array,2));
            for iT = size(T_array,2) : -1 : 1
                EF_matrix_ph(:,iT) = EF_array_ph';
                for iEF = size(EF_array_ph,2):-1:1
                    FD_ph(:,iEF,iT)=1./(exp((E_array-EF_array_ph(iEF))./(kB*T_array(iT)/q0))+1);
                    integrand_n_imp(:,iEF,iT)=DOS_tot.*FD_ph(:,iEF,iT)';
                end
                N_imp_matrix_ph = squeeze(trapz(E_array,integrand_n_imp,1));  % total charge carrier concentration in m^(-3) for ph.limited transport, maybe useless
            end
        end
    end    


    
    if strcmp(bipolar_transport,'yes')

        
        nE_M = size(E_array_majority,2); nEF = size(EF_matrix_ph,1); nT = size(EF_matrix_ph,2);
        integrand_n_carrier_majority_ph = zeros(nE_M,nEF,nT);
        nE_m = size(E_array_minority,2);
        integrand_n_carrier_minority_ph = zeros(nE_m,nEF,nT);
        FD_majority_ph = zeros(nE_M,nEF,nT); FD_minority_ph = zeros(nE_m,nEF,nT);
        for iEF = size(EF_matrix_ph,1):-1:1
            for iT = 1:size(T_array,2)              
                EF_array_ph = EF_matrix_ph(:,iT)';

                FD_majority_ph(:,iEF,iT)=1./(exp((E_array_majority-EF_array_ph(iEF))./(kB*T_array(iT)/q0))+1);
                FD_minority_ph(:,iEF,iT)=1-1./(exp((-E_array_minority-EF_array_ph(iEF))./(kB*T_array(iT)/q0))+1);

                dfdE_ph(:,iEF,iT)=-1./(kB*T_array(iT)/q0).*exp((E_array-EF_array_ph(iEF))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_array_ph(iEF))./(kB*T_array(iT)/q0))+1).^2;        

            end
        end

    else % unipolar
       for iEF=size(EF_matrix_ph,1):-1:1
            for iT=size(T_array,2):-1:1
                
                FD_ph(:,iEF,iT)=1./(exp((E_array-EF_matrix_ph(iEF,iT))./(kB*T_array(iT)/q0))+1);
                dfdE_ph(:,iEF,iT)=-1./(kB*T_array(iT)/q0).*exp((E_array-EF_matrix_ph(iEF,iT))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_matrix_ph(iEF,iT))./(kB*T_array(iT)/q0))+1).^2;
                integrand_n_carrier_ph(:,iEF,iT)=(DOS_tot'.*FD_ph(:,iEF,iT))';
                
            end
        end
    end
    
    % charge carrier concentration relevant to the transport, in m^(-3)
    % DOS_tot already contains the 2/8pi^3, dSk and BZ_factor elements
    if strcmp(bipolar_transport,'yes')
        for iEF = size(EF_matrix_ph,1):-1:1
            for iT = size(T_array,2):-1:1

                integrand_n_carrier_majority_ph(:,iEF,iT)=DOS_tot_majority'.*FD_majority_ph(:,iEF,iT) ;
                integrand_n_carrier_minority_ph(:,iEF,iT)=DOS_tot_minority'.*FD_minority_ph(:,iEF,iT) ; 

            end
        end
        n_majority_ph = squeeze( trapz( E_array_majority,integrand_n_carrier_majority_ph,1) );
        n_minority_ph = squeeze( trapz( E_array_minority,integrand_n_carrier_minority_ph,1) );  
        n_carrier_ph = (n_majority_ph + n_minority_ph) ;

    else  % unipolar
        for iEF = size(EF_matrix_ph,1):-1:1
            for iT = size(T_array,2):-1:1

                integrand_n_carrier_ph(:,iEF,iT)=DOS_tot'.*FD_ph(:,iEF,iT);

            end
        end
        n_carrier_ph = ( squeeze(trapz(E_array,integrand_n_carrier_ph,1) ) );  % charge carrier concentration in m^(-3) 

    end
  
%     n_carrier_ph=squeeze(trapz(E_array,integrand_n_carrier_ph,1)); 





% ---------  ADP only ---------------------------------------------
if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes')
    
    
    TDF_xx_ADP = TDF_sep.ADP.xx; TDF_yy_ADP = TDF_sep.ADP.yy;
    TDF_xy_ADP = TDF_sep.ADP.xy; TDF_yx_ADP = TDF_sep.ADP.yx;
    
    
    integrand_sigma_xx_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yy_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_sigma_xy_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yx_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));  

    integrand_S_xx_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yy_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_S_xy_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yx_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

    integrand_k_e_xx_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yy_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_k_e_xy_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yx_ADP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

    


    for iEF = size(EF_matrix_ph,1):-1:1
        for iT = size(T_array,2) : -1 : 1
                integrand_sigma_xx_ADP(:,iEF,iT)=TDF_xx_ADP(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_yy_ADP(:,iEF,iT)=TDF_yy_ADP(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_xy_ADP(:,iEF,iT)=TDF_xy_ADP(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_yx_ADP(:,iEF,iT)=TDF_yx_ADP(:,iT).*(dfdE_ph(:,iEF,iT));

                integrand_S_xx_ADP(:,iEF,iT) = integrand_sigma_xx_ADP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_yy_ADP(:,iEF,iT) = integrand_sigma_yy_ADP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_xy_ADP(:,iEF,iT) = integrand_sigma_xy_ADP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_yx_ADP(:,iEF,iT) = integrand_sigma_yx_ADP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                
                integrand_k_e_xx_ADP(:,iEF,iT) = integrand_sigma_xx_ADP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_yy_ADP(:,iEF,iT) = integrand_sigma_yy_ADP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_xy_ADP(:,iEF,iT) = integrand_sigma_xy_ADP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_yx_ADP(:,iEF,iT) = integrand_sigma_yx_ADP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        end
    end

    sigma_xx_ADP=squeeze(-q0*trapz(E_array,integrand_sigma_xx_ADP,1));
    sigma_yy_ADP=squeeze(-q0*trapz(E_array,integrand_sigma_yy_ADP,1));
    sigma_xy_ADP=squeeze(-q0*trapz(E_array,integrand_sigma_xy_ADP,1));
    sigma_yx_ADP=squeeze(-q0*trapz(E_array,integrand_sigma_yx_ADP,1));

    mu_xx_ADP=sigma_xx_ADP./n_carrier_ph/q0;
    mu_yy_ADP=sigma_yy_ADP./n_carrier_ph/q0;
    mu_xy_ADP=sigma_xy_ADP./n_carrier_ph/q0;
    mu_yx_ADP=sigma_yx_ADP./n_carrier_ph/q0;


    S_xx_ADP = carrier_sign .* kB./sigma_xx_ADP.* squeeze(trapz(E_array,integrand_S_xx_ADP,1));
    S_yy_ADP = carrier_sign .* kB./sigma_yy_ADP.* squeeze(trapz(E_array,integrand_S_yy_ADP,1));
    S_xy_ADP = carrier_sign .* kB./sigma_xy_ADP.* squeeze(trapz(E_array,integrand_S_xy_ADP,1));  
    S_yx_ADP = carrier_sign .* kB./sigma_yx_ADP.* squeeze(trapz(E_array,integrand_S_yx_ADP,1));

    PF_xx_ADP = sigma_xx_ADP .* S_xx_ADP.^2;
    PF_yy_ADP = sigma_yy_ADP .* S_yy_ADP.^2;
    PF_xy_ADP = sigma_xx_ADP .* S_xy_ADP.^2;
    PF_yx_ADP = sigma_xx_ADP .* S_yx_ADP.^2;
    
    k_e_xx_ADP = -1./(q0*T_array).*  squeeze(trapz(E_array,integrand_k_e_xx_ADP,1)) - sigma_xx_ADP .* S_xx_ADP.^2 .* T_array ;
    k_e_yy_ADP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy_ADP,1)) - sigma_yy_ADP .* S_yy_ADP.^2 .* T_array ;
    k_e_xy_ADP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy_ADP,1)) - sigma_xy_ADP .* S_xy_ADP.^2 .* T_array ;
    k_e_yx_ADP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx_ADP,1)) - sigma_yx_ADP .* S_yx_ADP.^2 .* T_array ;
    
    
    % saving into structures
    sigma_sep.ADP.xx = sigma_xx_ADP; sigma_sep.ADP.xy = sigma_xy_ADP; 
    sigma_sep.ADP.yx = sigma_yx_ADP; sigma_sep.ADP.yy = sigma_yy_ADP;

    mu_sep.ADP.xx = mu_xx_ADP; mu_sep.ADP.xy = mu_xy_ADP;
    mu_sep.ADP.yx = mu_yx_ADP; mu_sep.ADP.yy = mu_yy_ADP; 

    S_sep.ADP.xx = S_xx_ADP; S_sep.ADP.xy = S_xy_ADP;
    S_sep.ADP.yx = S_yx_ADP; S_sep.ADP.yy = S_yy_ADP; 

    PF_sep.ADP.xx = PF_xx_ADP; PF_sep.ADP.xy = PF_xy_ADP;
    PF_sep.ADP.yx = PF_yx_ADP; PF_sep.ADP.yy = PF_yy_ADP; 

    ke_sep.ADP.xx = k_e_xx_ADP; ke_sep.ADP.xy = k_e_xy_ADP;
    ke_sep.ADP.yx = k_e_yx_ADP; ke_sep.ADP.yy = k_e_yy_ADP; 

end
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------



% ---------  ODP only -----------------------------------------------------
if strcmp(ODP,'yes')
    
    TDF_xx_ODP = TDF_sep.ODP.xx; TDF_yy_ODP = TDF_sep.ODP.yy; 
    TDF_xy_ODP = TDF_sep.ODP.xy; TDF_yx_ODP = TDF_sep.ODP.yx; 
    
    
    integrand_sigma_xx_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yy_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_sigma_xy_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yx_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));  

    integrand_S_xx_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yy_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_S_xy_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yx_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

    integrand_k_e_xx_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yy_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_k_e_xy_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yx_ODP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

    
    for iEF = size(EF_matrix_ph,1):-1:1
        for iT = size(T_array,2) : -1 : 1
            
        integrand_sigma_xx_ODP(:,iEF,iT) = TDF_xx_ODP(:,iT).*(dfdE_ph(:,iEF,iT));
        integrand_sigma_yy_ODP(:,iEF,iT) = TDF_yy_ODP(:,iT).*(dfdE_ph(:,iEF,iT));
        integrand_sigma_xy_ODP(:,iEF,iT) = TDF_xy_ODP(:,iT).*(dfdE_ph(:,iEF,iT));
        integrand_sigma_yx_ODP(:,iEF,iT) = TDF_yx_ODP(:,iT).*(dfdE_ph(:,iEF,iT));

        integrand_S_xx_ODP(:,iEF,iT) = integrand_sigma_xx_ODP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
        integrand_S_yy_ODP(:,iEF,iT) = integrand_sigma_yy_ODP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
        integrand_S_xy_ODP(:,iEF,iT) = integrand_sigma_xy_ODP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
        integrand_S_yx_ODP(:,iEF,iT) = integrand_sigma_yx_ODP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
        
        integrand_k_e_xx_ODP(:,iEF,iT) = integrand_sigma_xx_ODP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        integrand_k_e_yy_ODP(:,iEF,iT) = integrand_sigma_yy_ODP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        integrand_k_e_xy_ODP(:,iEF,iT) = integrand_sigma_xy_ODP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        integrand_k_e_yx_ODP(:,iEF,iT) = integrand_sigma_yx_ODP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        end
    end

    sigma_xx_ODP=squeeze(-q0*trapz(E_array,integrand_sigma_xx_ODP,1));
    sigma_yy_ODP=squeeze(-q0*trapz(E_array,integrand_sigma_yy_ODP,1));
    sigma_xy_ODP=squeeze(-q0*trapz(E_array,integrand_sigma_xy_ODP,1));
    sigma_yx_ODP=squeeze(-q0*trapz(E_array,integrand_sigma_yx_ODP,1));


    mu_xx_ODP=sigma_xx_ODP./n_carrier_ph/q0;
    mu_yy_ODP=sigma_yy_ODP./n_carrier_ph/q0;
    mu_xy_ODP=sigma_xy_ODP./n_carrier_ph/q0;
    mu_yx_ODP=sigma_yx_ODP./n_carrier_ph/q0;


    S_xx_ODP = carrier_sign .* kB./sigma_xx_ODP.* squeeze(trapz(E_array,integrand_S_xx_ODP,1));
    S_yy_ODP = carrier_sign .* kB./sigma_yy_ODP.* squeeze(trapz(E_array,integrand_S_yy_ODP,1));
    S_xy_ODP = carrier_sign .* kB./sigma_xy_ODP.* squeeze(trapz(E_array,integrand_S_xy_ODP,1));
    S_yx_ODP = carrier_sign .* kB./sigma_yx_ODP.* squeeze(trapz(E_array,integrand_S_yx_ODP,1));

    PF_xx_ODP = sigma_xx_ODP .* S_xx_ODP.^2;
    PF_yy_ODP = sigma_yy_ODP .* S_yy_ODP.^2;
    PF_xy_ODP = sigma_xy_ODP .* S_xy_ODP.^2;
    PF_yx_ODP = sigma_xy_ODP .* S_yx_ODP.^2;
    
    k_e_xx_ODP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx_ODP,1)) - sigma_xx_ODP .* S_xx_ODP.^2 .* T_array ;
    k_e_yy_ODP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy_ODP,1)) - sigma_yy_ODP .* S_yy_ODP.^2 .* T_array ;
    k_e_xy_ODP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy_ODP,1)) - sigma_xy_ODP .* S_xy_ODP.^2 .* T_array ;
    k_e_yx_ODP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx_ODP,1)) - sigma_yx_ODP .* S_yx_ODP.^2 .* T_array ;
   
    
    
    % saving into structures
    sigma_sep.ODP.xx = sigma_xx_ODP; sigma_sep.ODP.xy = sigma_xy_ODP; 
    sigma_sep.ODP.yx = sigma_yx_ODP; sigma_sep.ODP.yy = sigma_yy_ODP;

    mu_sep.ODP.xx = mu_xx_ODP; mu_sep.ODP.xy = mu_xy_ODP; 
    mu_sep.ODP.yx = mu_yx_ODP; mu_sep.ODP.yy = mu_yy_ODP; 

    S_sep.ODP.xx = S_xx_ODP; S_sep.ODP.xy = S_xy_ODP; 
    S_sep.ODP.yx = S_yx_ODP; S_sep.ODP.yy = S_yy_ODP; 

    PF_sep.ODP.xx = PF_xx_ODP; PF_sep.ODP.xy = PF_xy_ODP; 
    PF_sep.ODP.yx = PF_yx_ODP; PF_sep.ODP.yy = PF_yy_ODP; 

    ke_sep.ODP.xx = k_e_xx_ODP; ke_sep.ODP.xy = k_e_xy_ODP; 
    ke_sep.ODP.yx = k_e_yx_ODP; ke_sep.ODP.yy = k_e_yy_ODP;     

end
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------




% ---------  IVS only -----------------------------------------------------
if strcmp(IVS,'yes')
    
    TDF_xx_IVS = TDF_sep.IVS.xx; TDF_yy_IVS = TDF_sep.IVS.yy; 
    TDF_xy_IVS = TDF_sep.IVS.xy; TDF_yx_IVS = TDF_sep.IVS.yx;
    
    
    integrand_sigma_xx_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yy_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_sigma_xy_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yx_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

    integrand_S_xx_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yy_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_S_xy_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yx_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

    integrand_k_e_xx_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yy_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_k_e_xy_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yx_IVS=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

    

    for iEF = size(EF_matrix_ph,1):-1:1
        for iT = size(T_array,2) : -1 : 1
                integrand_sigma_xx_IVS(:,iEF,iT)=TDF_xx_IVS(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_yy_IVS(:,iEF,iT)=TDF_yy_IVS(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_xy_IVS(:,iEF,iT)=TDF_xy_IVS(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_yx_IVS(:,iEF,iT)=TDF_yx_IVS(:,iT).*(dfdE_ph(:,iEF,iT));

                integrand_S_xx_IVS(:,iEF,iT) = integrand_sigma_xx_IVS(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_yy_IVS(:,iEF,iT) = integrand_sigma_yy_IVS(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_xy_IVS(:,iEF,iT) = integrand_sigma_xy_IVS(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));              
                integrand_S_yx_IVS(:,iEF,iT) = integrand_sigma_yx_IVS(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                
                integrand_k_e_xx_IVS(:,iEF,iT) = integrand_sigma_xx_IVS(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_yy_IVS(:,iEF,iT) = integrand_sigma_yy_IVS(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_xy_IVS(:,iEF,iT) = integrand_sigma_xy_IVS(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;                  
                integrand_k_e_yx_IVS(:,iEF,iT) = integrand_sigma_yx_IVS(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        end
    end
    

    sigma_xx_IVS=squeeze(-q0*trapz(E_array,integrand_sigma_xx_IVS,1));
    sigma_yy_IVS=squeeze(-q0*trapz(E_array,integrand_sigma_yy_IVS,1));
    sigma_xy_IVS=squeeze(-q0*trapz(E_array,integrand_sigma_xy_IVS,1));
    sigma_yx_IVS=squeeze(-q0*trapz(E_array,integrand_sigma_yx_IVS,1));


    mu_xx_IVS=sigma_xx_IVS./n_carrier_ph/q0;
    mu_yy_IVS=sigma_yy_IVS./n_carrier_ph/q0;
    mu_xy_IVS=sigma_xy_IVS./n_carrier_ph/q0;       
    mu_yx_IVS=sigma_yx_IVS./n_carrier_ph/q0;

    S_xx_IVS = carrier_sign .* kB./sigma_xx_IVS.* squeeze(trapz(E_array,integrand_S_xx_IVS,1));
    S_yy_IVS = carrier_sign .* kB./sigma_yy_IVS.* squeeze(trapz(E_array,integrand_S_yy_IVS,1));
    S_xy_IVS = carrier_sign .* kB./sigma_xy_IVS.* squeeze(trapz(E_array,integrand_S_xy_IVS,1));    
    S_yx_IVS = carrier_sign .* kB./sigma_yx_IVS.* squeeze(trapz(E_array,integrand_S_yx_IVS,1));

    PF_xx_IVS = sigma_xx_IVS .* S_xx_IVS.^2;
    PF_yy_IVS = sigma_yy_IVS .* S_yy_IVS.^2;
    PF_xy_IVS = sigma_xy_IVS .* S_xy_IVS.^2;    
    PF_yx_IVS = sigma_yx_IVS .* S_yx_IVS.^2;
    
    k_e_xx_IVS = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx_IVS,1)) - sigma_xx_IVS .* S_xx_IVS.^2 .* T_array ;
    k_e_yy_IVS = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy_IVS,1)) - sigma_yy_IVS .* S_yy_IVS.^2 .* T_array ;
    k_e_xy_IVS = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy_IVS,1)) - sigma_xy_IVS .* S_xy_IVS.^2 .* T_array ;
    k_e_yx_IVS = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx_IVS,1)) - sigma_yx_IVS .* S_yx_IVS.^2 .* T_array ;    
    
    
    % saving into structures
    sigma_sep.IVS.xx = sigma_xx_IVS; sigma_sep.IVS.xy = sigma_xy_IVS; 
    sigma_sep.IVS.yx = sigma_yx_IVS; sigma_sep.IVS.yy = sigma_yy_IVS; 

    mu_sep.IVS.xx = mu_xx_IVS; mu_sep.IVS.xy = mu_xy_IVS; 
    mu_sep.IVS.yx = mu_yx_IVS; mu_sep.IVS.yy = mu_yy_IVS; 

    S_sep.IVS.xx = S_xx_IVS; S_sep.IVS.xy = S_xy_IVS; 
    S_sep.IVS.yx = S_yx_IVS; S_sep.IVS.yy = S_yy_IVS; 

    PF_sep.IVS.xx = PF_xx_IVS; PF_sep.IVS.xy = PF_xy_IVS; 
    PF_sep.IVS.yx = PF_yx_IVS; PF_sep.IVS.yy = PF_yy_IVS; 

    ke_sep.IVS.xx = k_e_xx_IVS; ke_sep.IVS.xy = k_e_xy_IVS; 
    ke_sep.IVS.yx = k_e_yx_IVS; ke_sep.IVS.yy = k_e_yy_IVS;     

end
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------



% ---------  POP only -----------------------------------------------------
if strcmp(POP,'yes')
    
    TDF_xx_POP = TDF_sep.POP.xx; TDF_yy_POP = TDF_sep.POP.yy; 
    TDF_xy_POP = TDF_sep.POP.xy; TDF_yx_POP = TDF_sep.POP.yx; 

    if strcmp(screening_POP,'no')    
        
        integrand_sigma_xx_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yy_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
        integrand_sigma_xy_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yx_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

        integrand_S_xx_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yy_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
        integrand_S_xy_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yx_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

        integrand_k_e_xx_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yy_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
        integrand_k_e_xy_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yx_POP=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

        for iEF = size(EF_matrix_ph,1):-1:1
            for iT = size(T_array,2) : -1 : 1

                    integrand_sigma_xx_POP(:,iEF,iT)=TDF_xx_POP(:,iT).*(dfdE_ph(:,iEF,iT));
                    integrand_sigma_yy_POP(:,iEF,iT)=TDF_yy_POP(:,iT).*(dfdE_ph(:,iEF,iT));
                    integrand_sigma_xy_POP(:,iEF,iT)=TDF_xy_POP(:,iT).*(dfdE_ph(:,iEF,iT));
                    integrand_sigma_yx_POP(:,iEF,iT)=TDF_yx_POP(:,iT).*(dfdE_ph(:,iEF,iT));

                    integrand_S_xx_POP(:,iEF,iT) = integrand_sigma_xx_POP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                    integrand_S_yy_POP(:,iEF,iT) = integrand_sigma_yy_POP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                    integrand_S_xy_POP(:,iEF,iT) = integrand_sigma_xy_POP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));               
                    integrand_S_yx_POP(:,iEF,iT) = integrand_sigma_yx_POP(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));

                    integrand_k_e_xx_POP(:,iEF,iT) = integrand_sigma_xx_POP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                    integrand_k_e_yy_POP(:,iEF,iT) = integrand_sigma_yy_POP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                    integrand_k_e_xy_POP(:,iEF,iT) = integrand_sigma_xy_POP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;                 
                    integrand_k_e_yx_POP(:,iEF,iT) = integrand_sigma_yx_POP(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
            end
        end
        
        
    elseif strcmp(screening_POP,'yes')
        
        integrand_sigma_xx_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_sigma_yy_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
        integrand_sigma_xy_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_sigma_yx_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); 

        integrand_S_xx_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_S_yy_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
        integrand_S_xy_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_S_yx_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));

        integrand_k_e_xx_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_k_e_yy_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
        integrand_k_e_xy_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_k_e_yx_POP=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
                
    for iEF = size(EF_matrix,1):-1:1
        for iT = size(T_array,2) : -1 : 1
        
                integrand_sigma_xx_POP(:,iEF,iT)=TDF_xx_POP(:,iEF,iT).*(dfdE(:,iEF,iT));
                integrand_sigma_yy_POP(:,iEF,iT)=TDF_yy_POP(:,iEF,iT).*(dfdE(:,iEF,iT));
                integrand_sigma_xy_POP(:,iEF,iT)=TDF_xy_POP(:,iEF,iT).*(dfdE(:,iEF,iT));
                integrand_sigma_yx_POP(:,iEF,iT)=TDF_yx_POP(:,iEF,iT).*(dfdE(:,iEF,iT));

                integrand_S_xx_POP(:,iEF,iT) = integrand_sigma_xx_POP(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_yy_POP(:,iEF,iT) = integrand_sigma_yy_POP(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_xy_POP(:,iEF,iT) = integrand_sigma_xy_POP(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));               
                integrand_S_yx_POP(:,iEF,iT) = integrand_sigma_yx_POP(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));
                
                integrand_k_e_xx_POP(:,iEF,iT) = integrand_sigma_xx_POP(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;
                integrand_k_e_yy_POP(:,iEF,iT) = integrand_sigma_yy_POP(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;
                integrand_k_e_xy_POP(:,iEF,iT) = integrand_sigma_xy_POP(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;                   
                integrand_k_e_yx_POP(:,iEF,iT) = integrand_sigma_yx_POP(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;
        end
    end
        
    end

    sigma_xx_POP=squeeze(-q0*trapz(E_array,integrand_sigma_xx_POP,1));
    sigma_yy_POP=squeeze(-q0*trapz(E_array,integrand_sigma_yy_POP,1));
    sigma_xy_POP=squeeze(-q0*trapz(E_array,integrand_sigma_xy_POP,1));
    sigma_yx_POP=squeeze(-q0*trapz(E_array,integrand_sigma_yx_POP,1));
    
   
    if strcmp(screening_POP,'no')
        n_carrier_temp = n_carrier_ph;
    elseif strcmp(screening_POP,'yes')
        n_carrier_temp = n_carrier;
    end
    mu_xx_POP=sigma_xx_POP./n_carrier_temp/q0;
    mu_yy_POP=sigma_yy_POP./n_carrier_temp/q0;
    mu_xy_POP=sigma_xy_POP./n_carrier_temp/q0;
    mu_yx_POP=sigma_yx_POP./n_carrier_temp/q0;

    S_xx_POP = carrier_sign .* kB./sigma_xx_POP.* squeeze(trapz(E_array,integrand_S_xx_POP,1));
    S_yy_POP = carrier_sign .* kB./sigma_yy_POP.* squeeze(trapz(E_array,integrand_S_yy_POP,1));
    S_xy_POP = carrier_sign .* kB./sigma_xy_POP.* squeeze(trapz(E_array,integrand_S_xy_POP,1));
    S_yx_POP = carrier_sign .* kB./sigma_yx_POP.* squeeze(trapz(E_array,integrand_S_yx_POP,1));

    PF_xx_POP = sigma_xx_POP .* S_xx_POP.^2;
    PF_yy_POP = sigma_yy_POP .* S_yy_POP.^2;
    PF_xy_POP = sigma_xy_POP .* S_xy_POP.^2;
    PF_yx_POP = sigma_yx_POP .* S_yx_POP.^2;
    
    k_e_xx_POP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx_POP,1)) - sigma_xx_POP .* S_xx_POP.^2 .* T_array ;
    k_e_yy_POP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy_POP,1)) - sigma_yy_POP .* S_yy_POP.^2 .* T_array ;
    k_e_xy_POP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy_POP,1)) - sigma_xy_POP .* S_xy_POP.^2 .* T_array ;
    k_e_yx_POP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx_POP,1)) - sigma_yx_POP .* S_yx_POP.^2 .* T_array ;
    
    
    % saving into structures
    sigma_sep.POP.xx = sigma_xx_POP; sigma_sep.POP.xy = sigma_xy_POP;
    sigma_sep.POP.yx = sigma_yx_POP; sigma_sep.POP.yy = sigma_yy_POP;

    mu_sep.POP.xx = mu_xx_POP; mu_sep.POP.xy = mu_xy_POP;
    mu_sep.POP.yx = mu_yx_POP; mu_sep.POP.yy = mu_yy_POP;

    S_sep.POP.xx = S_xx_POP; S_sep.POP.xy = S_xy_POP;
    S_sep.POP.yx = S_yx_POP; S_sep.POP.yy = S_yy_POP;

    PF_sep.POP.xx = PF_xx_POP; PF_sep.POP.xy = PF_xy_POP;
    PF_sep.POP.yx = PF_yx_POP; PF_sep.POP.yy = PF_yy_POP;

    ke_sep.POP.xx = k_e_xx_POP; ke_sep.POP.xy = k_e_xy_POP; 
    ke_sep.POP.yx = k_e_yx_POP; ke_sep.POP.yy = k_e_yy_POP;

end

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------



% ---------  Alloy only ---------------------------------------------------
if strcmp(Alloy,'yes')
       
    TDF_xx_Alloy = TDF_sep.Alloy.xx; TDF_yy_Alloy = TDF_sep.Alloy.yy;
    TDF_xy_Alloy = TDF_sep.Alloy.xy; TDF_yx_Alloy = TDF_sep.Alloy.yx;
    
    
    
    integrand_sigma_xx_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yy_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_sigma_xy_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yx_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

    integrand_S_xx_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yy_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_S_xy_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yx_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

    integrand_k_e_xx_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yy_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
    integrand_k_e_xy_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yx_Alloy=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 
    
    
    for iEF = size(EF_matrix_ph,1):-1:1
        for iT = size(T_array,2) : -1 : 1
                integrand_sigma_xx_Alloy(:,iEF,iT)=TDF_xx_Alloy(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_yy_Alloy(:,iEF,iT)=TDF_yy_Alloy(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_xy_Alloy(:,iEF,iT)=TDF_xy_Alloy(:,iT).*(dfdE_ph(:,iEF,iT));
                integrand_sigma_yx_Alloy(:,iEF,iT)=TDF_yx_Alloy(:,iT).*(dfdE_ph(:,iEF,iT));

                integrand_S_xx_Alloy(:,iEF,iT) = integrand_sigma_xx_Alloy(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_yy_Alloy(:,iEF,iT) = integrand_sigma_yy_Alloy(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_xy_Alloy(:,iEF,iT) = integrand_sigma_xy_Alloy(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                integrand_S_yx_Alloy(:,iEF,iT) = integrand_sigma_yx_Alloy(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                
                integrand_k_e_xx_Alloy(:,iEF,iT) = integrand_sigma_xx_Alloy(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_yy_Alloy(:,iEF,iT) = integrand_sigma_yy_Alloy(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_xy_Alloy(:,iEF,iT) = integrand_sigma_xy_Alloy(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                integrand_k_e_yx_Alloy(:,iEF,iT) = integrand_sigma_yx_Alloy(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
        end
    end
    

    sigma_xx_Alloy=squeeze(-q0*trapz(E_array,integrand_sigma_xx_Alloy,1));
    sigma_yy_Alloy=squeeze(-q0*trapz(E_array,integrand_sigma_yy_Alloy,1));
    sigma_xy_Alloy=squeeze(-q0*trapz(E_array,integrand_sigma_xy_Alloy,1));
    sigma_yx_Alloy=squeeze(-q0*trapz(E_array,integrand_sigma_yx_Alloy,1));

    mu_xx_Alloy=sigma_xx_Alloy./n_carrier_ph/q0;
    mu_yy_Alloy=sigma_yy_Alloy./n_carrier_ph/q0;
    mu_xy_Alloy=sigma_xy_Alloy./n_carrier_ph/q0;
    mu_yx_Alloy=sigma_yx_Alloy./n_carrier_ph/q0;

    S_xx_Alloy = carrier_sign .* kB./sigma_xx_Alloy.* squeeze(trapz(E_array,integrand_S_xx_Alloy,1));
    S_yy_Alloy = carrier_sign .* kB./sigma_yy_Alloy.* squeeze(trapz(E_array,integrand_S_yy_Alloy,1));
    S_xy_Alloy = carrier_sign .* kB./sigma_xy_Alloy.* squeeze(trapz(E_array,integrand_S_xy_Alloy,1));
    S_yx_Alloy = carrier_sign .* kB./sigma_yx_Alloy.* squeeze(trapz(E_array,integrand_S_yx_Alloy,1));

    PF_xx_Alloy = sigma_xx_Alloy .* S_xx_Alloy.^2;
    PF_yy_Alloy = sigma_yy_Alloy .* S_yy_Alloy.^2;
    PF_xy_Alloy = sigma_xy_Alloy .* S_xy_Alloy.^2;
    PF_yx_Alloy = sigma_yx_Alloy .* S_yx_Alloy.^2;
    
    k_e_xx_Alloy = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx_Alloy,1)) - sigma_xx_Alloy .* S_xx_Alloy.^2 .* T_array ;
    k_e_yy_Alloy = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy_Alloy,1)) - sigma_yy_Alloy .* S_yy_Alloy.^2 .* T_array ;
    k_e_xy_Alloy = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy_Alloy,1)) - sigma_xy_Alloy .* S_xy_Alloy.^2 .* T_array ;
    k_e_yx_Alloy = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx_Alloy,1)) - sigma_yx_Alloy .* S_yx_Alloy.^2 .* T_array ;
    
    
    % saving into structures
    sigma_sep.Alloy.xx = sigma_xx_Alloy; sigma_sep.Alloy.xy = sigma_xy_Alloy;
    sigma_sep.Alloy.yx = sigma_yx_Alloy; sigma_sep.Alloy.yy = sigma_yy_Alloy;

    mu_sep.Alloy.xx = mu_xx_Alloy; mu_sep.Alloy.xy = mu_xy_Alloy;
    mu_sep.Alloy.yx = mu_yx_Alloy; mu_sep.Alloy.yy = mu_yy_Alloy;

    S_sep.Alloy.xx = S_xx_Alloy; S_sep.Alloy.xy = S_xy_Alloy;
    S_sep.Alloy.yx = S_yx_Alloy; S_sep.Alloy.yy = S_yy_Alloy;

    PF_sep.Alloy.xx = PF_xx_Alloy; PF_sep.Alloy.xy = PF_xy_Alloy;
    PF_sep.Alloy.yx = PF_yx_Alloy; PF_sep.Alloy.yy = PF_yy_Alloy;

    ke_sep.Alloy.xx = k_e_xx_Alloy; ke_sep.Alloy.xy = k_e_xy_Alloy;
    ke_sep.Alloy.yx = k_e_yx_Alloy; ke_sep.Alloy.yy = k_e_yy_Alloy;

end
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------



% ---------  phonons (all) only @ all T------------------------------------
   
    TDF_xx_ph = TDF_ph.xx; TDF_yy_ph = TDF_ph.yy; 
    TDF_xy_ph = TDF_ph.xy; TDF_yx_ph = TDF_ph.yx;
    
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        

        integrand_sigma_xx_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_sigma_yy_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
        integrand_sigma_xy_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_sigma_yx_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));

        integrand_S_xx_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_S_yy_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
        integrand_S_xy_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_S_yx_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));

        integrand_k_e_xx_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_k_e_yy_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
        integrand_k_e_xy_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2)); integrand_k_e_yx_ph=zeros(size(E_array,2),size(EF_matrix,1),size(T_array,2));
    
        for iEF=size(EF_matrix,1):-1:1
            for iT=1:size(T_array,2)

                            integrand_sigma_xx_ph(:,iEF,iT)=TDF_xx_ph(:,iEF,iT).*(dfdE(:,iEF,iT));
                            integrand_sigma_yy_ph(:,iEF,iT)=TDF_yy_ph(:,iEF,iT).*(dfdE(:,iEF,iT));
                            integrand_sigma_xy_ph(:,iEF,iT)=TDF_xy_ph(:,iEF,iT).*(dfdE(:,iEF,iT));
                            integrand_sigma_yx_ph(:,iEF,iT)=TDF_yx_ph(:,iEF,iT).*(dfdE(:,iEF,iT));
                            
                            % integral argument for Seebeck coeff.
                            integrand_S_xx_ph(:,iEF,iT) = integrand_sigma_xx_ph(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));
                            integrand_S_yy_ph(:,iEF,iT) = integrand_sigma_yy_ph(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));
                            integrand_S_xy_ph(:,iEF,iT) = integrand_sigma_xy_ph(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));
                            integrand_S_yx_ph(:,iEF,iT) = integrand_sigma_yx_ph(:,iEF,iT).*(E_array'-EF_matrix(iEF,iT))*q0/(kB*T_array(iT));


                            % integral argument for k_e
                            integrand_k_e_xx_ph(:,iEF,iT) = integrand_sigma_xx_ph(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;
                            integrand_k_e_yy_ph(:,iEF,iT) = integrand_sigma_yy_ph(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;
                            integrand_k_e_xy_ph(:,iEF,iT) = integrand_sigma_xy_ph(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;
                            integrand_k_e_yx_ph(:,iEF,iT) = integrand_sigma_yx_ph(:,iEF,iT) .* ((E_array'-EF_matrix(iEF,iT))*q0).^2;

            end
        end
        
        
        
    else % POP not screened
        
        integrand_sigma_xx_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yy_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
        integrand_sigma_xy_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_sigma_yx_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

        integrand_S_xx_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yy_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
        integrand_S_xy_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_S_yx_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));

        integrand_k_e_xx_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yy_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2));
        integrand_k_e_xy_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); integrand_k_e_yx_ph=zeros(size(E_array,2),size(EF_matrix_ph,1),size(T_array,2)); 

        for iEF=size(EF_matrix_ph,1):-1:1
            for iT=1:size(T_array,2)

                            integrand_sigma_xx_ph(:,iEF,iT)=TDF_xx_ph(:,iT).*(dfdE_ph(:,iEF,iT));
                            integrand_sigma_yy_ph(:,iEF,iT)=TDF_yy_ph(:,iT).*(dfdE_ph(:,iEF,iT));
                            integrand_sigma_xy_ph(:,iEF,iT)=TDF_xy_ph(:,iT).*(dfdE_ph(:,iEF,iT));
                            integrand_sigma_yx_ph(:,iEF,iT)=TDF_yx_ph(:,iT).*(dfdE_ph(:,iEF,iT));
                            
                            % integral argument for Seebeck coeff.
                            integrand_S_xx_ph(:,iEF,iT) = integrand_sigma_xx_ph(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                            integrand_S_yy_ph(:,iEF,iT) = integrand_sigma_yy_ph(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                            integrand_S_xy_ph(:,iEF,iT) = integrand_sigma_xy_ph(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));
                            integrand_S_yx_ph(:,iEF,iT) = integrand_sigma_yx_ph(:,iEF,iT).*(E_array'-EF_matrix_ph(iEF,iT))*q0/(kB*T_array(iT));


                            % integral argument for k_e
                            integrand_k_e_xx_ph(:,iEF,iT) = integrand_sigma_xx_ph(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                            integrand_k_e_yy_ph(:,iEF,iT) = integrand_sigma_yy_ph(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                            integrand_k_e_xy_ph(:,iEF,iT) = integrand_sigma_xy_ph(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;
                            integrand_k_e_yx_ph(:,iEF,iT) = integrand_sigma_yx_ph(:,iEF,iT) .* ((E_array'-EF_matrix_ph(iEF,iT))*q0).^2;

            end
        end
    end

    sigma_xx_ph=squeeze(-q0*trapz(E_array,integrand_sigma_xx_ph,1));
    sigma_yy_ph=squeeze(-q0*trapz(E_array,integrand_sigma_yy_ph,1));
    sigma_xy_ph=squeeze(-q0*trapz(E_array,integrand_sigma_xy_ph,1));
    sigma_yx_ph=squeeze(-q0*trapz(E_array,integrand_sigma_yx_ph,1));
    
    sigma_average_ph = (sigma_xx_ph+sigma_yy_ph )/2;
    
    if strcmp(screening_POP,'no')
        n_carrier_temp = n_carrier_ph;
    elseif strcmp(screening_POP,'yes')
        n_carrier_temp = n_carrier;
    end
    mu_xx_ph=sigma_xx_ph./n_carrier_temp/q0;
    mu_yy_ph=sigma_yy_ph./n_carrier_temp/q0;
    mu_xy_ph=sigma_xy_ph./n_carrier_temp/q0;
    mu_yx_ph=sigma_yx_ph./n_carrier_temp/q0;
    
    mu_average_ph=(mu_xx_ph+mu_yy_ph )/2;

    S_xx_ph = carrier_sign .* kB./sigma_xx_ph.* squeeze(trapz(E_array,integrand_S_xx_ph,1));
    S_yy_ph = carrier_sign .* kB./sigma_yy_ph.* squeeze(trapz(E_array,integrand_S_yy_ph,1));
    S_xy_ph = carrier_sign .* kB./sigma_xy_ph.* squeeze(trapz(E_array,integrand_S_xy_ph,1));
    S_yx_ph = carrier_sign .* kB./sigma_yx_ph.* squeeze(trapz(E_array,integrand_S_yx_ph,1));
    
    S_average_ph=(S_xx_ph+S_yy_ph )/2;

    PF_xx_ph = sigma_xx_ph .* S_xx_ph.^2;
    PF_yy_ph = sigma_yy_ph .* S_yy_ph.^2;
    PF_xy_ph = sigma_xx_ph .* S_xy_ph.^2;
    PF_yx_ph = sigma_xx_ph .* S_yx_ph.^2;
    
    PF_average_ph=(PF_xx_ph+PF_yy_ph )/2;
    
    % electron thermal conductivity
    k_e_xx_ph = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx_ph,1)) - sigma_xx_ph .* S_xx_ph.^2 .* T_array ;
    k_e_yy_ph = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy_ph,1)) - sigma_yy_ph .* S_yy_ph.^2 .* T_array ;
    k_e_xy_ph = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xy_ph,1)) - sigma_xy_ph .* S_xy_ph.^2 .* T_array ;
    k_e_yx_ph = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yx_ph,1)) - sigma_yx_ph .* S_yx_ph.^2 .* T_array ;

    k_e_average_ph = (k_e_xx_ph + k_e_yy_ph  ) / 2;
    
    
    
    % save into structures
    sigma_ph.xx = sigma_xx_ph; sigma_ph.xy = sigma_xy_ph;
    sigma_ph.yx = sigma_yx_ph; sigma_ph.yy = sigma_yy_ph;
    sigma_ph.average = sigma_average_ph;

    mu_ph.xx = mu_xx_ph; mu_ph.xy = mu_xy_ph;
    mu_ph.yx = mu_yx_ph; mu_ph.yy = mu_yy_ph; 
    mu_ph.average = mu_average_ph;

    S_ph.xx = S_xx_ph; S_ph.xy = S_xy_ph;
    S_ph.yx = S_yx_ph; S_ph.yy = S_yy_ph; 
    S_ph.average = S_average_ph;

    PF_ph.xx = PF_xx_ph; PF_ph.xy = PF_xy_ph;
    PF_ph.yx = PF_yx_ph; PF_ph.yy = PF_yy_ph;
    PF_ph.average = PF_average_ph;

    ke_ph.xx = k_e_xx_ph; ke_ph.xy = k_e_xy_ph;
    ke_ph.yx = k_e_yx_ph; ke_ph.yy = k_e_yy_ph; 
    ke_ph.average = k_e_average_ph;

% ------------------------------------------------------------------------


% end % end of the dimensionality check

end