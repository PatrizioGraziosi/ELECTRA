
% The scattering parameters for GaAs - Lundstrom and Nag mostly...

% RELEVANT SCATTERING for GaAs conduction band
% ADP (intravalley) POP (Gamma intravalley) and IVS and ODP (L valleys)


% The first is the Gamma valley, the other eights are the L valleys
% physically, they belong to the same band but have different scattering
% parameters
valley_type = ['A','B','B','B','B','B','B','B','B'];
degen_valley = [1,8];
%----------- PHONONS ---------
rho_mass_density=5.36*1e-3/(1e-2)^3; % kg/m^3
% 
% sl = 5.24e3;  % m/s , elasticity theory
% st = 3e3;               % m/s , elasticity theory
% us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975
us_sound_vel=5.24*1e3;               % m/s

%------- for electrons ---------------
% from table 2.1 Lundstrom's book

% ELASTIC, INTRAVALLEY - ADP
AA_D_adp = 7.0; % eV
BB_D_adp = 9.2;

D_adp_e = 7.0; % temp

% INELASTIC - INTRAVALLEY - ODP
% ODP active only for L-valleys
BB_D_odp_e = 3.0*1e10; % eV/m
BB_hbar_w_odp_e = 0.0343; % eV
BB_Zf_odp_e = 1;

% INELASTIC - INTERVALLY - IVS
% array of processes data
AB_D_ivs_e=10e10;  % in eV/m
BB_D_ivs_e=10e10;

AB_hbar_w_ivs_e=0.0278; % in eV
BB_hbar_w_ivs_e=0.029;

AB_Zf_ivs_e=1;
BB_Zf_ivs_e=1;

BA_D_ivs_e=AB_D_ivs_e; BA_hbar_w_ivs_e=AB_hbar_w_ivs_e; BA_Zf_ivs_E=AB_Zf_ivs_e;

% POLAR OPTICAL PHONONS
% INELASTIC - INTRAVALLEY - POP
hbar_w_pop=0.03536; % eV
AA_hbar_w_pop=0.03536;


%--------------------------------------------------------




% for Coulomb scattering - screened
k_s=12.9;
k_inf=10.92;
%LD=sqrt(eps_0*(eps_wire/eps_0)*kB*T/q0^2); % still need to divide by n0 in the sqrt



