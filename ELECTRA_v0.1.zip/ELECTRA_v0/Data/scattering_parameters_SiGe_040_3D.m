fraction = 0.40;
x = fraction;
Delta_gap = 1.13-0.661; % eV
% Vcell = ( (47.8 - 40.9) * x + 40.9 ) * 1e-30; % in m^3 
Vcell = ( (47.8^(1/3) - 40.9^(1/3)) * x + 40.9^(1/3) ).^3 * 1e-30; % in m^3
atoms_cell = 2;

% The scattering parameters for Ge and Si

%----------- PHONONS ---------
rho_mass_density_Ge=5.32*1e-3/(1e-2)^3; % kg/m^3
% 
sl_Ge = 5.4e3;  % m/s , elasticity theory
st_Ge = 3.2e3;               % m/s , elasticity theory
%
rho_mass_density_Si=2.329*1e-3/(1e-2)^3; % kg/m^3
%
sl_Si=9.041e3;                % m/s
st_Si=5.34*1e3;               % m/s


rho_mass_density = ( rho_mass_density_Ge - rho_mass_density_Si ) * x + rho_mass_density_Si;
%
sl = ( sl_Ge - sl_Si ) * x + sl_Si;
st = ( st_Ge - st_Si ) * x + st_Si;
us_sound_vel = 1/3*sl+2/3*st;               % m/s   Ottaviani 1975


%------------ C.B. labels ----------
% They are labelled according to thier position for my clarity, L for L, G
% for Gamma, X for the Delta point close to X
valley_type = ['L','L','L','L','G','X','X','X','X','X','X'];
% ----------------------------------


% ELASTIC, INTRAVALLEY - ADP

% --------- electrons--------------
LL_D_adp_e = 11;  % 11 or 12
GG_D_adp_e = 5;
XX_D_adp_e = 9; % Jacoboni Reggiani 1979 say 9 eV, Fawcett Paige 1971 say 5.99


% INELASTIC - INTRAVALLEY - ODP 
% for Si the value are taken from Lundstrom's book even if it is not clear
% what processes are what

% -------- electrons --------------
LL_D_odp_e = ( 5.5e10 - 2e10 ) * x + 2e10 ;
LL_hbar_w_odp_e = ( 0.0369 - 0.050 ) * x + 0.050 ;
LL_Z_f_odp_e = 1;


% INELASTIC - INTERVALLY - IVS
% array of processes data
LL_D_ivs_e = ( 1.6e10 + 2e10 ) * x + 2e10 ; 
LL_hbar_w_ivs_e = ( 0.0275 + 0.050 ) * x + 0.050 ;
LL_Z_f_ivs_e = 1;

LG_D_ivs_e = 2e10;
LG_hbar_w_ivs_e = 0.0275;
LG_Z_f_ivs_e = 1;
GL_D_ivs_e = LG_D_ivs_e; GL_hbar_w_ivs_e = LG_hbar_w_ivs_e; GL_Z_f_ivs_e = LG_Z_f_ivs_e;

LX_D_ivs_e = 5.5e10; % 5.5 or 4.0
LX_hbar_w_ivs_e = 0.0275;
LX_Z_f_ivs_e = 1;
XL_D_ivs_e = LX_D_ivs_e; XL_hbar_w_ivs_e = LX_hbar_w_ivs_e; XL_Z_f_ivs_e = LX_Z_f_ivs_e;

GX_D_ivs_e = 10e10;
GX_hbar_w_ivs_e = 0.0275;
GX_Z_f_ivs_e = 1;
XG_D_ivs_e = GX_D_ivs_e; XG_hbar_w_ivs_e = GX_hbar_w_ivs_e; XG_Z_f_ivs_e = GX_Z_f_ivs_e;

XX_D_ivs_e = ( [0.78e10, 9.4e10] - [0.8e10, 3.5e10] ) .* x + [0.5e10, 3.5e10];  % in eV/m
XX_hbar_w_ivs_e = ( [0.0086, 0.0369] - [0.018, 0.044] ) .* x + [0.018, 0.044];
XX_Z_f_ivs = [1,1];

%--------------------------------------------------------

% for Coulomb scattering - screened
k_s=16;
k_inf = 16;



