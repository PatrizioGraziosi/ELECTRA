% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@gmail.com, during the              %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source and the author when publishing results      %
% obtained  using the present  code                                       %
%                                                                         %
% ----------------------------------------------------------------------- %

% this is the default function that runs on parallel in the workers
% it runs for each iE,in couple
% part about overlap_integrals_analytical added on 4Dec.2019

% ADP at line  187, subfunction at line 2177
% ADP_IVS at line 261, subfunction at line 2202
% ODP at line 361, subfunction at line 2221
% POP at line 456, subfunction at line 2243
% IVS at line 537, subfunction at line 2221
% IIS at line 633 abd 664, subfunction at line 2361
% screened POP at line 719, subfunction at line 2444
% Alloy at line 882, subfunction at line 2301
% Matthiessen's rule applied at line 928
% TDF part at line 1025

% For the general case with NON-labelled valleys/bands
function [ TDF_n, TDF_ph_n, TDF_sep_n, MFP_n, MFP_ph_n, MFP_sep_n, tauE_n, tauE_ph_n, tauE_sep_n, tauE_IIS_n] = TDF_calc_ELECTRA_v1(iE, in, WorkSpace4 ) %#codegen


% ----------------------------------------
% Section 1, calc. of the relaxation times, section 2 start at line 1015
% ----------------------------------------


state_ID = WorkSpace4.state_ID ;           % state ID struct and quantities
Ek = WorkSpace4.Ek ;
E_array = WorkSpace4.E_array ;
T_array = WorkSpace4.T_array ;
EF_matrix = WorkSpace4.EF_matrix ;

Estep = WorkSpace4.Estep ;
scan_type = WorkSpace4.scan_type;

n_bands_transp = WorkSpace4.n_bands_transp ;
bands_transp = WorkSpace4.bands_transp ;
sd_array = WorkSpace4.sd_array ;

ADP = WorkSpace4.ADP ;                          % scattering instructions
ADP_IVS = WorkSpace4.ADP_IVS ;
Alloy = WorkSpace4.Alloy ;
ODP = WorkSpace4.ODP ;
POP = WorkSpace4.POP ;
screening_POP = WorkSpace4.screening_POP ;
IVS = WorkSpace4.IVS ;
IIS = WorkSpace4.IIS ;
IIS_interband_flag = WorkSpace4.IIS_interband_flag ;
Z_i = WorkSpace4.Z_i;
overlap_integrals_analytical = WorkSpace4.overlap_integrals_analytical ;
k_restriction = WorkSpace4.k_restriction ;
k_restriction_cutoff = WorkSpace4.k_restriction_cutoff ;
semimetal = WorkSpace4.semimetal;
if strcmp(semimetal,'yes')
pseudovalence_bands = WorkSpace4.pseudovalence_bands ;
end

remove_matth = WorkSpace4.remove_matth ;

carriers = WorkSpace4.carriers ;
if strcmp(carriers,'electrons')
    carrier_appendix = 'e';
else
    carrier_appendix = 'h';
end
if strcmp(carriers,'electrons')
    overlap_integrals_analytical = 'no';
end
if strcmp(semimetal,'yes') && any(pseudovalence_bands(:) == bands_transp(in) ) 
    carriers = 'holes';
end

hbar=(6.6261e-34)/(2*pi); % [J-sec]                  % physical constants
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
eps_0=8.85e-12;           % [F/m]


if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes') % scattering parameters, def. pot. e scatt. rate
    tau_pos_ADP = WorkSpace4.tau_pos_ADP ;    
    us_sound_vel = WorkSpace4.us_sound_vel ;
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'D_adp_e')
         D_adp = WorkSpace4.D_adp_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'D_adp_h')
         D_adp = WorkSpace4.D_adp_h ;
    elseif isfield(WorkSpace4,'D_adp')
        D_adp = WorkSpace4.D_adp ;
    end
end
if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes') || strcmp(ODP,'yes') || strcmp(IVS,'yes')
    rho_mass_density = WorkSpace4.rho_mass_density ;
end
if strcmp(ODP,'yes')
    tau_pos_ODP = WorkSpace4.tau_pos_ODP ;
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'D_odp_e')
        D_odp = WorkSpace4.D_odp_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'D_odp_h')
        D_odp = WorkSpace4.D_odp_h ;
    elseif isfield(WorkSpace4,'D_odp')
        D_odp = WorkSpace4.D_odp ;
    end   
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'hbar_w_odp_e')
        hbar_w_odp = WorkSpace4.hbar_w_odp_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'hbar_w_odp_h')
        hbar_w_odp = WorkSpace4.hbar_w_odp_h ;
    elseif isfield(WorkSpace4,'hbar_w_odp')
        hbar_w_odp = WorkSpace4.hbar_w_odp ;
    end
end
if strcmp(IVS,'yes')
    tau_pos_IVS = WorkSpace4.tau_pos_IVS ;
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'D_ivs_e')
        D_ivs = WorkSpace4.D_ivs_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'D_ivs_h')
        D_ivs = WorkSpace4.D_ivs_h ;
    elseif isfield(WorkSpace4,'D_ivs')
        D_ivs = WorkSpace4.D_ivs ;
    end   
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'hbar_w_ivs_e')
        hbar_w_ivs = WorkSpace4.hbar_w_ivs_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'hbar_w_ivs_h')
        hbar_w_ivs = WorkSpace4.hbar_w_ivs_h ;
    elseif isfield(WorkSpace4,'hbar_w_ivs')
        hbar_w_ivs = WorkSpace4.hbar_w_ivs ;
    end
end
if strcmp(POP,'yes')
    tau_pos_POP = WorkSpace4.tau_pos_POP ;
    k_inf = WorkSpace4.k_inf ;
    k_s = WorkSpace4.k_s ;
    field_name = (['hbar_w_pop_',carrier_appendix]);                                    
    field_name2 = ('hbar_w_pop');
    if isfield(WorkSpace4,field_name)
        hbar_w_pop = WorkSpace4.(field_name) ;
    else
        hbar_w_pop = WorkSpace4.(field_name2) ;
    end
end
if strcmp(Alloy,'yes')
    tau_pos_Alloy = WorkSpace4.tau_pos_Alloy ;
    Vcell = WorkSpace4.Vcell ; 
    fraction = WorkSpace4.fraction ; 
    Delta_gap = WorkSpace4.Delta_gap ;
end
if strcmp(IIS,'yes') || strcmp(POP,'yes') || strcmp(Alloy,'yes') || strcmp(k_restriction,'yes') 
    Ga = WorkSpace4.Ga ;
    Gb = WorkSpace4.Gb ;
    Gc = WorkSpace4.Gc ;
    LD = WorkSpace4.LD ;
%     IIS_scatt_rate = WorkSpace4.IIS_scatt_rate ;

    k_s = WorkSpace4.k_s ;
    N_imp_matrix = WorkSpace4.N_imp_matrix;
end
            
WF = WorkSpace4.WF ;
I_int = sum(WF(:,in).^2); % overlap integral between the states of that band

        if not(size(state_ID(iE,in).v_x)) == 0   % the state is not empty
            
            % define an empty struct that will be eventualy filled
            taus = struct(); taus.x = []; taus.y = [] ; taus.z = [];

            
            
            for iT = 1:size(T_array,2)  % TEMPERATURE loop
                EF_array = EF_matrix(:,iT)';
                if (E_array(iE) < max(EF_array)+6*kB*T_array(iT)/q0) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*T_array(iT)/q0 ) % it takes only the value inside 6kT from the maximum EF position or all the values inbetween the band edge and 5kT if the maximum EF is in the gap
%                     for id_k = k_points_number(id_E,id_n) % in the case of reduced BZ, it runs over only the partial BZ points
%                     for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop

                          
                            if strcmp(ADP,'yes')
                                tau_pos=tau_pos_ADP;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    if strcmp(overlap_integrals_analytical,'yes')
                                        angle = acos( (state_ID(iE,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,in).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
        ( sqrt(state_ID(iE,in).kx.^2+state_ID(iE,in).ky.^2+state_ID(iE,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                        I_int_f = I_int .* G_overlap;
                                    else
                                        I_int_f=I_int;
                                    end

                                    ADP_scatt_rate = pi*(D_adp.*q0).^2*(kB*T_array(iT))/(hbar*rho_mass_density*us_sound_vel^2) * 2; % combining both ABS and EMS
                                
                                
                                    [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp  ] = ...
                                        tau_ADP_funct(ADP_scatt_rate, q0, I_int_f, state_ID(iE,in).DOS, state_ID(iE,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,in).v_z, state_ID(iE,in).v_z(id_k));

                                    if strcmp(k_restriction,'yes')
                                        delta_k_array = sqrt((state_ID(iE,in).kx-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-state_ID(iE,in).kz(id_k)).^2);
                                    delta_Matrix = [delta_k_array;
                                        sqrt((state_ID(iE,in).kx+Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2)];

    %                                     Npositive = (delta_k_array>0); % it finds everything but the initial state
    %                                     cutoff_distance = min(delta_k_array(Npositive)); % it finds the closest point to the initial state, closer points cannot exist in the used mesh

                                        q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
    %                                     Nlow = find(q_exchanged < cutoff_distance); % it finds the points where the exchanged vector is lower then the closest point, these are unphysical
    %                                     q_exchanged(Nlow) = delta_k_array(Nlow); % the exchanged vector for the points above is substituted with the initial one

                                        k_cutoff = mean([norm(Ga),norm(Gb),norm(Gc)]) * k_restriction_cutoff ;
                                        Ncutoff = find( q_exchanged < k_cutoff );
    %                                                     Ncutoff = ( q_exchanged(Ncutoff_1)>=0);

                                        taus.x(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_x_temp(Ncutoff)) )^(-1);
                                        taus.y(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_y_temp(Ncutoff)) )^(-1);
                                        taus.z(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_z_temp(Ncutoff)) )^(-1);

                                    else
                                                    
                                        taus.x(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_x_temp) )^(-1);
                                        taus.y(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_y_temp) )^(-1);
                                        taus.z(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_z_temp) )^(-1);
                                    end
                                end
                            end % end of ADP
                            

                            if strcmp(ADP_IVS,'yes')  % ADP and ADP_IVS are mutually esclusive
                                tau_pos=tau_pos_ADP;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp=zeros(1,n_bands_transp); one_over_tau_y_temp=zeros(1,n_bands_transp); one_over_tau_z_temp=zeros(1,n_bands_transp);
                                                            
                                    
                                    ADP_scatt_rate = pi*(D_adp.*q0).^2*(kB*T_array(iT))/(hbar*rho_mass_density*us_sound_vel^2) * 2; % combining both ABS and EMS
                                    
                                    for  id_n_final = 1:n_bands_transp
                                        
                                        if strcmp(overlap_integrals_analytical,'yes')
                                                    angle = acos( (state_ID(iE,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                    ( sqrt(state_ID(iE,id_n_final).kx.^2+state_ID(iE,id_n_final).ky.^2+state_ID(iE,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));
                                                    
                                                    if id_n_final == in
                                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                                    else 
                                                        G_overlap = 0.75 * sin(angle).^2;
                                                    end                                                   
                                        end
                                        
                                        if not(size(state_ID(iE,id_n_final).DOS)) == 0 
                                            if sd_array(in) == sd_array (id_n_final) 
                                                if isfield(WorkSpace4,'Z_f_adp') 
                                                     Z_f_adp = WorkSpace4.Z_f_adp ;
                                                else
                                                    Z_f_adp = ones(1,id_n_final);
                                                end 
                                                if size(Z_f_adp,2) < id_n_final
                                                    Z_f_adp = ones(1,id_n_final);
                                                end
                                                I_int_f=sum(WF(:,id_n_final).^2);
                                                if strcmp(overlap_integrals_analytical,'yes')
                                                    I_int_f = I_int_f .* G_overlap;
                                                end
                                                [ one_over_tau_x_temp_array,one_over_tau_y_temp_array,one_over_tau_z_temp_array ] = ...
                                            tau_ADP_IVS_funct(ADP_scatt_rate, q0, I_int_f, Z_f_adp(id_n_final), state_ID(iE,id_n_final).DOS, state_ID(iE,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,id_n_final).v_z, state_ID(iE,in).v_z(id_k));


                                                if strcmp(k_restriction,'yes')
                                                        delta_k_array = sqrt((state_ID(iE,id_n_final).kx-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-state_ID(iE,in).kz(id_k)).^2);
                                                    delta_Matrix = [delta_k_array;
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2)];

%                                                         Npositive = (delta_k_array>0); % it finds everything but the initial state
%                                                         cutoff_distance = min(delta_k_array(Npositive)); % it finds the closest point to the initial state, closer points cannot exist in the used mesh

                                                        q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
%                                                         Nlow = find(q_exchanged < cutoff_distance); % it finds the points where the exchanged vector is lower then the closest point, these are unphysical
%                                                         q_exchanged(Nlow) = delta_k_array(Nlow); % the exchanged vector for the points above is substituted with the initial one

                                                        k_cutoff = mean([norm(Ga),norm(Gb),norm(Gc)]) * k_restriction_cutoff ;
                                                        Ncutoff = find( q_exchanged < k_cutoff );
    %                                                     Ncutoff = ( q_exchanged(Ncutoff_1)>=0);

                                                        one_over_tau_x_temp(id_n_final) = real( 1/(2*pi)^3*sum(one_over_tau_x_temp_array(Ncutoff)) );
                                                        one_over_tau_y_temp(id_n_final) = real( 1/(2*pi)^3*sum(one_over_tau_y_temp_array(Ncutoff)) );
                                                        one_over_tau_z_temp(id_n_final) = real( 1/(2*pi)^3*sum(one_over_tau_z_temp_array(Ncutoff)) );

                                                else

                                                    one_over_tau_x_temp(id_n_final) = 1/(2*pi)^3*sum(one_over_tau_x_temp_array);
                                                    one_over_tau_y_temp(id_n_final) = 1/(2*pi)^3*sum(one_over_tau_y_temp_array);
                                                    one_over_tau_z_temp(id_n_final) = 1/(2*pi)^3*sum(one_over_tau_z_temp_array);
                                                end
                                            end
                                        end
                                    end
                                    
                                    taus.x(tau_pos,id_k,iT) = (sum(one_over_tau_x_temp)).^(-1);% tau_pos is tau_pos_ADP, defined in tau_calc at any if clause about the scattering mechanisms
                                    taus.y(tau_pos,id_k,iT) = (sum(one_over_tau_y_temp)).^(-1);
                                    taus.z(tau_pos,id_k,iT) = (sum(one_over_tau_z_temp)).^(-1);
                                end
                            end % end of ADP_IVS
                                                
                            if strcmp(ODP,'yes')
                                tau_pos=tau_pos_ODP;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp_abs=zeros(1); one_over_tau_y_temp_abs=zeros(1); one_over_tau_z_temp_abs=zeros(1);                               
                                    one_over_tau_x_temp_ems=zeros(1); one_over_tau_y_temp_ems=zeros(1); one_over_tau_z_temp_ems=zeros(1);
                                
                                              
                                    N_w=1./(exp(hbar_w_odp./(kB*T_array(iT)/q0))-1); % probability of finding phonons in a given state with a given energy hbar*w
                                    
                                    for id_process = size(hbar_w_odp,2):-1:1
                                        E_skip_points = floor(hbar_w_odp(id_process)/Estep)+1; % number of E points to be skipped, the Delta_Efi is implicit in the analysis of the DOS for the specific band
                                        
                                        for id_n_final = n_bands_transp:-1:1 % the carrier scatters everywhere (Phytos)
                                            
                                            field_name = (['Z_f_odp_',carrier_appendix]);                                    
                                            field_name2 = ('Z_f_odp');
                                            if isfield(WorkSpace4,field_name)
                                                Z_f_odp = WorkSpace4.(field_name) ;
                                            elseif isfield(WorkSpace4,field_name2)
                                                Z_f_odp = WorkSpace4.(field_name2) ;
                                            else
                                                Z_f_odp = ones(1,size(hbar_w_odp,2) ) ;
                                            end
                                                                                       
                                            % ABS, the phonon is absorbed, the energy increased
                                            if iE < (size(E_array,2)-E_skip_points) 
                                                if not(size(state_ID(iE+E_skip_points,id_n_final).DOS)) == 0 
                                                    if sd_array(in) == sd_array (id_n_final) % if the state is not empty
                                                    
                                                        I_int_f=sum(WF(:,id_n_final).^2);
                                                        if strcmp(overlap_integrals_analytical,'yes')
                                                        angle = acos( (state_ID(iE+E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                        ( sqrt(state_ID(iE+E_skip_points,id_n_final).kx.^2+state_ID(iE+E_skip_points,id_n_final).ky.^2+state_ID(iE+E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                            if id_n_final == in
                                                                G_overlap = 0.25*(1+3*cos(angle).^2);
                                                            else 
                                                                G_overlap = 0.75 * sin(angle).^2;
                                                            end
                                                            I_int_f = I_int_f .* G_overlap;
                                                        end

                                                        ODP_scatt_rate = pi * (D_odp(id_process)*q0)^2 ./...
                                                            (rho_mass_density * hbar_w_odp(id_process) * q0/hbar) * N_w(id_process);

                                                [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                            tau_ODP_funct(ODP_scatt_rate, q0, I_int_f, Z_f_odp(id_process), state_ID(iE+E_skip_points,id_n_final).DOS, state_ID(iE+E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                                        one_over_tau_x_temp_abs(id_process,id_n_final) = one_over_tau_x_temp; 
                                                        one_over_tau_y_temp_abs(id_process,id_n_final) = one_over_tau_y_temp;
                                                        one_over_tau_z_temp_abs(id_process,id_n_final) = one_over_tau_z_temp;
                                                    end
                                                end
                                            end
                                            
                                            % EMS, the phonon is emitted
                                            if iE > E_skip_points
                                                if not(size(state_ID(iE-E_skip_points,id_n_final).DOS)) == 0 
                                                    if sd_array(in) == sd_array (id_n_final) 

                                                        I_int_f=sum(WF(:,id_n_final).^2);
                                                        if strcmp(overlap_integrals_analytical,'yes')
                                                        angle = acos( (state_ID(iE-E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                        ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,id_n_final).ky.^2+state_ID(iE-E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                            if id_n_final == in
                                                                G_overlap = 0.25*(1+3*cos(angle).^2);
                                                            else 
                                                                G_overlap = 0.75 * sin(angle).^2;
                                                            end
                                                            I_int_f = I_int_f .* G_overlap;

                                                        end                                                    

                                                        ODP_scatt_rate = pi * (D_odp(id_process).*q0).^2 ./...
                                                            (rho_mass_density * hbar_w_odp(id_process) * q0/hbar) * (N_w(id_process)+1);

                                                        [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                            tau_ODP_funct(ODP_scatt_rate, q0, I_int_f, Z_f_odp(id_process), state_ID(iE-E_skip_points,id_n_final).DOS, state_ID(iE-E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                                        one_over_tau_x_temp_ems(id_process, id_n_final) = one_over_tau_x_temp; 
                                                        one_over_tau_y_temp_ems(id_process, id_n_final) = one_over_tau_y_temp;
                                                        one_over_tau_z_temp_ems(id_process, id_n_final) = one_over_tau_z_temp;
                                                    end                                                                                                       
                                                end
                                            end
                                        end % end of the final bands
                                    end % end of the processes
                                    
                                    taus.x(tau_pos,id_k,iT) = (sum(sum(one_over_tau_x_temp_abs)) + sum(sum(one_over_tau_x_temp_ems)))^(-1); % sum of 1/tau for all the processes and all the bands
                                    taus.y(tau_pos,id_k,iT) = (sum(sum(one_over_tau_y_temp_abs)) + sum(sum(one_over_tau_y_temp_ems)))^(-1);
                                    taus.z(tau_pos,id_k,iT) = (sum(sum(one_over_tau_z_temp_abs)) + sum(sum(one_over_tau_z_temp_ems)))^(-1);
                                end
                            end % end of the ODP 
                            
                            if strcmp(POP,'yes') && strcmp(screening_POP,'no')
                                    tau_pos=tau_pos_POP;
                                    for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                        one_over_tau_x_temp_abs=zeros(1); one_over_tau_y_temp_abs=zeros(1); one_over_tau_z_temp_abs=zeros(1);
                                        one_over_tau_x_temp_ems=zeros(1); one_over_tau_y_temp_ems=zeros(1); one_over_tau_z_temp_ems=zeros(1);


                                        N_w=1./(exp(hbar_w_pop./(kB*T_array(iT)/q0))-1); % probability of finding phonons in a given state with a given energy hbar*w

                                                for id_process = 1:size(hbar_w_pop,2)
                                                    E_skip_points = floor(hbar_w_pop(id_process)/Estep)+1; % number of E points to be skipped, the Delta_Efi is implicit in the analysis of the DOS for the specific band
                                                    for id_n_final = 1:n_bands_transp
%                                                         if id_n == id_n_final
                                                        if sd_array(in) == sd_array (id_n_final)  
                                                            % ABS, the phonon is absorbed, the energy increased
                                                            if iE < (size(E_array,2)-E_skip_points)
                                                                if not(size(state_ID(iE+E_skip_points,id_n_final).DOS)) == 0 % if the state is not empty  
                                                                    
                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE+E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE+E_skip_points,id_n_final).kx.^2+state_ID(iE+E_skip_points,id_n_final).ky.^2+state_ID(iE+E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));
                                                                        
                                                                        if id_n_final == in
                                                                            G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                        else 
                                                                            G_overlap = 0.75 * sin(angle).^2;
                                                                        end
                                                                        I_int_f = I_int_f .* G_overlap;
                                                                    end
                                                                    
                                                                    POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                        ./ eps_0 .* (1/k_inf-1/k_s) .* N_w(id_process);                                                                    
                                                                    
                                                                    [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                        tau_POP_funct(POP_scatt_rate, Ga, Gb, Gc, q0, I_int_f, state_ID(iE+E_skip_points,id_n_final).DOS, state_ID(iE+E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE+E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE+E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE+E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));
                                                    
                                                                    one_over_tau_x_temp_abs(id_process,id_n_final) = one_over_tau_x_temp; 
                                                                    one_over_tau_y_temp_abs(id_process,id_n_final) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_abs(id_process,id_n_final) = one_over_tau_z_temp;                                                                 
                                                                    
                                                                end
                                                            end
                                                            
                                                            % EMS, the phonon is emitted
                                                            if iE > E_skip_points
                                                                if not(size(state_ID(iE-E_skip_points,id_n_final).DOS)) == 0
                                                                    
                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE-E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,id_n_final).ky.^2+state_ID(iE-E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                        if id_n_final == in
                                                                            G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                        else 
                                                                            G_overlap = 0.75 * sin(angle).^2;
                                                                        end
                                                                        I_int_f = I_int_f .* G_overlap;
                                                                    end
                                                                    
                                                                    POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                        ./ eps_0 .* (1/k_inf-1/k_s) .* (N_w(id_process)+1);                                                                    
                                                                                                                                        
                                                                    [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                        tau_POP_funct(POP_scatt_rate, Ga, Gb, Gc, q0, I_int_f, state_ID(iE-E_skip_points,id_n_final).DOS, state_ID(iE-E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE-E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE-E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE-E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));
                                                    
                                                                    one_over_tau_x_temp_ems(id_process,id_n_final) = one_over_tau_x_temp; 
                                                                    one_over_tau_y_temp_ems(id_process,id_n_final) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_ems(id_process,id_n_final) = one_over_tau_z_temp;                                                                    
                                                                end
                                                            end
                                                        end
                                                    end % end of the final band loop
                                                end % end of the processes loop
                                                taus.x(tau_pos,id_k,iT) = (sum(sum(one_over_tau_x_temp_abs)) + sum(sum(one_over_tau_x_temp_ems)))^(-1); % sum of 1/tau for all the processes and all the bands
                                                taus.y(tau_pos,id_k,iT) = (sum(sum(one_over_tau_y_temp_abs)) + sum(sum(one_over_tau_y_temp_ems)))^(-1);
                                                taus.z(tau_pos,id_k,iT) = (sum(sum(one_over_tau_z_temp_abs)) + sum(sum(one_over_tau_z_temp_ems)))^(-1);
                                    end
                            end  % end of the POP
                            
                            if strcmp(IVS,'yes')
                                tau_pos=tau_pos_IVS;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp_abs=zeros(1); one_over_tau_y_temp_abs=zeros(1); one_over_tau_z_temp_abs=zeros(1);
                                    one_over_tau_x_temp_ems=zeros(1); one_over_tau_y_temp_ems=zeros(1); one_over_tau_z_temp_ems=zeros(1);

                                % ok for Si, Ge ... equivalent valleys, thus IVS is treated 
                                % as an intravalley scattering timed by the final number of final available valleys, as they are all equivalent
                                % TO BE AVOIDED when using also ODP in non-multivalleys as it already contains the inter-valley processes
                                                                
                                    field_name = (['Z_f_ivs_',carrier_appendix]);                                    
                                    field_name2 = ('Z_f_ivs');
                                    if isfield(WorkSpace4,field_name)
                                        Z_f_ivs = WorkSpace4.(field_name) ;
                                    elseif isfield(WorkSpace4,field_name2)
                                        Z_f_ivs = WorkSpace4.(field_name2) ;
                                    else
                                        Z_f_ivs = ones(1,size(hbar_w_ivs,2) ) ;
                                    end
                                                            
                                    N_w=1./(exp(hbar_w_ivs./(kB*T_array(iT)/q0))-1);
                                                                        
                                    for id_process = 1:size(hbar_w_ivs,2)
                                        E_skip_points = floor(hbar_w_ivs(id_process)/Estep)+1; % number of E points to be skipped
                                        
                                        % ABS, the phonon is absorbed, the energy increased
                                        if iE < (size(E_array,2)-E_skip_points)
                                            if not(size(state_ID(iE+E_skip_points,in).DOS)) == 0 % the final state isnot empty
                                                
                                                I_int_f = I_int; % equivalent valleys                                    
                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE+E_skip_points,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,in).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE+E_skip_points,in).kx.^2+state_ID(iE+E_skip_points,in).ky.^2+state_ID(iE+E_skip_points,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                G_overlap = 0.75 * sin(angle).^2;
                                                                I_int_f = I_int_f .* G_overlap;

                                                end
                                                
                                                IVS_scatt_rate = pi * (D_ivs(id_process).*q0).^2./...
                                                    (rho_mass_density*hbar_w_ivs(id_process)*q0/hbar)*N_w(id_process);
                                                                                                
                                                [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                        tau_ODP_funct(IVS_scatt_rate, q0, I_int_f, Z_f_ivs(id_process), state_ID(iE+E_skip_points,in).DOS, state_ID(iE+E_skip_points,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,in).v_z, state_ID(iE,in).v_z(id_k));
                                                    
                                                one_over_tau_x_temp_abs(id_process) = one_over_tau_x_temp; 
                                                one_over_tau_y_temp_abs(id_process) = one_over_tau_y_temp;
                                                one_over_tau_z_temp_abs(id_process) = one_over_tau_z_temp;
                                                
                                            end
                                        end
                                        
                                        % EMS, the phonon is emitted
                                        if iE > E_skip_points
                                            if not(size(state_ID(iE-E_skip_points,in).DOS)) == 0
                                                
                                                I_int_f = I_int; % equivalent valleys                                    
                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE-E_skip_points,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,in).ky.^2+state_ID(iE-E_skip_points,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                            G_overlap = 0.75 * sin(angle).^2;
                                                                        I_int_f = I_int_f .* G_overlap;
                                                end
                                                
                                                IVS_scatt_rate = pi * (D_ivs(id_process).*q0).^2./...
                                                    (rho_mass_density*hbar_w_ivs(id_process)*q0/hbar)*(N_w(id_process)+1);
                                                
                                                [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                    tau_ODP_funct(IVS_scatt_rate, q0, I_int_f, Z_f_ivs(id_process), state_ID(iE-E_skip_points,in).DOS, state_ID(iE-E_skip_points,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,in).v_z, state_ID(iE,in).v_z(id_k));

                                                one_over_tau_x_temp_ems(id_process) = one_over_tau_x_temp; 
                                                one_over_tau_y_temp_ems(id_process) = one_over_tau_y_temp;
                                                one_over_tau_z_temp_ems(id_process) = one_over_tau_z_temp;
                                            end
                                        end
                                        
                                    end % end of the foor loop on the processes
                                    
                                    taus.x(tau_pos,id_k,iT) = (sum(one_over_tau_x_temp_abs) + sum(one_over_tau_x_temp_ems))^(-1); % sum of 1/tau for all the processes 
                                    taus.y(tau_pos,id_k,iT) = (sum(one_over_tau_y_temp_abs) + sum(one_over_tau_y_temp_ems))^(-1);
                                    taus.z(tau_pos,id_k,iT) = (sum(one_over_tau_z_temp_abs) + sum(one_over_tau_z_temp_ems))^(-1);
                                end
                            end  % end of the IVS
                           
                                                       
%                         if strcmp(Piezo,'yes')                 
%                         end
%                         if strcmp(SRS,'yes')
%                         end
%                         if strcmp(ee,'yes') 
%                         end
% 
% end of the impurity independent processes


                        if strcmp(IIS,'yes') && strcmp(IIS_interband_flag,'no')
                            for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                if strcmp(overlap_integrals_analytical,'yes')
                                    angle = acos( (state_ID(iE,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,in).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
        ( sqrt(state_ID(iE,in).kx.^2+state_ID(iE,in).ky.^2+state_ID(iE,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                    G_overlap = 0.25*(1+3*cos(angle).^2);

                                    I_int_f = I_int .* G_overlap;
                                else
                                    I_int_f = I_int;
                                end


                                N_imp_array = N_imp_matrix(:,iT) ;

                                IIS_scatt_rate = 2*pi/hbar*N_imp_array*q0^4/(k_s*eps_0)^2 * Z_i^2 ;

                                [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                        tau_IIS_funct(IIS_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE,in).DOS, state_ID(iE,in).kx, state_ID(iE,in).kx(id_k), state_ID(iE,in).ky, state_ID(iE,in).ky(id_k), state_ID(iE,in).kz, state_ID(iE,in).kz(id_k), state_ID(iE,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,in).v_z, state_ID(iE,in).v_z(id_k));

                                    taus_IIS.x(:,iT,id_k)=tau_x_temp;
                                    taus_IIS.y(:,iT,id_k)=tau_y_temp;
                                    taus_IIS.z(:,iT,id_k)=tau_z_temp;
                            end
                        elseif strcmp(IIS,'no')  
                                taus_IIS.x=[];
                                taus_IIS.y=[];
                                taus_IIS.z=[]; 
                        end                               % end of the IIS
                        
                        if strcmp(IIS,'yes') && strcmp(IIS_interband_flag,'yes')
                            for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                               for  id_n_final = 1:n_bands_transp

                                    if strcmp(overlap_integrals_analytical,'yes')
                                        angle = acos( (state_ID(iE,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
            ( sqrt(state_ID(iE,id_n_final).kx.^2+state_ID(iE,id_n_final).ky.^2+state_ID(iE,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                    else
                                        G_overlap = 1;
                                    end

                                    if not(size(state_ID(iE,id_n_final).DOS)) == 0 % if the state is not empty
                                        if sd_array(in) == sd_array (id_n_final) 
                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                    if strcmp(overlap_integrals_analytical,'yes')
                                                        I_int_f = I_int_f .* G_overlap;
                                                    end


                                    N_imp_array = N_imp_matrix(:,iT) ;

                                    IIS_scatt_rate = 2*pi/hbar*N_imp_array*q0^4/(k_s*eps_0)^2 * Z_i^2;

                                    [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                            tau_IIS_funct(IIS_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE,id_n_final).DOS, state_ID(iE,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                            tau_IIS_band.x(:,id_n_final)=tau_x_temp;
                                            tau_IIS_band.y(:,id_n_final)=tau_y_temp;
                                            tau_IIS_band.z(:,id_n_final)=tau_z_temp;
                                        else
                                            tau_IIS_band.x(:,id_n_final)=Inf(size(EF_array,2),1);
                                            tau_IIS_band.y(:,id_n_final)=Inf(size(EF_array,2),1);
                                            tau_IIS_band.z(:,id_n_final)=Inf(size(EF_array,2),1);
                                        end
                                    else
                                        tau_IIS_band.x(:,id_n_final)=Inf(size(EF_array,2),1);
                                        tau_IIS_band.y(:,id_n_final)=Inf(size(EF_array,2),1);
                                        tau_IIS_band.z(:,id_n_final)=Inf(size(EF_array,2),1);
                                   end
                                end

                                taus_IIS.x(:,iT,id_k) = 1./sum(1./tau_IIS_band.x,2);
                                taus_IIS.y(:,iT,id_k) = 1./sum(1./tau_IIS_band.y,2);
                                taus_IIS.z(:,iT,id_k) = 1./sum(1./tau_IIS_band.z,2);
                            end
                                
                        elseif strcmp(IIS,'no')  
                                taus_IIS.x=[];
                                taus_IIS.y=[];
                                taus_IIS.z=[]; 
                        end                      % end of the IIS interband
                  
                        
                        if strcmp(screening_POP,'yes') && strcmp(POP,'yes')
                            for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp_abs = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_y_temp_abs = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_z_temp_abs = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_x_temp_ems = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_y_temp_ems = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_z_temp_ems = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                                                                                                                             
                                                                                                                       
                                            N_w=1./(exp(hbar_w_pop./(kB*T_array(iT)/q0))-1); % probability of finding phonons in a given state with a given energy hbar*w
                                            for id_process = 1:size(hbar_w_pop,2)
                                                E_skip_points = floor(hbar_w_pop(id_process)/Estep)+1; % number of E points to be skipped, the Delta_Efi is implicit in the analysis of the DOS for the specific band
                                                for id_n_final = 1:n_bands_transp
                                                    if sd_array(in) == sd_array (id_n_final) % the transition between the valleys is permitted
%                                                         if id_n == id_n_final

                                                        % ABS, the phonon is absorbed, the energy increased
                                                        if iE < (size(E_array,2)-E_skip_points)
                                                            if not(size(state_ID(iE+E_skip_points,id_n_final).DOS)) == 0 % if the state is not empty  

                                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                    angle = acos( (state_ID(iE+E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                ( sqrt(state_ID(iE+E_skip_points,id_n_final).kx.^2+state_ID(iE+E_skip_points,id_n_final).ky.^2+state_ID(iE+E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if id_n_final == in
                                                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                    else 
                                                                        G_overlap = 0.75 * sin(angle).^2;
                                                                    end
                                                                    I_int_f = I_int_f .* G_overlap;
                                                                end

                                                                POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                    ./ eps_0 .* (1/k_inf-1/k_s) .* N_w(id_process);
                                                                
                                                                [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp ] = ...
                                                                        tau_screenedPOP_funct(POP_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE+E_skip_points,id_n_final).DOS, state_ID(iE+E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE+E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE+E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE+E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                                                    one_over_tau_x_temp_abs(id_process,id_n_final,:) = one_over_tau_x_temp; % arrays of the size of the Fermi array
                                                                    one_over_tau_y_temp_abs(id_process,id_n_final,:) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_abs(id_process,id_n_final,:) = one_over_tau_z_temp;                                                               
                                                            end
                                                        end
                                                        % EMS, the phonon is emitted
                                                        if iE > E_skip_points
                                                            if not(size(state_ID(iE-E_skip_points,id_n_final).DOS)) == 0

                                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                    angle = acos( (state_ID(iE-E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,id_n_final).ky.^2+state_ID(iE-E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if id_n_final == in
                                                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                    else 
                                                                        G_overlap = 0.75 * sin(angle).^2;
                                                                    end
                                                                    I_int_f = I_int_f .* G_overlap;
                                                                end

                                                                POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                    ./ eps_0 .* (1/k_inf-1/k_s) .* (N_w(id_process)+1);
                                                                
                                                                [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp ] = ...
                                                                        tau_screenedPOP_funct(POP_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE-E_skip_points,id_n_final).DOS, state_ID(iE-E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE-E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE-E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE-E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));
                                                                    
                                                                    one_over_tau_x_temp_ems(id_process,id_n_final,:) = one_over_tau_x_temp; % arrays of the size of the Fermi array
                                                                    one_over_tau_y_temp_ems(id_process,id_n_final,:) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_ems(id_process,id_n_final,:) = one_over_tau_z_temp;                                                                    
                                                            end
                                                        end
                                                    end
                                                end % end of the final band loop
                                            end % end of the processes loop
                                            if n_bands_transp > 1
                                            taus_POP.x(:,iT,id_k) = sum(squeeze(sum((sum((one_over_tau_x_temp_abs + one_over_tau_x_temp_ems),1)),1))).^(-1); % sum of 1/tau for all the processes and all the final bands
                                            taus_POP.y(:,iT,id_k) = sum(squeeze(sum((sum((one_over_tau_y_temp_abs + one_over_tau_y_temp_ems),1)),1))).^(-1);
                                            taus_POP.z(:,iT,id_k) = sum(squeeze(sum((sum((one_over_tau_z_temp_abs + one_over_tau_z_temp_ems),1)),1))).^(-1);
                                            else                                               
                                            taus_POP.x(:,iT,id_k) = (squeeze(sum((sum((one_over_tau_x_temp_abs + one_over_tau_x_temp_ems),1)),1))).^(-1); % sum of 1/tau for all the processes and all the final bands
                                            taus_POP.y(:,iT,id_k) = (squeeze(sum((sum((one_over_tau_y_temp_abs + one_over_tau_y_temp_ems),1)),1))).^(-1);
                                            taus_POP.z(:,iT,id_k) = (squeeze(sum((sum((one_over_tau_z_temp_abs + one_over_tau_z_temp_ems),1)),1))).^(-1);
                                            end 
                                            
%                                             control over the taus as they are not used to compose the Matthiessen's
%                                             taus and would skip the control there
                                            NNan=isnan(taus_POP.x);
                                            taus_POP.x(NNan)=0;
                                            NNan=isnan(taus_POP.y);
                                            taus_POP.y(NNan)=0;
                                            NNan=isnan(taus_POP.z);
                                            taus_POP.z(NNan)=0;
                                            NInf=isinf(taus_POP.x);
                                            taus_POP.x(NInf)=0;
                                            NInf=isinf(taus_POP.y);
                                            taus_POP.y(NInf)=0;
                                            NInf=isinf(taus_POP.z);
                                            taus_POP.z(NInf)=0;

                            end % end of the k-points loop
                        elseif strcmp(screening_POP,'no')  
                                taus_POP.x=[];
                                taus_POP.y=[];
                                taus_POP.z=[];
                        end                      % end of the screened POP

                        
                        
%                     end % end of the for loop on the k points
                    
                    
                    % removing the noise spikes
                    if strcmp(scan_type,'DT')
                        n_c = 1;
                    else
                        n_c = 4;
                    end
                    
                    if strcmp(POP,'yes') && strcmp(screening_POP,'no')  
                        Ax = taus.x(tau_pos_POP,:,iT);
                        Ay = taus.y(tau_pos_POP,:,iT);
                        Az = taus.z(tau_pos_POP,:,iT);
                        
                        taus.x(tau_pos_POP,:,iT) = smooth(Ax,'rlowess') ;
                        taus.y(tau_pos_POP,:,iT) = smooth(Ay,'rlowess') ;
                        taus.z(tau_pos_POP,:,iT) = smooth(Az,'rlowess') ;                        
                    end
                    
                    for ii_EF = 1:size(EF_matrix,1) 
                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes') && isempty(taus_POP.x) == 0
                            Ax = squeeze(taus_POP.x(ii_EF,iT,:))' ;
                            Ay = squeeze(taus_POP.y(ii_EF,iT,:))' ;
                            Az = squeeze(taus_POP.z(ii_EF,iT,:))' ;
                            
                            threshold_level = 2 ;
                            [Ax,Ay,Az] = denoise(Ax,Ay,Az, threshold_level, n_c) ;

                            taus_POP.x(ii_EF,iT,:) = smooth(Ax,7) ; %Ax ;
                            taus_POP.y(ii_EF,iT,:) = smooth(Ay,7) ; %Ay ;
                            taus_POP.z(ii_EF,iT,:) = smooth(Az,7) ; %Az ;
                        end
                        
                        if strcmp(IIS,'yes') && isempty(taus_IIS.x) == 0
                            Ax = squeeze(taus_IIS.x(ii_EF,iT,:))' ;
                            Ay = squeeze(taus_IIS.y(ii_EF,iT,:))' ;
                            Az = squeeze(taus_IIS.z(ii_EF,iT,:))' ;
                            
                           threshold_level = 2 ;
                           [Ax,Ay,Az] = denoise(Ax,Ay,Az, threshold_level, n_c) ;

                            taus_IIS.x(ii_EF,iT,:) = smooth(Ax,7) ; % Ax ;
                            taus_IIS.y(ii_EF,iT,:) = smooth(Ay,7) ; % Ay ;
                            taus_IIS.z(ii_EF,iT,:) = smooth(Az,7) ; % Az ;
                            

                        end
                    end
                    
                end % end of the if clause on the energy extension
            end % end of the loop on the temperature
            
            
            if strcmp(Alloy,'yes')  % intra- and inter- 
                tau_pos=tau_pos_Alloy;
                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop

                    tau_x_temp_array = Inf(1,n_bands_transp);
                    tau_y_temp_array = Inf(1,n_bands_transp);
                    tau_z_temp_array = Inf(1,n_bands_transp);
                    for  id_n_final = 1:n_bands_transp
                        if sd_array(in) == sd_array (id_n_final)
                            if not(size(state_ID(iE,id_n_final).DOS)) == 0 

                            if strcmp(overlap_integrals_analytical,'yes')
                                angle = acos( (state_ID(iE,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
( sqrt(state_ID(iE,id_n_final).kx.^2+state_ID(iE,id_n_final).ky.^2+state_ID(iE,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                G_overlap = 0.25*(1+3*cos(angle).^2);
                                I_int_f = I_int .* G_overlap;
                            else
                                I_int_f=I_int;
                            end

                            alloy_scatt_rate = 2*pi/hbar * Vcell * fraction*(1-fraction) * (Delta_gap.*q0).^2 ;
                            Ra = ( 3/( 4*pi ) * Vcell )^(1/3);
                            [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                            tau_alloy_funct(alloy_scatt_rate, Ra, Ga, Gb, Gc, q0, I_int_f, state_ID(iE,id_n_final).DOS, ...
                                            state_ID(iE,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE,id_n_final).kz, state_ID(iE,in).kz(id_k), ...
                                            state_ID(iE,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                            tau_x_temp_array(id_n_final)=tau_x_temp;
                            tau_y_temp_array(id_n_final)=tau_y_temp;
                            tau_z_temp_array(id_n_final)=tau_z_temp;
                            end
                        end
                    end
                    for iT = 1:size(T_array,2)
                        EF_array = EF_matrix(:,iT)';
                        if (E_array(iE) < max(EF_array)+6*kB*T_array(iT)/q0) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*T_array(iT)/q0 ) 
                            taus.x(tau_pos,id_k,iT)=1./sum(1./tau_x_temp_array);
                            taus.y(tau_pos,id_k,iT)=1./sum(1./tau_y_temp_array);
                            taus.z(tau_pos,id_k,iT)=1./sum(1./tau_z_temp_array);
                        end
                    end
                end
            end
            
            
        % the Matthiessen rule is applied at any k point, the IIS is NOT INCLUDED
        % the taus has dimensions (tau_pos,id_k,id_T), 
        % 1st dim. is the scattering mechanism, 
        % 2nd dim. is the k point, 
        % 3rd dim. is the temperature        
            if isempty(taus.x) == 0    % taus exists
                                
                Ax = taus.x ;
                Ay = taus.y ;
                Az = taus.z ;
                NNan = isnan(Ax) ;
                Ax(NNan) = Inf ; 
                NNan = isnan(Ay) ;
                Ay(NNan) = Inf; 
                NNan = isnan(Ay) ;
                Az(NNan) = Inf;
                [r,c] = find( Ax == 0 );
                Ax(r,c) = Inf ;
                [r,c] = find (Ay == 0 ) ;
                Ay(r,c) = Inf ;
                [r,c] = find(Az == 0 ) ;
                Az(r,c) = Inf ;
                
                taus.x = Ax ;
                taus.y = Ay ;
                taus.z = Az ;

                tau_temp_x = 1./squeeze(sum(1./taus.x,1)); % sums along the different mechanisms for same k point
                tau_temp_y = 1./squeeze(sum(1./taus.y,1));
                tau_temp_z = 1./squeeze(sum(1./taus.z,1));

                if size(T_array,2) == 1

                    taus_matth.x = tau_temp_x ; % array of taus, one for each k point, sums run along the vertical direction (scatt mechanism)
                    taus_matth.y = tau_temp_y ; % array of taus, one for each k point
                    taus_matth.z = tau_temp_z ; % array of taus, one for each k point
                else
                    for iT=1:size(T_array,2) % PAY ATTENTION TO THE INDEX!!
                        if (E_array(iE) < max(EF_array)+6*kB*T_array(iT)/q0) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*T_array(iT)/q0 ) 
                            % it takes only the value inside 6kT from the maximum EF position or all the values inbetween the band edge and 5kT if the maximum EF is in the gap
                            taus_matth.x(:,iT) = tau_temp_x(:,iT) ; % array of taus, one for each k point, sums run along the vertical direction (scatt mechanism)
                            taus_matth.y(:,iT) = tau_temp_y(:,iT) ; % array of taus, one for each k point
                            taus_matth.z(:,iT) = tau_temp_z(:,iT) ; % array of taus, one for each k point
                        end
                    end
                end
                    NNan=isnan(taus_matth.x);
                    taus_matth.x(NNan)=Inf;
                    NNan=isnan(taus_matth.y);
                    taus_matth.y(NNan)=Inf;
                    NNan=isnan(taus_matth.z);
                    taus_matth.z(NNan)=Inf;                        


                                            
            else % we assign empty value at taus
                taus.x = [];
                taus.y = [];
                taus.z = [];
                taus_matth.x = [];
                taus_matth.y = [];
                taus_matth.z = [];
                taus_IIS.x = [];
                taus_IIS.y = [];
                taus_IIS.z = [];
                taus_POP.x = [];
                taus_POP.y = [];
                taus_POP.z = [];

            end
        
        else % else, if vx is empty, the state is empty
                taus.x = [];
                taus.y = [];
                taus.z = [];
                taus_matth.x = [];
                taus_matth.y = [];
                taus_matth.z = [];
                taus_IIS.x = [];
                taus_IIS.y = [];
                taus_IIS.z = [];
                taus_POP.x = [];
                taus_POP.y = [];
                taus_POP.z = [];

        end
        
        
        
        
% -----------------------------------------------------------------------
% -----------------------------------------------------------------------




% -----------------------------------------------------------------------
%  Section 2, calc. of the TDF etc. 
% -----------------------------------------------------------------------


    TDF_n=struct(); TDF_ph_n=struct(); TDF_sep_n=struct(); MFP_n=struct(); MFP_ph_n=struct(); MFP_sep_n=struct(); tauE_n=struct(); tauE_ph_n=struct(); tauE_sep_n=struct(); tauE_IIS_n=struct();
    
    % fields with the different bands
    TDF_n.xx = zeros(size(EF_array,2),size(T_array,2)); TDF_n.yy = zeros(size(EF_array,2),size(T_array,2)); TDF_n.zz = zeros(size(EF_array,2),size(T_array,2));
    TDF_n.xy = zeros(size(EF_array,2),size(T_array,2)); TDF_n.yz = zeros(size(EF_array,2),size(T_array,2)); TDF_n.xz = zeros(size(EF_array,2),size(T_array,2));
    TDF_n.yx = zeros(size(EF_array,2),size(T_array,2)); TDF_n.zy = zeros(size(EF_array,2),size(T_array,2)); TDF_n.zx = zeros(size(EF_array,2),size(T_array,2));
    MFP_n.x= zeros(size(EF_array,2),size(T_array,2)); MFP_n.y = zeros(size(EF_array,2),size(T_array,2)); MFP_n.z = zeros(size(EF_array,2),size(T_array,2));
    tauE_n.x = zeros(size(EF_array,2),size(T_array,2)); tauE_n.y = zeros(size(EF_array,2),size(T_array,2)); tauE_n.z = zeros(size(EF_array,2),size(T_array,2));
    tauE_IIS_n.x = zeros(size(EF_array,2),size(T_array,2)); tauE_IIS_n.y = zeros(size(EF_array,2),size(T_array,2)); tauE_IIS_n.z = zeros(size(EF_array,2),size(T_array,2));
    
    TDF_sep_n.ADP=struct(); TDF_sep_n.ODP=struct(); TDF_sep_n.POP=struct(); TDF_sep_n.IVS=struct(); TDF_sep_n.Alloy=struct();
    tauE_sep_n.ADP=struct(); tauE_sep_n.ODP=struct(); tauE_sep_n.POP=struct(); tauE_sep_n.IVS=struct(); tauE_sep_n.Alloy=struct();
    MFP_sep_n.ADP=struct(); MFP_sep_n.ODP=struct(); MFP_sep_n.POP=struct(); MFP_sep_n.IVS=struct(); MFP_sep_n.Alloy=struct();
    
    TDF_sep_n.ADP.xx = zeros(1,size(T_array,2)); TDF_sep_n.ADP.yy = zeros(1,size(T_array,2)); TDF_sep_n.ADP.zz = zeros(1,size(T_array,2));
    TDF_sep_n.ADP.xy = zeros(1,size(T_array,2)); TDF_sep_n.ADP.yz = zeros(1,size(T_array,2)); TDF_sep_n.ADP.xz = zeros(1,size(T_array,2));
    TDF_sep_n.ADP.yx = zeros(1,size(T_array,2)); TDF_sep_n.ADP.zy = zeros(1,size(T_array,2)); TDF_sep_n.ADP.zx = zeros(1,size(T_array,2));
    TDF_sep_n.ODP.xx = zeros(1,size(T_array,2)); TDF_sep_n.ODP.yy = zeros(1,size(T_array,2)); TDF_sep_n.ODP.zz = zeros(1,size(T_array,2));
    TDF_sep_n.ODP.xy = zeros(1,size(T_array,2)); TDF_sep_n.ODP.yz = zeros(1,size(T_array,2)); TDF_sep_n.ODP.xz = zeros(1,size(T_array,2));
    TDF_sep_n.ODP.yx = zeros(1,size(T_array,2)); TDF_sep_n.ODP.zy = zeros(1,size(T_array,2)); TDF_sep_n.ODP.zx = zeros(1,size(T_array,2));
    TDF_sep_n.IVS.xx = zeros(1,size(T_array,2)); TDF_sep_n.IVS.yy = zeros(1,size(T_array,2)); TDF_sep_n.IVS.zz = zeros(1,size(T_array,2));
    TDF_sep_n.IVS.xy = zeros(1,size(T_array,2)); TDF_sep_n.IVS.yz = zeros(1,size(T_array,2)); TDF_sep_n.IVS.xz = zeros(1,size(T_array,2));
    TDF_sep_n.IVS.yx = zeros(1,size(T_array,2)); TDF_sep_n.IVS.zy = zeros(1,size(T_array,2)); TDF_sep_n.IVS.zx = zeros(1,size(T_array,2));
    TDF_sep_n.Alloy.xx = zeros(1,size(T_array,2)); TDF_sep_n.Alloy.yy = zeros(1,size(T_array,2)); TDF_sep_n.Alloy.zz = zeros(1,size(T_array,2));
    TDF_sep_n.Alloy.xy = zeros(1,size(T_array,2)); TDF_sep_n.Alloy.yz = zeros(1,size(T_array,2)); TDF_sep_n.Alloy.xz = zeros(1,size(T_array,2));
    TDF_sep_n.Alloy.yx = zeros(1,size(T_array,2)); TDF_sep_n.Alloy.zy = zeros(1,size(T_array,2)); TDF_sep_n.Alloy.zx = zeros(1,size(T_array,2));
    
    MFP_sep_n.ADP.x = zeros(1,size(T_array,2)); MFP_sep_n.ADP.y = zeros(1,size(T_array,2)); MFP_sep_n.ADP.z = zeros(1,size(T_array,2));
    MFP_sep_n.ODP.x = zeros(1,size(T_array,2)); MFP_sep_n.ODP.y = zeros(1,size(T_array,2)); MFP_sep_n.ODP.z = zeros(1,size(T_array,2));
    MFP_sep_n.IVS.x = zeros(1,size(T_array,2)); MFP_sep_n.IVS.y = zeros(1,size(T_array,2)); MFP_sep_n.IVS.z = zeros(1,size(T_array,2));
    MFP_sep_n.Alloy.x = zeros(1,size(T_array,2)); MFP_sep_n.Alloy.y = zeros(1,size(T_array,2)); MFP_sep_n.Alloy.z = zeros(1,size(T_array,2));
    
    tauE_sep_n.ADP.x = zeros(1,size(T_array,2)); tauE_sep_n.ADP.y = zeros(1,size(T_array,2)); tauE_sep_n.ADP.z = zeros(1,size(T_array,2));
    tauE_sep_n.ODP.x = zeros(1,size(T_array,2)); tauE_sep_n.ODP.y = zeros(1,size(T_array,2)); tauE_sep_n.ODP.z = zeros(1,size(T_array,2));
    tauE_sep_n.IVS.x = zeros(1,size(T_array,2)); tauE_sep_n.IVS.y = zeros(1,size(T_array,2)); tauE_sep_n.IVS.z = zeros(1,size(T_array,2));
    tauE_sep_n.Alloy.x = zeros(1,size(T_array,2)); tauE_sep_n.Alloy.y = zeros(1,size(T_array,2)); tauE_sep_n.Alloy.z = zeros(1,size(T_array,2));
    
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_sep_n.POP.xx = zeros(size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yy = zeros(size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zz = zeros(size(EF_array,2),size(T_array,2));
        TDF_sep_n.POP.xy = zeros(size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yz = zeros(size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.xz = zeros(size(EF_array,2),size(T_array,2));
        TDF_sep_n.POP.yx = zeros(size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zy = zeros(size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zx = zeros(size(EF_array,2),size(T_array,2));
        MFP_sep_n.POP.x = zeros(size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.y = zeros(size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.z = zeros(size(EF_array,2),size(T_array,2));
        tauE_sep_n.POP.x = zeros(size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.y = zeros(size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.z = zeros(size(EF_array,2),size(T_array,2));
                       
        TDF_ph_n.xx = zeros(size(EF_array,2),size(T_array,2)); TDF_ph_n.yy = zeros(size(EF_array,2),size(T_array,2)); TDF_ph_n.zz = zeros(size(EF_array,2),size(T_array,2));
        TDF_ph_n.xy = zeros(size(EF_array,2),size(T_array,2)); TDF_ph_n.yz = zeros(size(EF_array,2),size(T_array,2)); TDF_ph_n.xz = zeros(size(EF_array,2),size(T_array,2));
        TDF_ph_n.yx = zeros(size(EF_array,2),size(T_array,2)); TDF_ph_n.zy = zeros(size(EF_array,2),size(T_array,2)); TDF_ph_n.zx = zeros(size(EF_array,2),size(T_array,2));
        MFP_ph_n.x = zeros(size(EF_array,2),size(T_array,2)); MFP_ph_n.y = zeros(size(EF_array,2),size(T_array,2)); MFP_ph_n.z = zeros(size(EF_array,2),size(T_array,2));
        tauE_ph_n.x = zeros(size(EF_array,2),size(T_array,2)); tauE_ph_n.y = zeros(size(EF_array,2),size(T_array,2)); tauE_ph_n.z = zeros(size(EF_array,2),size(T_array,2));
           
    else
        
        TDF_sep_n.POP.xx = zeros(1,size(T_array,2)); TDF_sep_n.POP.yy = zeros(1,size(T_array,2)); TDF_sep_n.POP.zz = zeros(1,size(T_array,2));
        TDF_sep_n.POP.xy = zeros(1,size(T_array,2)); TDF_sep_n.POP.yz = zeros(1,size(T_array,2)); TDF_sep_n.POP.xz = zeros(1,size(T_array,2));
        TDF_sep_n.POP.yx = zeros(1,size(T_array,2)); TDF_sep_n.POP.zy = zeros(1,size(T_array,2)); TDF_sep_n.POP.zx = zeros(1,size(T_array,2));
        MFP_sep_n.POP.x = zeros(1,size(T_array,2)); MFP_sep_n.POP.y = zeros(1,size(T_array,2)); MFP_sep_n.POP.z = zeros(1,size(T_array,2));
        tauE_sep_n.POP.x = zeros(1,size(T_array,2)); tauE_sep_n.POP.y = zeros(1,size(T_array,2)); tauE_sep_n.POP.z = zeros(1,size(T_array,2));
        
        TDF_ph_n.xx = zeros(1,size(T_array,2)); TDF_ph_n.yy = zeros(1,size(T_array,2)); TDF_ph_n.zz = zeros(1,size(T_array,2));
        TDF_ph_n.xy = zeros(1,size(T_array,2)); TDF_ph_n.yz = zeros(1,size(T_array,2)); TDF_ph_n.xz = zeros(1,size(T_array,2));
        TDF_ph_n.yx = zeros(1,size(T_array,2)); TDF_ph_n.zy = zeros(1,size(T_array,2)); TDF_ph_n.zx = zeros(1,size(T_array,2));
        MFP_ph_n.x = zeros(1,size(T_array,2)); MFP_ph_n.y = zeros(1,size(T_array,2)); MFP_ph_n.z = zeros(1,size(T_array,2));
        tauE_ph_n.x = zeros(1,size(T_array,2)); tauE_ph_n.y = zeros(1,size(T_array,2)); tauE_ph_n.z = zeros(1,size(T_array,2));
       
    end
    



    %  NOTE: all the taus ar for each (iE, in)
    if strcmp(IIS,'yes')

            
            for id_EF = 1:size(EF_array,2)
                for id_T = 1:size(T_array,2)
                    EF_array = EF_matrix(:,id_T)';
%                         if E_array(id_E) < max(EF_array)+6*kB*T_array(iT)/q0
                    if ( E_array(iE) < max(EF_array)+6*kB*max(T_array)/q0 ) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*max(T_array)/q0 ) 
                       % it takes all the energies for which a value has been calculated
            % contribution of each k point with energy E, for all the bands
            % the state_ID(iE,id_n) is an array of DOS, v, etc. having a
            % length corresponding to the number of points in that state,
            % each array state_ID(iE,id_n) have different length
                        if not(size(taus_IIS.x)) == 0 % the state is not empty
                            if size(T_array,2) == 1
                                tau_IIS_x_temp = squeeze(taus_IIS.x(id_EF,:)) ;
                                tau_IIS_y_temp = squeeze(taus_IIS.y(id_EF,:)) ;
                                tau_IIS_z_temp = squeeze(taus_IIS.z(id_EF,:)) ;
                                if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                        tau_POP_x_temp = squeeze(taus_POP.x(id_EF,:)) ;
                                        tau_POP_y_temp = squeeze(taus_POP.y(id_EF,:)) ;
                                        tau_POP_z_temp = squeeze(taus_POP.z(id_EF,:)) ;
                                end
                            else
                                        tau_IIS_x_temp = smooth( squeeze(taus_IIS.x(id_EF,id_T,:)) ,2)' ;
                                        tau_IIS_y_temp = smooth( squeeze(taus_IIS.y(id_EF,id_T,:)) ,2)' ;
                                        tau_IIS_z_temp = smooth( squeeze(taus_IIS.z(id_EF,id_T,:)) ,2)' ;
                                if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                            
                                        tau_POP_x_temp = squeeze(taus_POP.x(id_EF,id_T,:))' ;
                                        tau_POP_y_temp = squeeze(taus_POP.y(id_EF,id_T,:))' ;
                                        tau_POP_z_temp = squeeze(taus_POP.z(id_EF,id_T,:))' ;
                                end
                            end
                        else
                            tau_IIS_x_temp = [];
                            tau_IIS_y_temp = [];
                            tau_IIS_z_temp = [];
                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                    tau_POP_x_temp = [];
                                    tau_POP_y_temp = [];
                                    tau_POP_z_temp = [];
                            end
                        end


                        if not(size(taus_matth.x)) == 0  % the state is involved in the transport (not empty)                                
                            if strcmp(remove_matth,'yes') % "neutralize" the taus_matth in the case it is not needed
                                if size(T_array,2) == 1
                                    taus_matth.x(:) = Inf; 
                                    taus_matth.y(:) = Inf; 
                                    taus_matth.z(:) = Inf; 
                                else
                                    taus_matth.x(:,id_T) = Inf ; 
                                    taus_matth.y(:,id_T) = Inf ; 
                                    taus_matth.z(:,id_T) = Inf ; 
                                end
                            end

                            if size(T_array,2) == 1

                                if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                    TDF_n.xx(id_EF) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yy(id_EF) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS); 

                                    TDF_n.zz(id_EF) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xy(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yz(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xz(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zy(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);


                                    
                                    MFP_n.x(id_EF) = sum( abs(state_ID(iE,in).v_x .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.y(id_EF) = sum( abs(state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.z(id_EF) = sum( abs(state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);



                                    tauE_n.x(id_EF) = sum( (1./taus_matth.x +...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.y(id_EF) = sum( (1./taus_matth.y +...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.z(id_EF) = sum( (1./taus_matth.z +...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);



                                    tauE_IIS_n.x(id_EF) = ( sum( tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) ); % 1 ./ ( sum( 1./tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.y(id_EF) = ( sum( tau_IIS_y_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.z(id_EF) = ( sum( tau_IIS_z_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                else

                                    TDF_n.xx(id_EF) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS); 

                                    TDF_n.yy(id_EF) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS); 

                                    TDF_n.zz(id_EF) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS); 

                                    TDF_n.xy(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yz(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xz(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zy(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS);



                                    MFP_n.x(id_EF) = sum( abs(state_ID(iE,in).v_x .* (1./taus_matth.x +...
                                        1./tau_IIS_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.y(id_EF) = sum( abs(state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                        1./tau_IIS_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.z(id_EF) = sum( abs(state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                        1./tau_IIS_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                    tauE_n.x(id_EF) = sum( (1./taus_matth.x +...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.y(id_EF) = sum( (1./taus_matth.y +...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.z(id_EF) = sum( (1./taus_matth.z +...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                    tauE_IIS_n.x(id_EF) = ( sum( tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) ); % 1 ./ ( sum( 1./tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.y(id_EF) = ( sum( tau_IIS_y_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.z(id_EF) = ( sum( tau_IIS_z_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );


                                end                                    


                            else % more than one T

                                if strcmp(POP,'yes') && strcmp(screening_POP,'yes')

                                    TDF_n.xx(id_EF,id_T) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yy(id_EF,id_T) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zz(id_EF,id_T) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xy(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yz(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xz(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zy(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);


                                    MFP_n.x(id_EF,id_T) = sum( abs(state_ID(iE,in).v_x .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.y(id_EF,id_T) = sum( abs(state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.z(id_EF,id_T) = sum( abs(state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                    tauE_n.x(id_EF,id_T) = sum( (1./taus_matth.x(:,id_T)' +...
                                        1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.y(id_EF,id_T) = sum( (1./taus_matth.y(:,id_T)' +...
                                        1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.z(id_EF,id_T) = sum( (1./taus_matth.z(:,id_T)' +...
                                        1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                    tauE_IIS_n.x(id_EF,id_T) = ( sum( tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) ); % 1 ./ ( sum( 1./tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.y(id_EF,id_T) = ( sum( tau_IIS_y_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.z(id_EF,id_T) = ( sum( tau_IIS_z_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );


                                else

                                    TDF_n.xx(id_EF,id_T) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yy(id_EF,id_T) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zz(id_EF,id_T) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xy(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yz(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.xz(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.yx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zy(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                    TDF_n.zx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS);


                                    MFP_n.x(id_EF,id_T) = sum( abs(state_ID(iE,in).v_x .* (1./taus_matth.x(:,id_T)'+...
                                        1./tau_IIS_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.y(id_EF,id_T) = sum( abs(state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                        1./tau_IIS_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    MFP_n.z(id_EF,id_T) = sum( abs(state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                        1./tau_IIS_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);



                                    tauE_n.x(id_EF,id_T) = sum( (1./taus_matth.x(:,id_T)' +...
                                        1./tau_IIS_x_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.y(id_EF,id_T) = sum( (1./taus_matth.y(:,id_T)' +...
                                        1./tau_IIS_y_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                    tauE_n.z(id_EF,id_T) = sum( (1./taus_matth.z(:,id_T)' +...
                                        1./tau_IIS_z_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                    tauE_IIS_n.x(id_EF,id_T) = ( sum( tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) ); % 1 ./ ( sum( 1./tau_IIS_x_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.y(id_EF,id_T) = ( sum( tau_IIS_y_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );

                                    tauE_IIS_n.z(id_EF,id_T) = ( sum( tau_IIS_z_temp .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS) );


                                end
                            end
                        end
                    end
                end           
            end
            
            
        else % no IIS 

                    for id_EF = 1:size(EF_array,2)
                        for id_T = 1:size(T_array,2)
                            EF_array = EF_matrix(:,id_T)';
                            if ( E_array(iE) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*max(T_array)/q0 )
                                % it takes all the energies for which a value has been calculated
                    % contribution of each k point with energy E, for all the bands
                    % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                    % length corresponding to the number of points in that state,
                    % each array state_ID(id_E,id_n) have different length
                    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                        if not(size(taus_POP.x)) == 0   % the state is not empty
                                    if size(T_array,2) == 1
                                        tau_POP_x_temp = squeeze(taus_POP.x(id_EF,:)) ;
                                        tau_POP_y_temp = squeeze(taus_POP.y(id_EF,:)) ;
                                        tau_POP_z_temp = squeeze(taus_POP.z(id_EF,:)) ;
                                    else                                            
                                        tau_POP_x_temp = squeeze(taus_POP.x(id_EF,id_T,:))' ;
                                        tau_POP_y_temp = squeeze(taus_POP.y(id_EF,id_T,:))' ;
                                        tau_POP_z_temp = squeeze(taus_POP.z(id_EF,id_T,:))' ;
                                    end
                        else
                                    tau_POP_x_temp = [];
                                    tau_POP_y_temp = [];
                                    tau_POP_z_temp = [];
                        end
                    end


                                if not(size(taus_matth.x)) == 0  % the state is involved in the transport
                                    if strcmp(remove_matth,'yes') % "neutralize" the taus_matth in the case it is not needed
                                        if size(T_array,2) == 1
                                            taus_matth.x(:) = Inf; 
                                            taus_matth.y(:) = Inf; 
                                            taus_matth.z(:) = Inf; 
                                        else
                                            taus_matth.x(:,id_T) = Inf ; 
                                            taus_matth.y(:,id_T) = Inf ; 
                                            taus_matth.z(:,id_T) = Inf ; 
                                        end
                                    end

                                    if size(T_array,2) == 1

                                         if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            TDF_n.xx(id_EF) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* (1./taus_matth.x +...
                                               + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.yy(id_EF) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS); 

                                            TDF_n.zz(id_EF) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.xy(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.yz(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.xz(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.yx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.zy(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.zx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);


                                            MFP_n.x(id_EF) = sum( abs(state_ID(iE,in).v_x .* (1./taus_matth.x +...
                                                + 1./tau_POP_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            MFP_n.y(id_EF) = sum( abs(state_ID(iE,in).v_y .* (1./taus_matth.y +...
                                                + 1./tau_POP_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            MFP_n.z(id_EF) = sum( abs(state_ID(iE,in).v_z .* (1./taus_matth.z +...
                                                + 1./tau_POP_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                            tauE_n.x(id_EF) = sum( (1./taus_matth.x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            tauE_n.y(id_EF) = sum( (1./taus_matth.y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            tauE_n.z(id_EF) = sum( (1./taus_matth.z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                         else         
                                                
                                            NInf=isinf(taus_matth.x); % remove the points to avoid TDF = 0
                                            taus_matth.x(NInf)=0;
                                            NInf=isinf(taus_matth.y);
                                            taus_matth.y(NInf)=0;
                                            NInf=isinf(taus_matth.z);
                                            taus_matth.z(NInf)=0;

                                            TDF_n.xx(id_EF) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* taus_matth.x ...
                                                .* state_ID(iE,in).DOS); 

                                            TDF_n.yy(id_EF) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* taus_matth.y ...
                                                .* state_ID(iE,in).DOS); 

                                            TDF_n.zz(id_EF) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* taus_matth.z ...
                                                .* state_ID(iE,in).DOS); 

                                            TDF_n.xy(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* taus_matth.y ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.xz(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* taus_matth.z ...
                                                .* state_ID(iE,in).DOS);

                                            TDF_n.yz(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* taus_matth.z ...
                                                .* state_ID(iE,in).DOS);

                                            TDF_n.yx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* taus_matth.x ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.zx(id_EF) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* taus_matth.x ...
                                                .* state_ID(iE,in).DOS);

                                            TDF_n.zy(id_EF) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* taus_matth.y ...
                                                .* state_ID(iE,in).DOS);


                                            MFP_n.x(id_EF) = sum( abs(state_ID(iE,in).v_x .* taus_matth.x) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                            MFP_n.y(id_EF) = sum( abs(state_ID(iE,in).v_y .* taus_matth.y) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                            MFP_n.z(id_EF) = sum( abs(state_ID(iE,in).v_z .* taus_matth.z) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                            tauE_n.x(id_EF) = sum( taus_matth.x .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                            tauE_n.y(id_EF) = sum( taus_matth.y .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                            tauE_n.z(id_EF) = sum( taus_matth.z .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                         end

                                    else % more temperature values

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                        
                                            TDF_n.xx(id_EF,id_T) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* (1./taus_matth.x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.yy(id_EF,id_T) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.zz(id_EF,id_T) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.xy(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.yz(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.xz(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.yx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* (1./taus_matth.x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.zy(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* (1./taus_matth.y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS);

                                            TDF_n.zx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* (1./taus_matth.x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS);


                                            MFP_n.x(id_EF,id_T) = sum( abs(state_ID(iE,in).v_x .* (1./taus_matth.x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            MFP_n.y(id_EF,id_T) = sum( abs(state_ID(iE,in).v_y .* (1./taus_matth.y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            MFP_n.z(id_EF,id_T) = sum( abs(state_ID(iE,in).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);                                        


                                            tauE_n.x(id_EF,id_T) = sum( (1./taus_matth.x(:,id_T)' +...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            tauE_n.y(id_EF,id_T) = sum( (1./taus_matth.y(:,id_T)' +...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                            tauE_n.z(id_EF,id_T) = sum( (1./taus_matth.z(:,id_T)' +...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                        else
                                            
                                            NInf=isinf(taus_matth.x); % remove the points to avoid TDF = 0
                                            taus_matth.x(NInf)=0;
                                            NInf=isinf(taus_matth.y);
                                            taus_matth.y(NInf)=0;
                                            NInf=isinf(taus_matth.z);
                                            taus_matth.z(NInf)=0;

                                            TDF_n.xx(id_EF,id_T) = sum(state_ID(iE,in).v_x .* state_ID(iE,in).v_x .* taus_matth.x(:,id_T)'...
                                            .* state_ID(iE,in).DOS); 

                                            TDF_n.yy(id_EF,id_T) = sum(state_ID(iE,in).v_y .* state_ID(iE,in).v_y .* taus_matth.y(:,id_T)'...
                                                .* state_ID(iE,in).DOS); 

                                            TDF_n.zz(id_EF,id_T) = sum(state_ID(iE,in).v_z .* state_ID(iE,in).v_z .* taus_matth.z(:,id_T)'...
                                                .* state_ID(iE,in).DOS); 

                                            TDF_n.xy(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* taus_matth.y(:,id_T)' ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.xz(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* taus_matth.z(:,id_T)' ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.yz(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* taus_matth.z(:,id_T)' ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.yx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_y .* taus_matth.x(:,id_T)' ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.zx(id_EF,id_T) = sum( state_ID(iE,in).v_x .* state_ID(iE,in).v_z .* taus_matth.x(:,id_T)' ...
                                                .*state_ID(iE,in).DOS);

                                            TDF_n.zy(id_EF,id_T) = sum( state_ID(iE,in).v_y .* state_ID(iE,in).v_z .* taus_matth.y(:,id_T)' ...
                                                .*state_ID(iE,in).DOS);

                                            MFP_n.x(id_EF,id_T) = sum( abs(state_ID(iE,in).v_x .* taus_matth.x(:,id_T)') .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                            MFP_n.y(id_EF,id_T) = sum( abs(state_ID(iE,in).v_y .* taus_matth.y(:,id_T)') .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                            MFP_n.z(id_EF,id_T) = sum( abs(state_ID(iE,in).v_z .* taus_matth.z(:,id_T)') .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);                                                                             

                                            tauE_n.x(id_EF,id_T) = sum( taus_matth.x(:,id_T)' .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);                                        
                                            tauE_n.y(id_EF,id_T) = sum( taus_matth.y(:,id_T)' .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);                                        
                                            tauE_n.z(id_EF,id_T) = sum( taus_matth.z(:,id_T)' .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);                                        

                                        end   
                                    end
                                end
                            end
                        end
                    end
           
    end

    
    
    
    
    
    
    %
    id_E = iE; id_n = in; % to make copy-paste faster
    %
    
    
    
    
    
     % -------------  ADP only ---------------------------------------------
    if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes')
         

                if not(size(taus.x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauADP ------
                    NNan=isnan(taus.x(tau_pos_ADP,:,id_T));
                    taus.x(tau_pos_ADP,NNan,id_T)=0;
                    NNan=isnan(taus.y(tau_pos_ADP,:,id_T));
                    taus.y(tau_pos_ADP,NNan,id_T)=0;
                    NNan=isnan(taus.z(tau_pos_ADP,:,id_T));
                    taus.z(tau_pos_ADP,NNan,id_T)=0;
                    NInf=isinf(taus.x(tau_pos_ADP,:,id_T)); % for the other scatt. mech. this control is into the subfunctions
                    taus.x(tau_pos_ADP,NInf,id_T)=0;
                    NInf=isinf(taus.y(tau_pos_ADP,:,id_T));
                    taus.y(tau_pos_ADP,NInf,id_T)=0;
                    NInf=isinf(taus.z(tau_pos_ADP,:,id_T));
                    taus.z(tau_pos_ADP,NInf,id_T)=0;                
                    %------------------------------------------
                        TDF_sep_n.ADP.xx(id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus.x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yy(id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus.y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.zz(id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus.z(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ADP.xy(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yz(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.z(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.xz(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.z(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ADP.yx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.zy(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.zx(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.ADP.x(id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus.x(tau_pos_ADP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.ADP.y(id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus.y(tau_pos_ADP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.ADP.z(id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus.z(tau_pos_ADP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                        tauE_sep_n.ADP.x(id_T) = sum( taus.x(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ADP.y(id_T) = sum( taus.y(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ADP.z(id_T) = sum( taus.z(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);  
                                end
                    end

                end
        

    end
    % --------------------------------------------------------------------------------------------------------


    % ---------  ODP only -----------------------------------------------------
    if strcmp(ODP,'yes')

                if not(size(taus.x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauODP ------
                    NNan=isnan(taus.x(tau_pos_ODP,:,id_T));
                    taus.x(tau_pos_ODP,NNan,id_T)=0;
                    NNan=isnan(taus.y(tau_pos_ODP,:,id_T));
                    taus.y(tau_pos_ODP,NNan,id_T)=0;
                    NNan=isnan(taus.z(tau_pos_ODP,:,id_T));
                    taus.z(tau_pos_ODP,NNan,id_T)=0;
                    NInf=isinf(taus.x(tau_pos_ODP,:,id_T));
                    taus.x(tau_pos_ODP,NInf,id_T)=0;
                    NInf=isinf(taus.y(tau_pos_ODP,:,id_T));
                    taus.y(tau_pos_ODP,NInf,id_T)=0;
                    NInf=isinf(taus.z(tau_pos_ODP,:,id_T));
                    taus.z(tau_pos_ODP,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.ODP.xx(id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus.x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yy(id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus.y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.zz(id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus.z(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ODP.xy(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yz(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.z(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.xz(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.z(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ODP.yx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.zy(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.zx(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.ODP.x(id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus.x(tau_pos_ODP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.ODP.y(id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus.y(tau_pos_ODP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.ODP.z(id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus.z(tau_pos_ODP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                        tauE_sep_n.ODP.x(id_T) = sum( taus.x(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ODP.y(id_T) = sum( taus.y(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ODP.z(id_T) = sum( taus.z(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                         

                                end
                    end
                end
 
              
    end
    % --------------------------------------------------------------------------------

    % ---------  IVS only -----------------------------------------------------
    if strcmp(IVS,'yes')
     
                if not(size(taus.x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauIVS ------
                    NNan=isnan(taus.x(tau_pos_IVS,:,id_T));
                    taus.x(tau_pos_IVS,NNan,id_T)=0;
                    NNan=isnan(taus.y(tau_pos_IVS,:,id_T));
                    taus.y(tau_pos_IVS,NNan,id_T)=0;
                    NNan=isnan(taus.z(tau_pos_IVS,:,id_T));
                    taus.z(tau_pos_IVS,NNan,id_T)=0;                
                    NInf=isinf(taus.x(tau_pos_IVS,:,id_T));
                    taus.x(tau_pos_IVS,NInf,id_T)=0;
                    NInf=isinf(taus.y(tau_pos_IVS,:,id_T));
                    taus.y(tau_pos_IVS,NInf,id_T)=0;
                    NInf=isinf(taus.z(tau_pos_IVS,:,id_T));
                    taus.z(tau_pos_IVS,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.IVS.xx(id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus.x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yy(id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus.y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.zz(id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus.z(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.IVS.xy(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yz(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.z(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.xz(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.z(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.IVS.yx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.zy(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.zx(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.IVS.x(id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus.x(tau_pos_IVS,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.IVS.y(id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus.y(tau_pos_IVS,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.IVS.z(id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus.z(tau_pos_IVS,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                        tauE_sep_n.IVS.x(id_T) = sum( taus.x(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.IVS.y(id_T) = sum( taus.y(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.IVS.z(id_T) = sum( taus.z(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                          

                                end
                    end
                end

        
    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  POP only -----------------------------------------------------
    if strcmp(POP,'yes') 
        if strcmp(screening_POP,'no')

                    if not(size(taus.x)) == 0
                        for id_T = size(T_array,2):-1:1
                            EF_array = EF_matrix(:,id_T)';
                                    if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                        % ------------------------- add a control over tauPOP ------
                        NNan=isnan(taus.x(tau_pos_POP,:,id_T));
                        taus.x(tau_pos_POP,NNan,id_T)=0;
                        NNan=isnan(taus.y(tau_pos_POP,:,id_T));
                        taus.y(tau_pos_POP,NNan,id_T)=0;
                        NNan=isnan(taus.z(tau_pos_POP,:,id_T));
                        taus.z(tau_pos_POP,NNan,id_T)=0;
                        NInf=isinf(taus.x(tau_pos_POP,:,id_T)); % for the other scatt. mech. this control is into the subfunctions
                        taus.x(tau_pos_POP,NInf,id_T)=0;
                        NInf=isinf(taus.y(tau_pos_POP,:,id_T));
                        taus.y(tau_pos_POP,NInf,id_T)=0;
                        NInf=isinf(taus.z(tau_pos_POP,:,id_T));
                        taus.z(tau_pos_POP,NInf,id_T)=0;
                        %------------------------------------------
                        TDF_sep_n.POP.xx(id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus.x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yy(id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus.y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.zz(id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus.z(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.xy(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yz(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.z(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xz(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.z(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.yx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.zy(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.zx(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.POP.x(id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus.x(tau_pos_POP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.POP.y(id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus.y(tau_pos_POP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.POP.z(id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus.z(tau_pos_POP,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                        tauE_sep_n.POP.x(id_T) = sum( taus.x(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.y(id_T) = sum( taus.y(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.z(id_T) = sum( taus.z(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                       

                                    end
                        end
                    end

            
        elseif strcmp(screening_POP,'yes')

                if not(size(taus.x)) == 0
                    for id_EF = 1:size(EF_array,2)
                        for id_T = size(T_array,2):-1:1
                            EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauPOP ------
                    if not(size(taus_POP.x)) == 0   % the state is not empty
                                if size(T_array,2) == 1
                                    tau_POP_x_temp = squeeze(taus_POP.x(id_EF,:)) ;
                                    tau_POP_y_temp = squeeze(taus_POP.y(id_EF,:)) ;
                                    tau_POP_z_temp = squeeze(taus_POP.z(id_EF,:)) ;
                                else                                            
                                    tau_POP_x_temp = squeeze(taus_POP.x(id_EF,id_T,:))' ;
                                    tau_POP_y_temp = squeeze(taus_POP.y(id_EF,id_T,:))' ;
                                    tau_POP_z_temp = squeeze(taus_POP.z(id_EF,id_T,:))' ;
                                end
                    else
                                tau_POP_x_temp = [];
                                tau_POP_y_temp = [];
                                tau_POP_z_temp = [];
                    end
                    %------------------------------------------
                        TDF_sep_n.POP.xx(id_EF,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yy(id_EF,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.zz(id_EF,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z .*tau_POP_z_temp .*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.xy(id_EF,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yz(id_EF,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*tau_POP_z_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xz(id_EF,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*tau_POP_z_temp .*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.yx(id_EF,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yz(id_EF,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xz(id_EF,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.POP.x(id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* tau_POP_x_temp ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.POP.y(id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* tau_POP_y_temp ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.POP.z(id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* tau_POP_z_temp ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                        tauE_sep_n.POP.x(id_EF,id_T) = sum( tau_POP_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.y(id_EF,id_T) = sum( tau_POP_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.z(id_EF,id_T) = sum( tau_POP_z_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                end
                        end
                    end
                end

       
        end
        
    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  Alloy only -----------------------------------------------------
    if strcmp(Alloy,'yes')
       
                if not(size(taus.x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauAlloy ------
                    NNan=isnan(taus.x(tau_pos_Alloy,:,id_T));
                    taus.x(tau_pos_Alloy,NNan,id_T)=0;
                    NNan=isnan(taus.y(tau_pos_Alloy,:,id_T));
                    taus.y(tau_pos_Alloy,NNan,id_T)=0;
                    NNan=isnan(taus.z(tau_pos_Alloy,:,id_T));
                    taus.z(tau_pos_Alloy,NNan,id_T)=0;                
                    NInf=isinf(taus.x(tau_pos_Alloy,:,id_T));
                    taus.x(tau_pos_Alloy,NInf,id_T)=0;
                    NInf=isinf(taus.y(tau_pos_Alloy,:,id_T));
                    taus.y(tau_pos_Alloy,NInf,id_T)=0;
                    NInf=isinf(taus.z(tau_pos_Alloy,:,id_T));
                    taus.z(tau_pos_Alloy,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.Alloy.xx(id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus.x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yy(id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus.y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.zz(id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus.z(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.Alloy.xy(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yz(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.z(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.xz(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.z(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.Alloy.yx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus.x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.zy(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus.y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.zx(id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus.x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.Alloy.x(id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus.x(tau_pos_Alloy,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.Alloy.y(id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus.y(tau_pos_Alloy,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                        MFP_sep_n.Alloy.z(id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus.z(tau_pos_Alloy,:,id_T) ) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                        tauE_sep_n.Alloy.x(id_T) = sum( taus.x(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.Alloy.y(id_T) = sum( taus.y(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.Alloy.z(id_T) = sum( taus.z(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);   
                                end
                    end
                end

       

    end
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------

    
    
    % ---------  phonons (all) only @ all T--------------------------------
    % ---------------------------------------------------------------------
    
                     for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )
                                    % it takes all the energies for which a value has been calculated
                        % contribution of each k point with energy E, for all the bands
                        % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                        % length corresponding to the number of points in that state,
                        % each array state_ID(id_E,id_n) have different length
                                    if not(size(taus_matth.x)) == 0   % the state is involved in the transport

                                        if size(T_array,2) == 1

                                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                            

                                                for id_EF = size(EF_array,2):-1:1
                                                    
                                                    if not(size(taus_POP.x)) == 0   % the state is not empty
                                                        tau_POP_x_temp = squeeze(taus_POP.x(id_EF,:)) ;
                                                        tau_POP_y_temp = squeeze(taus_POP.y(id_EF,:)) ;
                                                        tau_POP_z_temp = squeeze(taus_POP.z(id_EF,:)) ;
                                                    else
                                                        tau_POP_x_temp = [];
                                                        tau_POP_y_temp = [];
                                                        tau_POP_z_temp = [];
                                                    end

                                                    TDF_ph_n.xx(id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth.x +...
                                                       + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yy(id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth.y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                                    TDF_ph_n.zz(id_EF) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth.z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xy(id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth.y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yz(id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth.z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xz(id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth.z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yx(id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth.x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zy(id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth.y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zx(id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth.x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                                    MFP_ph_n.x(id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth.x +...
                                                        + 1./tau_POP_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                                    MFP_ph_n.y(id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth.y +...
                                                        + 1./tau_POP_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                                    MFP_ph_n.z(id_EF) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth.z +...
                                                        + 1./tau_POP_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);


                                                    tauE_ph_n.x(id_EF) = sum( (1./taus_matth.x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_ph_n.y(id_EF) = sum( (1./taus_matth.y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_ph_n.z(id_EF) = sum( (1./taus_matth.z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                end
                                            else
                                                
                                                NInf=isinf(taus_matth.x); % remove the points to avoid TDF = 0
                                                taus_matth.x(NInf)=0;
                                                NInf=isinf(taus_matth.y);
                                                taus_matth.y(NInf)=0;
                                                NInf=isinf(taus_matth.z);
                                                taus_matth.z(NInf)=0;
                                                
                                                TDF_ph_n.xx = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth.x ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.yy = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth.y ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.zz = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* taus_matth.z ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.xy = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth.y .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.xz = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth.z .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yz = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth.z .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yx = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth.x .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.zx = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth.x .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.zy = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth.y .* state_ID(id_E,id_n).DOS);


                                                MFP_ph_n.x = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth.x) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                                MFP_ph_n.y = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth.y) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                                MFP_ph_n.z = sum( abs(state_ID(id_E,id_n).v_z .* taus_matth.z) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                                tauE_ph_n.x = sum( taus_matth.x .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_ph_n.y = sum( taus_matth.y .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_ph_n.z = sum( taus_matth.z .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            end
                                        else % more T values
                                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')  

                                                for id_EF = size(EF_array,2):-1:1
                                                    
                                                    if not(size(taus_POP.x)) == 0   % the state is not empty
                                                        tau_POP_x_temp = squeeze(taus_POP.x(id_EF,id_T,:))' ;
                                                        tau_POP_y_temp = squeeze(taus_POP.y(id_EF,id_T,:))' ;
                                                        tau_POP_z_temp = squeeze(taus_POP.z(id_EF,id_T,:))' ;
                                                    else
                                                        tau_POP_x_temp = [];
                                                        tau_POP_y_temp = [];
                                                        tau_POP_z_temp = [];
                                                    end

                                                    TDF_ph_n.xx(id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth.x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yy(id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth.y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zz(id_EF,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xy(id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth.y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yz(id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xz(id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yx(id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth.x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zy(id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth.y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zx(id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth.x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                                    MFP_ph_n.x(id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth.x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                                    MFP_ph_n.y(id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth.y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                                    MFP_ph_n.z(id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth.z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1)) .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);                                        


                                                    tauE_ph_n.x(id_EF,id_T) = sum( (1./taus_matth.x(:,id_T)' +...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_ph_n.y(id_EF,id_T) = sum( (1./taus_matth.y(:,id_T)' +...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_ph_n.z(id_EF,id_T) = sum( (1./taus_matth.z(:,id_T)' +...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                end

                                            else
                                            
                                                NInf=isinf(taus_matth.x); % remove the points to avoid TDF = 0
                                                taus_matth.x(NInf)=0;
                                                NInf=isinf(taus_matth.y);
                                                taus_matth.y(NInf)=0;
                                                NInf=isinf(taus_matth.z);
                                                taus_matth.z(NInf)=0;

                                                TDF_ph_n.xx(id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth.x(:,id_T)'...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.yy(id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth.y(:,id_T)'...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.zz(id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* taus_matth.z(:,id_T)'...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.xy(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth.y(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.xz(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth.z(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yz(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth.z(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth.x(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.zx(id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth.x(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.zy(id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth.y(:,id_T)' .* state_ID(id_E,id_n).DOS);

                                                MFP_ph_n.x(id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth.x(:,id_T)') .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                                MFP_ph_n.y(id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth.y(:,id_T)') .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);
                                                MFP_ph_n.z(id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus_matth.z(:,id_T)') .* state_ID(iE,in).DOS ) ./ sum(state_ID(iE,in).DOS);

                                                tauE_ph_n.x(id_T) = sum( taus_matth.x(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_ph_n.y(id_T) = sum( taus_matth.y(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_ph_n.z(id_T) = sum( taus_matth.z(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            end
                                        end
                                    end
                                end                
                    end
       
    % ------------------------------------------------------------------------
        
end




% -----------------------------------------------------------------------
% sub-functions for the scatt. mechanisms

% the ADP function, it gives arrays of 1/taus for eah k state
% only INTRA-band
function [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp ] = ...
    tau_ADP_funct(Skk, e, I, DOS, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)


    one_over_tau_x_temp = Skk .* DOS./e .* I .* (1 - v_x./v_x_k);
    NNan = isnan(one_over_tau_x_temp); one_over_tau_x_temp(NNan) = 0;
    NInf = isinf(one_over_tau_x_temp); one_over_tau_x_temp(NInf) = 0;
        
    one_over_tau_y_temp = Skk .* DOS./e .* I .* (1 - v_y./v_y_k);
    NNan = isnan(one_over_tau_y_temp); one_over_tau_y_temp(NNan) = 0;
    NInf = isinf(one_over_tau_y_temp); one_over_tau_y_temp(NInf) = 0;
        
    one_over_tau_z_temp = Skk .* DOS./e .* I .* (1 - v_z./v_z_k);
    NNan = isnan(one_over_tau_z_temp); one_over_tau_z_temp(NNan) = 0;
    NInf = isinf(one_over_tau_z_temp); one_over_tau_z_temp(NInf) = 0;
           
end


% the ADP_IVS function 
function [ one_over_tau_x_temp_array,one_over_tau_y_temp_array,one_over_tau_z_temp_array ] = ...
                                    tau_ADP_IVS_funct(Skk, e, I, z, DOSf, vf_x, v_x_k, vf_y, v_y_k, vf_z, v_z_k)
                                
    one_over_tau_x_temp_array = z .* Skk .* DOSf./e .* I .* (1 - vf_x./v_x_k); 
    NNan = isnan(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NInf) = 0;

    one_over_tau_y_temp_array = z .* Skk .* DOSf./e .* I .* (1 - vf_y./v_y_k);
    NNan = isnan(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NInf) = 0;
    
    one_over_tau_z_temp_array = z .* Skk .* DOSf./e .* I .* (1 - vf_z./v_z_k);
    NNan = isnan(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NInf) = 0;
   
end


% the ODP and IVS function
function [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp] = ...
                                        tau_ODP_funct(Skk, e, I, z, DOSf, vf_x, v_x_k, vf_y, v_y_k, vf_z, v_z_k)
       
    one_over_tau_temp_array = z .* Skk .* DOSf./e .* I .* (1-vf_x./v_x_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_x_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array); % integral over all the k' points
    
    one_over_tau_temp_array = z .* Skk .* DOSf./e .* I .* (1-vf_y./v_y_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_y_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
    
    one_over_tau_temp_array = z .* Skk .* DOSf./e .* I .* (1-vf_z./v_z_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_z_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
                                   
end                           


% the POP function
function [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
    tau_POP_funct(Skk, g1, g2, g3, e, I, DOSf, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, vf_x, v_x_k, vf_y, v_y_k, vf_z, v_z_k)


% this finds the points that have a closer symmetrical one in a neighbour
    % reciprocal u.c. and shifts the exchanged vector
    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];


    q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
    
    one_over_tau_temp_array = Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-vf_x./v_x_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_x_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
    
    one_over_tau_temp_array = Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-vf_y./v_y_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_y_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
    
    one_over_tau_temp_array = Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-vf_z./v_z_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_z_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
        
end


% the alloy scattering sub function with Gq
function [ tau_x_temp, tau_y_temp, tau_z_temp ] = ...
                                    tau_alloy_funct(Skk,  Ra, g1, g2, g3, e, I, DOS, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)
  

    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];

    
    q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
    
    % the form factor function G_q    
    G_q = 3.*( sin(q_exchanged.*Ra) - (q_exchanged.*Ra).*cos(q_exchanged.*Ra) ) ./ (q_exchanged.*Ra).^3 ;
    
    % Skk = 2pi/hbar * (x(1-x)) * Delta_Egap^2
        
    one_over_tau_temp_array = Skk .* G_q.^2 .* DOS./e .* I .* (1 - v_x./v_x_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    tau_x_temp = ( 1/(2*pi)^3*sum(one_over_tau_temp_array) )^(-1);
    
    one_over_tau_temp_array = Skk .* G_q .* DOS./e .* I .* (1 - v_y./v_y_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    tau_y_temp = ( 1/(2*pi)^3*sum(one_over_tau_temp_array) )^(-1);
    
    one_over_tau_temp_array = Skk .* G_q .* DOS./e .* I .* (1 - v_z./v_z_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    tau_z_temp = ( 1/(2*pi)^3*sum(one_over_tau_temp_array) )^(-1);
end


% the IIS function
function [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                    tau_IIS_funct(Skk, Fermi, T, Lsc, g1, g2, g3, e, I, DOS, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)
  
    % this finds the points that have a closer symmetrical one in a neighbour
    % reciprocal u.c. and shifts the exchanged vector
    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];

q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector

tau_x_temp = zeros(1,size(Fermi,2)); tau_y_temp = zeros(1,size(Fermi,2)); 
tau_z_temp = zeros(1,size(Fermi,2)); 
for iEF = 1:size(Fermi,2)

    one_over_tau_x_temp_array = Skk(iEF) .* DOS./e .* I .* (1-v_x./v_x_k) ./...
            ( (q_exchanged.^2 + 1/Lsc(iEF,T).^2).^2 );
    NNan = isnan(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NInf) = 0;

    one_over_tau_y_temp_array = Skk(iEF) .* DOS./e .* I .* (1-v_y./v_y_k) ./...
            ( (q_exchanged.^2 + 1/Lsc(iEF,T).^2).^2 );
    NNan = isnan(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NInf) = 0;

    one_over_tau_z_temp_array = Skk(iEF) .* DOS./e .* I .* (1-v_z./v_z_k) ./...
            ( (q_exchanged.^2 + 1/Lsc(iEF,T).^2).^2 );
    NNan = isnan(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NInf) = 0;
        
       
        
%     it creates an array of taus for each impurity concentration (row)
        tau_x_temp(iEF) = (sum(1/(2*pi)^3.*one_over_tau_x_temp_array))^(-1); % the integration element dSk is already in the DOS
        tau_y_temp(iEF) = (sum(1/(2*pi)^3.*one_over_tau_y_temp_array))^(-1); 
        tau_z_temp(iEF) = (sum(1/(2*pi)^3.*one_over_tau_z_temp_array))^(-1);

end

% control over the tau_IIS as they are not used to compose the Matthiessen's
% taus and would skip the control there
NNan=isnan(tau_x_temp);
tau_x_temp(NNan)=0;
NNan=isnan(tau_y_temp);
tau_y_temp(NNan)=0;
NNan=isnan(tau_z_temp);
tau_z_temp(NNan)=0;
NInf=isinf(tau_x_temp);
tau_x_temp(NInf)=0;
NInf=isinf(tau_y_temp);
tau_y_temp(NInf)=0;
NInf=isinf(tau_z_temp);
tau_z_temp(NInf)=0;
end


% the screened POP function, the 1/tau are summed here
function [ oneovertau_x_temp_array,oneovertau_y_temp_array,oneovertau_z_temp_array ] = ...
                                    tau_screenedPOP_funct(Skk, Fermi, T, Lsc, g1, g2, g3, e, I, DOSf, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)

                                
    % this finds the points that have a closer symmetrical one in a neighbour
    % reciprocal u.c. and shifts the exchanged vector
    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];

q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector

oneovertau_x_temp_array = ones(1,size(Fermi,2)); oneovertau_y_temp_array = ones(1,size(Fermi,2)); oneovertau_z_temp_array = ones(1,size(Fermi,2));
for iEF = size(Fermi,2):-1:1

    temp_array = ( Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-v_x./v_x_k) ./...
            ( (1 + 1./q_exchanged.^2 * 1./ Lsc(iEF,T).^2).^2 ) );
    NNan = isnan(temp_array); temp_array(NNan) = 0;
    NInf = isinf(temp_array); temp_array(NInf) = 0;
    oneovertau_x_temp_array(iEF) = 1/(2*pi)^3 * sum(temp_array);

    temp_array = ( Skk ./ ( q_exchanged.^2) .* DOSf./e .* I .* (1-v_y./v_y_k) ./...
            ( (1 + 1./q_exchanged.^2 * 1./ Lsc(iEF,T).^2).^2 ) );
    NNan = isnan(temp_array); temp_array(NNan) = 0;
    NInf = isinf(temp_array); temp_array(NInf) = 0;
    oneovertau_y_temp_array(iEF) = 1/(2*pi)^3 * sum(temp_array);

    temp_array = ( Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-v_z./v_z_k) ./...
            ( (1 + 1./q_exchanged.^2 * 1./ Lsc(iEF,T).^2).^2 ) );
    NNan = isnan(temp_array); temp_array(NNan) = 0;
    NInf = isinf(temp_array); temp_array(NInf) = 0;
    oneovertau_z_temp_array(iEF) = 1/(2*pi)^3 * sum(temp_array);
    
end

end

% Denoising function
function [Ax_d,Ay_d,Az_d] = denoise(Ax,Ay,Az, threshold_level, n_c) 
for n_d = 1:n_c
    mx = mean(abs(Ax));
    my = mean(abs(Ay));
    mz = mean(abs(Az));
    for i = 1:size(Ax,2)
        if abs(Ax(i)) > threshold_level*mx
            Ax(i) = sign(Ax(i))*mx ; 
        end
        if abs(Ay(i)) > threshold_level*my
            Ay(i) = sign(Ay(i))*my ; 
        end
        if abs(Az(i)) > threshold_level*mz
            Az(i) = sign(Az(i))*mz ;
        end
    end
end
for n_d = 1:n_c
    mx = mean(abs(Ax));
    my = mean(abs(Ay));
    mz = mean(abs(Az));
    for i = 3:size(Ax,2)-2
        if abs(Ax(i)) > 2*mx
            Ax(i) = ( Ax(i-2)+Ax(i-1)+Ax(i+1)+Ax(i+2) )/4;
        end
        if abs(Ay(i)) > 2*my
            Ay(i) = ( Ay(i-2)+Ay(i-1)+Ay(i+1)+Ay(i+2) )/4;
        end
        if abs(Az(i)) > 2*mz
            Az(i) = ( Az(i-2)+Az(i-1)+Az(i+1)+Az(i+2) )/4;
        end
    end
end
mx = mean(abs(Ax));
my = mean(abs(Ay));
mz = mean(abs(Az));
for i = 1:size(Ax,2)
    if abs(Ax(i)) > threshold_level*mx
        Ax(i) = sign(Ax(i))*mx ; % ( Ax(i-2)+Ax(i-1)+Ax(i+1)+Ax(i+2) )/4;
    end
    if abs(Ay(i)) > threshold_level*my
        Ay(i) = sign(Ay(i))*my ; % ( Ay(i-2)+Ay(i-1)+Ay(i+1)+Ay(i+2) )/4;
    end
    if abs(Az(i)) > threshold_level*mz
        Az(i) = sign(Az(i))*mz ; % ( Az(i-2)+Az(i-1)+Az(i+1)+Az(i+2) )/4;
    end
end
Ax_d = Ax; Ay_d = Ay; Az_d = Az;
end