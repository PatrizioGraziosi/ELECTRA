function ELECTRA_multiple_run_Linux(material_names_file)

run([material_names_file,'.m'])

nm = size(materials_list,2);
if exist('alat','var') 
    if size(alat,2) ~= nm %#ok<NODEF>
        disp(' .mat type Ek files assmed')
        alat = ones(1,nm);
    end
else
    alat = ones(1,nm);
end

addpath('code/','-end');
disp('running the main function'); disp(' ');

materials_data.list = materials_list;
materials_data.alat = alat;
for id_m = 1:nm
    main_ELECTRA_multiple_Linux( materials_data, id_m ) ;
end

addpath('code/','-frozen');
end