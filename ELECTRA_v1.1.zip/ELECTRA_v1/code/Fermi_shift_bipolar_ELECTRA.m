% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source and the author when publishing results      %
% obtained  using the present  code                                       %
% ACS Appl. Energy Mater. 2020, 3, 6, 5913–5926
% https://doi.org/10.1021/acsaem.0c00825
%                                                                         %
% ----------------------------------------------------------------------- %


% calculation ot the Fermi array at each temperature
% considering the charge that comes from both the CB and the VB


function [EF_matrix, N_imp_matrix] = Fermi_shift_bipolar_ELECTRA( EF_array, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd, pseudoconduction_bands, pseudovalence_bands ) %#codegen

Ek(isnan(Ek)) = Inf;

EF_matrix = zeros(size(EF_array,2),size(T_array,2)); N_imp_matrix = EF_matrix;

% ----------------------- k space volume element -------------------------
dkx_v = [kx_matrix(2,1,1) ky_matrix(2,1,1) kz_matrix(2,1,1)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
dky_v = [kx_matrix(1,2,1) ky_matrix(1,2,1) kz_matrix(1,2,1)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
dkz_v = [kx_matrix(1,1,2) ky_matrix(1,1,2) kz_matrix(1,1,2)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
dVk = dot(cross(dkx_v,dky_v),dkz_v);
% ------------------------------------------------------------------------

if exist('sd','var')
else
    sd = 2;
end   
%------------ % Physical Constants -----------------
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
%----------------------------------------------------

% determination of the impurities density assuming the material is in its
% extrinsic region at 300 K, or atthe close temperature
[~, nT]=min(T_array-300);

Nd = zeros(size(EF_array,2),1)' ;
Nd_signed = Nd;
for id_EF = size(EF_array,2) : -1 : 1

        Nd(id_EF) = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF_array(id_EF))./(kB*T_array(nT)/q0))+1))))) - sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF_array(id_EF))./(kB*T_array(nT)/q0))+1)))));        
        Nd_signed(id_EF) = Nd(id_EF);
        Nd(id_EF) = abs(Nd(id_EF));
end


for id_EF = 1:size(EF_array,2) 
        Nd_temp = Nd_signed(id_EF); % impurities densities at 300 K, it does not change with the temperature
        
     for id_T = 1:size(T_array,2)
         EF_temp = EF_array(id_EF);
         
         Nd_new = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF_temp)./(kB*T_array(id_T)/q0))+1))))) - sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF_temp)./(kB*T_array(id_T)/q0))+1)))));
         carrier_sign = sign( Nd_new-Nd_temp );

         
         EF1 = EF_temp;
         EF2 = EF_temp + carrier_sign * kB*T_array(id_T)/q0; 
         EF0 = EF_temp - carrier_sign * kB*T_array(id_T)/q0;
         
         n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF0)./(kB*T_array(id_T)/q0))+1)))));
         n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF0)./(kB*T_array(id_T)/q0))+1)))));
         n0 = n_cond - n_val - Nd_temp;
         n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF1)./(kB*T_array(id_T)/q0))+1)))));
         n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF1)./(kB*T_array(id_T)/q0))+1)))));
         n1 = n_cond - n_val - Nd_temp;
         n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF2)./(kB*T_array(id_T)/q0))+1)))));
         n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF2)./(kB*T_array(id_T)/q0))+1)))));
         n2 = n_cond - n_val - Nd_temp;
         
         iF = 1;
         while n1*n2 > 0 && n0*n1 > 0
            iF = iF+1;
            EF2 = EF_temp + iF * carrier_sign * kB*T_array(id_T)/q0; 
            EF0 = EF_temp - iF * carrier_sign * kB*T_array(id_T)/q0;

            n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF0)./(kB*T_array(id_T)/q0))+1)))));
            n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF0)./(kB*T_array(id_T)/q0))+1)))));
            n0 = n_cond - n_val - Nd_temp;
            n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF2)./(kB*T_array(id_T)/q0))+1)))));
            n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF2)./(kB*T_array(id_T)/q0))+1)))));
            n2 = n_cond - n_val - Nd_temp;        
         end
         
%          Delta_N = abs(n1) / max([abs(n0),abs(n2)]);
         Delta_N = abs(n1) / Nd_temp;
         if isnan(Delta_N)
             Delta_N = 0;
         end
         
        while abs(Delta_N) > 0.004  % &&  abs(EF0 - EF2) > 0.0001 % || Delta_N < 0
            
            if n2*n1 < 0
                EFa = EF2;
                EFb = EF1;
                EFc = (EF2 + EF1)/2;
                v_EF = [EFa, EFb, EFc];
                EF2 = max( v_EF );
                EF0 = min( v_EF );
%                 v_EF(v_EF == EF0) = [];
%                 v_EF(v_EF == EF2) = [];
%                 EF1 = v_EF;
                for idd = 1:3
                    if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                        EF1 = v_EF(idd);
                    end
                end
            elseif n1*n0 < 0
                EFa = EF1;
                EFb = EF0;
                EFc = (EF1 + EF0)/2;
                v_EF = [EFa, EFb, EFc];
                EF2 = max( v_EF );
                EF0 = min( v_EF );
%                 v_EF(v_EF == EF0) = [];
%                 v_EF(v_EF == EF2) = [];
%                 EF1 = v_EF;
                for idd = 1:3
                    if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                        EF1 = v_EF(idd);
                    end
                end
            end
            
            
            n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF0)./(kB*T_array(id_T)/q0))+1)))));
            n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF0)./(kB*T_array(id_T)/q0))+1)))));
            n0 = n_cond - n_val - Nd_temp;
            n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF1)./(kB*T_array(id_T)/q0))+1)))));
            n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF1)./(kB*T_array(id_T)/q0))+1)))));
            n1 = n_cond - n_val - Nd_temp;
            n_val = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((-Ek(:,:,:,pseudovalence_bands)+EF2)./(kB*T_array(id_T)/q0))+1)))));
            n_cond = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,pseudoconduction_bands)-EF2)./(kB*T_array(id_T)/q0))+1)))));
            n2 = n_cond - n_val - Nd_temp;
            
            
             Delta_N = n1 / Nd_temp;
            
        end
       EF_matrix(id_EF,id_T) = EF1;
       
       N_imp_matrix(id_EF,id_T) = abs( Nd_temp + n1 );
     end
    
end
Nz = ~N_imp_matrix;
N_imp_matrix(Nz) = 1e6;

end