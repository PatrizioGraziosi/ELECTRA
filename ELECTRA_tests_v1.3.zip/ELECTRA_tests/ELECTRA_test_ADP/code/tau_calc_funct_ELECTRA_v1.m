% Copyright 2022 Patrizio Graziosi and Neophytos Neophytou                %
% A creation of Patrizio Graziosi and Neophytos Neophytou, developed by   %
% Patrizio Graziosi, patrizio.graziosi@gmail.com, during the              %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% The supervision of Neophytos Neophytou, University of Warwick, and      %
% computational ideas from Laura de Sousa Oliveira, University of Wyoming,%
% are greatly acknowledged.                                               %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source and the author when publishing results      %
% obtained  using the present  code                                       %
%                                                                         %
% ----------------------------------------------------------------------- %

% this is the default function that runs on parallel in the workers
% it runs for each iE,in couple

% part about overlap_integrals_analytical added on 4Dec.2019

% ADP at line  184, subfunction at line 1008
% ADP_IVS at line 257, subfunction at line 1029
% ODP at line 356, subfunction at line 1048
% POP at line 449, subfunction at line 1071
% IVS at line 530, subfunction at line 1048
% IIS at lines 619 and 651(inter-), subfunction at line 1188
% screened POP at line 705, subfunction at line 1272
% Alloy at line 864, subfunction at line 1128
% Matthiessen's rule applied at line 911


% For the general case with NON-labelled valleys/bands
function [tau_temp, tau_matth_temp, tau_IIS_temp, tau_POP_temp] = tau_calc_funct_ELECTRA_v1(iE, in, WorkSpace4 ) %#codegen


state_ID = WorkSpace4.state_ID ;           % state ID struct and quantities
Ek = WorkSpace4.Ek ;
E_array = WorkSpace4.E_array ;
T_array = WorkSpace4.T_array ;
EF_matrix = WorkSpace4.EF_matrix ;

Estep = WorkSpace4.Estep ;
scan_type = WorkSpace4.scan_type;

n_bands_transp = WorkSpace4.n_bands_transp ;
bands_transp = WorkSpace4.bands_transp ;
sd_array = WorkSpace4.sd_array ;

ADP = WorkSpace4.ADP ;                          % scattering instructions
ADP_IVS = WorkSpace4.ADP_IVS ;
Alloy = WorkSpace4.Alloy ;
ODP = WorkSpace4.ODP ;
POP = WorkSpace4.POP ;
screening_POP = WorkSpace4.screening_POP ;
IVS = WorkSpace4.IVS ;
IIS = WorkSpace4.IIS ;
IIS_interband_flag = WorkSpace4.IIS_interband_flag ;
Z_i = WorkSpace4.Z_i ;
overlap_integrals_analytical = WorkSpace4.overlap_integrals_analytical ;
k_restriction = WorkSpace4.k_restriction ;
if strcmp(k_restriction,'yes')
    k_restriction_cutoff = WorkSpace4.k_restriction_cutoff ;
end
semimetal = WorkSpace4.semimetal;

carriers = WorkSpace4.carriers ;
if strcmp(carriers,'electrons')
    carrier_appendix = 'e';
else
    carrier_appendix = 'h';
end
if strcmp(carriers,'electrons')
    overlap_integrals_analytical = 'no';
end
if strcmp(semimetal,'yes') 
    pseudovalence_bands = WorkSpace4.pseudovalence_bands ;
    if any(pseudovalence_bands(:) == bands_transp(in) ) 
    carriers = 'holes';
    end
end


hbar=(6.6261e-34)/(2*pi); % [J-sec]                  % physical constants
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
eps_0=8.85e-12;           % [F/m]


if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes') % scattering parameters, def. pot. e scatt. rate
    tau_pos_ADP = WorkSpace4.tau_pos_ADP ;    
    us_sound_vel = WorkSpace4.us_sound_vel ;
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'D_adp_e')
         D_adp = WorkSpace4.D_adp_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'D_adp_h')
         D_adp = WorkSpace4.D_adp_h ;
    elseif isfield(WorkSpace4,'D_adp')
        D_adp = WorkSpace4.D_adp ;
    end
end
if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes') || strcmp(ODP,'yes') || strcmp(IVS,'yes')
    rho_mass_density = WorkSpace4.rho_mass_density ;
end
if strcmp(ODP,'yes')
    tau_pos_ODP = WorkSpace4.tau_pos_ODP ;
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'D_odp_e')
        D_odp = WorkSpace4.D_odp_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'D_odp_h')
        D_odp = WorkSpace4.D_odp_h ;
    elseif isfield(WorkSpace4,'D_odp')
        D_odp = WorkSpace4.D_odp ;
    end   
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'hbar_w_odp_e')
        hbar_w_odp = WorkSpace4.hbar_w_odp_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'hbar_w_odp_h')
        hbar_w_odp = WorkSpace4.hbar_w_odp_h ;
    elseif isfield(WorkSpace4,'hbar_w_odp')
        hbar_w_odp = WorkSpace4.hbar_w_odp ;
    end
end
if strcmp(IVS,'yes')
    tau_pos_IVS = WorkSpace4.tau_pos_IVS ;
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'D_ivs_e')
        D_ivs = WorkSpace4.D_ivs_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'D_ivs_h')
        D_ivs = WorkSpace4.D_ivs_h ;
    elseif isfield(WorkSpace4,'D_ivs')
        D_ivs = WorkSpace4.D_ivs ;
    end   
    if strcmp(carriers,'electrons')&& isfield(WorkSpace4,'hbar_w_ivs_e')
        hbar_w_ivs = WorkSpace4.hbar_w_ivs_e ;
    elseif strcmp(carriers,'holes')&& isfield(WorkSpace4,'hbar_w_ivs_h')
        hbar_w_ivs = WorkSpace4.hbar_w_ivs_h ;
    elseif isfield(WorkSpace4,'hbar_w_ivs')
        hbar_w_ivs = WorkSpace4.hbar_w_ivs ;
    end
end
if strcmp(POP,'yes')
    tau_pos_POP = WorkSpace4.tau_pos_POP ;
    k_inf = WorkSpace4.k_inf ;
    k_s = WorkSpace4.k_s ;
    field_name = (['hbar_w_pop_',carrier_appendix]);                                    
    field_name2 = ('hbar_w_pop');
    if isfield(WorkSpace4,field_name)
        hbar_w_pop = WorkSpace4.(field_name) ;
    else
        hbar_w_pop = WorkSpace4.(field_name2) ;
    end
end
if strcmp(Alloy,'yes')
    tau_pos_Alloy = WorkSpace4.tau_pos_Alloy ;
    Vcell = WorkSpace4.Vcell ; 
    fraction = WorkSpace4.fraction ; 
    Delta_gap = WorkSpace4.Delta_gap ;
end
if strcmp(IIS,'yes') || strcmp(POP,'yes') || strcmp(Alloy,'yes') || strcmp(k_restriction,'yes') 
    Ga = WorkSpace4.Ga ;
    Gb = WorkSpace4.Gb ;
    Gc = WorkSpace4.Gc ;
    LD = WorkSpace4.LD ;
    k_s = WorkSpace4.k_s ;

    N_imp_matrix = WorkSpace4.N_imp_matrix;
end  

WF = WorkSpace4.WF ;
I_int = sum(WF(:,in).^2); % overlap integral between the states of that band


        if not(size(state_ID(iE,in).v_x)) == 0   % the state is not empty
            tau_temp = struct();                 % define an empty struct that will be eventualy filled 
            tau_temp.x = []; tau_temp.y = [] ; tau_temp.z = [];
            
            
            for iT = 1:size(T_array,2)  % TEMPERATURE loop
                EF_array = EF_matrix(:,iT)';
                if (E_array(iE) < max(EF_array)+6*kB*T_array(iT)/q0) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*T_array(iT)/q0 ) % it takes only the value inside 6kT from the maximum EF position or all the values inbetween the band edge and 5kT if the maximum EF is in the gap
%                     for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop

                            if strcmp(ADP,'yes')
                                tau_pos=tau_pos_ADP;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    
                                    if strcmp(overlap_integrals_analytical,'yes')
                                        angle = acos( (state_ID(iE,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,in).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
        ( sqrt(state_ID(iE,in).kx.^2+state_ID(iE,in).ky.^2+state_ID(iE,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                        I_int_f = I_int .* G_overlap;
                                    else
                                        I_int_f=I_int;
                                    end

                                    ADP_scatt_rate = pi*(D_adp.*q0).^2*(kB*T_array(iT))/(hbar*rho_mass_density*us_sound_vel^2) * 2; % combining both ABS and EMS


                                    [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp  ] = ...
                                        tau_ADP_funct(ADP_scatt_rate, q0, I_int_f, state_ID(iE,in).DOS, state_ID(iE,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,in).v_z, state_ID(iE,in).v_z(id_k));

                                    if strcmp(k_restriction,'yes')
                                        delta_k_array = sqrt((state_ID(iE,in).kx-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-state_ID(iE,in).kz(id_k)).^2);
                                    delta_Matrix = [delta_k_array;
                                        sqrt((state_ID(iE,in).kx+Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                        sqrt((state_ID(iE,in).kx-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,in).ky-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,in).kz-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2)];

    %                                     Npositive = (delta_k_array>0); % it finds everything but the initial state
    %                                     cutoff_distance = min(delta_k_array(Npositive)); % it finds the closest point to the initial state, closer points cannot exist in the used mesh

                                        q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
    %                                     Nlow = find(q_exchanged < cutoff_distance); % it finds the points where the exchanged vector is lower then the closest point, these are unphysical
    %                                     q_exchanged(Nlow) = delta_k_array(Nlow); % the exchanged vector for the points above is substituted with the initial one

                                        k_cutoff = mean([norm(Ga),norm(Gb),norm(Gc)]) * k_restriction_cutoff ;
                                        Ncutoff = find( q_exchanged < k_cutoff );
    %                                                     Ncutoff = ( q_exchanged(Ncutoff_1)>=0);
                                        tau_temp.x(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_x_temp(Ncutoff)) )^(-1);
                                        tau_temp.y(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_y_temp(Ncutoff)) )^(-1);
                                        tau_temp.z(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_z_temp(Ncutoff)) )^(-1);

                                    else

                                        tau_temp.x(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_x_temp) )^(-1);
                                        tau_temp.y(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_y_temp) )^(-1);
                                        tau_temp.z(tau_pos,id_k,iT) = ( 1/(2*pi)^3*sum(one_over_tau_z_temp) )^(-1);
                                    end
                                end
                            end % end of ADP
                            
                            if strcmp(ADP_IVS,'yes')  % ADP and ADP_IVS are mutually esclusive
                                tau_pos=tau_pos_ADP;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp=zeros(1,n_bands_transp); one_over_tau_y_temp=zeros(1,n_bands_transp); one_over_tau_z_temp=zeros(1,n_bands_transp);                                                            
                                    
                                    ADP_scatt_rate = pi*(D_adp.*q0).^2*(kB*T_array(iT))/(hbar*rho_mass_density*us_sound_vel^2) * 2; % combining both ABS and EMS
                                    
                                    for  id_n_final = 1:n_bands_transp
                                        
                                        if strcmp(overlap_integrals_analytical,'yes')
                                                    angle = acos( (state_ID(iE,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                    ( sqrt(state_ID(iE,id_n_final).kx.^2+state_ID(iE,id_n_final).ky.^2+state_ID(iE,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));
                                                    
                                                    if id_n_final == in
                                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                                    else 
                                                        G_overlap = 0.75 * sin(angle).^2;
                                                    end                                                   
                                        end
                                        
                                        if not(size(state_ID(iE,id_n_final).DOS)) == 0 
                                            if sd_array(in) == sd_array (id_n_final) 
                                                if isfield(WorkSpace4,'Z_f_adp') 
                                                     Z_f_adp = WorkSpace4.Z_f_adp ;
                                                else
                                                    Z_f_adp = ones(1,id_n_final);
                                                end 
                                                if size(Z_f_adp,2) < id_n_final
                                                    Z_f_adp = ones(1,id_n_final);
                                                end
                                                I_int_f=sum(WF(:,id_n_final).^2);
                                                if strcmp(overlap_integrals_analytical,'yes')
                                                    I_int_f = I_int_f .* G_overlap;
                                                end
                                                [ one_over_tau_x_temp_array,one_over_tau_y_temp_array,one_over_tau_z_temp_array ] = ...
                                            tau_ADP_IVS_funct(ADP_scatt_rate, q0, I_int_f, Z_f_adp(id_n_final), state_ID(iE,id_n_final).DOS, state_ID(iE,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,id_n_final).v_z, state_ID(iE,in).v_z(id_k));


                                                if strcmp(k_restriction,'yes')
                                                        delta_k_array = sqrt((state_ID(iE,id_n_final).kx-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-state_ID(iE,in).kz(id_k)).^2);
                                                    delta_Matrix = [delta_k_array;
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gb(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gb(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gb(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Ga(1)-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Ga(2)-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Ga(3)-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx+Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky+Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz+Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gb(1)+Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gb(2)+Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gb(3)+Gc(3)-state_ID(iE,in).kz(id_k)).^2);
                                                        sqrt((state_ID(iE,id_n_final).kx-Gb(1)-Gc(1)-state_ID(iE,in).kx(id_k)).^2+(state_ID(iE,id_n_final).ky-Gb(2)-Gc(2)-state_ID(iE,in).ky(id_k)).^2+(state_ID(iE,id_n_final).kz-Gb(3)-Gc(3)-state_ID(iE,in).kz(id_k)).^2)];

%                                                         Npositive = (delta_k_array>0); % it finds everything but the initial state
%                                                         cutoff_distance = min(delta_k_array(Npositive)); % it finds the closest point to the initial state, closer points cannot exist in the used mesh

                                                        q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
%                                                         Nlow = find(q_exchanged < cutoff_distance); % it finds the points where the exchanged vector is lower then the closest point, these are unphysical
%                                                         q_exchanged(Nlow) = delta_k_array(Nlow); % the exchanged vector for the points above is substituted with the initial one

                                                        k_cutoff = mean([norm(Ga),norm(Gb),norm(Gc)]) * k_restriction_cutoff ;
                                                        Ncutoff = find( q_exchanged < k_cutoff );
    %                                                     Ncutoff = ( q_exchanged(Ncutoff_1)>=0);

                                                        one_over_tau_x_temp(id_n_final) = real( 1/(2*pi)^3*sum(one_over_tau_x_temp_array(Ncutoff)) );
                                                        one_over_tau_y_temp(id_n_final) = real( 1/(2*pi)^3*sum(one_over_tau_y_temp_array(Ncutoff)) );
                                                        one_over_tau_z_temp(id_n_final) = real( 1/(2*pi)^3*sum(one_over_tau_z_temp_array(Ncutoff)) );

                                                else

                                                    one_over_tau_x_temp(id_n_final) = 1/(2*pi)^3*sum(one_over_tau_x_temp_array);
                                                    one_over_tau_y_temp(id_n_final) = 1/(2*pi)^3*sum(one_over_tau_y_temp_array);
                                                    one_over_tau_z_temp(id_n_final) = 1/(2*pi)^3*sum(one_over_tau_z_temp_array);
                                                end
                                            end
                                        end
                                    end
                                    
                                    tau_temp.x(tau_pos,id_k,iT) = (sum(one_over_tau_x_temp)).^(-1);% tau_pos is tau_pos_ADP, defined in tau_calc at any if clause about the scattering mechanisms
                                    tau_temp.y(tau_pos,id_k,iT) = (sum(one_over_tau_y_temp)).^(-1);
                                    tau_temp.z(tau_pos,id_k,iT) = (sum(one_over_tau_z_temp)).^(-1);
                                end
                            end % end of ADP_IVS
                                                
                            if strcmp(ODP,'yes')
                                tau_pos=tau_pos_ODP;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp_abs=zeros(1); one_over_tau_y_temp_abs=zeros(1); one_over_tau_z_temp_abs=zeros(1);                               
                                    one_over_tau_x_temp_ems=zeros(1); one_over_tau_y_temp_ems=zeros(1); one_over_tau_z_temp_ems=zeros(1);                                

                                    N_w=1./(exp(hbar_w_odp./(kB*T_array(iT)/q0))-1); % probability of finding phonons in a given state with a given energy hbar*w
                                    
                                    for id_process = size(hbar_w_odp,2):-1:1
                                        E_skip_points = floor(hbar_w_odp(id_process)/Estep)+1; % number of E points to be skipped, the Delta_Efi is implicit in the analysis of the DOS for the specific band
                                        
                                        for id_n_final = n_bands_transp:-1:1 % the carrier scatters everywhere (Phytos)
                                            field_name = (['Z_f_odp_',carrier_appendix]);                                    
                                            field_name2 = ('Z_f_odp');
                                            if isfield(WorkSpace4,field_name)
                                                Z_f_odp = WorkSpace4.(field_name) ;
                                            elseif isfield(WorkSpace4,field_name2)
                                                Z_f_odp = WorkSpace4.(field_name2) ;
                                            else
                                                Z_f_odp = ones(1,size(hbar_w_odp,2) ) ;
                                            end
                                                                                       
                                            % ABS, the phonon is absorbed, the energy increased
                                            if iE < (size(E_array,2)-E_skip_points) 
                                                if not(size(state_ID(iE+E_skip_points,id_n_final).DOS)) == 0 
                                                    if sd_array(in) == sd_array (id_n_final) % if the state is not empty
                                                    
                                                        I_int_f=sum(WF(:,id_n_final).^2);
                                                        if strcmp(overlap_integrals_analytical,'yes')
                                                            angle = acos( (state_ID(iE+E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                            ( sqrt(state_ID(iE+E_skip_points,id_n_final).kx.^2+state_ID(iE+E_skip_points,id_n_final).ky.^2+state_ID(iE+E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                            if id_n_final == in
                                                                G_overlap = 0.25*(1+3*cos(angle).^2);
                                                            else 
                                                                G_overlap = 0.75 * sin(angle).^2;
                                                            end
                                                            I_int_f = I_int_f .* G_overlap;
                                                        end

                                                        ODP_scatt_rate = pi * (D_odp(id_process)*q0)^2 ./...
                                                            (rho_mass_density * hbar_w_odp(id_process) * q0/hbar) * N_w(id_process);

                                                [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                            tau_ODP_funct(ODP_scatt_rate, q0, I_int_f, Z_f_odp(id_process), state_ID(iE+E_skip_points,id_n_final).DOS, state_ID(iE+E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                                        one_over_tau_x_temp_abs(id_process,id_n_final) = one_over_tau_x_temp; 
                                                        one_over_tau_y_temp_abs(id_process,id_n_final) = one_over_tau_y_temp;
                                                        one_over_tau_z_temp_abs(id_process,id_n_final) = one_over_tau_z_temp;
                                                    end
                                                end
                                            end
                                            
                                            % EMS, the phonon is emitted
                                            if iE > E_skip_points
                                                if not(size(state_ID(iE-E_skip_points,id_n_final).DOS)) == 0 
                                                    if sd_array(in) == sd_array (id_n_final) 

                                                        I_int_f=sum(WF(:,id_n_final).^2);
                                                        if strcmp(overlap_integrals_analytical,'yes')
                                                            angle = acos( (state_ID(iE-E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                            ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,id_n_final).ky.^2+state_ID(iE-E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                            if id_n_final == in
                                                                G_overlap = 0.25*(1+3*cos(angle).^2);
                                                            else 
                                                                G_overlap = 0.75 * sin(angle).^2;
                                                            end
                                                            I_int_f = I_int_f .* G_overlap;

                                                        end                                                    

                                                        ODP_scatt_rate = pi * (D_odp(id_process).*q0).^2 ./...
                                                            (rho_mass_density * hbar_w_odp(id_process) * q0/hbar) * (N_w(id_process)+1);

                                                        [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                            tau_ODP_funct(ODP_scatt_rate, q0, I_int_f, Z_f_odp(id_process), state_ID(iE-E_skip_points,id_n_final).DOS, state_ID(iE-E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                                        one_over_tau_x_temp_ems(id_process, id_n_final) = one_over_tau_x_temp; 
                                                        one_over_tau_y_temp_ems(id_process, id_n_final) = one_over_tau_y_temp;
                                                        one_over_tau_z_temp_ems(id_process, id_n_final) = one_over_tau_z_temp;
                                                    end                                                                                                       
                                                end
                                            end
                                        end % end of the final bands
                                    end % end of the processes
                                    
                                    tau_temp.x(tau_pos,id_k,iT) = (sum(sum(one_over_tau_x_temp_abs)) + sum(sum(one_over_tau_x_temp_ems)))^(-1); % sum of 1/tau for all the processes and all the bands
                                    tau_temp.y(tau_pos,id_k,iT) = (sum(sum(one_over_tau_y_temp_abs)) + sum(sum(one_over_tau_y_temp_ems)))^(-1);
                                    tau_temp.z(tau_pos,id_k,iT) = (sum(sum(one_over_tau_z_temp_abs)) + sum(sum(one_over_tau_z_temp_ems)))^(-1);
                                end
                            end % end of the ODP 
                            
                            if strcmp(POP,'yes') && strcmp(screening_POP,'no')
                                    tau_pos=tau_pos_POP;
                                    for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                        one_over_tau_x_temp_abs=zeros(1); one_over_tau_y_temp_abs=zeros(1); one_over_tau_z_temp_abs=zeros(1);
                                        one_over_tau_x_temp_ems=zeros(1); one_over_tau_y_temp_ems=zeros(1); one_over_tau_z_temp_ems=zeros(1);
                                    
                                                                
                                        N_w=1./(exp(hbar_w_pop./(kB*T_array(iT)/q0))-1); % probability of finding phonons in a given state with a given energy hbar*w
                                            
                                                for id_process = 1:size(hbar_w_pop,2)
                                                    E_skip_points = floor(hbar_w_pop(id_process)/Estep)+1; % number of E points to be skipped, the Delta_Efi is implicit in the analysis of the DOS for the specific band
                                                    for id_n_final = 1:n_bands_transp
%                                                         if id_n == id_n_final
                                                        if sd_array(in) == sd_array (id_n_final)  
                                                            % ABS, the phonon is absorbed, the energy increased
                                                            if iE < (size(E_array,2)-E_skip_points)
                                                                if not(size(state_ID(iE+E_skip_points,id_n_final).DOS)) == 0 % if the state is not empty  
                                                                    
                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE+E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE+E_skip_points,id_n_final).kx.^2+state_ID(iE+E_skip_points,id_n_final).ky.^2+state_ID(iE+E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));
                                                                        
                                                                        if id_n_final == in
                                                                            G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                        else 
                                                                            G_overlap = 0.75 * sin(angle).^2;
                                                                        end
                                                                        I_int_f = I_int_f .* G_overlap;
                                                                    end
                                                                    
                                                                    POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                        ./ eps_0 .* (1/k_inf-1/k_s) .* N_w(id_process);                                                                    
                                                                    
                                                                    [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                        tau_POP_funct(POP_scatt_rate, Ga, Gb, Gc, q0, I_int_f, state_ID(iE+E_skip_points,id_n_final).DOS, state_ID(iE+E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE+E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE+E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE+E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));
                                                    
                                                                    one_over_tau_x_temp_abs(id_process,id_n_final) = one_over_tau_x_temp; 
                                                                    one_over_tau_y_temp_abs(id_process,id_n_final) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_abs(id_process,id_n_final) = one_over_tau_z_temp;                                                                 
                                                                    
                                                                end
                                                            end
                                                            
                                                            % EMS, the phonon is emitted
                                                            if iE > E_skip_points
                                                                if not(size(state_ID(iE-E_skip_points,id_n_final).DOS)) == 0
                                                                    
                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE-E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,id_n_final).ky.^2+state_ID(iE-E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                        if id_n_final == in
                                                                            G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                        else 
                                                                            G_overlap = 0.75 * sin(angle).^2;
                                                                        end
                                                                        I_int_f = I_int_f .* G_overlap;
                                                                    end
                                                                    
                                                                    POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                        ./ eps_0 .* (1/k_inf-1/k_s) .* (N_w(id_process)+1);                                                                    
                                                                                                                                        
                                                                    [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                        tau_POP_funct(POP_scatt_rate, Ga, Gb, Gc, q0, I_int_f, state_ID(iE-E_skip_points,id_n_final).DOS, state_ID(iE-E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE-E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE-E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE-E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));
                                                    
                                                                    one_over_tau_x_temp_ems(id_process,id_n_final) = one_over_tau_x_temp; 
                                                                    one_over_tau_y_temp_ems(id_process,id_n_final) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_ems(id_process,id_n_final) = one_over_tau_z_temp;                                                                    
                                                                end
                                                            end
                                                        end
                                                    end % end of the final band loop
                                                end % end of the processes loop
                                                tau_temp.x(tau_pos,id_k,iT) = (sum(sum(one_over_tau_x_temp_abs)) + sum(sum(one_over_tau_x_temp_ems)))^(-1); % sum of 1/tau for all the processes and all the bands
                                                tau_temp.y(tau_pos,id_k,iT) = (sum(sum(one_over_tau_y_temp_abs)) + sum(sum(one_over_tau_y_temp_ems)))^(-1);
                                                tau_temp.z(tau_pos,id_k,iT) = (sum(sum(one_over_tau_z_temp_abs)) + sum(sum(one_over_tau_z_temp_ems)))^(-1);
                                    end
                            end  % end of the POP
                            
                            if strcmp(IVS,'yes')
                                tau_pos=tau_pos_IVS;
                                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp_abs=zeros(1); one_over_tau_y_temp_abs=zeros(1); one_over_tau_z_temp_abs=zeros(1);
                                    one_over_tau_x_temp_ems=zeros(1); one_over_tau_y_temp_ems=zeros(1); one_over_tau_z_temp_ems=zeros(1);                                
                            % ok for Si, Ge ... equivalent valleys, thus IVS is treated 
                            % as an intravalley scattering timed by the final number of final available valleys, as they are all equivalent
                            % TO BE AVOIDED when using also ODP in non-multivalleys as it already contains the inter-valley processes
                                                                
                                    field_name = (['Z_f_ivs_',carrier_appendix]);                                    
                                    field_name2 = ('Z_f_ivs');
                                    if isfield(WorkSpace4,field_name)
                                        Z_f_ivs = WorkSpace4.(field_name) ;
                                    elseif isfield(WorkSpace4,field_name2)
                                        Z_f_ivs = WorkSpace4.(field_name2) ;
                                    else
                                        Z_f_ivs = ones(1,size(hbar_w_ivs,2) ) ;
                                    end
                                    %                         
                                    N_w=1./(exp(hbar_w_ivs./(kB*T_array(iT)/q0))-1);
                                                                        
                                    for id_process = 1:size(hbar_w_ivs,2)
                                        E_skip_points = floor(hbar_w_ivs(id_process)/Estep)+1; % number of E points to be skipped
                                        
                                        % ABS, the phonon is absorbed, the energy increased
                                        if iE < (size(E_array,2)-E_skip_points)
                                            if not(size(state_ID(iE+E_skip_points,in).DOS)) == 0 % the final state isnot empty
                                                
                                                I_int_f = I_int; % equivalent valleys                                    
                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE+E_skip_points,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,in).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE+E_skip_points,in).kx.^2+state_ID(iE+E_skip_points,in).ky.^2+state_ID(iE+E_skip_points,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                G_overlap = 0.75 * sin(angle).^2;
                                                                I_int_f = I_int_f .* G_overlap;

                                                end
                                                
                                                IVS_scatt_rate = pi * (D_ivs(id_process).*q0).^2./...
                                                    (rho_mass_density*hbar_w_ivs(id_process)*q0/hbar)*N_w(id_process);
                                                                                                
                                                [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                                        tau_ODP_funct(IVS_scatt_rate, q0, I_int_f, Z_f_ivs(id_process), state_ID(iE+E_skip_points,in).DOS, state_ID(iE+E_skip_points,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,in).v_z, state_ID(iE,in).v_z(id_k));
                                                    
                                                one_over_tau_x_temp_abs(id_process) = one_over_tau_x_temp; 
                                                one_over_tau_y_temp_abs(id_process) = one_over_tau_y_temp;
                                                one_over_tau_z_temp_abs(id_process) = one_over_tau_z_temp;
                                                
                                            end
                                        end
                                        
                                        % EMS, the phonon is emitted
                                        if iE > E_skip_points
                                            if not(size(state_ID(iE-E_skip_points,in).DOS)) == 0
                                                
                                                I_int_f = I_int; % equivalent valleys                                    
                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                        angle = acos( (state_ID(iE-E_skip_points,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                    ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,in).ky.^2+state_ID(iE-E_skip_points,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                            G_overlap = 0.75 * sin(angle).^2;
                                                                        I_int_f = I_int_f .* G_overlap;
                                                end
                                                
                                                IVS_scatt_rate = pi * (D_ivs(id_process).*q0).^2./...
                                                    (rho_mass_density*hbar_w_ivs(id_process)*q0/hbar)*(N_w(id_process)+1);
                                                
                                                [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
                    tau_ODP_funct(IVS_scatt_rate, q0, I_int_f, Z_f_ivs(id_process), state_ID(iE-E_skip_points,in).DOS, state_ID(iE-E_skip_points,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,in).v_z, state_ID(iE,in).v_z(id_k));

                                                one_over_tau_x_temp_ems(id_process) = one_over_tau_x_temp; 
                                                one_over_tau_y_temp_ems(id_process) = one_over_tau_y_temp;
                                                one_over_tau_z_temp_ems(id_process) = one_over_tau_z_temp;
                                            end
                                        end
                                        
                                    end % end of the foor loop on the processes
                                    
                                    tau_temp.x(tau_pos,id_k,iT) = (sum(one_over_tau_x_temp_abs) + sum(one_over_tau_x_temp_ems))^(-1); % sum of 1/tau for all the processes 
                                    tau_temp.y(tau_pos,id_k,iT) = (sum(one_over_tau_y_temp_abs) + sum(one_over_tau_y_temp_ems))^(-1);
                                    tau_temp.z(tau_pos,id_k,iT) = (sum(one_over_tau_z_temp_abs) + sum(one_over_tau_z_temp_ems))^(-1);
                                end
                            end  % end of the IVS
                            
                            
% end of the impurity independent processes



                        if strcmp(IIS,'yes') && strcmp(IIS_interband_flag,'no')
                            for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                if strcmp(overlap_integrals_analytical,'yes')
                                    angle = acos( (state_ID(iE,in).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,in).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,in).kz.*state_ID(iE,in).kz(id_k)) ./ ...
        ( sqrt(state_ID(iE,in).kx.^2+state_ID(iE,in).ky.^2+state_ID(iE,in).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                    G_overlap = 0.25*(1+3*cos(angle).^2);

                                    I_int_f = I_int .* G_overlap;
                                else
                                    I_int_f = I_int;
                                end

                                N_imp_array = N_imp_matrix(:,iT) ;

                                IIS_scatt_rate = 2*pi/hbar*N_imp_array*q0^4/(k_s*eps_0)^2 * Z_i^2 ;

                                [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                        tau_IIS_funct(IIS_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE,in).DOS, state_ID(iE,in).kx, state_ID(iE,in).kx(id_k), state_ID(iE,in).ky, state_ID(iE,in).ky(id_k), state_ID(iE,in).kz, state_ID(iE,in).kz(id_k), state_ID(iE,in).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,in).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,in).v_z, state_ID(iE,in).v_z(id_k));

                                    tau_IIS_temp.x(:,iT,id_k)=tau_x_temp;
                                    tau_IIS_temp.y(:,iT,id_k)=tau_y_temp;
                                    tau_IIS_temp.z(:,iT,id_k)=tau_z_temp;
                            end
                                
                        elseif strcmp(IIS,'no')  
                                tau_IIS_temp.x=[];
                                tau_IIS_temp.y=[];
                                tau_IIS_temp.z=[];
                        end                               % end of the IIS

                                                
                        if strcmp(IIS,'yes') && strcmp(IIS_interband_flag,'yes')
                            for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                               for  id_n_final = 1:n_bands_transp

                                    if strcmp(overlap_integrals_analytical,'yes')
                                        angle = acos( (state_ID(iE,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
            ( sqrt(state_ID(iE,id_n_final).kx.^2+state_ID(iE,id_n_final).ky.^2+state_ID(iE,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                    else
                                        G_overlap = 1;
                                    end

                                    if not(size(state_ID(iE,id_n_final).DOS)) == 0 
                                        if sd_array(in) == sd_array (id_n_final) % if the state is not empty
                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                    if strcmp(overlap_integrals_analytical,'yes')
                                                        I_int_f = I_int_f .* G_overlap;
                                                    end

                                    N_imp_array = N_imp_matrix(:,iT) ;

                                    IIS_scatt_rate = 2*pi/hbar*N_imp_array*q0^4/(k_s*eps_0)^2 * Z_i^2 ;

                                    [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                            tau_IIS_funct(IIS_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE,id_n_final).DOS, state_ID(iE,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                            tau_IIS_band.x(:,id_n_final)=tau_x_temp;
                                            tau_IIS_band.y(:,id_n_final)=tau_y_temp;
                                            tau_IIS_band.z(:,id_n_final)=tau_z_temp;
                                        else
                                            tau_IIS_band.x(:,id_n_final)=Inf(size(EF_array,2),1);
                                            tau_IIS_band.y(:,id_n_final)=Inf(size(EF_array,2),1);
                                            tau_IIS_band.z(:,id_n_final)=Inf(size(EF_array,2),1);
                                        end
                                    else
                                        tau_IIS_band.x(:,id_n_final)=Inf(size(EF_array,2),1);
                                        tau_IIS_band.y(:,id_n_final)=Inf(size(EF_array,2),1);
                                        tau_IIS_band.z(:,id_n_final)=Inf(size(EF_array,2),1);
                                    end
                               end

                                tau_IIS_temp.x(:,iT,id_k) = 1./sum(1./tau_IIS_band.x,2);
                                tau_IIS_temp.y(:,iT,id_k) = 1./sum(1./tau_IIS_band.y,2);
                                tau_IIS_temp.z(:,iT,id_k) = 1./sum(1./tau_IIS_band.z,2);
                            end
                            
                        elseif strcmp(IIS,'no')  
                                tau_IIS_temp.x=[];
                                tau_IIS_temp.y=[];
                                tau_IIS_temp.z=[]; 
                        end                      % end of the IIS interband
                  
                        
                        if strcmp(screening_POP,'yes') && strcmp(POP,'yes') 
                            for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop
                                    one_over_tau_x_temp_abs = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_y_temp_abs = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_z_temp_abs = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_x_temp_ems = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_y_temp_ems = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                    one_over_tau_z_temp_ems = zeros(size(hbar_w_pop,2),n_bands_transp,size(EF_array,2));
                                                                                                                                             
                                                                                                                       
                                            N_w=1./(exp(hbar_w_pop./(kB*T_array(iT)/q0))-1); % probability of finding phonons in a given state with a given energy hbar*w
                                            for id_process = 1:size(hbar_w_pop,2)
                                                E_skip_points = floor(hbar_w_pop(id_process)/Estep)+1; % number of E points to be skipped, the Delta_Efi is implicit in the analysis of the DOS for the specific band
                                                for id_n_final = 1:n_bands_transp
                                                    if sd_array(in) == sd_array (id_n_final) % the transition between the valleys is permitted
%                                                         if id_n == id_n_final

                                                        % ABS, the phonon is absorbed, the energy increased
                                                        if iE < (size(E_array,2)-E_skip_points)
                                                            if not(size(state_ID(iE+E_skip_points,id_n_final).DOS)) == 0 % if the state is not empty  

                                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                    angle = acos( (state_ID(iE+E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE+E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE+E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                ( sqrt(state_ID(iE+E_skip_points,id_n_final).kx.^2+state_ID(iE+E_skip_points,id_n_final).ky.^2+state_ID(iE+E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if id_n_final == in
                                                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                    else 
                                                                        G_overlap = 0.75 * sin(angle).^2;
                                                                    end
                                                                    I_int_f = I_int_f .* G_overlap;
                                                                end

                                                                POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                    ./ eps_0 .* (1/k_inf-1/k_s) .* N_w(id_process);
                                                                
                                                                [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp ] = ...
                                                                        tau_screenedPOP_funct(POP_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE+E_skip_points,id_n_final).DOS, state_ID(iE+E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE+E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE+E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE+E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE+E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE+E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                                                                    one_over_tau_x_temp_abs(id_process,id_n_final,:) = one_over_tau_x_temp; % arrays of the size of the Fermi array
                                                                    one_over_tau_y_temp_abs(id_process,id_n_final,:) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_abs(id_process,id_n_final,:) = one_over_tau_z_temp;                                                               
                                                            end
                                                        end
                                                        % EMS, the phonon is emitted
                                                        if iE > E_skip_points
                                                            if not(size(state_ID(iE-E_skip_points,id_n_final).DOS)) == 0

                                                                if strcmp(overlap_integrals_analytical,'yes')
                                                                    angle = acos( (state_ID(iE-E_skip_points,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE-E_skip_points,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE-E_skip_points,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                                ( sqrt(state_ID(iE-E_skip_points,id_n_final).kx.^2+state_ID(iE-E_skip_points,id_n_final).ky.^2+state_ID(iE-E_skip_points,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                                                    I_int_f=sum(WF(:,id_n_final).^2);
                                                                    if id_n_final == in
                                                                        G_overlap = 0.25*(1+3*cos(angle).^2);
                                                                    else 
                                                                        G_overlap = 0.75 * sin(angle).^2;
                                                                    end
                                                                    I_int_f = I_int_f .* G_overlap;
                                                                end

                                                                POP_scatt_rate = pi * q0^2 * (hbar_w_pop(id_process) * q0/hbar)...        
                                                                    ./ eps_0 .* (1/k_inf-1/k_s) .* (N_w(id_process)+1);
                                                                
                                                                [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp ] = ...
                                                                        tau_screenedPOP_funct(POP_scatt_rate, EF_array, iT, LD, Ga, Gb, Gc, q0, I_int_f, state_ID(iE-E_skip_points,id_n_final).DOS, state_ID(iE-E_skip_points,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE-E_skip_points,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE-E_skip_points,id_n_final).kz, state_ID(iE,in).kz(id_k), state_ID(iE-E_skip_points,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE-E_skip_points,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE-E_skip_points,id_n_final).v_z, state_ID(iE,in).v_z(id_k));
                                                                    
                                                                    one_over_tau_x_temp_ems(id_process,id_n_final,:) = one_over_tau_x_temp; % arrays of the size of the Fermi array
                                                                    one_over_tau_y_temp_ems(id_process,id_n_final,:) = one_over_tau_y_temp;
                                                                    one_over_tau_z_temp_ems(id_process,id_n_final,:) = one_over_tau_z_temp;                                                                    
                                                            end
                                                        end
                                                    end
                                                end % end of the final band loop
                                            end % end of the processes loop
                                            if n_bands_transp > 1
                                            tau_POP_temp.x(:,iT,id_k) = sum(squeeze(sum((sum((one_over_tau_x_temp_abs + one_over_tau_x_temp_ems),1)),1))).^(-1); % sum of 1/tau for all the processes and all the final bands
                                            tau_POP_temp.y(:,iT,id_k) = sum(squeeze(sum((sum((one_over_tau_y_temp_abs + one_over_tau_y_temp_ems),1)),1))).^(-1);
                                            tau_POP_temp.z(:,iT,id_k) = sum(squeeze(sum((sum((one_over_tau_z_temp_abs + one_over_tau_z_temp_ems),1)),1))).^(-1);
                                            else                                               
                                            tau_POP_temp.x(:,iT,id_k) = (squeeze(sum((sum((one_over_tau_x_temp_abs + one_over_tau_x_temp_ems),1)),1))).^(-1); % sum of 1/tau for all the processes and all the final bands
                                            tau_POP_temp.y(:,iT,id_k) = (squeeze(sum((sum((one_over_tau_y_temp_abs + one_over_tau_y_temp_ems),1)),1))).^(-1);
                                            tau_POP_temp.z(:,iT,id_k) = (squeeze(sum((sum((one_over_tau_z_temp_abs + one_over_tau_z_temp_ems),1)),1))).^(-1);
                                            end 
                                            
%                                             control over the taus as they are not used to compose the Matthiessen's
%                                             taus and would skip the control there
                                            NNan=isnan(tau_POP_temp.x);
                                            tau_POP_temp.x(NNan)=0;
                                            NNan=isnan(tau_POP_temp.y);
                                            tau_POP_temp.y(NNan)=0;
                                            NNan=isnan(tau_POP_temp.z);
                                            tau_POP_temp.z(NNan)=0;
                                            NInf=isinf(tau_POP_temp.x);
                                            tau_POP_temp.x(NInf)=0;
                                            NInf=isinf(tau_POP_temp.y);
                                            tau_POP_temp.y(NInf)=0;
                                            NInf=isinf(tau_POP_temp.z);
                                            tau_POP_temp.z(NInf)=0;

                            end     
                        elseif strcmp(screening_POP,'no')  
                                tau_POP_temp.x=[];
                                tau_POP_temp.y=[];
                                tau_POP_temp.z=[];
                        end                      % end of the screened POP

                        
%                     end % end of the for loop on the k points
                    
                    
                    % removing the noise spikes
                    if strcmp(scan_type,'DT')
                        n_c = 1;
                    else
                        n_c = 4;
                    end
                    
                    if strcmp(POP,'yes') && strcmp(screening_POP,'no')  
                        Ax = tau_temp.x(tau_pos_POP,:,iT);
                        Ay = tau_temp.y(tau_pos_POP,:,iT);
                        Az = tau_temp.z(tau_pos_POP,:,iT);
                        tau_temp.x(tau_pos_POP,:,iT) = smooth(Ax,'rlowess') ;
                        tau_temp.y(tau_pos_POP,:,iT) = smooth(Ay,'rlowess') ;
                        tau_temp.z(tau_pos_POP,:,iT) = smooth(Az,'rlowess') ;                        
                    end
                    
                    for ii_EF = 1:size(EF_matrix,1) 
                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes') && isempty(tau_POP_temp.x) == 0
                            Ax = squeeze(tau_POP_temp.x(ii_EF,iT,:))' ;
                            Ay = squeeze(tau_POP_temp.y(ii_EF,iT,:))' ;
                            Az = squeeze(tau_POP_temp.z(ii_EF,iT,:))' ;
                            
                            threshold_level = 2 ;
                            [Ax,Ay,Az] = denoise(Ax,Ay,Az, threshold_level, n_c) ;                           
                            
                            tau_POP_temp.x(ii_EF,iT,:) = smooth(Ax,7) ; %Ax ;
                            tau_POP_temp.y(ii_EF,iT,:) = smooth(Ay,7) ; %Ay ;
                            tau_POP_temp.z(ii_EF,iT,:) = smooth(Az,7) ; %Az ;
                        end
                        
                        if strcmp(IIS,'yes') && isempty(tau_IIS_temp.x) == 0
                            Ax = squeeze(tau_IIS_temp.x(ii_EF,iT,:))' ;
                            Ay = squeeze(tau_IIS_temp.y(ii_EF,iT,:))' ;
                            Az = squeeze(tau_IIS_temp.z(ii_EF,iT,:))' ;
                            
                            threshold_level = 2 ;
                            [Ax,Ay,Az] = denoise(Ax,Ay,Az, threshold_level, n_c) ;
                                                        
                            tau_IIS_temp.x(ii_EF,iT,:) = smooth(Ax,7) ;%smooth(Ax,'rlowess', np_s) ; % smooth(Ax,3) ;
                            tau_IIS_temp.y(ii_EF,iT,:) = smooth(Ay,7) ;
                            tau_IIS_temp.z(ii_EF,iT,:) = smooth(Az,7) ;
                        end
                    end
                                        
                end % end of the if clause on the energy extension
            end % end of the loop on the temperature
            
            if strcmp(Alloy,'yes')  % intra- and inter- 
                tau_pos=tau_pos_Alloy;
                for id_k = 1:size(state_ID(iE,in).v_x,2) % k-points loop

                    tau_x_temp_array = Inf(1,n_bands_transp);
                    tau_y_temp_array = Inf(1,n_bands_transp);
                    tau_z_temp_array = Inf(1,n_bands_transp);
                    for  id_n_final = 1:n_bands_transp
                        if sd_array(in) == sd_array (id_n_final)
                            if not(size(state_ID(iE,id_n_final).DOS)) == 0 

                            if strcmp(overlap_integrals_analytical,'yes')
                                angle = acos( (state_ID(iE,id_n_final).kx.*state_ID(iE,in).kx(id_k)+state_ID(iE,id_n_final).ky.*state_ID(iE,in).ky(id_k)+state_ID(iE,id_n_final).kz.*state_ID(iE,in).kz(id_k)) ./ ...
                            ( sqrt(state_ID(iE,id_n_final).kx.^2+state_ID(iE,id_n_final).ky.^2+state_ID(iE,id_n_final).kz.^2) * sqrt(state_ID(iE,in).kx(id_k)^2+state_ID(iE,in).ky(id_k)^2+state_ID(iE,in).kz(id_k)^2)));

                                G_overlap = 0.25*(1+3*cos(angle).^2);
                                I_int_f = I_int .* G_overlap;
                            else
                                I_int_f=I_int;
                            end

                            alloy_scatt_rate = 2*pi/hbar * Vcell * fraction*(1-fraction) * (Delta_gap.*q0).^2 ;
                            Ra = ( 3/( 4*pi ) * Vcell )^(1/3);

                            [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                        tau_alloy_funct(alloy_scatt_rate, Ra, Ga, Gb, Gc, q0, I_int_f, state_ID(iE,id_n_final).DOS, ...
                                        state_ID(iE,id_n_final).kx, state_ID(iE,in).kx(id_k), state_ID(iE,id_n_final).ky, state_ID(iE,in).ky(id_k), state_ID(iE,id_n_final).kz, state_ID(iE,in).kz(id_k), ...
                                        state_ID(iE,id_n_final).v_x, state_ID(iE,in).v_x(id_k), state_ID(iE,id_n_final).v_y, state_ID(iE,in).v_y(id_k), state_ID(iE,id_n_final).v_z, state_ID(iE,in).v_z(id_k));

                            tau_x_temp_array(id_n_final)=tau_x_temp;
                            tau_y_temp_array(id_n_final)=tau_y_temp;
                            tau_z_temp_array(id_n_final)=tau_z_temp;
                            end
                        end
                    end
                    for iT = 1:size(T_array,2)
                        EF_array = EF_matrix(:,iT)';
                        if (E_array(iE) < max(EF_array)+6*kB*T_array(iT)/q0) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*T_array(iT)/q0 ) 
                                tau_temp.x(tau_pos,id_k,iT)=1./sum(1./tau_x_temp_array);
                                tau_temp.y(tau_pos,id_k,iT)=1./sum(1./tau_y_temp_array);
                                tau_temp.z(tau_pos,id_k,iT)=1./sum(1./tau_z_temp_array);
                        end
                    end
                end
            end
          
            
        % the Matthiessen rule is applied at any k point, the IIS is NOT INCLUDED
        % the taus has dimensions (tau_pos,id_k,id_T), 
        % 1st dim. is the scattering mechanism, 
        % 2nd dim. is the k point, 
        % 3rd dim. is the temperature        
            if isempty(tau_temp.x) == 0    % tau_temp exists
                
                Ax = tau_temp.x ;
                Ay = tau_temp.y ;
                Az = tau_temp.z ;
                NNan = isnan(Ax) ;
                Ax(NNan) = Inf ; 
                NNan = isnan(Ay) ;
                Ay(NNan) = Inf; 
                NNan = isnan(Az) ;
                Az(NNan) = Inf;
                [r,c] = find( Ax == 0 );
                Ax(r,c) = Inf ;
                [r,c] = find (Ay == 0 ) ;
                Ay(r,c) = Inf ;
                [r,c] = find(Az == 0 ) ;
                Az(r,c) = Inf ;
                
                tau_temp.x = Ax ;
                tau_temp.y = Ay ;
                tau_temp.z = Az ;

                    tau_temp_x = 1./squeeze(sum(1./tau_temp.x,1)); % sums along the different mechanisms for same k point
                    tau_temp_y = 1./squeeze(sum(1./tau_temp.y,1));
                    tau_temp_z = 1./squeeze(sum(1./tau_temp.z,1));

                    if size(T_array,2) == 1

                        tau_matth_temp.x = tau_temp_x ; % array of taus, one for each k point, sums run along the vertical direction (scatt mechanism)
                        tau_matth_temp.y = tau_temp_y ; % array of taus, one for each k point
                        tau_matth_temp.z = tau_temp_z ; % array of taus, one for each k point
                    else
                        for iT=1:size(T_array,2) % PAY ATTENTION TO THE INDEX!!
                            if (E_array(iE) < max(EF_array)+6*kB*T_array(iT)/q0) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(in))))) && E_array(iE) < min(min(min(Ek(:,:,:,bands_transp(in))))) + 6*kB*T_array(iT)/q0 ) 
                                % it takes only the value inside 6kT from the maximum EF position or all the values inbetween the band edge and 5kT if the maximum EF is in the gap
                                tau_matth_temp.x(:,iT) = tau_temp_x(:,iT) ; % array of taus, one for each k point, sums run along the vertical direction (scatt mechanism)
                                tau_matth_temp.y(:,iT) = tau_temp_y(:,iT) ; % array of taus, one for each k point
                                tau_matth_temp.z(:,iT) = tau_temp_z(:,iT) ; % array of taus, one for each k point
                            end
                        end
                    end
                        NNan=isnan(tau_matth_temp.x);
                        tau_matth_temp.x(NNan)=0;
                        NNan=isnan(tau_matth_temp.y);
                        tau_matth_temp.y(NNan)=0;
                        NNan=isnan(tau_matth_temp.z);
                        tau_matth_temp.z(NNan)=0;
                        NInf=isinf(tau_matth_temp.x);
                        tau_matth_temp.x(NInf)=0;
                        NInf=isinf(tau_matth_temp.y);
                        tau_matth_temp.y(NInf)=0;
                        NInf=isinf(tau_matth_temp.z);
                        tau_matth_temp.z(NInf)=0;

                                            
            else % we assign empty value at tau_temp
                tau_temp.x = [];
                tau_temp.y = [];
                tau_temp.z = [];
                tau_matth_temp.x = [];
                tau_matth_temp.y = [];
                tau_matth_temp.z = [];
                tau_IIS_temp.x = [];
                tau_IIS_temp.y = [];
                tau_IIS_temp.z = [];
                tau_POP_temp.x = [];
                tau_POP_temp.y = [];
                tau_POP_temp.z = [];

            end
        
        else % the state is empty
                tau_temp.x = [];
                tau_temp.y = [];
                tau_temp.z = [];
                tau_matth_temp.x = [];
                tau_matth_temp.y = [];
                tau_matth_temp.z = [];
                tau_IIS_temp.x = [];
                tau_IIS_temp.y = [];
                tau_IIS_temp.z = [];
                tau_POP_temp.x = [];
                tau_POP_temp.y = [];
                tau_POP_temp.z = [];

        end
end


% -----------------------------------------------------------------------
% sub-functions for the scatt. mechanisms

% the ADP function, it gives arrays of 1/taus for eah k state
% only INTRA-band
function [ one_over_tau_x_temp,one_over_tau_y_temp,one_over_tau_z_temp ] = ...
    tau_ADP_funct(Skk, e, I, DOS, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)


    one_over_tau_x_temp = Skk .* DOS./e .* I .* (1 - v_x./v_x_k);
    NNan = isnan(one_over_tau_x_temp); one_over_tau_x_temp(NNan) = 0;
    NInf = isinf(one_over_tau_x_temp); one_over_tau_x_temp(NInf) = 0;
        
    one_over_tau_y_temp = Skk .* DOS./e .* I .* (1 - v_y./v_y_k);
    NNan = isnan(one_over_tau_y_temp); one_over_tau_y_temp(NNan) = 0;
    NInf = isinf(one_over_tau_y_temp); one_over_tau_y_temp(NInf) = 0;
        
    one_over_tau_z_temp = Skk .* DOS./e .* I .* (1 - v_z./v_z_k);
    NNan = isnan(one_over_tau_z_temp); one_over_tau_z_temp(NNan) = 0;
    NInf = isinf(one_over_tau_z_temp); one_over_tau_z_temp(NInf) = 0;
           
end


% the ADP_IVS function 
function [ one_over_tau_x_temp_array,one_over_tau_y_temp_array,one_over_tau_z_temp_array ] = ...
                                    tau_ADP_IVS_funct(Skk, e, I, z, DOSf, vf_x, v_x_k, vf_y, v_y_k, vf_z, v_z_k)
                                
    one_over_tau_x_temp_array = z .* Skk .* DOSf./e .* I .* (1 - vf_x./v_x_k); 
    NNan = isnan(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NInf) = 0;

    one_over_tau_y_temp_array = z .* Skk .* DOSf./e .* I .* (1 - vf_y./v_y_k);
    NNan = isnan(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NInf) = 0;
    
    one_over_tau_z_temp_array = z .* Skk .* DOSf./e .* I .* (1 - vf_z./v_z_k);
    NNan = isnan(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NInf) = 0;
   
end


% the ODP and IVS function
function [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp] = ...
                                        tau_ODP_funct(Skk, e, I, z, DOSf, vf_x, v_x_k, vf_y, v_y_k, vf_z, v_z_k)
       
    one_over_tau_temp_array = z .* Skk .* DOSf./e .* I .* (1-vf_x./v_x_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_x_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array); % integral over all the k' points
    
    one_over_tau_temp_array = z .* Skk .* DOSf./e .* I .* (1-vf_y./v_y_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_y_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
    
    one_over_tau_temp_array = z .* Skk .* DOSf./e .* I .* (1-vf_z./v_z_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_z_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
                                   
end                           


% the POP function
function [ one_over_tau_x_temp, one_over_tau_y_temp, one_over_tau_z_temp ] = ...
    tau_POP_funct(Skk, g1, g2, g3, e, I, DOSf, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, vf_x, v_x_k, vf_y, v_y_k, vf_z, v_z_k)


% this finds the points that have a closer symmetrical one in a neighbour
    % reciprocal u.c. and shifts the exchanged vector
    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];

q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector


    one_over_tau_temp_array = Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-vf_x./v_x_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_x_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
    
    one_over_tau_temp_array = Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-vf_y./v_y_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_y_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
    
    one_over_tau_temp_array = Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-vf_z./v_z_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    one_over_tau_z_temp = 1/(2*pi)^3 .* sum(one_over_tau_temp_array);
        
end


% the alloy scattering sub function w Gq
function [ tau_x_temp, tau_y_temp, tau_z_temp ] = ...
                                    tau_alloy_funct(Skk,  Ra, g1, g2, g3, e, I, DOS, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)
  

    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];

  
    q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector
 
    % the form factor function G_q    
    G_q = 3.*( sin(q_exchanged.*Ra) - (q_exchanged.*Ra).*cos(q_exchanged.*Ra) ) ./ (q_exchanged.*Ra).^3 ;
    
    % Skk = 2pi/hbar * (x(1-x)) * Delta_Egap^2
        
    one_over_tau_temp_array = Skk .* G_q.^2 .* DOS./e .* I .* (1 - v_x./v_x_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    tau_x_temp = ( 1/(2*pi)^3*sum(one_over_tau_temp_array) )^(-1);
    
    one_over_tau_temp_array = Skk .* G_q .* DOS./e .* I .* (1 - v_y./v_y_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    tau_y_temp = ( 1/(2*pi)^3*sum(one_over_tau_temp_array) )^(-1);
    
    one_over_tau_temp_array = Skk .* G_q .* DOS./e .* I .* (1 - v_z./v_z_k);
    NNan = isnan(one_over_tau_temp_array); one_over_tau_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_temp_array); one_over_tau_temp_array(NInf) = 0;
    tau_z_temp = ( 1/(2*pi)^3*sum(one_over_tau_temp_array) )^(-1);
  end


% the IIS function
function [ tau_x_temp,tau_y_temp,tau_z_temp ] = ...
                                    tau_IIS_funct(Skk, Fermi, T, Lsc, g1, g2, g3, e, I, DOS, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)
  
    % this finds the points that have a closer symmetrical one in a neighbour
    % reciprocal u.c. and shifts the exchanged vector
    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];


q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector

tau_x_temp = zeros(1,size(Fermi,2)); tau_y_temp = zeros(1,size(Fermi,2)); 
tau_z_temp = zeros(1,size(Fermi,2)); 
for iEF = 1:size(Fermi,2)

    one_over_tau_x_temp_array = Skk(iEF) .* DOS./e .* I .* (1-v_x./v_x_k) ./...
            ( (q_exchanged.^2 + 1/Lsc(iEF,T).^2).^2 );
    NNan = isnan(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_x_temp_array); one_over_tau_x_temp_array(NInf) = 0;

    one_over_tau_y_temp_array = Skk(iEF) .* DOS./e .* I .* (1-v_y./v_y_k) ./...
            ( (q_exchanged.^2 + 1/Lsc(iEF,T).^2).^2 );
    NNan = isnan(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_y_temp_array); one_over_tau_y_temp_array(NInf) = 0;

    one_over_tau_z_temp_array = Skk(iEF) .* DOS./e .* I .* (1-v_z./v_z_k) ./...
            ( (q_exchanged.^2 + 1/Lsc(iEF,T).^2).^2 );
    NNan = isnan(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NNan) = 0;
    NInf = isinf(one_over_tau_z_temp_array); one_over_tau_z_temp_array(NInf) = 0;
        
       
        
%     it creates an array of taus for each impurity concentration (row)
        tau_x_temp(iEF) = (sum(1/(2*pi)^3.*one_over_tau_x_temp_array))^(-1); % the integration element dSk is already in the DOS
        tau_y_temp(iEF) = (sum(1/(2*pi)^3.*one_over_tau_y_temp_array))^(-1); 
        tau_z_temp(iEF) = (sum(1/(2*pi)^3.*one_over_tau_z_temp_array))^(-1);

end

% control over the tau_IIS as they are not used to compose the Matthiessen's
% taus and would skip the control there
NNan=isnan(tau_x_temp);
tau_x_temp(NNan)=0;
NNan=isnan(tau_y_temp);
tau_y_temp(NNan)=0;
NNan=isnan(tau_z_temp);
tau_z_temp(NNan)=0;
NInf=isinf(tau_x_temp);
tau_x_temp(NInf)=0;
NInf=isinf(tau_y_temp);
tau_y_temp(NInf)=0;
NInf=isinf(tau_z_temp);
tau_z_temp(NInf)=0;
end


% the screened POP function, the 1/tau are summed here
function [ oneovertau_x_temp_array,oneovertau_y_temp_array,oneovertau_z_temp_array ] = ...
                                    tau_screenedPOP_funct(Skk, Fermi, T, Lsc, g1, g2, g3, e, I, DOSf, kf_x, kx_k, kf_y, ky_k, kf_z, kz_k, v_x, v_x_k, v_y, v_y_k, v_z, v_z_k)

                                
    % this finds the points that have a closer symmetrical one in a neighbour
    % reciprocal u.c. and shifts the exchanged vector
    delta_k_array = sqrt((kf_x-kx_k).^2+(kf_y-ky_k).^2+(kf_z-kz_k).^2);
    % G is imported from tau_calc as Ga, Gb, Gc that read as g1, g2, g3
    delta_Matrix = [delta_k_array;
    sqrt((kf_x+g1(1)-kx_k).^2+(kf_y+g1(2)-ky_k).^2+(kf_z+g1(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-kx_k).^2+(kf_y+g2(2)-ky_k).^2+(kf_z+g2(3)-kz_k).^2);
    sqrt((kf_x+g3(1)-kx_k).^2+(kf_y+g3(2)-ky_k).^2+(kf_z+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y+g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z+g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-kx_k).^2+(kf_y-g1(2)-ky_k).^2+(kf_z-g1(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-kx_k).^2+(kf_y-g2(2)-ky_k).^2+(kf_z-g2(3)-kz_k).^2);
    sqrt((kf_x-g3(1)-kx_k).^2+(kf_y-g3(2)-ky_k).^2+(kf_z-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)+g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)+g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)+g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)+g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g1(1)-g2(1)-g3(1)-kx_k).^2+(kf_y-g1(2)-g2(2)-g3(2)-ky_k).^2+(kf_z-g1(3)-g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)+g3(1)-kx_k).^2+(kf_y+g2(2)+g3(2)-ky_k).^2+(kf_z+g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x+g2(1)-g3(1)-kx_k).^2+(kf_y+g2(2)-g3(2)-ky_k).^2+(kf_z+g2(3)-g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)+g3(1)-kx_k).^2+(kf_y-g2(2)+g3(2)-ky_k).^2+(kf_z-g2(3)+g3(3)-kz_k).^2);
    sqrt((kf_x-g2(1)-g3(1)-kx_k).^2+(kf_y-g2(2)-g3(2)-ky_k).^2+(kf_z-g2(3)-g3(3)-kz_k).^2)];


q_exchanged = min(delta_Matrix,[],1); % exchanged wave vector

oneovertau_x_temp_array = ones(1,size(Fermi,2)); oneovertau_y_temp_array = ones(1,size(Fermi,2)); oneovertau_z_temp_array = ones(1,size(Fermi,2));
for iEF = size(Fermi,2):-1:1

    temp_array = ( Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-v_x./v_x_k) ./...
            ( (1 + 1./q_exchanged.^2 * 1./ Lsc(iEF,T).^2).^2 ) );
    NNan = isnan(temp_array); temp_array(NNan) = 0;
    NInf = isinf(temp_array); temp_array(NInf) = 0;
    oneovertau_x_temp_array(iEF) = 1/(2*pi)^3 * sum(temp_array);

    temp_array = ( Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-v_y./v_y_k) ./...
            ( (1 + 1./q_exchanged.^2 * 1./ Lsc(iEF,T).^2).^2 ) );
    NNan = isnan(temp_array); temp_array(NNan) = 0;
    NInf = isinf(temp_array); temp_array(NInf) = 0;
    oneovertau_y_temp_array(iEF) = 1/(2*pi)^3 * sum(temp_array);

    temp_array = ( Skk ./ ( q_exchanged.^2 ) .* DOSf./e .* I .* (1-v_z./v_z_k) ./...
            ( (1 + 1./q_exchanged.^2 * 1./ Lsc(iEF,T).^2).^2 ) );
    NNan = isnan(temp_array); temp_array(NNan) = 0;
    NInf = isinf(temp_array); temp_array(NInf) = 0;
    oneovertau_z_temp_array(iEF) = 1/(2*pi)^3 * sum(temp_array);
    
end

end


% Denoising function
function [Ax_d,Ay_d,Az_d] = denoise(Ax,Ay,Az, threshold_level, n_c) 
for n_d = 1:n_c
    mx = mean(abs(Ax));
    my = mean(abs(Ay));
    mz = mean(abs(Az));
    for i = 1:size(Ax,2)
        if abs(Ax(i)) > threshold_level*mx
            Ax(i) = sign(Ax(i))*mx ; 
        end
        if abs(Ay(i)) > threshold_level*my
            Ay(i) = sign(Ay(i))*my ; 
        end
        if abs(Az(i)) > threshold_level*mz
            Az(i) = sign(Az(i))*mz ;
        end
    end
end
for n_d = 1:n_c
    mx = mean(abs(Ax));
    my = mean(abs(Ay));
    mz = mean(abs(Az));
    for i = 3:size(Ax,2)-2
        if abs(Ax(i)) > 2*mx
            Ax(i) = ( Ax(i-2)+Ax(i-1)+Ax(i+1)+Ax(i+2) )/4;
        end
        if abs(Ay(i)) > 2*my
            Ay(i) = ( Ay(i-2)+Ay(i-1)+Ay(i+1)+Ay(i+2) )/4;
        end
        if abs(Az(i)) > 2*mz
            Az(i) = ( Az(i-2)+Az(i-1)+Az(i+1)+Az(i+2) )/4;
        end
    end
end
mx = mean(abs(Ax));
my = mean(abs(Ay));
mz = mean(abs(Az));
for i = 1:size(Ax,2)
    if abs(Ax(i)) > threshold_level*mx
        Ax(i) = sign(Ax(i))*mx ; % ( Ax(i-2)+Ax(i-1)+Ax(i+1)+Ax(i+2) )/4;
    end
    if abs(Ay(i)) > threshold_level*my
        Ay(i) = sign(Ay(i))*my ; % ( Ay(i-2)+Ay(i-1)+Ay(i+1)+Ay(i+2) )/4;
    end
    if abs(Az(i)) > threshold_level*mz
        Az(i) = sign(Az(i))*mz ; % ( Az(i-2)+Az(i-1)+Az(i+1)+Az(i+2) )/4;
    end
end
Ax_d = Ax; Ay_d = Ay; Az_d = Az;
end