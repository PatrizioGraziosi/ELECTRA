% The scattering parameters for Silicon - Jacoboni mostly...

% RELEVANT SCATTERING for Si conduction band
% ADP (intravalley) and IVS


%----------- PHONONS ---------
rho_mass_density=2.329*1e-3/(1e-2)^3; % kg/m^3
% us_sound_vel=9.04*1e3;               % m/s
sl=9.041e3;                % m/s
st=5.34*1e3;               % m/s
us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975


%------- for electrons ---------------
ADP = 9.5 ;

D_ivs = [ 3.86e10, 2.86e10,  3.6e10 ] ; % g f f

hbar_w_ivs =  [ 0.061, 0.047, 0.056 ] ; % g f f

Z_f_ivs=[1, 4, 4] / 6; % number of final available valleys, g, g, f, f, g, f

%X-L intervalley is ignored as L valleys are 1 eV above (fine for TE)
%--------------------------------------------------------


%-------- for holes ------------------

ADP_h = 5.58 ;

ODP_h = 8.57e10 ;

%--------------------------------------------------------


% for Coulomb scattering - screened
k_s = 11.7;
k_inf = 0; % Not used for Silicon but the code requires it to be enetered

Z_i = 1 ; % ionize dimpurity charge