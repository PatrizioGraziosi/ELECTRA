This directory contains tests for the different scattering processes, using as input bandstructure the one for Silicon computed with a 10x10x10 k-grid.

The objective is to allow the user to be sure that all the individual parts work on a specific machine.

The ADP and IVS processesa are tested for electron transport in the CB, ADP_IVS and ODP for hole transport in the VB.
A bipolar test case uses for inter-valley ADP only. 
All the pertinent mechanisms are finally implemented in both CB and VB separately.