% Copyright 2021 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %


% this code computes the TDF properties


% in the first dimension, the E values run, 
% in the second dimension, the EF values run,
% in the third dimension, the T values run

% optionally, the band index runs in the second dimension and the rest is
% shifted

% NOTE 
% on 08/05/2019 I added some lines to consider the EF shift imposing that 
% EF_array becomes the EF_matrix column that corresponds at each 
% temperature, and other lines to consider that the maximum EF can be in the gap
%
% on 21/12/2019 I noticed that IIS and screening POP need of another phonon
% process... I shall re-modulate everything...




% the '_temp' variables are struct indexed as (id_E,id_n)

function [TDF, TDF_n, TDF_ph, TDF_ph_n, TDF_sep, TDF_sep_n, MFP, MFP_n, MFP_ph, MFP_ph_n, MFP_sep, MFP_sep_n, tauE, tauE_n, tauE_ph, tauE_ph_n, tauE_sep, tauE_sep_n, tauE_IIS, tauE_IIS_n] ...
                    = TDF_reshuffling_ELECTRA(TDF_temp, TDF_ph_temp, TDF_sep_temp, MFP_temp, MFP_ph_temp, MFP_sep_temp, tauE_temp, tauE_ph_temp, tauE_sep_temp, tauE_IIS_temp, E_array, n_bands_transp, EF_array, T_array, IIS, POP, screening_POP, sd)  % #codegen
        
   nE = size(E_array,2);
   nEF = size(EF_array,2); 
   nT = size(T_array,2);
   
   
    
    
    TDF_n=struct(); TDF_ph_n=struct(); TDF_sep_n=struct(); MFP_n=struct(); MFP_ph_n=struct(); MFP_sep_n=struct(); tauE_n=struct(); tauE_ph_n=struct(); tauE_sep_n=struct(); tauE_IIS_n=struct();
    TDF=struct(); TDF_ph=struct(); TDF_sep=struct(); MFP=struct(); MFP_ph=struct(); MFP_sep=struct(); tauE=struct(); tauE_ph=struct(); tauE_sep=struct(); tauE_IIS=struct();
    
    
    % fields with the different bands
    TDF_n.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.zz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    TDF_n.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.yz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.xz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    TDF_n.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.zy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.zx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    MFP_n.x= zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    tauE_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    tauE_IIS_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_IIS_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_IIS_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    
    
    TDF_sep_n.ADP=struct(); TDF_sep_n.ODP=struct(); TDF_sep_n.POP=struct(); TDF_sep_n.IVS=struct(); TDF_sep_n.Alloy=struct();
    TDF_sep.ADP=struct(); TDF_sep.ODP=struct(); TDF_sep.POP=struct(); TDF_sep.IVS=struct(); TDF_sep.Alloy=struct();
    tauE_sep_n.ADP=struct(); tauE_sep_n.ODP=struct(); tauE_sep_n.POP=struct(); tauE_sep_n.IVS=struct(); tauE_sep_n.Alloy=struct();
    tauE_sep.ADP=struct(); tauE_sep.ODP=struct(); tauE_sep.POP=struct(); tauE_sep.IVS=struct(); tauE_sep.Alloy=struct();
    MFP_sep_n.ADP=struct(); MFP_sep_n.ODP=struct(); MFP_sep_n.POP=struct(); MFP_sep_n.IVS=struct(); MFP_sep_n.Alloy=struct();
    MFP_sep.ADP=struct(); MFP_sep.ODP=struct(); MFP_sep.POP=struct(); MFP_sep.IVS=struct(); MFP_sep.Alloy=struct();
    
    TDF_sep_n.ADP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ADP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ADP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.zx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.zx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.IVS.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.IVS.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.IVS.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.zx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.zx = zeros(nE,n_bands_transp,size(T_array,2));
    
    MFP_sep_n.ADP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ADP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ADP.z = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.ODP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ODP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ODP.z = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.IVS.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.IVS.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.IVS.z = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.Alloy.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.Alloy.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.Alloy.z = zeros(nE,n_bands_transp,size(T_array,2));
    
    tauE_sep_n.ADP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ADP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ADP.z = zeros(nE,n_bands_transp,size(T_array,2));
    tauE_sep_n.ODP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ODP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ODP.z = zeros(nE,n_bands_transp,size(T_array,2));
    tauE_sep_n.IVS.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.IVS.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.IVS.z = zeros(nE,n_bands_transp,size(T_array,2));
    tauE_sep_n.Alloy.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.Alloy.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.Alloy.z = zeros(nE,n_bands_transp,size(T_array,2));
    
    
    % fields after summed for the bands
    TDF.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.yy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.zz = zeros(nE,size(EF_array,2),size(T_array,2));
    TDF.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.yz = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.xz = zeros(nE,size(EF_array,2),size(T_array,2));
    TDF.yx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.zy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.zx = zeros(nE,size(EF_array,2),size(T_array,2));
    MFP.x= zeros(nE,size(EF_array,2),size(T_array,2)); MFP.y = zeros(nE,size(EF_array,2),size(T_array,2)); MFP.z = zeros(nE,size(EF_array,2),size(T_array,2));
    tauE.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE.z = zeros(nE,size(EF_array,2),size(T_array,2));
    tauE_IIS.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_IIS.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_IIS.z = zeros(nE,size(EF_array,2),size(T_array,2));
    
    TDF_sep.ADP.xx = zeros(nE,size(T_array,2)); TDF_sep.ADP.yy = zeros(nE,size(T_array,2)); TDF_sep.ADP.zz = zeros(nE,size(T_array,2));
    TDF_sep.ADP.xy = zeros(nE,size(T_array,2)); TDF_sep.ADP.yz = zeros(nE,size(T_array,2)); TDF_sep.ADP.xz = zeros(nE,size(T_array,2));
    TDF_sep.ADP.yx = zeros(nE,size(T_array,2)); TDF_sep.ADP.zy = zeros(nE,size(T_array,2)); TDF_sep.ADP.zx = zeros(nE,size(T_array,2));
    TDF_sep.ODP.xx = zeros(nE,size(T_array,2)); TDF_sep.ODP.yy = zeros(nE,size(T_array,2)); TDF_sep.ODP.zz = zeros(nE,size(T_array,2));
    TDF_sep.ODP.xy = zeros(nE,size(T_array,2)); TDF_sep.ODP.yz = zeros(nE,size(T_array,2)); TDF_sep.ODP.xz = zeros(nE,size(T_array,2));
    TDF_sep.ODP.yx = zeros(nE,size(T_array,2)); TDF_sep.ODP.zy = zeros(nE,size(T_array,2)); TDF_sep.ODP.zx = zeros(nE,size(T_array,2));
    TDF_sep.IVS.xx = zeros(nE,size(T_array,2)); TDF_sep.IVS.yy = zeros(nE,size(T_array,2)); TDF_sep.IVS.zz = zeros(nE,size(T_array,2));
    TDF_sep.IVS.xy = zeros(nE,size(T_array,2)); TDF_sep.IVS.yz = zeros(nE,size(T_array,2)); TDF_sep.IVS.xz = zeros(nE,size(T_array,2));
    TDF_sep.IVS.yx = zeros(nE,size(T_array,2)); TDF_sep.IVS.zy = zeros(nE,size(T_array,2)); TDF_sep.IVS.zx = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.xx = zeros(nE,size(T_array,2)); TDF_sep.Alloy.yy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.zz = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.xy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.yz = zeros(nE,size(T_array,2)); TDF_sep.Alloy.xz = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.yx = zeros(nE,size(T_array,2)); TDF_sep.Alloy.zy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.zx = zeros(nE,size(T_array,2));
    
    MFP_sep.ADP.x = zeros(nE,size(T_array,2)); MFP_sep.ADP.y = zeros(nE,size(T_array,2)); MFP_sep.ADP.z = zeros(nE,size(T_array,2));
    MFP_sep.ODP.x = zeros(nE,size(T_array,2)); MFP_sep.ODP.y = zeros(nE,size(T_array,2)); MFP_sep.ODP.z = zeros(nE,size(T_array,2));
    MFP_sep.IVS.x = zeros(nE,size(T_array,2)); MFP_sep.IVS.y = zeros(nE,size(T_array,2)); MFP_sep.IVS.z = zeros(nE,size(T_array,2));
    MFP_sep.Alloy.x = zeros(nE,size(T_array,2)); MFP_sep.Alloy.y = zeros(nE,size(T_array,2)); MFP_sep.Alloy.z = zeros(nE,size(T_array,2));
    
    tauE_sep.ADP.x = zeros(nE,size(T_array,2)); tauE_sep.ADP.y = zeros(nE,size(T_array,2)); tauE_sep.ADP.z = zeros(nE,size(T_array,2));
    tauE_sep.ODP.x = zeros(nE,size(T_array,2)); tauE_sep.ODP.y = zeros(nE,size(T_array,2)); tauE_sep.ODP.z = zeros(nE,size(T_array,2));
    tauE_sep.IVS.x = zeros(nE,size(T_array,2)); tauE_sep.IVS.y = zeros(nE,size(T_array,2)); tauE_sep.IVS.z = zeros(nE,size(T_array,2));
    tauE_sep.Alloy.x = zeros(nE,size(T_array,2)); tauE_sep.Alloy.y = zeros(nE,size(T_array,2)); tauE_sep.Alloy.z = zeros(nE,size(T_array,2));
    
    
    % now, idem as above for POP and all but IIS (ph), separating according
    % if POP is screened or not
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_sep_n.POP.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_sep_n.POP.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.xz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_sep_n.POP.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        MFP_sep_n.POP.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        tauE_sep_n.POP.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
               
        TDF_sep.POP.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.yy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.zz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_sep.POP.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.yz = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.xz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_sep.POP.yx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.zy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.zx = zeros(nE,size(EF_array,2),size(T_array,2));
        MFP_sep.POP.x = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_sep.POP.y = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_sep.POP.z = zeros(nE,size(EF_array,2),size(T_array,2));
        tauE_sep.POP.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_sep.POP.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_sep.POP.z = zeros(nE,size(EF_array,2),size(T_array,2));
        
        TDF_ph_n.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.zz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_ph_n.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.yz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.xz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_ph_n.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.zy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.zx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        MFP_ph_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_ph_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_ph_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        tauE_ph_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_ph_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_ph_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));

        TDF_ph.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.yy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.zz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_ph.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.yz = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.xz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_ph.yx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.zy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.zx = zeros(nE,size(EF_array,2),size(T_array,2));
        MFP_ph.x= zeros(nE,size(EF_array,2),size(T_array,2)); MFP_ph.y = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_ph.z = zeros(nE,size(EF_array,2),size(T_array,2));
        tauE_ph.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_ph.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_ph.z = zeros(nE,size(EF_array,2),size(T_array,2));
           
    else
        
        TDF_sep_n.POP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_sep_n.POP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.xz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_sep_n.POP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zx = zeros(nE,n_bands_transp,size(T_array,2));
        MFP_sep_n.POP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.POP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.POP.z = zeros(nE,n_bands_transp,size(T_array,2));
        tauE_sep_n.POP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.POP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.POP.z = zeros(nE,n_bands_transp,size(T_array,2));
        
        TDF_sep.POP.xx = zeros(nE,size(T_array,2)); TDF_sep.POP.yy = zeros(nE,size(T_array,2)); TDF_sep.POP.zz = zeros(nE,size(T_array,2));
        TDF_sep.POP.xy = zeros(nE,size(T_array,2)); TDF_sep.POP.yz = zeros(nE,size(T_array,2)); TDF_sep.POP.xz = zeros(nE,size(T_array,2));
        TDF_sep.POP.yx = zeros(nE,size(T_array,2)); TDF_sep.POP.zy = zeros(nE,size(T_array,2)); TDF_sep.POP.zx = zeros(nE,size(T_array,2));
        MFP_sep.POP.x = zeros(nE,size(T_array,2)); MFP_sep.POP.y = zeros(nE,size(T_array,2)); MFP_sep.POP.z = zeros(nE,size(T_array,2));
        tauE_sep.POP.x = zeros(nE,size(T_array,2)); tauE_sep.POP.y = zeros(nE,size(T_array,2)); tauE_sep.POP.z = zeros(nE,size(T_array,2));
        
        TDF_ph_n.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.zz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_ph_n.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.xz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_ph_n.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.zx = zeros(nE,n_bands_transp,size(T_array,2));
        MFP_ph_n.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_ph_n.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_ph_n.z = zeros(nE,n_bands_transp,size(T_array,2));
        tauE_ph_n.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_ph_n.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_ph_n.z = zeros(nE,n_bands_transp,size(T_array,2));

        TDF_ph.xx = zeros(nE,size(T_array,2)); TDF_ph.yy = zeros(nE,size(T_array,2)); TDF_ph.zz = zeros(nE,size(T_array,2));
        TDF_ph.xy = zeros(nE,size(T_array,2)); TDF_ph.yz = zeros(nE,size(T_array,2)); TDF_ph.xz = zeros(nE,size(T_array,2));
        TDF_ph.yx = zeros(nE,size(T_array,2)); TDF_ph.zy = zeros(nE,size(T_array,2)); TDF_ph.zx = zeros(nE,size(T_array,2));
        MFP_ph.x= zeros(nE,size(T_array,2)); MFP_ph.y = zeros(nE,size(T_array,2)); MFP_ph.z = zeros(nE,size(T_array,2));
        tauE_ph.x = zeros(nE,size(T_array,2)); tauE_ph.y = zeros(nE,size(T_array,2)); tauE_ph.z = zeros(nE,size(T_array,2));
        
    end
    
    
    % ---------------------------------------------------------------------
    % End of the inizialitions of all the output struct data types etc. 
    
    
    
    % composition of the 'n' dependent struct 
    % the '_temp' variables are struct indexed as (id_E,id_n)
    for id_E = 1:nE
        for id_n = 1:n_bands_transp
            
            TDF_n.xx(id_E,id_n,:,:) = TDF_temp(id_E,id_n).xx(:,:) ;
            TDF_n.xy(id_E,id_n,:,:) = TDF_temp(id_E,id_n).xy(:,:) ;
            TDF_n.xz(id_E,id_n,:,:) = TDF_temp(id_E,id_n).xz(:,:) ;
            TDF_n.yx(id_E,id_n,:,:) = TDF_temp(id_E,id_n).yx(:,:) ;
            TDF_n.yy(id_E,id_n,:,:) = TDF_temp(id_E,id_n).yy(:,:) ;
            TDF_n.yz(id_E,id_n,:,:) = TDF_temp(id_E,id_n).yz(:,:) ;
            TDF_n.zx(id_E,id_n,:,:) = TDF_temp(id_E,id_n).zx(:,:) ;
            TDF_n.zy(id_E,id_n,:,:) = TDF_temp(id_E,id_n).zy(:,:) ;
            TDF_n.zz(id_E,id_n,:,:) = TDF_temp(id_E,id_n).zz(:,:) ;
            
            
            MFP_n.x(id_E,id_n,:,:) = MFP_temp(id_E,id_n).x(:,:) ;
            MFP_n.y(id_E,id_n,:,:) = MFP_temp(id_E,id_n).y(:,:) ;
            MFP_n.z(id_E,id_n,:,:) = MFP_temp(id_E,id_n).z(:,:) ;
            
            
            tauE_n.x(id_E,id_n,:,:) = tauE_temp(id_E,id_n).x(:,:) ;
            tauE_n.y(id_E,id_n,:,:) = tauE_temp(id_E,id_n).y(:,:) ;
            tauE_n.z(id_E,id_n,:,:) = tauE_temp(id_E,id_n).z(:,:) ;
            
            if isempty(tauE_IIS_temp(id_E,id_n).x) == 0
                tauE_IIS_n.x(id_E,id_n,:,:) = tauE_IIS_temp(id_E,id_n).x(:,:) ;
                tauE_IIS_n.y(id_E,id_n,:,:) = tauE_IIS_temp(id_E,id_n).y(:,:) ;
                tauE_IIS_n.z(id_E,id_n,:,:) = tauE_IIS_temp(id_E,id_n).z(:,:) ;
            end
            
            
        end
    end
    
            TDF.xx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xx,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            TDF.yy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yy,2));
            TDF.zz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zz,2));
            TDF.xy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xy,2));
            TDF.xz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xz,2));
            TDF.yz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yz,2));
            TDF.yx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yx,2));
            TDF.zx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zx,2));
            TDF.zy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zy,2));

            MFP.x = squeeze(mean(abs(MFP_n.x),2));
            MFP.y = squeeze(mean(abs(MFP_n.y),2));
            MFP.z = squeeze(mean(abs(MFP_n.z),2));

            tauE.x = squeeze(sum(tauE_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE.y = squeeze(sum(tauE_n.y,2)); % tauE = tauE(E,EF,T)
            tauE.z = squeeze(sum(tauE_n.z,2));

            % controls over TDFs
            Ninf = isinf(TDF.xx); TDF.xx(Ninf) = 0; NNan = isnan(TDF.xx); TDF.xx(NNan) = 0;
            Ninf = isinf(TDF.yy); TDF.yy(Ninf) = 0; NNan = isnan(TDF.yy); TDF.yy(NNan) = 0;
            Ninf = isinf(TDF.zz); TDF.zz(Ninf) = 0; NNan = isnan(TDF.zz); TDF.zz(NNan) = 0;
            Ninf = isinf(TDF.xy); TDF.xy(Ninf) = 0; NNan = isnan(TDF.xy); TDF.xy(NNan) = 0;
            Ninf = isinf(TDF.yz); TDF.yz(Ninf) = 0; NNan = isnan(TDF.yz); TDF.yz(NNan) = 0;
            Ninf = isinf(TDF.xz); TDF.xz(Ninf) = 0; NNan = isnan(TDF.xz); TDF.xz(NNan) = 0;
            Ninf = isinf(TDF.yx); TDF.yx(Ninf) = 0; NNan = isnan(TDF.yx); TDF.yx(NNan) = 0;
            Ninf = isinf(TDF.zy); TDF.zy(Ninf) = 0; NNan = isnan(TDF.zy); TDF.zy(NNan) = 0;
            Ninf = isinf(TDF.zx); TDF.zx(Ninf) = 0; NNan = isnan(TDF.zx); TDF.zx(NNan) = 0;
  
  
            
            % denoising the TDF etc.
        for ii_EF = 1:nEF
            for ii_T = 1:nT
                    
                    A = abs( TDF.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.zz(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.zz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.xz(:,ii_EF,ii_T) ) ;
                    A1 = TDF.xz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yz(:,ii_EF,ii_T) ) ;
                    A1 = TDF.yz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.zy(:,ii_EF,ii_T) ) ;
                    A1 = TDF.zy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.zy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.zx(:,ii_EF,ii_T) ) ;
                    A1 = TDF.zx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  2 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.zx(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( MFP.x(:,ii_EF,ii_T) ) ;
                    A1 = MFP.x(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP.y(:,ii_EF,ii_T) ) ;
                    A1 = MFP.y(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.y(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP.z(:,ii_EF,ii_T) ) ;
                    A1 = MFP.z(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.z(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.x(:,ii_EF,ii_T) ) ;
                    A1 = tauE.x(:,ii_EF,ii_T);
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.y(:,ii_EF,ii_T) ) ;
                    A1 = tauE.y(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.y(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.z(:,ii_EF,ii_T) ) ;
                    A1 = tauE.z(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.z(:,ii_EF,ii_T) = A1 ;
                    if strcmp(IIS,'yes')
                        A = abs( tauE_IIS.x(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.x(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.x(:,ii_EF,ii_T) = A1 ;
                        A = abs( tauE_IIS.y(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.y(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.y(:,ii_EF,ii_T) = A1 ;
                        A = abs( tauE_IIS.z(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.z(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.z(:,ii_EF,ii_T) = A1 ;
                    end
                    
            end
        end



    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------


    % ---------------------------------------------------------------------
    % ------------------- WITHOUT IMPURITIES ------------------------------
    % for the calculations without impurities I use a different Fermi array
        
    
    
    % -------------  ADP only ---------------------------------------------
    if isempty(TDF_sep_temp(1,1).ADP.xx) == 0
        
 
        for id_E = size(E_array,2):-1:1 
            for id_n = n_bands_transp:-1:1
                
                        TDF_sep_n.ADP.xx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.xx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.yy(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.ADP.zz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.zz(:) ;
                        TDF_sep_n.ADP.xy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.xy(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.yz(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.ADP.xz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.xz(:) ;
                        TDF_sep_n.ADP.yx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.yx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.zy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.zy(:) ;% the dSk element is already in the DOS
                        TDF_sep_n.ADP.zx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ADP.zx(:) ;

                        MFP_sep_n.ADP.x(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).ADP.x(:) ;
                        MFP_sep_n.ADP.y(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).ADP.y(:) ;
                        MFP_sep_n.ADP.z(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).ADP.z(:) ;

                        tauE_sep_n.ADP.x(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).ADP.x(:) ;                                       
                        tauE_sep_n.ADP.y(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).ADP.y(:) ;                                       
                        tauE_sep_n.ADP.z(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).ADP.z(:) ;
                            
            end            
        end
        TDF_sep.ADP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.ADP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.zz,2));
        TDF_sep.ADP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.xy,2)); % it sums the contribution of the bands
        TDF_sep.ADP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.xz,2));
        TDF_sep.ADP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.yx,2)); % it sums the contribution of the bands
        TDF_sep.ADP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.zx,2));
        Ninf = isinf(TDF_sep.ADP.xx); TDF_sep.ADP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xx); TDF_sep.ADP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yy); TDF_sep.ADP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yy); TDF_sep.ADP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.zz); TDF_sep.ADP.zz(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.zz); TDF_sep.ADP.zz(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.xy); TDF_sep.ADP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xy); TDF_sep.ADP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yz); TDF_sep.ADP.yz(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yz); TDF_sep.ADP.yz(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.xz); TDF_sep.ADP.xz(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xz); TDF_sep.ADP.xz(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yx); TDF_sep.ADP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yx); TDF_sep.ADP.yx(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.zy); TDF_sep.ADP.zy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.zy); TDF_sep.ADP.zy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.zx); TDF_sep.ADP.zx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.zx); TDF_sep.ADP.zx(NNan) = 0;

        MFP_sep.ADP.x = squeeze(mean(abs(MFP_sep_n.ADP.x),2));
        MFP_sep.ADP.y = squeeze(mean(abs(MFP_sep_n.ADP.y),2));
        MFP_sep.ADP.z = squeeze(mean(abs(MFP_sep_n.ADP.z),2));

        tauE_sep.ADP.x = squeeze(sum(tauE_sep_n.ADP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.ADP.y = squeeze(sum(tauE_sep_n.ADP.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.ADP.z = squeeze(sum(tauE_sep_n.ADP.z,2));


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.ADP.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.xy(:,ii_T) ) ;
            A1 = TDF_sep.ADP.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.xz(:,ii_T) ) ;
            A1 = TDF_sep.ADP.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yz(:,ii_T) ) ;
            A1 = TDF_sep.ADP.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yx(:,ii_T) ) ;
            A1 = TDF_sep.ADP.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.zy(:,ii_T) ) ;
            A1 = TDF_sep.ADP.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.zx(:,ii_T) ) ;
            A1 = TDF_sep.ADP.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.zx(:,ii_T) = A1 ;

        end


    end
    % --------------------------------------------------------------------------------------------------------


    % ---------  ODP only -----------------------------------------------------
     if isempty(TDF_sep_temp(1,1).ODP.xx) == 0
        
 
        for id_E = size(E_array,2):-1:1 
            for id_n = n_bands_transp:-1:1
                
                        TDF_sep_n.ODP.xx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.xx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.yy(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.ODP.zz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.zz(:) ;
                        TDF_sep_n.ODP.xy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.xy(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.yz(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.ODP.xz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.xz(:) ;
                        TDF_sep_n.ODP.yx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.yx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.zy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.zy(:) ;% the dSk element is already in the DOS
                        TDF_sep_n.ODP.zx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).ODP.zx(:) ;

                        MFP_sep_n.ODP.x(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).ODP.x(:) ;
                        MFP_sep_n.ODP.y(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).ODP.y(:) ;
                        MFP_sep_n.ODP.z(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).ODP.z(:) ;

                        tauE_sep_n.ODP.x(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).ODP.x(:) ;                                       
                        tauE_sep_n.ODP.y(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).ODP.y(:) ;                                       
                        tauE_sep_n.ODP.z(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).ODP.z(:) ;
                            
            end            
        end
        TDF_sep.ODP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.ODP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.zz,2));
        TDF_sep.ODP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.xy,2)); % it sums the contribution of the bands
        TDF_sep.ODP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.xz,2));
        TDF_sep.ODP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.yx,2)); % it sums the contribution of the bands
        TDF_sep.ODP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.zx,2));
        Ninf = isinf(TDF_sep.ODP.xx); TDF_sep.ODP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.xx); TDF_sep.ODP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.yy); TDF_sep.ODP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.yy); TDF_sep.ODP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.zz); TDF_sep.ODP.zz(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.zz); TDF_sep.ODP.zz(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.xy); TDF_sep.ODP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.xy); TDF_sep.ODP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.yz); TDF_sep.ODP.yz(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.yz); TDF_sep.ODP.yz(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.xz); TDF_sep.ODP.xz(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.xz); TDF_sep.ODP.xz(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.yx); TDF_sep.ODP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.yx); TDF_sep.ODP.yx(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.zy); TDF_sep.ODP.zy(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.zy); TDF_sep.ODP.zy(NNan) = 0;
        Ninf = isinf(TDF_sep.ODP.zx); TDF_sep.ODP.zx(Ninf) = 0;
        NNan = isnan(TDF_sep.ODP.zx); TDF_sep.ODP.zx(NNan) = 0;

        MFP_sep.ODP.x = squeeze(mean(abs(MFP_sep_n.ODP.x),2));
        MFP_sep.ODP.y = squeeze(mean(abs(MFP_sep_n.ODP.y),2));
        MFP_sep.ODP.z = squeeze(mean(abs(MFP_sep_n.ODP.z),2));

        tauE_sep.ODP.x = squeeze(sum(tauE_sep_n.ODP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.ODP.y = squeeze(sum(tauE_sep_n.ODP.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.ODP.z = squeeze(sum(tauE_sep_n.ODP.z,2));


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.ODP.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.xy(:,ii_T) ) ;
            A1 = TDF_sep.ODP.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.xz(:,ii_T) ) ;
            A1 = TDF_sep.ODP.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yz(:,ii_T) ) ;
            A1 = TDF_sep.ODP.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yx(:,ii_T) ) ;
            A1 = TDF_sep.ODP.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.zy(:,ii_T) ) ;
            A1 = TDF_sep.ODP.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.zx(:,ii_T) ) ;
            A1 = TDF_sep.ODP.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.zx(:,ii_T) = A1 ;

        end

    end
    % --------------------------------------------------------------------------------

    % ---------  IVS only -----------------------------------------------------
     if isempty(TDF_sep_temp(1,1).IVS.xx) == 0
        
 
        for id_E = size(E_array,2):-1:1 
            for id_n = n_bands_transp:-1:1
                
                        TDF_sep_n.IVS.xx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.xx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.yy(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.IVS.zz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.zz(:) ;
                        TDF_sep_n.IVS.xy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.xy(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.yz(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.IVS.xz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.xz(:) ;
                        TDF_sep_n.IVS.yx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.yx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.zy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.zy(:) ;% the dSk element is already in the DOS
                        TDF_sep_n.IVS.zx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).IVS.zx(:) ;

                        MFP_sep_n.IVS.x(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).IVS.x(:) ;
                        MFP_sep_n.IVS.y(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).IVS.y(:) ;
                        MFP_sep_n.IVS.z(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).IVS.z(:) ;

                        tauE_sep_n.IVS.x(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).IVS.x(:) ;                                       
                        tauE_sep_n.IVS.y(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).IVS.y(:) ;                                       
                        tauE_sep_n.IVS.z(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).IVS.z(:) ;
                            
            end            
        end
        TDF_sep.IVS.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.xx ,2)); % it sums the contribution of the bands
        TDF_sep.IVS.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.zz,2));
        TDF_sep.IVS.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.xy,2)); % it sums the contribution of the bands
        TDF_sep.IVS.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.xz,2));
        TDF_sep.IVS.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.yx,2)); % it sums the contribution of the bands
        TDF_sep.IVS.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.zx,2));
        Ninf = isinf(TDF_sep.IVS.xx); TDF_sep.IVS.xx(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.xx); TDF_sep.IVS.xx(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.yy); TDF_sep.IVS.yy(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.yy); TDF_sep.IVS.yy(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.zz); TDF_sep.IVS.zz(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.zz); TDF_sep.IVS.zz(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.xy); TDF_sep.IVS.xy(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.xy); TDF_sep.IVS.xy(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.yz); TDF_sep.IVS.yz(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.yz); TDF_sep.IVS.yz(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.xz); TDF_sep.IVS.xz(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.xz); TDF_sep.IVS.xz(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.yx); TDF_sep.IVS.yx(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.yx); TDF_sep.IVS.yx(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.zy); TDF_sep.IVS.zy(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.zy); TDF_sep.IVS.zy(NNan) = 0;
        Ninf = isinf(TDF_sep.IVS.zx); TDF_sep.IVS.zx(Ninf) = 0;
        NNan = isnan(TDF_sep.IVS.zx); TDF_sep.IVS.zx(NNan) = 0;

        MFP_sep.IVS.x = squeeze(mean(abs(MFP_sep_n.IVS.x),2));
        MFP_sep.IVS.y = squeeze(mean(abs(MFP_sep_n.IVS.y),2));
        MFP_sep.IVS.z = squeeze(mean(abs(MFP_sep_n.IVS.z),2));

        tauE_sep.IVS.x = squeeze(sum(tauE_sep_n.IVS.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.IVS.y = squeeze(sum(tauE_sep_n.IVS.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.IVS.z = squeeze(sum(tauE_sep_n.IVS.z,2));


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.IVS.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.xy(:,ii_T) ) ;
            A1 = TDF_sep.IVS.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.xz(:,ii_T) ) ;
            A1 = TDF_sep.IVS.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yz(:,ii_T) ) ;
            A1 = TDF_sep.IVS.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yx(:,ii_T) ) ;
            A1 = TDF_sep.IVS.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.zy(:,ii_T) ) ;
            A1 = TDF_sep.IVS.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.zx(:,ii_T) ) ;
            A1 = TDF_sep.IVS.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.zx(:,ii_T) = A1 ;
            
        end

    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  POP only -----------------------------------------------------
    if strcmp(POP,'yes') 
        if strcmp(screening_POP,'no')
            
                for id_E = size(E_array,2):-1:1 
                    for id_n = n_bands_transp:-1:1

                                TDF_sep_n.POP.xx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.xx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                                TDF_sep_n.POP.yy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.yy(:) ; % the dSk element is already in the DOS
                                TDF_sep_n.POP.zz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.zz(:) ;
                                TDF_sep_n.POP.xy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.xy(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                                TDF_sep_n.POP.yz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.yz(:) ; % the dSk element is already in the DOS
                                TDF_sep_n.POP.xz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.xz(:) ;
                                TDF_sep_n.POP.yx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.yx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                                TDF_sep_n.POP.zy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.zy(:) ;% the dSk element is already in the DOS
                                TDF_sep_n.POP.zx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).POP.zx(:) ;

                                MFP_sep_n.POP.x(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).POP.x(:) ;
                                MFP_sep_n.POP.y(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).POP.y(:) ;
                                MFP_sep_n.POP.z(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).POP.z(:) ;

                                tauE_sep_n.POP.x(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).POP.x(:) ;                                       
                                tauE_sep_n.POP.y(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).POP.y(:) ;                                       
                                tauE_sep_n.POP.z(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).POP.z(:) ;

                    end            
                end
                TDF_sep.POP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xx ,2)); % it sums the contribution of the bands
                TDF_sep.POP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yy ,2)); % the dSk elemnts is already in the DOS
                TDF_sep.POP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zz,2));
                TDF_sep.POP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xy,2)); % it sums the contribution of the bands
                TDF_sep.POP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yz,2)); % the dSk elemnts is already in the DOS
                TDF_sep.POP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xz,2));
                TDF_sep.POP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yx,2)); % it sums the contribution of the bands
                TDF_sep.POP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zy,2)); % the dSk elemnts is already in the DOS
                TDF_sep.POP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zx,2));
                Ninf = isinf(TDF_sep.POP.xx); TDF_sep.POP.xx(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.xx); TDF_sep.POP.xx(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.yy); TDF_sep.POP.yy(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.yy); TDF_sep.POP.yy(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.zz); TDF_sep.POP.zz(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.zz); TDF_sep.POP.zz(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.xy); TDF_sep.POP.xy(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.xy); TDF_sep.POP.xy(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.yz); TDF_sep.POP.yz(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.yz); TDF_sep.POP.yz(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.xz); TDF_sep.POP.xz(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.xz); TDF_sep.POP.xz(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.yx); TDF_sep.POP.yx(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.yx); TDF_sep.POP.yx(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.zy); TDF_sep.POP.zy(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.zy); TDF_sep.POP.zy(NNan) = 0;
                Ninf = isinf(TDF_sep.POP.zx); TDF_sep.POP.zx(Ninf) = 0;
                NNan = isnan(TDF_sep.POP.zx); TDF_sep.POP.zx(NNan) = 0;

                MFP_sep.POP.x = squeeze(mean(abs(MFP_sep_n.POP.x),2));
                MFP_sep.POP.y = squeeze(mean(abs(MFP_sep_n.POP.y),2));
                MFP_sep.POP.z = squeeze(mean(abs(MFP_sep_n.POP.z),2));

                tauE_sep.POP.x = squeeze(sum(tauE_sep_n.POP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
                tauE_sep.POP.y = squeeze(sum(tauE_sep_n.POP.y,2)); % tauE = tauE(E,EF,T)
                tauE_sep.POP.z = squeeze(sum(tauE_sep_n.POP.z,2));


                for ii_T = 1:size(T_array,2)
                    
                    A = abs( TDF_sep.POP.xx(:,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xx(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yy(:,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yy(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.zz(:,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.zz(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.xy(:,ii_T) ) ;
                    A1 = TDF_sep.POP.xy(:,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xy(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.xz(:,ii_T) ) ;
                    A1 = TDF_sep.POP.xz(:,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xz(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yz(:,ii_T) ) ;
                    A1 = TDF_sep.POP.yz(:,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yz(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yx(:,ii_T) ) ;
                    A1 = TDF_sep.POP.yx(:,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yx(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.zy(:,ii_T) ) ;
                    A1 = TDF_sep.POP.zy(:,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.zy(:,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.zx(:,ii_T) ) ;
                    A1 = TDF_sep.POP.zx(:,ii_T);
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.zx(:,ii_T) = A1 ;

                end            


        elseif strcmp(screening_POP,'yes')

            for id_E = size(E_array,2):-1:1 
                for id_n = n_bands_transp:-1:1

                            TDF_sep_n.POP.xx(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.xx(:,:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                            TDF_sep_n.POP.yy(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.yy(:,:) ; % the dSk element is already in the DOS
                            TDF_sep_n.POP.zz(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.zz(:,:) ;
                            TDF_sep_n.POP.xy(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.xy(:,:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                            TDF_sep_n.POP.yz(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.yz(:,:) ; % the dSk element is already in the DOS
                            TDF_sep_n.POP.xz(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.xz(:,:) ;
                            TDF_sep_n.POP.yx(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.yx(:,:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                            TDF_sep_n.POP.zy(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.zy(:,:) ;% the dSk element is already in the DOS
                            TDF_sep_n.POP.zx(id_E,id_n,:,:) = TDF_sep_temp(id_E,id_n).POP.zx(:,:) ;

                            MFP_sep_n.POP.x(id_E,id_n,:,:) = MFP_sep_temp(id_E,id_n).POP.x(:,:) ;
                            MFP_sep_n.POP.y(id_E,id_n,:,:) = MFP_sep_temp(id_E,id_n).POP.y(:,:) ;
                            MFP_sep_n.POP.z(id_E,id_n,:,:) = MFP_sep_temp(id_E,id_n).POP.z(:,:) ;

                            tauE_sep_n.POP.x(id_E,id_n,:,:) = tauE_sep_temp(id_E,id_n).POP.x(:,:) ;                                       
                            tauE_sep_n.POP.y(id_E,id_n,:,:) = tauE_sep_temp(id_E,id_n).POP.y(:,:) ;                                       
                            tauE_sep_n.POP.z(id_E,id_n,:,:) = tauE_sep_temp(id_E,id_n).POP.z(:,:) ;

                end            
            end
            TDF_sep.POP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xx ,2)); % it sums the contribution of the bands
            TDF_sep.POP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yy ,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zz,2));
            TDF_sep.POP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xy,2)); % it sums the contribution of the bands
            TDF_sep.POP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yz,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xz,2));
            TDF_sep.POP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yx,2)); % it sums the contribution of the bands
            TDF_sep.POP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zy,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zx,2));
            Ninf = isinf(TDF_sep.POP.xx); TDF_sep.POP.xx(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.xx); TDF_sep.POP.xx(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.yy); TDF_sep.POP.yy(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.yy); TDF_sep.POP.yy(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.zz); TDF_sep.POP.zz(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.zz); TDF_sep.POP.zz(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.xy); TDF_sep.POP.xy(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.xy); TDF_sep.POP.xy(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.yz); TDF_sep.POP.yz(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.yz); TDF_sep.POP.yz(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.xz); TDF_sep.POP.xz(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.xz); TDF_sep.POP.xz(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.yx); TDF_sep.POP.yx(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.yx); TDF_sep.POP.yx(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.zy); TDF_sep.POP.zy(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.zy); TDF_sep.POP.zy(NNan) = 0;
            Ninf = isinf(TDF_sep.POP.zx); TDF_sep.POP.zx(Ninf) = 0;
            NNan = isnan(TDF_sep.POP.zx); TDF_sep.POP.zx(NNan) = 0;

            MFP_sep.POP.x = squeeze(mean(abs(MFP_sep_n.POP.x),2));
            MFP_sep.POP.y = squeeze(mean(abs(MFP_sep_n.POP.y),2));
            MFP_sep.POP.z = squeeze(mean(abs(MFP_sep_n.POP.z),2));

            tauE_sep.POP.x = squeeze(sum(tauE_sep_n.POP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE_sep.POP.y = squeeze(sum(tauE_sep_n.POP.y,2)); % tauE = tauE(E,EF,T)
            tauE_sep.POP.z = squeeze(sum(tauE_sep_n.POP.z,2));
            
            
            for ii_T = 1:size(T_array,2)
                for ii_EF = 1:size(EF_array,2)

                        A = abs( TDF_sep.POP.xx(:,ii_EF,ii_T) ) ;
                        A1 = A;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.xx(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.yy(:,ii_EF,ii_T) ) ;
                        A1 = A;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.yy(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.zz(:,ii_EF,ii_T) ) ;
                        A1 = A;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.zz(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.xy(:,ii_EF,ii_T) ) ;
                        A1 = TDF_sep.POP.xy(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.xy(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.xz(:,ii_EF,ii_T) ) ;
                        A1 = TDF_sep.POP.xz(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.xz(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.yz(:,ii_EF,ii_T) ) ;
                        A1 = TDF_sep.POP.yz(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.yz(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.yx(:,ii_EF,ii_T) ) ;
                        A1 = TDF_sep.POP.yx(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.yx(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.zy(:,ii_EF,ii_T) ) ;
                        A1 = TDF_sep.POP.zy(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.zy(:,ii_EF,ii_T) = A1 ;
                        A = abs( TDF_sep.POP.zx(:,ii_EF,ii_T) ) ;
                        A1 = TDF_sep.POP.zx(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        TDF_sep.POP.zx(:,ii_EF,ii_T) = A1 ;

                end
            end



            
        end        
    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  Alloy only -----------------------------------------------------
     if isempty(TDF_sep_temp(1,1).Alloy.xx) == 0
        
 
        for id_E = size(E_array,2):-1:1 
            for id_n = n_bands_transp:-1:1
                
                        TDF_sep_n.Alloy.xx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.xx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.yy(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.zz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.zz(:) ;
                        TDF_sep_n.Alloy.xy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.xy(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.yz(:) ; % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.xz(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.xz(:) ;
                        TDF_sep_n.Alloy.yx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.yx(:) ; % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.zy(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.zy(:) ;% the dSk element is already in the DOS
                        TDF_sep_n.Alloy.zx(id_E,id_n,:) = TDF_sep_temp(id_E,id_n).Alloy.zx(:) ;

                        MFP_sep_n.Alloy.x(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).Alloy.x(:) ;
                        MFP_sep_n.Alloy.y(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).Alloy.y(:) ;
                        MFP_sep_n.Alloy.z(id_E,id_n,:) = MFP_sep_temp(id_E,id_n).Alloy.z(:) ;

                        tauE_sep_n.Alloy.x(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).Alloy.x(:) ;                                       
                        tauE_sep_n.Alloy.y(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).Alloy.y(:) ;                                       
                        tauE_sep_n.Alloy.z(id_E,id_n,:) = tauE_sep_temp(id_E,id_n).Alloy.z(:) ;
                            
            end            
        end
        TDF_sep.Alloy.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.xx ,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.zz,2));
        TDF_sep.Alloy.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.xy,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.xz,2));
        TDF_sep.Alloy.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.yx,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.zx,2));
        Ninf = isinf(TDF_sep.Alloy.xx); TDF_sep.Alloy.xx(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.xx); TDF_sep.Alloy.xx(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.yy); TDF_sep.Alloy.yy(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.yy); TDF_sep.Alloy.yy(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.zz); TDF_sep.Alloy.zz(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.zz); TDF_sep.Alloy.zz(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.xy); TDF_sep.Alloy.xy(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.xy); TDF_sep.Alloy.xy(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.yz); TDF_sep.Alloy.yz(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.yz); TDF_sep.Alloy.yz(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.xz); TDF_sep.Alloy.xz(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.xz); TDF_sep.Alloy.xz(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.yx); TDF_sep.Alloy.yx(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.yx); TDF_sep.Alloy.yx(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.zy); TDF_sep.Alloy.zy(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.zy); TDF_sep.Alloy.zy(NNan) = 0;
        Ninf = isinf(TDF_sep.Alloy.zx); TDF_sep.Alloy.zx(Ninf) = 0;
        NNan = isnan(TDF_sep.Alloy.zx); TDF_sep.Alloy.zx(NNan) = 0;

        MFP_sep.Alloy.x = squeeze(mean(abs(MFP_sep_n.Alloy.x),2));
        MFP_sep.Alloy.y = squeeze(mean(abs(MFP_sep_n.Alloy.y),2));
        MFP_sep.Alloy.z = squeeze(mean(abs(MFP_sep_n.Alloy.z),2));

        tauE_sep.Alloy.x = squeeze(sum(tauE_sep_n.Alloy.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.Alloy.y = squeeze(sum(tauE_sep_n.Alloy.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.Alloy.z = squeeze(sum(tauE_sep_n.Alloy.z,2));


        for ii_T = 1:size(T_array,2)
            A = abs( TDF_sep.Alloy.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.xy(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.xz(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yz(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yx(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.zy(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.zx(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.zx(:,ii_T) = A1 ;
        end

    end
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------

    
    
    % ---------  phonons (all) only @ all T--------------------------------
    % ---------------------------------------------------------------------
    
    if isempty(TDF_ph_temp(1,1).xx) == 0
        
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                    
                TDF_ph_n.xx(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).xx(:,:) ;
                TDF_ph_n.xy(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).xy(:,:) ;
                TDF_ph_n.xz(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).xz(:,:) ;
                TDF_ph_n.yx(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).yx(:,:) ;
                TDF_ph_n.yy(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).yy(:,:) ;
                TDF_ph_n.yz(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).yz(:,:) ;
                TDF_ph_n.zx(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).zx(:,:) ;
                TDF_ph_n.zy(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).zy(:,:) ;
                TDF_ph_n.zz(id_E,id_n,:,:) = TDF_ph_temp(id_E,id_n).zz(:,:) ;


                MFP_ph_n.x(id_E,id_n,:,:) = MFP_ph_temp(id_E,id_n).x(:,:) ;
                MFP_ph_n.y(id_E,id_n,:,:) = MFP_ph_temp(id_E,id_n).y(:,:) ;
                MFP_ph_n.z(id_E,id_n,:,:) = MFP_ph_temp(id_E,id_n).z(:,:) ;


                tauE_ph_n.x(id_E,id_n,:,:) = tauE_ph_temp(id_E,id_n).x(:,:) ;
                tauE_ph_n.y(id_E,id_n,:,:) = tauE_ph_temp(id_E,id_n).y(:,:) ;
                tauE_ph_n.z(id_E,id_n,:,:) = tauE_ph_temp(id_E,id_n).z(:,:) ;
                            
            end            
        end

        Ninf = isinf(TDF_ph_n.xx); TDF_ph_n.xx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xx); TDF_ph_n.xx(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yy); TDF_ph_n.yy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yy); TDF_ph_n.yy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.zz); TDF_ph_n.zz(Ninf) = 0;
        NNan = isnan(TDF_ph_n.zz); TDF_ph_n.zz(NNan) = 0;
        Ninf = isinf(TDF_ph_n.xy); TDF_ph_n.xy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xy); TDF_ph_n.xy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yz); TDF_ph_n.yz(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yz); TDF_ph_n.yz(NNan) = 0;
        Ninf = isinf(TDF_ph_n.xz); TDF_ph_n.xz(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xz); TDF_ph_n.xz(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yx); TDF_ph_n.yx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yx); TDF_ph_n.yx(NNan) = 0;
        Ninf = isinf(TDF_ph_n.zy); TDF_ph_n.zy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.zy); TDF_ph_n.zy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.zx); TDF_ph_n.zx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.zx); TDF_ph_n.zx(NNan) = 0;
        TDF_ph.xx = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.xx,2)); % it sums the contribution of the bands
        TDF_ph.yy = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.yy,2)); % the dSk elemnts is already in the DOS
        TDF_ph.zz = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.zz,2));
        TDF_ph.xy = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.xy,2)); 
        TDF_ph.yz = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.yz,2)); 
        TDF_ph.xz = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.xz,2));
        TDF_ph.yx = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.yx,2)); 
        TDF_ph.zy = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.zy,2)); 
        TDF_ph.zx = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.zx,2));    

        MFP_ph.x = squeeze(mean(abs(MFP_ph_n.x),2));
        MFP_ph.y = squeeze(mean(abs(MFP_ph_n.y),2));
        MFP_ph.z = squeeze(mean(abs(MFP_ph_n.z),2));

        tauE_ph.x = squeeze(sum(tauE_ph_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_ph.y = squeeze(sum(tauE_ph_n.y,2)); % tauE = tauE(E,EF,T)
        tauE_ph.z = squeeze(sum(tauE_ph_n.z,2));


        % denoising the TDF
        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
            for ii_T = 1:size(T_array,2)
                for ii_EF = 1:size(EF_array,2)
                                         
                    A = abs( TDF_ph.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.zz(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.zz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.xz(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.xz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yz(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.yz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.zy(:,ii_EF,ii_T) ) ;
                    A1 = abs( TDF_ph.zy(:,ii_EF,ii_T) ) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.zy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.zx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.zx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.zx(:,ii_EF,ii_T) = A1 ;                
                    
                end
            end
        else
            for ii_T = 1:size(T_array,2)
                A = abs( TDF_ph.xx(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xx(:,ii_T) = A1 ;
                A = abs( TDF_ph.yy(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yy(:,ii_T) = A1 ;
                A = abs( TDF_ph.zz(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.zz(:,ii_T) = A1 ;
                A = abs( TDF_ph.xy(:,ii_T) ) ;
                A1 = TDF_ph.xy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xy(:,ii_T) = A1 ;
                A = abs( TDF_ph.xz(:,ii_T) ) ;
                A1 = TDF_ph.xz(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xz(:,ii_T) = A1 ;
                A = abs( TDF_ph.yz(:,ii_T) ) ;
                A1 = TDF_ph.yz(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yz(:,ii_T) = A1 ;
                A = abs( TDF_ph.yx(:,ii_T) ) ;
                A1 = TDF_ph.yx(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yx(:,ii_T) = A1 ;
                A = abs( TDF_ph.zy(:,ii_T) ) ;
                A1 = TDF_ph.zy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.zy(:,ii_T) = A1 ;
                A = abs( TDF_ph.zx(:,ii_T) ) ;
                A1 = TDF_ph.zx(:,ii_T);
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.zx(:,ii_T) = A1 ;                

            end
        end


        
    end
    % ------------------------------------------------------------------------

    % two types of phonons is not performed at present, see_v3 to have the
    % code lines
%     end % end of the dimensionality check
    
end