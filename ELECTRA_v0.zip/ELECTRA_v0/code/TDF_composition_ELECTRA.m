% Copyright 2021 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %


% this code computes the TDF properties


% in the first dimension, the E values run, 
% in the second dimension, the EF values run,
% in the third dimension, the T values run

% optionally, the band index runs in the second dimension and the rest is
% shifted

% NOTE 
% on 08/05/2019 I added some lines to consider the EF shift imposing that 
% EF_array becomes the EF_matrix column that corresponds at each 
% temperature, and other lines to consider that the maximum EF can be in the gap
%
% on 21/12/2019 I noticed that IIS and screening POP need of another phonon
% process... I shall re-modulate everything...

function [TDF, TDF_n, TDF_ph, TDF_ph_n, TDF_sep, TDF_sep_n, MFP, MFP_n, MFP_ph, MFP_ph_n, MFP_sep, MFP_sep_n, tauE, tauE_n, tauE_ph, tauE_ph_n, tauE_sep, tauE_sep_n, tauE_IIS, tauE_IIS_n] = TDF_composition_ELECTRA(WorkSpace4, taus, taus_matth, taus_IIS, taus_POP) %#codegen
        
    % extraction of the data from the WorkSpace4 struct file
    state_ID = WorkSpace4.state_ID ;           % state ID struct and quantities
    Ek = WorkSpace4.Ek ;
    E_array = WorkSpace4.E_array ;
    T_array = WorkSpace4.T_array ;
    EF_array = WorkSpace4.EF_array ;
    EF_matrix = WorkSpace4.EF_matrix ;
%     N_imp_matrix = WorkSpace4.N_imp_matrix ;

    n_bands_transp = WorkSpace4.n_bands_transp ;
    bands_transp = WorkSpace4.bands_transp ;

    ADP = WorkSpace4.ADP ;                          % scattering instructions
    ADP_IVS = WorkSpace4.ADP_IVS ;
    Alloy = WorkSpace4.Alloy ;
    ODP = WorkSpace4.ODP ;
    POP = WorkSpace4.POP ;
    screening_POP = WorkSpace4.screening_POP ;
    IVS = WorkSpace4.IVS ;
    IIS = WorkSpace4.IIS ;
%     semimetal = WorkSpace4.semimetal;
%     pseudovalence_bands = WorkSpace4.pseudovalence_bands ;
    remove_matth = WorkSpace4.remove_matth ;
%     bipolar_transport = WorkSpace4.bipolar_transport ;
%     Fermi_shift_flag = WorkSpace4.Fermi_shift_flag ;
    sd = WorkSpace4.sd ;
%     constant_tau = WorkSpace4.constant_tau ;
    
    if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes') % scattering parameters, def. pot. e scatt. rate
        tau_pos_ADP = WorkSpace4.tau_pos_ADP ;  
    end
    if strcmp(ODP,'yes')
        tau_pos_ODP = WorkSpace4.tau_pos_ODP ;
    end
    if strcmp(IVS,'yes')
        tau_pos_IVS = WorkSpace4.tau_pos_IVS ;
    end
    if strcmp(POP,'yes')
        tau_pos_POP = WorkSpace4.tau_pos_POP ;
    end
    if strcmp(Alloy,'yes')
        tau_pos_Alloy = WorkSpace4.tau_pos_Alloy ;
    end
    
%     kx_matrix = WorkSpace4.kx_matrix ;
%     ky_matrix = WorkSpace4.ky_matrix ;
%     kz_matrix = WorkSpace4.kz_matrix ;

%     carriers = WorkSpace4.carriers ;
%     if strcmp(semimetal,'yes') && any(pseudovalence_bands(:) == bands_transp(id_n) ) 
%         carriers = 'holes';
%     end

    q0=1.609e-19;             % [col]
    kB=1.38e-23;              % [J/K]
    
    
    % ---------------------------------------------------------------------
    
    
    % Inizialization of the output variables and struct data
    nE = size(E_array,2) ;
    
%     FD = zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
%     dfdE = zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
    
    
    TDF_n=struct(); TDF_ph_n=struct(); TDF_sep_n=struct(); MFP_n=struct(); MFP_ph_n=struct(); MFP_sep_n=struct(); tauE_n=struct(); tauE_ph_n=struct(); tauE_sep_n=struct(); tauE_IIS_n=struct();
    TDF=struct(); TDF_ph=struct(); TDF_sep=struct(); MFP=struct(); MFP_ph=struct(); MFP_sep=struct(); tauE=struct(); tauE_ph=struct(); tauE_sep=struct(); tauE_IIS=struct();
    
    
    % fields with the different bands
    TDF_n.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.zz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    TDF_n.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.yz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.xz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    TDF_n.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.zy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.zx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    MFP_n.x= zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    tauE_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    tauE_IIS_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_IIS_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_IIS_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    
    
    TDF_sep_n.ADP=struct(); TDF_sep_n.ODP=struct(); TDF_sep_n.POP=struct(); TDF_sep_n.IVS=struct(); TDF_sep_n.Alloy=struct();
    TDF_sep.ADP=struct(); TDF_sep.ODP=struct(); TDF_sep.POP=struct(); TDF_sep.IVS=struct(); TDF_sep.Alloy=struct();
    tauE_sep_n.ADP=struct(); tauE_sep_n.ODP=struct(); tauE_sep_n.POP=struct(); tauE_sep_n.IVS=struct(); tauE_sep_n.Alloy=struct();
    tauE_sep.ADP=struct(); tauE_sep.ODP=struct(); tauE_sep.POP=struct(); tauE_sep.IVS=struct(); tauE_sep.Alloy=struct();
    MFP_sep_n.ADP=struct(); MFP_sep_n.ODP=struct(); MFP_sep_n.POP=struct(); MFP_sep_n.IVS=struct(); MFP_sep_n.Alloy=struct();
    MFP_sep.ADP=struct(); MFP_sep.ODP=struct(); MFP_sep.POP=struct(); MFP_sep.IVS=struct(); MFP_sep.Alloy=struct();
    
    TDF_sep_n.ADP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ADP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ADP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.zx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.zx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.IVS.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.IVS.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.IVS.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.zx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.zz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.xz = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.zx = zeros(nE,n_bands_transp,size(T_array,2));
    
    MFP_sep_n.ADP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ADP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ADP.z = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.ODP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ODP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ODP.z = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.IVS.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.IVS.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.IVS.z = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.Alloy.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.Alloy.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.Alloy.z = zeros(nE,n_bands_transp,size(T_array,2));
    
    tauE_sep_n.ADP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ADP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ADP.z = zeros(nE,n_bands_transp,size(T_array,2));
    tauE_sep_n.ODP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ODP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ODP.z = zeros(nE,n_bands_transp,size(T_array,2));
    tauE_sep_n.IVS.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.IVS.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.IVS.z = zeros(nE,n_bands_transp,size(T_array,2));
    tauE_sep_n.Alloy.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.Alloy.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.Alloy.z = zeros(nE,n_bands_transp,size(T_array,2));
    
    
    % fields after summed for the bands
    TDF.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.yy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.zz = zeros(nE,size(EF_array,2),size(T_array,2));
    TDF.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.yz = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.xz = zeros(nE,size(EF_array,2),size(T_array,2));
    TDF.yx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.zy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.zx = zeros(nE,size(EF_array,2),size(T_array,2));
    MFP.x= zeros(nE,size(EF_array,2),size(T_array,2)); MFP.y = zeros(nE,size(EF_array,2),size(T_array,2)); MFP.z = zeros(nE,size(EF_array,2),size(T_array,2));
    tauE.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE.z = zeros(nE,size(EF_array,2),size(T_array,2));
    tauE_IIS.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_IIS.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_IIS.z = zeros(nE,size(EF_array,2),size(T_array,2));
    
    TDF_sep.ADP.xx = zeros(nE,size(T_array,2)); TDF_sep.ADP.yy = zeros(nE,size(T_array,2)); TDF_sep.ADP.zz = zeros(nE,size(T_array,2));
    TDF_sep.ADP.xy = zeros(nE,size(T_array,2)); TDF_sep.ADP.yz = zeros(nE,size(T_array,2)); TDF_sep.ADP.xz = zeros(nE,size(T_array,2));
    TDF_sep.ADP.yx = zeros(nE,size(T_array,2)); TDF_sep.ADP.zy = zeros(nE,size(T_array,2)); TDF_sep.ADP.zx = zeros(nE,size(T_array,2));
    TDF_sep.ODP.xx = zeros(nE,size(T_array,2)); TDF_sep.ODP.yy = zeros(nE,size(T_array,2)); TDF_sep.ODP.zz = zeros(nE,size(T_array,2));
    TDF_sep.ODP.xy = zeros(nE,size(T_array,2)); TDF_sep.ODP.yz = zeros(nE,size(T_array,2)); TDF_sep.ODP.xz = zeros(nE,size(T_array,2));
    TDF_sep.ODP.yx = zeros(nE,size(T_array,2)); TDF_sep.ODP.zy = zeros(nE,size(T_array,2)); TDF_sep.ODP.zx = zeros(nE,size(T_array,2));
    TDF_sep.IVS.xx = zeros(nE,size(T_array,2)); TDF_sep.IVS.yy = zeros(nE,size(T_array,2)); TDF_sep.IVS.zz = zeros(nE,size(T_array,2));
    TDF_sep.IVS.xy = zeros(nE,size(T_array,2)); TDF_sep.IVS.yz = zeros(nE,size(T_array,2)); TDF_sep.IVS.xz = zeros(nE,size(T_array,2));
    TDF_sep.IVS.yx = zeros(nE,size(T_array,2)); TDF_sep.IVS.zy = zeros(nE,size(T_array,2)); TDF_sep.IVS.zx = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.xx = zeros(nE,size(T_array,2)); TDF_sep.Alloy.yy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.zz = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.xy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.yz = zeros(nE,size(T_array,2)); TDF_sep.Alloy.xz = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.yx = zeros(nE,size(T_array,2)); TDF_sep.Alloy.zy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.zx = zeros(nE,size(T_array,2));
    
    MFP_sep.ADP.x = zeros(nE,size(T_array,2)); MFP_sep.ADP.y = zeros(nE,size(T_array,2)); MFP_sep.ADP.z = zeros(nE,size(T_array,2));
    MFP_sep.ODP.x = zeros(nE,size(T_array,2)); MFP_sep.ODP.y = zeros(nE,size(T_array,2)); MFP_sep.ODP.z = zeros(nE,size(T_array,2));
    MFP_sep.IVS.x = zeros(nE,size(T_array,2)); MFP_sep.IVS.y = zeros(nE,size(T_array,2)); MFP_sep.IVS.z = zeros(nE,size(T_array,2));
    MFP_sep.Alloy.x = zeros(nE,size(T_array,2)); MFP_sep.Alloy.y = zeros(nE,size(T_array,2)); MFP_sep.Alloy.z = zeros(nE,size(T_array,2));
    
    tauE_sep.ADP.x = zeros(nE,size(T_array,2)); tauE_sep.ADP.y = zeros(nE,size(T_array,2)); tauE_sep.ADP.z = zeros(nE,size(T_array,2));
    tauE_sep.ODP.x = zeros(nE,size(T_array,2)); tauE_sep.ODP.y = zeros(nE,size(T_array,2)); tauE_sep.ODP.z = zeros(nE,size(T_array,2));
    tauE_sep.IVS.x = zeros(nE,size(T_array,2)); tauE_sep.IVS.y = zeros(nE,size(T_array,2)); tauE_sep.IVS.z = zeros(nE,size(T_array,2));
    tauE_sep.Alloy.x = zeros(nE,size(T_array,2)); tauE_sep.Alloy.y = zeros(nE,size(T_array,2)); tauE_sep.Alloy.z = zeros(nE,size(T_array,2));
    
    
    % now, idem as above for POP and all but IIS (ph), separating according
    % if POP is screened or not
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_sep_n.POP.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_sep_n.POP.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.xz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_sep_n.POP.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.zx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        MFP_sep_n.POP.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        tauE_sep_n.POP.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
               
        TDF_sep.POP.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.yy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.zz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_sep.POP.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.yz = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.xz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_sep.POP.yx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.zy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.zx = zeros(nE,size(EF_array,2),size(T_array,2));
        MFP_sep.POP.x = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_sep.POP.y = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_sep.POP.z = zeros(nE,size(EF_array,2),size(T_array,2));
        tauE_sep.POP.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_sep.POP.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_sep.POP.z = zeros(nE,size(EF_array,2),size(T_array,2));
        
        TDF_ph_n.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.zz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_ph_n.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.yz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.xz = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        TDF_ph_n.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.zy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.zx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        MFP_ph_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_ph_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_ph_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        tauE_ph_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_ph_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_ph_n.z = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));

        TDF_ph.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.yy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.zz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_ph.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.yz = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.xz = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_ph.yx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.zy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.zx = zeros(nE,size(EF_array,2),size(T_array,2));
        MFP_ph.x= zeros(nE,size(EF_array,2),size(T_array,2)); MFP_ph.y = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_ph.z = zeros(nE,size(EF_array,2),size(T_array,2));
        tauE_ph.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_ph.y = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_ph.z = zeros(nE,size(EF_array,2),size(T_array,2));
           
    else
        
        TDF_sep_n.POP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_sep_n.POP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.xz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_sep_n.POP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zx = zeros(nE,n_bands_transp,size(T_array,2));
        MFP_sep_n.POP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.POP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.POP.z = zeros(nE,n_bands_transp,size(T_array,2));
        tauE_sep_n.POP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.POP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.POP.z = zeros(nE,n_bands_transp,size(T_array,2));
        
        TDF_sep.POP.xx = zeros(nE,size(T_array,2)); TDF_sep.POP.yy = zeros(nE,size(T_array,2)); TDF_sep.POP.zz = zeros(nE,size(T_array,2));
        TDF_sep.POP.xy = zeros(nE,size(T_array,2)); TDF_sep.POP.yz = zeros(nE,size(T_array,2)); TDF_sep.POP.xz = zeros(nE,size(T_array,2));
        TDF_sep.POP.yx = zeros(nE,size(T_array,2)); TDF_sep.POP.zy = zeros(nE,size(T_array,2)); TDF_sep.POP.zx = zeros(nE,size(T_array,2));
        MFP_sep.POP.x = zeros(nE,size(T_array,2)); MFP_sep.POP.y = zeros(nE,size(T_array,2)); MFP_sep.POP.z = zeros(nE,size(T_array,2));
        tauE_sep.POP.x = zeros(nE,size(T_array,2)); tauE_sep.POP.y = zeros(nE,size(T_array,2)); tauE_sep.POP.z = zeros(nE,size(T_array,2));
        
        TDF_ph_n.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.yy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.zz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_ph_n.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.yz = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.xz = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_ph_n.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.zx = zeros(nE,n_bands_transp,size(T_array,2));
        MFP_ph_n.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_ph_n.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_ph_n.z = zeros(nE,n_bands_transp,size(T_array,2));
        tauE_ph_n.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_ph_n.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_ph_n.z = zeros(nE,n_bands_transp,size(T_array,2));

        TDF_ph.xx = zeros(nE,size(T_array,2)); TDF_ph.yy = zeros(nE,size(T_array,2)); TDF_ph.zz = zeros(nE,size(T_array,2));
        TDF_ph.xy = zeros(nE,size(T_array,2)); TDF_ph.yz = zeros(nE,size(T_array,2)); TDF_ph.xz = zeros(nE,size(T_array,2));
        TDF_ph.yx = zeros(nE,size(T_array,2)); TDF_ph.zy = zeros(nE,size(T_array,2)); TDF_ph.zx = zeros(nE,size(T_array,2));
        MFP_ph.x= zeros(nE,size(T_array,2)); MFP_ph.y = zeros(nE,size(T_array,2)); MFP_ph.z = zeros(nE,size(T_array,2));
        tauE_ph.x = zeros(nE,size(T_array,2)); tauE_ph.y = zeros(nE,size(T_array,2)); tauE_ph.z = zeros(nE,size(T_array,2));
        
    end
    
    
    % ---------------------------------------------------------------------
    % End of the inizialitions of all the output struct data types etc. 
    
    
    % formation of the FD and dfdE
%     for iEF=1:size(EF_array,2)
%         for iT=1:size(T_array,2)
%             EF_array = EF_matrix(:,iT)';
% 
%             FD(:,iEF,iT)=1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1);
%             dfdE(:,iEF,iT)=-1./(kB*T_array(iT)/q0).*exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1).^2;
%         end
%     end

%     if strcmp(carriers,'holes')
%         carrier_sign = -1;
%     else 
%         carrier_sign = 1;
%     end

    %calculation of the Transport Density Fnction, 1D array with the TDF values,
    %the size is the same of the E_array
%     if strcmp(dimensionality,'3D')

        if strcmp(IIS,'yes')
            for id_E=1:size(E_array,2) %parfor
                for id_n=1:n_bands_transp 
                    for id_EF = 1:size(EF_array,2)
                        for id_T = 1:size(T_array,2)
                            EF_array = EF_matrix(:,id_T)';
    %                         if E_array(id_E) < max(EF_array)+6*kB*T_array(iT)/q0
                            if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0 ) || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 ) 
                               % it takes all the energies for which a value has been calculated
                    % contribution of each k point with energy E, for all the bands
                    % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                    % length corresponding to the number of points in that state,
                    % each array state_ID(id_E,id_n) have different length
                                if not(size(taus_IIS(id_E,id_n).x)) == 0 % the state is not empty
                                    if size(T_array,2) == 1
%                                         tau_IIS_x_temp = smooth( squeeze(taus_IIS(id_E,id_n).x(id_EF,:)) ,2)' ;
%                                         tau_IIS_y_temp = smooth( squeeze(taus_IIS(id_E,id_n).y(id_EF,:)) ,2)' ;
%                                         tau_IIS_z_temp = smooth( squeeze(taus_IIS(id_E,id_n).z(id_EF,:)) ,2)' ;
                                        tau_IIS_x_temp = squeeze(taus_IIS(id_E,id_n).x(id_EF,:)) ;
                                        tau_IIS_y_temp = squeeze(taus_IIS(id_E,id_n).y(id_EF,:)) ;
                                        tau_IIS_z_temp = squeeze(taus_IIS(id_E,id_n).z(id_EF,:)) ;                                        
                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                                tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                                tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                                tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,:)) ,2)' ;
                                        end
                                    else
                                        tau_IIS_x_temp = smooth( squeeze(taus_IIS(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                        tau_IIS_y_temp = smooth( squeeze(taus_IIS(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                        tau_IIS_z_temp = smooth( squeeze(taus_IIS(id_E,id_n).z(id_EF,id_T,:)) ,2)' ;
                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                            
                                                tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                                tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                                tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,id_T,:)) ,2)' ;
                                        end
                                    end
                                    [~,Nzero] = find(~tau_IIS_x_temp) ;
                                    tau_IIS_x_temp(Nzero) = Inf ;
                                    [~,Nzero] = find(~tau_IIS_y_temp) ;
                                    tau_IIS_y_temp(Nzero) = Inf ;
                                    [~,Nzero] = find(~tau_IIS_z_temp) ;
                                    tau_IIS_z_temp(Nzero) = Inf ;
                                else
                                    tau_IIS_x_temp = [];
                                    tau_IIS_y_temp = [];
                                    tau_IIS_z_temp = [];
                                    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            tau_POP_x_temp = [];
                                            tau_POP_y_temp = [];
                                            tau_POP_z_temp = [];
                                    end
                                end


                                if not(size(taus_matth(id_E,id_n).x)) == 0  % the state is involved in the transport (not empty)                                
                                    if strcmp(remove_matth,'yes') % "neutralize" the taus_matth in the case it is not needed
                                        if size(T_array,2) == 1
                                            taus_matth(id_E,id_n).x(:) = Inf; 
                                            taus_matth(id_E,id_n).y(:) = Inf; 
                                            taus_matth(id_E,id_n).z(:) = Inf; 
                                        else
                                            taus_matth(id_E,id_n).x(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).y(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).z(:,id_T) = Inf ; 
                                        end
                                    end

                                    if size(T_array,2) == 1

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.zz(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);



                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.z(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);



                                            tauE_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.z(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);



                                            tauE_IIS_n.x(id_E,id_n,id_EF) = 1 ./ ( sum( 1./tau_IIS_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                            tauE_IIS_n.y(id_E,id_n,id_EF) = 1 ./ ( sum( 1./tau_IIS_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                            tauE_IIS_n.z(id_E,id_n,id_EF) = 1 ./ ( sum( 1./tau_IIS_z_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                        else

                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.zz(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.z(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.z(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).z +...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF) = 1./sum( 1./(tau_IIS_x_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.y(id_E,id_n,id_EF) = 1./sum( 1./(tau_IIS_y_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.z(id_E,id_n,id_EF) = 1./sum( 1./(tau_IIS_z_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);


                                        end                                    


                                    else % more than one T

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')

                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zz(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.z(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.z(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).z(:,id_T)' +...
                                                1./tau_IIS_z_temp + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF,id_T) = 1./sum( 1./(tau_IIS_x_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.y(id_E,id_n,id_EF,id_T) = 1./sum( 1./(tau_IIS_y_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.z(id_E,id_n,id_EF,id_T) = 1./sum( 1./(tau_IIS_z_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);


                                        else

                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zz(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.z(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_IIS_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);



                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.z(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).z(:,id_T)' +...
                                                1./tau_IIS_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF,id_T) = 1./sum( 1./(tau_IIS_x_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.y(id_E,id_n,id_EF,id_T) = 1./sum( 1./(tau_IIS_y_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.z(id_E,id_n,id_EF,id_T) = 1./sum( 1./(tau_IIS_z_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);


                                        end
                                    end
                                end
                            end
                        end
                    end
                end           
            end
            TDF.xx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xx,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            TDF.yy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yy,2)); % TDF = TDF(E,EF,T)
            TDF.zz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zz,2));
            TDF.xy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xy,2));
            TDF.xz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xz,2));
            TDF.yz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yz,2));
            TDF.yx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yx,2));
            TDF.zx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zx,2));
            TDF.zy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zy,2));

            %MFP_x = (2/((2*pi)^3)).*squeeze(sum(MFP_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            MFP.x = squeeze(mean(abs(MFP_n.x),2));
            MFP.y = squeeze(mean(abs(MFP_n.y),2));
            MFP.z = squeeze(mean(abs(MFP_n.z),2));

            tauE.x = squeeze(sum(tauE_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE.y = squeeze(sum(tauE_n.y,2)); % tauE = tauE(E,EF,T)
            tauE.z = squeeze(sum(tauE_n.z,2));
            tauE_IIS.x = squeeze(sum(tauE_IIS_n.x,2)); 
            tauE_IIS.y = squeeze(sum(tauE_IIS_n.y,2)); 
            tauE_IIS.z = squeeze(sum(tauE_IIS_n.z,2));

            % controls over TDFs
            Ninf = isinf(TDF.xx); TDF.xx(Ninf) = 0; NNan = isnan(TDF.xx); TDF.xx(NNan) = 0;
            Ninf = isinf(TDF.yy); TDF.yy(Ninf) = 0; NNan = isnan(TDF.yy); TDF.yy(NNan) = 0;
            Ninf = isinf(TDF.zz); TDF.zz(Ninf) = 0; NNan = isnan(TDF.zz); TDF.zz(NNan) = 0;
            Ninf = isinf(TDF.xy); TDF.xy(Ninf) = 0; NNan = isnan(TDF.xy); TDF.xy(NNan) = 0;
            Ninf = isinf(TDF.yz); TDF.yz(Ninf) = 0; NNan = isnan(TDF.yz); TDF.yz(NNan) = 0;
            Ninf = isinf(TDF.xz); TDF.xz(Ninf) = 0; NNan = isnan(TDF.xz); TDF.xz(NNan) = 0;
            Ninf = isinf(TDF.yx); TDF.yx(Ninf) = 0; NNan = isnan(TDF.yx); TDF.yx(NNan) = 0;
            Ninf = isinf(TDF.zy); TDF.zy(Ninf) = 0; NNan = isnan(TDF.zy); TDF.zy(NNan) = 0;
            Ninf = isinf(TDF.zx); TDF.zx(Ninf) = 0; NNan = isnan(TDF.zx); TDF.zx(NNan) = 0;


        else % no IIS 

            for id_E=1:size(E_array,2) %parfor
                for id_n=1:n_bands_transp 
                    for id_EF = 1:size(EF_array,2)
                        for id_T = 1:size(T_array,2)
                            EF_array = EF_matrix(:,id_T)';
                            if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )
                                % it takes all the energies for which a value has been calculated
                    % contribution of each k point with energy E, for all the bands
                    % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                    % length corresponding to the number of points in that state,
                    % each array state_ID(id_E,id_n) have different length
                    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                        if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                    if size(T_array,2) == 1
                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                        tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,:)) ,2)' ;
                                    else                                            
                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                        tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,id_T,:)) ,2)' ;
                                    end
                        else
                                    tau_POP_x_temp = [];
                                    tau_POP_y_temp = [];
                                    tau_POP_z_temp = [];
                        end
                    end


                                if not(size(taus_matth(id_E,id_n).x)) == 0  % the state is involved in the transport
                                    if strcmp(remove_matth,'yes') % "neutralize" the taus_matth in the case it is not needed
                                        if size(T_array,2) == 1
                                            taus_matth(id_E,id_n).x(:) = Inf; 
                                            taus_matth(id_E,id_n).y(:) = Inf; 
                                            taus_matth(id_E,id_n).z(:) = Inf; 
                                        else
                                            taus_matth(id_E,id_n).x(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).y(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).z(:,id_T) = Inf ; 
                                        end
                                    end

                                    if size(T_array,2) == 1

                                         if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                               + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.zz(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.z(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                + 1./tau_POP_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.z(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).z +...
                                                + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                         else                                         

                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x ...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y ...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.zz(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z ...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z ...
                                                .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z ...
                                                .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).x ...
                                                .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).y ...
                                                .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.z(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF) = sum( taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            tauE_n.y(id_E,id_n,id_EF) = sum( taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            tauE_n.z(id_E,id_n,id_EF) = sum( taus_matth(id_E,id_n).z .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                         end

                                    else % more temperature values

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                        
                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zz(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.z(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                1./tau_POP_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        


                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.z(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).z(:,id_T)' +...
                                                1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                        else

                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)'...
                                            .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)'...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.zz(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)'...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.zx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).x(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.zy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).y(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.z(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                                                             

                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( taus_matth(id_E,id_n).x(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            tauE_n.z(id_E,id_n,id_EF,id_T) = sum( taus_matth(id_E,id_n).z(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                        end   
                                    end
                                end
                            end
                        end
                    end
                end           
            end
            TDF.xx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xx,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            TDF.yy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yy,2));
            TDF.zz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zz,2));
            TDF.xy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xy,2));
            TDF.xz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xz,2));
            TDF.yz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yz,2));
            TDF.yx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yx,2));
            TDF.zx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zx,2));
            TDF.zy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zy,2));

            MFP.x = squeeze(mean(abs(MFP_n.x),2));
            MFP.y = squeeze(mean(abs(MFP_n.y),2));
            MFP.z = squeeze(mean(abs(MFP_n.z),2));

            tauE.x = squeeze(sum(tauE_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE.y = squeeze(sum(tauE_n.y,2)); % tauE = tauE(E,EF,T)
            tauE.z = squeeze(sum(tauE_n.z,2));

            % controls over TDFs
            Ninf = isinf(TDF.xx); TDF.xx(Ninf) = 0; NNan = isnan(TDF.xx); TDF.xx(NNan) = 0;
            Ninf = isinf(TDF.yy); TDF.yy(Ninf) = 0; NNan = isnan(TDF.yy); TDF.yy(NNan) = 0;
            Ninf = isinf(TDF.zz); TDF.zz(Ninf) = 0; NNan = isnan(TDF.zz); TDF.zz(NNan) = 0;
            Ninf = isinf(TDF.xy); TDF.xy(Ninf) = 0; NNan = isnan(TDF.xy); TDF.xy(NNan) = 0;
            Ninf = isinf(TDF.yz); TDF.yz(Ninf) = 0; NNan = isnan(TDF.yz); TDF.yz(NNan) = 0;
            Ninf = isinf(TDF.xz); TDF.xz(Ninf) = 0; NNan = isnan(TDF.xz); TDF.xz(NNan) = 0;
            Ninf = isinf(TDF.yx); TDF.yx(Ninf) = 0; NNan = isnan(TDF.yx); TDF.yx(NNan) = 0;
            Ninf = isinf(TDF.zy); TDF.zy(Ninf) = 0; NNan = isnan(TDF.zy); TDF.zy(NNan) = 0;
            Ninf = isinf(TDF.zx); TDF.zx(Ninf) = 0; NNan = isnan(TDF.zx); TDF.zx(NNan) = 0;
        end

% Denoising the E-dependent quantities
%         for ii_EF = 1:size(EF_array,2)
%             for ii_T = 1:size(T_array,2)
%                     TDF.xx(:,ii_EF,ii_T) = smooth( TDF.xx(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.yy(:,ii_EF,ii_T) = smooth( TDF.yy(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.zz(:,ii_EF,ii_T) = smooth( TDF.zz(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.xy(:,ii_EF,ii_T) = smooth( TDF.xy(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.xz(:,ii_EF,ii_T) = smooth( TDF.xz(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.yz(:,ii_EF,ii_T) = smooth( TDF.yz(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.yx(:,ii_EF,ii_T) = smooth( TDF.yx(:,ii_EF,ii_T), 'rlowess' ) ;
%                     TDF.zy(:,ii_EF,ii_T) = smooth( TDF.zy(:,ii_EF,ii_T), 'rlowess') ;
%                     TDF.zx(:,ii_EF,ii_T) = smooth( TDF.zx(:,ii_EF,ii_T), 'rlowess' ) ;
%                     
%                     MFP.x(:,ii_EF,ii_T) = smooth( MFP.x(:,ii_EF,ii_T), 'rlowess' ) ;
%                     MFP.y(:,ii_EF,ii_T) = smooth( MFP.y(:,ii_EF,ii_T), 'rlowess' ) ;
%                     MFP.z(:,ii_EF,ii_T) = smooth( MFP.z(:,ii_EF,ii_T), 'rlowess' ) ;                    
%                     tauE.x(:,ii_EF,ii_T) = smooth( tauE.x(:,ii_EF,ii_T), 'rlowess' ) ;
%                     tauE.y(:,ii_EF,ii_T) = smooth( tauE.y(:,ii_EF,ii_T), 'rlowess' ) ;
%                     tauE.z(:,ii_EF,ii_T) = smooth( tauE.z(:,ii_EF,ii_T), 'rlowess' ) ;
%                     if strcmp(IIS,'yes')                        
%                         tauE_IIS.x(:,ii_EF,ii_T) = smooth( tauE_IIS.x(:,ii_EF,ii_T), 'rlowess' ) ;
%                         tauE_IIS.y(:,ii_EF,ii_T) = smooth( tauE_IIS.y(:,ii_EF,ii_T), 'rlowess' ) ;
%                         tauE_IIS.z(:,ii_EF,ii_T) = smooth( tauE_IIS.z(:,ii_EF,ii_T), 'rlowess' ) ;
%                     end
%                     
%             end
%         end
        for ii_EF = 1:size(EF_array,2)
            for ii_T = 1:size(T_array,2)
                    
                    A = abs( TDF.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.zz(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.zz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.xz(:,ii_EF,ii_T) ) ;
                    A1 = TDF.xz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yz(:,ii_EF,ii_T) ) ;
                    A1 = TDF.yz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.zy(:,ii_EF,ii_T) ) ;
                    A1 = TDF.zy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.zy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.zx(:,ii_EF,ii_T) ) ;
                    A1 = TDF.zx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.zx(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( MFP.x(:,ii_EF,ii_T) ) ;
                    A1 = MFP.x(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP.y(:,ii_EF,ii_T) ) ;
                    A1 = MFP.y(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.y(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP.z(:,ii_EF,ii_T) ) ;
                    A1 = MFP.z(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.z(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.x(:,ii_EF,ii_T) ) ;
                    A1 = tauE.x(:,ii_EF,ii_T);
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.y(:,ii_EF,ii_T) ) ;
                    A1 = tauE.y(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.y(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.z(:,ii_EF,ii_T) ) ;
                    A1 = tauE.z(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.z(:,ii_EF,ii_T) = A1 ;
                    if strcmp(IIS,'yes')
                        A = abs( tauE_IIS.x(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.x(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.x(:,ii_EF,ii_T) = A1 ;
                        A = abs( tauE_IIS.y(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.y(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.y(:,ii_EF,ii_T) = A1 ;
                        A = abs( tauE_IIS.z(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.z(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.z(:,ii_EF,ii_T) = A1 ;
                    end
                    
            end
        end




    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------


    % ---------------------------------------------------------------------
    % ------------------- WITHOUT IMPURITIES ------------------------------
    % for the calculations without impurities I use a different Fermi array
        
%     if strcmp(constant_tau,'no')
%         
%                 
%         EF_array = EF_matrix(:,1);
% 
%         EF_array_ph = min(EF_array):(abs(max(EF_array)-min(EF_array)))/200:max(EF_array);
% 
%         if strcmp(bipolar_transport,'no') 
%             if strcmp(Fermi_shift_flag,'yes')
%                 if strcmp(semimetal,'no')    
%                     [EF_matrix_ph, N_imp_matrix_ph] = Fermi_shift_unipolar_VOMBATO_C( EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd, bands_transp ) ;
%                 elseif strcmp(semimetal,'yes') % this flag should not be here anymore, semimetal are like normal bipolar rather than special unipolar
%                     [EF_matrix_ph, N_imp_matrix_ph] = Fermi_shift_bipolar_VOMBATO_C( EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd ) ;
%                 end
%             elseif strcmp(Fermi_shift_flag,'no')
%                 EF_matrix_ph = zeros(size(EF_array_ph,2),size(T_array,2));
%                 for iT = size(T_array,2) : -1 : 1
%                     EF_matrix_ph(:,iT) = EF_array_ph';                
%                     for iEF = size(EF_array_ph,2):-1:1
%                         FD_ph(:,iEF,iT)=1./(exp((E_array-EF_array_ph(iEF))./(kB*T_array(iT)/q0))+1);
%                         integrand_n_imp(:,iEF,iT)=DOS_tot.*FD_ph(:,iEF,iT)';
%                     end
%                     N_imp_matrix_ph = squeeze(trapz(E_array,integrand_n_imp,1));  % total charge carrier concentration in m^(-3) for ph.limited transport, prob. useless
%                 end
%             end
%         % calculation ot the Fermi array at each temperature (Fermi shift upon T)
%         % considering the carriers' density to be constant, i.e. in the extrinsic
%         % region
%         elseif strcmp(bipolar_transport,'yes')
%             if strcmp(Fermi_shift_flag,'yes')
%                 [EF_matrix_ph, N_imp_matrix_ph] = Fermi_shift_bipolar_VOMBATO_C( EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd, pseudoconduction_bands, pseudovalence_bands  ) ;
%                 % same as above but considering both CBs and VBs
%                 EF_array_ph = EF_matrix_ph(:,1)'; 
%         %         an intrinsic semiconductor has the same number of thermally
%         %         generated electrons and holes so that the intrinsic Fermi level
%         %         can be not in the midgap.
%             elseif strcmp(Fermi_shift_flag,'no')
%                 EF_matrix_ph = zeros(size(EF_array_ph,2),size(T_array,2));
%                 for iT = size(T_array,2) : -1 : 1
%                     EF_matrix_ph(:,iT) = EF_array_ph';
%                 end
%             end
%         end    
%         
% 
%         FD_ph = zeros(size(E_array,2),size(EF_array_ph,2),size(T_array,2));
%         dfdE_ph = zeros(size(E_array,2),size(EF_array_ph,2),size(T_array,2));
% 
%         for iEF = size(EF_matrix_ph,1):-1:1
%             for iT = size(T_array,2):-1:1
%                     FD_ph(:,iEF,iT) = 1./(exp((E_array-EF_matrix_ph(iEF,iT))./(kB*T_array(iT)/q0))+1);
%                     dfdE_ph(:,iEF,iT) = -1./(kB*T_array(iT)/q0).*exp((E_array-EF_matrix_ph(iEF,iT))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_matrix_ph(iEF,iT))./(kB*T_array(iT)/q0))+1).^2;
% %                     integrand_n_carrier_ph(:,iEF,iT) = (DOS_tot'.*FD_ph(:,iEF,iT))';
%             end
%         end
% %         n_carrier_ph = squeeze(trapz(E_array,integrand_n_carrier_ph,1)); 
%     end
    
    
    % -------------  ADP only ---------------------------------------------
    if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes')
        
 
        for id_E = size(E_array,2):-1:1 
            for id_n = n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauADP ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).x(tau_pos_ADP,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ADP,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).z(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).z(tau_pos_ADP,NNan,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_ADP,:,id_T)); % for the other scatt. mech. this control is into the subfunctions
                    taus(id_E,id_n).x(tau_pos_ADP,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ADP,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).z(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).z(tau_pos_ADP,NInf,id_T)=0;                
                    %------------------------------------------
                        TDF_sep_n.ADP.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.zz(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus(id_E,id_n).z(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ADP.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).z(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.xz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).z(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ADP.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.zy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.zx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.ADP.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_ADP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.ADP.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_ADP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.ADP.z(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus(id_E,id_n).z(tau_pos_ADP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.ADP.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ADP.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ADP.z(id_E,id_n,id_T) = sum( taus(id_E,id_n).z(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);  
                                end
                    end

                end
            end            
        end
        TDF_sep.ADP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.ADP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.zz,2));
        TDF_sep.ADP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.xy,2)); % it sums the contribution of the bands
        TDF_sep.ADP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.xz,2));
        TDF_sep.ADP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.yx,2)); % it sums the contribution of the bands
        TDF_sep.ADP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ADP.zx,2));
        Ninf = isinf(TDF_sep.ADP.xx); TDF_sep.ADP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xx); TDF_sep.ADP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yy); TDF_sep.ADP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yy); TDF_sep.ADP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.zz); TDF_sep.ADP.zz(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.zz); TDF_sep.ADP.zz(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.xy); TDF_sep.ADP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xy); TDF_sep.ADP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yz); TDF_sep.ADP.yz(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yz); TDF_sep.ADP.yz(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.xz); TDF_sep.ADP.xz(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xz); TDF_sep.ADP.xz(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yx); TDF_sep.ADP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yx); TDF_sep.ADP.yx(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.zy); TDF_sep.ADP.zy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.zy); TDF_sep.ADP.zy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.zx); TDF_sep.ADP.zx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.zx); TDF_sep.ADP.zx(NNan) = 0;

        MFP_sep.ADP.x = squeeze(mean(abs(MFP_sep_n.ADP.x),2));
        MFP_sep.ADP.y = squeeze(mean(abs(MFP_sep_n.ADP.y),2));
        MFP_sep.ADP.z = squeeze(mean(abs(MFP_sep_n.ADP.z),2));

        tauE_sep.ADP.x = squeeze(sum(tauE_sep_n.ADP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.ADP.y = squeeze(sum(tauE_sep_n.ADP.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.ADP.z = squeeze(sum(tauE_sep_n.ADP.z,2));


%         for ii_T = 1:size(T_array,2)
%                 TDF_sep.ADP.xx(:,ii_T) = smooth( TDF_sep.ADP.xx(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.yy(:,ii_T) = smooth( TDF_sep.ADP.yy(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.zz(:,ii_T) = smooth( TDF_sep.ADP.zz(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.xy(:,ii_T) = smooth( TDF_sep.ADP.xy(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.xz(:,ii_T) = smooth( TDF_sep.ADP.xz(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.yz(:,ii_T) = smooth( TDF_sep.ADP.yz(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.yx(:,ii_T) = smooth( TDF_sep.ADP.yx(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.zy(:,ii_T) = smooth( TDF_sep.ADP.zy(:,ii_T), 'rlowess'  ) ;
%                 TDF_sep.ADP.zx(:,ii_T) = smooth( TDF_sep.ADP.zx(:,ii_T), 'rlowess'  ) ;
%         end
        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.ADP.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.xy(:,ii_T) ) ;
            A1 = TDF_sep.ADP.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.xz(:,ii_T) ) ;
            A1 = TDF_sep.ADP.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yz(:,ii_T) ) ;
            A1 = TDF_sep.ADP.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yx(:,ii_T) ) ;
            A1 = TDF_sep.ADP.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.zy(:,ii_T) ) ;
            A1 = TDF_sep.ADP.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.zx(:,ii_T) ) ;
            A1 = TDF_sep.ADP.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.zx(:,ii_T) = A1 ;

        end

    end
    % --------------------------------------------------------------------------------------------------------


    % ---------  ODP only -----------------------------------------------------
    if strcmp(ODP,'yes')


        for id_E=size(E_array,2):-1:1 %parfor
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauODP ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).x(tau_pos_ODP,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ODP,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).z(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).z(tau_pos_ODP,NNan,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).x(tau_pos_ODP,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ODP,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).z(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).z(tau_pos_ODP,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.ODP.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.zz(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus(id_E,id_n).z(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ODP.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).z(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.xz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).z(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.ODP.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.zy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.zx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.ODP.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_ODP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.ODP.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_ODP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.ODP.z(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus(id_E,id_n).z(tau_pos_ODP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.ODP.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ODP.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ODP.z(id_E,id_n,id_T) = sum( taus(id_E,id_n).z(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                         

                                end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.ODP.xx); TDF_sep_n.ODP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.xx); TDF_sep_n.ODP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.yy); TDF_sep_n.ODP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.yy); TDF_sep_n.ODP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.zz); TDF_sep_n.ODP.zz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.zz); TDF_sep_n.ODP.zz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.xy); TDF_sep_n.ODP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.xy); TDF_sep_n.ODP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.yz); TDF_sep_n.ODP.yz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.yz); TDF_sep_n.ODP.yz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.xz); TDF_sep_n.ODP.xz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.xz); TDF_sep_n.ODP.xz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.yx); TDF_sep_n.ODP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.yx); TDF_sep_n.ODP.yx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.zy); TDF_sep_n.ODP.zy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.zy); TDF_sep_n.ODP.zy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.zx); TDF_sep_n.ODP.zx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.zx); TDF_sep_n.ODP.zx(NNan) = 0;
        TDF_sep.ODP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.ODP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.zz,2));
        TDF_sep.ODP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.xy,2)); % it sums the contribution of the bands
        TDF_sep.ODP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.xz,2));
        TDF_sep.ODP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.yx,2)); % it sums the contribution of the bands
        TDF_sep.ODP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.ODP.zx,2));
        

        MFP_sep.ODP.x = squeeze(mean(abs(MFP_sep_n.ODP.x),2));
        MFP_sep.ODP.y = squeeze(mean(abs(MFP_sep_n.ODP.y),2));
        MFP_sep.ODP.z = squeeze(mean(abs(MFP_sep_n.ODP.z),2));

        tauE_sep.ODP.x = squeeze(sum(tauE_sep_n.ODP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.ODP.y = squeeze(sum(tauE_sep_n.ODP.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.ODP.z = squeeze(sum(tauE_sep_n.ODP.z,2));


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.ODP.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.xy(:,ii_T) ) ;
            A1 = TDF_sep.ODP.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.xz(:,ii_T) ) ;
            A1 = TDF_sep.ODP.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yz(:,ii_T) ) ;
            A1 = TDF_sep.ODP.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yx(:,ii_T) ) ;
            A1 = TDF_sep.ODP.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.zy(:,ii_T) ) ;
            A1 = TDF_sep.ODP.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.zx(:,ii_T) ) ;
            A1 = TDF_sep.ODP.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.zx(:,ii_T) = A1 ;

        end
        
    end
    % --------------------------------------------------------------------------------

    % ---------  IVS only -----------------------------------------------------
    if strcmp(IVS,'yes')
       
        
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauIVS ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).x(tau_pos_IVS,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).y(tau_pos_IVS,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).z(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).z(tau_pos_IVS,NNan,id_T)=0;                
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).x(tau_pos_IVS,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).y(tau_pos_IVS,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).z(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).z(tau_pos_IVS,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.IVS.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.zz(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus(id_E,id_n).z(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.IVS.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).z(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.xz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).z(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.IVS.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.zy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.zx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.IVS.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_IVS,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.IVS.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_IVS,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.IVS.z(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus(id_E,id_n).z(tau_pos_IVS,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.IVS.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.IVS.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.IVS.z(id_E,id_n,id_T) = sum( taus(id_E,id_n).z(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                          

                                end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.IVS.xx); TDF_sep_n.IVS.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.xx); TDF_sep_n.IVS.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.yy); TDF_sep_n.IVS.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.yy); TDF_sep_n.IVS.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.zz); TDF_sep_n.IVS.zz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.zz); TDF_sep_n.IVS.zz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.xy); TDF_sep_n.IVS.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.xy); TDF_sep_n.IVS.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.yz); TDF_sep_n.IVS.yz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.yz); TDF_sep_n.IVS.yz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.xz); TDF_sep_n.IVS.xz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.xz); TDF_sep_n.IVS.xz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.yx); TDF_sep_n.IVS.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.yx); TDF_sep_n.IVS.yx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.zy); TDF_sep_n.IVS.zy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.zy); TDF_sep_n.IVS.zy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.zx); TDF_sep_n.IVS.zx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.zx); TDF_sep_n.IVS.zx(NNan) = 0;
        TDF_sep.IVS.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.xx ,2)); % it sums the contribution of the bands
        TDF_sep.IVS.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.zz,2));
        TDF_sep.IVS.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.xy,2)); % it sums the contribution of the bands
        TDF_sep.IVS.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.xz,2));
        TDF_sep.IVS.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.yx,2)); % it sums the contribution of the bands
        TDF_sep.IVS.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.IVS.zx,2));
        

        MFP_sep.IVS.x = squeeze(mean(abs(MFP_sep_n.IVS.x),2));
        MFP_sep.IVS.y = squeeze(mean(abs(MFP_sep_n.IVS.y),2));
        MFP_sep.IVS.z = squeeze(mean(abs(MFP_sep_n.IVS.z),2));

        tauE_sep.IVS.x = squeeze(sum(tauE_sep_n.IVS.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.IVS.y = squeeze(sum(tauE_sep_n.IVS.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.IVS.z = squeeze(sum(tauE_sep_n.IVS.z,2));


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.IVS.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.xy(:,ii_T) ) ;
            A1 = TDF_sep.IVS.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.xz(:,ii_T) ) ;
            A1 = TDF_sep.IVS.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yz(:,ii_T) ) ;
            A1 = TDF_sep.IVS.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yx(:,ii_T) ) ;
            A1 = TDF_sep.IVS.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.zy(:,ii_T) ) ;
            A1 = TDF_sep.IVS.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.zx(:,ii_T) ) ;
            A1 = TDF_sep.IVS.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.zx(:,ii_T) = A1 ;
            
        end
       

    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  POP only -----------------------------------------------------
    if strcmp(POP,'yes') 
        if strcmp(screening_POP,'no')
            
            for id_E=size(E_array,2):-1:1 %parfor
                for id_n=n_bands_transp:-1:1
                    if not(size(taus(id_E,id_n).x)) == 0
                        for id_T = size(T_array,2):-1:1
                            EF_array = EF_matrix(:,id_T)';
                                    if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                        % ------------------------- add a control over tauPOP ------
                        NNan=isnan(taus(id_E,id_n).x(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).x(tau_pos_POP,NNan,id_T)=0;
                        NNan=isnan(taus(id_E,id_n).y(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).y(tau_pos_POP,NNan,id_T)=0;
                        NNan=isnan(taus(id_E,id_n).z(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).z(tau_pos_POP,NNan,id_T)=0;
                        NInf=isinf(taus(id_E,id_n).x(tau_pos_POP,:,id_T)); % for the other scatt. mech. this control is into the subfunctions
                        taus(id_E,id_n).x(tau_pos_POP,NInf,id_T)=0;
                        NInf=isinf(taus(id_E,id_n).y(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).y(tau_pos_POP,NInf,id_T)=0;
                        NInf=isinf(taus(id_E,id_n).z(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).z(tau_pos_POP,NInf,id_T)=0;
                        %------------------------------------------
                        TDF_sep_n.POP.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.zz(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus(id_E,id_n).z(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).z(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).z(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.zy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.zx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.POP.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_POP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.POP.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_POP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.POP.z(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus(id_E,id_n).z(tau_pos_POP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.POP.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.z(id_E,id_n,id_T) = sum( taus(id_E,id_n).z(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                       

                                    end
                        end
                    end
                end            
            end
            Ninf = isinf(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.zz); TDF_sep_n.POP.zz(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.zz); TDF_sep_n.POP.zz(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.yz); TDF_sep_n.POP.yz(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.yz); TDF_sep_n.POP.yz(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.xz); TDF_sep_n.POP.xz(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.xz); TDF_sep_n.POP.xz(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.zy); TDF_sep_n.POP.zy(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.zy); TDF_sep_n.POP.zy(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.zx); TDF_sep_n.POP.zx(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.zx); TDF_sep_n.POP.zx(NNan) = 0;
            TDF_sep.POP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xx ,2)); % it sums the contribution of the bands
            TDF_sep.POP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yy ,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zz,2));
            TDF_sep.POP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xy,2)); % it sums the contribution of the bands
            TDF_sep.POP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yz,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xz,2));
            TDF_sep.POP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yx,2)); % it sums the contribution of the bands
            TDF_sep.POP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zy,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zx,2));


            MFP_sep.POP.x = squeeze(mean(abs(MFP_sep_n.POP.x),2));
            MFP_sep.POP.y = squeeze(mean(abs(MFP_sep_n.POP.y),2));
            MFP_sep.POP.z = squeeze(mean(abs(MFP_sep_n.POP.z),2));

            tauE_sep.POP.x = squeeze(sum(tauE_sep_n.POP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE_sep.POP.y = squeeze(sum(tauE_sep_n.POP.y,2)); % tauE = tauE(E,EF,T)
            tauE_sep.POP.z = squeeze(sum(tauE_sep_n.POP.z,2));


           for ii_T = 1:size(T_array,2)
                    
                A = abs( TDF_sep.POP.xx(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.xx(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.yy(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.yy(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.zz(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.zz(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.xy(:,ii_T) ) ;
                A1 = TDF_sep.POP.xy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.xy(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.xz(:,ii_T) ) ;
                A1 = TDF_sep.POP.xz(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.xz(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.yz(:,ii_T) ) ;
                A1 = TDF_sep.POP.yz(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.yz(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.yx(:,ii_T) ) ;
                A1 = TDF_sep.POP.yx(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.yx(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.zy(:,ii_T) ) ;
                A1 = TDF_sep.POP.zy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.zy(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.zx(:,ii_T) ) ;
                A1 = TDF_sep.POP.zx(:,ii_T);
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.zx(:,ii_T) = A1 ;
                
            end            


        elseif strcmp(screening_POP,'yes')

          
        for id_E=size(E_array,2):-1:1 %parfor
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_EF = 1:size(EF_array,2)
                        for id_T = size(T_array,2):-1:1
                            EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauPOP ------
                    if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                if size(T_array,2) == 1
                                    tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                    tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                    tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,:)) ,2)' ;
                                else                                            
                                    tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                    tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                    tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,id_T,:)) ,2)' ;
                                end
                    else
                                tau_POP_x_temp = [];
                                tau_POP_y_temp = [];
                                tau_POP_z_temp = [];
                    end
                    %------------------------------------------
                        TDF_sep_n.POP.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.zz(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z .*tau_POP_z_temp .*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*tau_POP_z_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*tau_POP_z_temp .*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.POP.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.POP.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* tau_POP_x_temp ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.POP.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* tau_POP_y_temp ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.POP.z(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* tau_POP_z_temp ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.POP.x(id_E,id_n,id_EF,id_T) = sum( tau_POP_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.y(id_E,id_n,id_EF,id_T) = sum( tau_POP_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.z(id_E,id_n,id_EF,id_T) = sum( tau_POP_z_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                end
                        end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.zz); TDF_sep_n.POP.zz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.zz); TDF_sep_n.POP.zz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.yz); TDF_sep_n.POP.yz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.yz); TDF_sep_n.POP.yz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.xz); TDF_sep_n.POP.xz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.xz); TDF_sep_n.POP.xz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.zy); TDF_sep_n.POP.zy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.zy); TDF_sep_n.POP.zy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.zx); TDF_sep_n.POP.zx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.zx); TDF_sep_n.POP.zx(NNan) = 0;
        TDF_sep.POP.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.POP.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.POP.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zz,2));
        TDF_sep.POP.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xy,2)); % it sums the contribution of the bands
        TDF_sep.POP.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.POP.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.xz,2));
        TDF_sep.POP.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.yx,2)); % it sums the contribution of the bands
        TDF_sep.POP.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.POP.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.POP.zx,2));


        MFP_sep.POP.x = squeeze(mean(abs(MFP_sep_n.POP.x),2));
        MFP_sep.POP.y = squeeze(mean(abs(MFP_sep_n.POP.y),2));
        MFP_sep.POP.z = squeeze(mean(abs(MFP_sep_n.POP.z),2));

        tauE_sep.POP.x = squeeze(sum(tauE_sep_n.POP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.POP.y = squeeze(sum(tauE_sep_n.POP.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.POP.z = squeeze(sum(tauE_sep_n.POP.z,2));

        for ii_T = 1:size(T_array,2)
            for ii_EF = 1:size(EF_array,2)
                
                 
                    A = abs( TDF_sep.POP.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.zz(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.zz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.xz(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.xz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yz(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.yz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.zy(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.zy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.zy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.zx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.zx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.zx(:,ii_EF,ii_T) = A1 ;
                
            end
        end


        end
        
    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  Alloy only -----------------------------------------------------
    if strcmp(Alloy,'yes')
       
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauAlloy ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).x(tau_pos_Alloy,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).y(tau_pos_Alloy,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).z(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).z(tau_pos_Alloy,NNan,id_T)=0;                
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).x(tau_pos_Alloy,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).y(tau_pos_Alloy,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).z(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).z(tau_pos_Alloy,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.Alloy.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.zz(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_z.*taus(id_E,id_n).z(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.Alloy.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).z(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.xz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).z(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.Alloy.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.zy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .*taus(id_E,id_n).y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.zx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_z.*state_ID(id_E,id_n).v_x .*taus(id_E,id_n).x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS);

                        MFP_sep_n.Alloy.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_Alloy,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.Alloy.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_Alloy,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.Alloy.z(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus(id_E,id_n).z(tau_pos_Alloy,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.Alloy.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.Alloy.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.Alloy.z(id_E,id_n,id_T) = sum( taus(id_E,id_n).z(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);   
                                end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.Alloy.xx); TDF_sep_n.Alloy.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.xx); TDF_sep_n.Alloy.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.yy); TDF_sep_n.Alloy.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.yy); TDF_sep_n.Alloy.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.zz); TDF_sep_n.Alloy.zz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.zz); TDF_sep_n.Alloy.zz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.xy); TDF_sep_n.Alloy.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.xy); TDF_sep_n.Alloy.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.yz); TDF_sep_n.Alloy.yz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.yz); TDF_sep_n.Alloy.yz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.xz); TDF_sep_n.Alloy.xz(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.xz); TDF_sep_n.Alloy.xz(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.yx); TDF_sep_n.Alloy.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.yx); TDF_sep_n.Alloy.yx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.zy); TDF_sep_n.Alloy.zy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.zy); TDF_sep_n.Alloy.zy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.zx); TDF_sep_n.Alloy.zx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.zx); TDF_sep_n.Alloy.zx(NNan) = 0;
        TDF_sep.Alloy.xx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.xx ,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.yy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.zz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.zz,2));
        TDF_sep.Alloy.xy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.xy,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.yz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.yz,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.xz = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.xz,2));
        TDF_sep.Alloy.yx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.yx,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.zy = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.zy,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.zx = (sd/(8*pi^3))*squeeze(sum(TDF_sep_n.Alloy.zx,2));
        

        MFP_sep.Alloy.x = squeeze(mean(abs(MFP_sep_n.Alloy.x),2));
        MFP_sep.Alloy.y = squeeze(mean(abs(MFP_sep_n.Alloy.y),2));
        MFP_sep.Alloy.z = squeeze(mean(abs(MFP_sep_n.Alloy.z),2));

        tauE_sep.Alloy.x = squeeze(sum(tauE_sep_n.Alloy.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.Alloy.y = squeeze(sum(tauE_sep_n.Alloy.y,2)); % tauE = tauE(E,EF,T)
        tauE_sep.Alloy.z = squeeze(sum(tauE_sep_n.Alloy.z,2));


         for ii_T = 1:size(T_array,2)
            A = abs( TDF_sep.Alloy.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yy(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.zz(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.zz(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.xy(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xy(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.xz(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.xz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xz(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yz(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.yz(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yz(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yx(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yx(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.zy(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.zy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.zy(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.zx(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.zx(:,ii_T);
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.zx(:,ii_T) = A1 ;
        end
        

    end
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------

    
    
    % ---------  phonons (all) only @ all T--------------------------------
    % ---------------------------------------------------------------------
    
    if strcmp(IIS,'yes') || strcmp(Alloy,'yes')
        
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) && E_array(id_E) < min(min(min(Ek(:,:,:,bands_transp(id_n))))) + 6*kB*max(T_array)/q0 )
                                    % it takes all the energies for which a value has been calculated
                        % contribution of each k point with energy E, for all the bands
                        % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                        % length corresponding to the number of points in that state,
                        % each array state_ID(id_E,id_n) have different length
                                    if not(size(taus_matth(id_E,id_n).x)) == 0   % the state is involved in the transport

                                        if size(T_array,2) == 1

                                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                            

                                                for id_EF = size(EF_array,2):-1:1
                                                    
                                                    if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                                        tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,:)) ,2)' ;
                                                    else
                                                        tau_POP_x_temp = [];
                                                        tau_POP_y_temp = [];
                                                        tau_POP_z_temp = [];
                                                    end

                                                    TDF_ph_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                       + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                                    TDF_ph_n.zz(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xz(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                                    MFP_n.x_ph(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    MFP_n.y_ph(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    MFP_n.z_ph(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z +...
                                                        + 1./tau_POP_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                                    tauE_n.x_ph(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_n.y_ph(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_n.z_ph(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).z +...
                                                        + 1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                end
                                            else
                                                TDF_ph_n.xx(id_E,id_n) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.yy(id_E,id_n) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.zz(id_E,id_n) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.xy(id_E,id_n) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.xz(id_E,id_n) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yz(id_E,id_n) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yx(id_E,id_n) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.zx(id_E,id_n) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.zy(id_E,id_n) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS);


                                                MFP_n.x_ph(id_E,id_n) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                MFP_n.y_ph(id_E,id_n) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                MFP_n.z_ph(id_E,id_n) = sum( abs(state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                tauE_n.x_ph(id_E,id_n) = sum( taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_n.y_ph(id_E,id_n) = sum( taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_n.z_ph(id_E,id_n) = sum( taus_matth(id_E,id_n).z .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            end
                                        else % more T values
                                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')  

                                                for id_EF = size(EF_array,2):-1:1
                                                    
                                                    if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                                        tau_POP_z_temp = smooth( squeeze(taus_POP(id_E,id_n).z(id_EF,id_T,:)) ,2)' ;
                                                    else
                                                        tau_POP_x_temp = [];
                                                        tau_POP_y_temp = [];
                                                        tau_POP_z_temp = [];
                                                    end

                                                    TDF_ph_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zz(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xz(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.zx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                                    MFP_n.x_ph(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    MFP_n.y_ph(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    MFP_n.z_ph(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* (1./taus_matth(id_E,id_n).z(:,id_T)'+...
                                                        1./tau_POP_z_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        


                                                    tauE_n.x_ph(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_n.y_ph(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_n.z_ph(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).z(:,id_T)' +...
                                                        1./tau_POP_z_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                end

                                        else
                                            TDF_ph_n.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)'...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_ph_n.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)'...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_ph_n.zz(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_z .* state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)'...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_ph_n.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                            TDF_ph_n.xz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                            TDF_ph_n.yz(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                            TDF_ph_n.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                            TDF_ph_n.zx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).x(:,id_T)' .* state_ID(id_E,id_n).DOS);
                                            TDF_ph_n.zy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS);

                                            MFP_n.x_ph(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.y_ph(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.z_ph(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_z .* taus_matth(id_E,id_n).z(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.x_ph(id_E,id_n,id_T) = sum( taus_matth(id_E,id_n).x(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            tauE_n.y_ph(id_E,id_n,id_T) = sum( taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            tauE_n.z_ph(id_E,id_n,id_T) = sum( taus_matth(id_E,id_n).z(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            end
                                        end
                                    end
                                end                
                    end
            end            
        end

        Ninf = isinf(TDF_ph_n.xx); TDF_ph_n.xx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xx); TDF_ph_n.xx(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yy); TDF_ph_n.yy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yy); TDF_ph_n.yy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.zz); TDF_ph_n.zz(Ninf) = 0;
        NNan = isnan(TDF_ph_n.zz); TDF_ph_n.zz(NNan) = 0;
        Ninf = isinf(TDF_ph_n.xy); TDF_ph_n.xy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xy); TDF_ph_n.xy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yz); TDF_ph_n.yz(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yz); TDF_ph_n.yz(NNan) = 0;
        Ninf = isinf(TDF_ph_n.xz); TDF_ph_n.xz(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xz); TDF_ph_n.xz(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yx); TDF_ph_n.yx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yx); TDF_ph_n.yx(NNan) = 0;
        Ninf = isinf(TDF_ph_n.zy); TDF_ph_n.zy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.zy); TDF_ph_n.zy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.zx); TDF_ph_n.zx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.zx); TDF_ph_n.zx(NNan) = 0;
        TDF_ph.xx = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.xx,2)); % it sums the contribution of the bands
        TDF_ph.yy = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.yy,2)); % the dSk elemnts is already in the DOS
        TDF_ph.zz = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.zz,2));
        TDF_ph.xy = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.xy,2)); 
        TDF_ph.yz = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.yz,2)); 
        TDF_ph.xz = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.xz,2));
        TDF_ph.yx = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.yx,2)); 
        TDF_ph.zy = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.zy,2)); 
        TDF_ph.zx = (sd/(8*pi^3)).*squeeze(sum(TDF_ph_n.zx,2));    

        MFP_ph.x = squeeze(mean(abs(MFP_ph_n.x),2));
        MFP_ph.y = squeeze(mean(abs(MFP_ph_n.y),2));
        MFP_ph.z = squeeze(mean(abs(MFP_ph_n.z),2));

        tauE_ph.x = squeeze(sum(tauE_ph_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_ph.y = squeeze(sum(tauE_ph_n.y,2)); % tauE = tauE(E,EF,T)
        tauE_ph.z = squeeze(sum(tauE_ph_n.z,2));


        % denoising the TDF
        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
            for ii_T = 1:size(T_array,2)
                for ii_EF = 1:size(EF_array,2)
                                         
                    A = abs( TDF_ph.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.zz(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.zz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.xz(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.xz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yz(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.yz(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yz(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.zy(:,ii_EF,ii_T) ) ;
                    A1 = abs( TDF_ph.zy(:,ii_EF,ii_T) ) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.zy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.zx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.zx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.zx(:,ii_EF,ii_T) = A1 ;                
                    
                end
            end
        else
            for ii_T = 1:size(T_array,2)
    %             for ii_E = 7:nE-1
    %                 if abs(TDF_xx_ph(ii_E,ii_T)) > 10*(abs(TDF_xx_ph(ii_E-1,ii_T))+abs(TDF_xx_ph(ii_E+1,ii_T)) )/2
    %                     TDF_xx_ph(ii_E,ii_T) = (TDF_xx_ph(ii_E-1,ii_T)+TDF_xx_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_yy_ph(ii_E,ii_T)) > 10*(abs(TDF_yy_ph(ii_E-1,ii_T))+abs(TDF_yy_ph(ii_E+1,ii_T)) )/2
    %                     TDF_yy_ph(ii_E,ii_T) = (TDF_yy_ph(ii_E-1,ii_T)+TDF_yy_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_zz_ph(ii_E,ii_T)) > 10*(abs(TDF_zz_ph(ii_E-1,ii_T))+abs(TDF_zz_ph(ii_E+1,ii_T)) )/2
    %                     TDF_zz_ph(ii_E,ii_T) = (TDF_zz_ph(ii_E-1,ii_T)+TDF_zz_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_xy_ph(ii_E,ii_T)) > 10*(abs(TDF_xy_ph(ii_E-1,ii_T))+abs(TDF_xy_ph(ii_E+1,ii_T)) )/2
    %                     TDF_xy_ph(ii_E,ii_T) = (TDF_xy_ph(ii_E-1,ii_T)+TDF_xy_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_yx_ph(ii_E,ii_T)) > 10*(abs(TDF_yx_ph(ii_E-1,ii_T))+abs(TDF_yx_ph(ii_E+1,ii_T)) )/2
    %                     TDF_yx_ph(ii_E,ii_T) = (TDF_yx_ph(ii_E-1,ii_T)+TDF_yx_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_xz_ph(ii_E,ii_T)) > 10*(abs(TDF_xz_ph(ii_E-1,ii_T))+abs(TDF_xz_ph(ii_E+1,ii_T)) )/2
    %                     TDF_xz_ph(ii_E,ii_T) = (TDF_xz_ph(ii_E-1,ii_T)+TDF_xz_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_zx_ph(ii_E,ii_T)) > 10*(abs(TDF_zx_ph(ii_E-1,ii_T))+abs(TDF_zx_ph(ii_E+1,ii_T)) )/2
    %                     TDF_zx_ph(ii_E,ii_T) = (TDF_zx_ph(ii_E-1,ii_T)+TDF_zx_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_yz_ph(ii_E,ii_T)) > 10*(abs(TDF_yz_ph(ii_E-1,ii_T))+abs(TDF_yz_ph(ii_E+1,ii_T)) )/2
    %                     TDF_yz_ph(ii_E,ii_T) = (TDF_yz_ph(ii_E-1,ii_T)+TDF_yz_ph(ii_E+1,ii_T) )/2;
    %                 end
    %                 if abs(TDF_zy_ph(ii_E,ii_T)) > 10*(abs(TDF_zy_ph(ii_E-1,ii_T))+abs(TDF_zy_ph(ii_E+1,ii_T)) )/2
    %                     TDF_zy_ph(ii_E,ii_T) = (TDF_zy_ph(ii_E-1,ii_T)+TDF_zy_ph(ii_E+1,ii_T) )/2;
    %                 end
    %             end
                A = abs( TDF_ph.xx(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xx(:,ii_T) = A1 ;
                A = abs( TDF_ph.yy(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yy(:,ii_T) = A1 ;
                A = abs( TDF_ph.zz(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.zz(:,ii_T) = A1 ;
                A = abs( TDF_ph.xy(:,ii_T) ) ;
                A1 = TDF_ph.xy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xy(:,ii_T) = A1 ;
                A = abs( TDF_ph.xz(:,ii_T) ) ;
                A1 = TDF_ph.xz(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xz(:,ii_T) = A1 ;
                A = abs( TDF_ph.yz(:,ii_T) ) ;
                A1 = TDF_ph.yz(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yz(:,ii_T) = A1 ;
                A = abs( TDF_ph.yx(:,ii_T) ) ;
                A1 = TDF_ph.yx(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yx(:,ii_T) = A1 ;
                A = abs( TDF_ph.zy(:,ii_T) ) ;
                A1 = TDF_ph.zy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.zy(:,ii_T) = A1 ;
                A = abs( TDF_ph.zx(:,ii_T) ) ;
                A1 = TDF_ph.zx(:,ii_T);
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.zx(:,ii_T) = A1 ;
                
            end
        end


        
    end
    % ------------------------------------------------------------------------

    % two types of phonons is not performed at present, see_v3 to have the
    % code lines
%     end % end of the dimensionality check
    
end