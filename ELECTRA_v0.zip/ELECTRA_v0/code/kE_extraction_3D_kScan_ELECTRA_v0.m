% Copyright 2021 Patrizio Graziosi and Neopohytos Neophytou               %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, 
% under the supervision of Prof. Neophytos Neophytou, during the          %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
%                                                                         %
% ----------------------------------------------------------------------- %


function [state_ID_temp,DOS,V,mass_tensor] = kE_extraction_3D_kScan_ELECTRA_v0(id_E,n_band,E_array,bands_transp,Ek,kx_matrix,ky_matrix,kz_matrix,sd,BZ_factor)  %#codegen

%------------------- Initializations ---------------------------------
nkx=size(Ek,1); nky=size(Ek,2); nkz=size(Ek,3);
Etmp = E_array(id_E);
n = bands_transp(n_band); %the band index, that does not correponsd to the position in the bands_transp array, but in the E(k) matrix
dSk=1; % dSn=(dkx*dky*dkz)^(2/3); % temporary set to one, asjusted later to dA, used only to keep the reasoning
hbar=(6.6261e-34)/(2*pi); % [J-sec]
q0=1.609e-19;             % [col]
%--------------------------------------------------------------------

% ---------------------- Declaration --------------------------------
kx_field =  [] ; % double.empty(1,0);
coder.varsize('kx_field');
ky_field =  [] ; % double.empty(1,0);
coder.varsize('ky_field');
kz_field =  [] ; % double.empty(1,0);
coder.varsize('kz_field');
knorm_field =  [] ; %  double.empty(1,0);
coder.varsize('knorm_field');

vx_field =  [] ; % double.empty(1,0);
coder.varsize('vx_field');
vy_field =  [] ; %  double.empty(1,0);
coder.varsize('vy_field');
vz_field =  [] ; %  double.empty(1,0);
coder.varsize('vz_field');
V_field =   [] ; % double.empty(1,0);
coder.varsize('V_field');

DOS_field =  [] ; % double.empty(1,0);
coder.varsize('DOS_field');
surface_field =  [] ; %  double.empty(1,0);
coder.varsize('surface_field');

m_xx_field = [] ; 
coder.varsize('m_xx_field');
m_yy_field = [] ; 
coder.varsize('m_yy_field');
m_zz_field = [] ; 
coder.varsize('m_zz_field');
m_xy_field = [] ; 
coder.varsize('m_xy_field');
m_xz_field = [] ; 
coder.varsize('m_xz_field');
m_yz_field = [] ; 
coder.varsize('m_yz_field');


vT_array = [] ; coder.varsize('vT_array');
% -------------------------------------------------------------------
         
        Emin_temp = min(min(min((Ek(:,:,:,n)))));
        Emax_temp = max(max(max((Ek(:,:,:,n)))));
        
        if Emin_temp < Etmp && Emax_temp > Etmp % select only the bands that cross that E value
            
            
            for ix = 1 : (nkx-1) % nkx is the number of k points in the x axis, y and z m.m.
                for iy = 1 : (nky-1)
                    for iz = 1 : (nkz-1)
                        
                        kx_condition = ( Ek(ix,iy,iz,n) <= Etmp && Ek(ix+1,iy,iz,n) > Etmp || Ek(ix,iy,iz,n) >= Etmp && Ek(ix+1,iy,iz,n) < Etmp );
                        ky_condition = ( Ek(ix,iy,iz,n) <= Etmp && Ek(ix,iy+1,iz,n) > Etmp || Ek(ix,iy,iz,n) >= Etmp && Ek(ix,iy+1,iz,n) < Etmp );
                        kz_condition = ( Ek(ix,iy,iz,n) <= Etmp && Ek(ix,iy,iz+1,n) > Etmp || Ek(ix,iy,iz,n) >= Etmp && Ek(ix,iy,iz+1,n) < Etmp );
                        
                        if kx_condition % +1 along x 
                            % define the k point
                            k1x = kx_matrix(ix,iy,iz) + (kx_matrix(ix+1,iy,iz)-kx_matrix(ix,iy,iz)) * ((Etmp-Ek(ix,iy,iz,n)) / (Ek(ix+1,iy,iz,n)-Ek(ix,iy,iz,n))); 
                            k1y = ky_matrix(ix,iy,iz); 
                            k1z = kz_matrix(ix,iy,iz);
                            knorm = norm([k1x,k1y,k1z]);
                            % put the point in the state_ID_temp of the state
                            kx_field = [kx_field, k1x];
                            ky_field = [ky_field, k1y];
                            kz_field = [kz_field, k1z];
                            knorm_field = [knorm_field, knorm];
  
                            
                            % variation from Lehmann 1972 
    
                            k1 = [kx_matrix(ix+1,iy,iz), ky_matrix(ix+1,iy,iz), kz_matrix(ix+1,iy,iz)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            k2 = [kx_matrix(ix,iy+1,iz), ky_matrix(ix,iy+1,iz), kz_matrix(ix,iy+1,iz)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            k3 = [kx_matrix(ix,iy,iz+1), ky_matrix(ix,iy,iz+1), kz_matrix(ix,iy,iz+1)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
                            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
                            r2 = cross(k3,k1) / vT; 
                            r3 = cross(k1,k2) / vT;
                            grad_E = (Ek(ix+1,iy,iz,n) - Ek(ix,iy,iz,n))*r1 + (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n))*r2 + (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n))*r3;
                            % grad_E = (Etmp - Ek(ix,iy,iz,n))*r1 + (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n))*r2 + (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n))*r3;

                            % Define DOS and velocities in correct units
                            Vx_k = q0/hbar * grad_E(1);
                            Vy_k = q0/hbar * grad_E(2);
                            Vz_k = q0/hbar * grad_E(3);
                           
                            vx_field = [vx_field, Vx_k];
                            vy_field = [vy_field, Vy_k];
                            vz_field = [vz_field, Vz_k];
                            V_field = [ V_field, norm([Vx_k,Vy_k,Vz_k]) ];
                            vT_array = [vT_array, vT] ;
                                
                            DOS_field = [DOS_field, dSk / norm( grad_E )]; % dSk is set to one at the beginning
                            
                            mass_tensor = kron(grad_E,grad_E') ; % / vT ;
%                             mass_tensor = kron(grad_E,grad_E') / ( (  (Ek(ix+1,iy,iz,n) - Ek(ix,iy,iz,n)) + (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n)) + (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n)) ) /3 ) ;
                            m_xx_field = [m_xx_field, dSk / norm( grad_E ) * mass_tensor(1,1) ];
                            m_yy_field = [m_yy_field, dSk / norm( grad_E ) * mass_tensor(2,2) ];
                            m_zz_field = [m_zz_field, dSk / norm( grad_E ) * mass_tensor(3,3) ];
                            m_xy_field = [m_xy_field, dSk / norm( grad_E ) * mass_tensor(1,2) ];
                            m_yz_field = [m_yz_field, dSk / norm( grad_E ) * mass_tensor(2,3) ];
                            m_xz_field = [m_xz_field, dSk / norm( grad_E ) * mass_tensor(1,3) ];
%                             m_xx_field = [m_xx_field,  mass_tensor(1,1) ];
%                             m_yy_field = [m_yy_field,  mass_tensor(2,2) ];
%                             m_zz_field = [m_zz_field, mass_tensor(3,3) ];
%                             m_xy_field = [m_xy_field, mass_tensor(1,2) ];
%                             m_yz_field = [m_yz_field, mass_tensor(2,3) ];
%                             m_xz_field = [m_xz_field,  mass_tensor(1,3) ];
%                             m_xx_field = [m_xx_field, dSk / norm( grad_E ) * grad_E(1)*grad_E(1) ];
%                             m_yy_field = [m_yy_field, dSk / norm( grad_E ) * grad_E(2)*grad_E(2) ];
%                             m_zz_field = [m_zz_field, dSk / norm( grad_E ) * grad_E(3)*grad_E(3) ];
%                             m_xy_field = [m_xy_field, dSk / norm( grad_E ) * grad_E(1)*grad_E(2) ];
%                             m_yz_field = [m_yz_field, dSk / norm( grad_E ) * grad_E(2)*grad_E(3) ];
%                             m_xz_field = [m_xz_field, dSk / norm( grad_E ) * grad_E(1)*grad_E(3) ];
                        end
                        
                        if ky_condition % +1 along ky 
                            % define the k point
                            k1x = kx_matrix(ix,iy,iz); 
                            k1y = ky_matrix(ix,iy,iz) + (ky_matrix(ix,iy+1,iz)-ky_matrix(ix,iy,iz)) * ((Etmp-Ek(ix,iy,iz,n)) / (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n)));
                            k1z = kz_matrix(ix,iy,iz);
                            knorm = norm([k1x,k1y,k1z]);
                            % put the point in the state_ID_temp of the state
                            kx_field = [kx_field, k1x];
                            ky_field = [ky_field, k1y];
                            kz_field = [kz_field, k1z];
                            knorm_field = [knorm_field, knorm];
                                
                                 % variation from Lehmann 1972
    
                            k1 = [kx_matrix(ix+1,iy,iz), ky_matrix(ix+1,iy,iz), kz_matrix(ix+1,iy,iz)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            k2 = [kx_matrix(ix,iy+1,iz), ky_matrix(ix,iy+1,iz), kz_matrix(ix,iy+1,iz)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            k3 = [kx_matrix(ix,iy,iz+1), ky_matrix(ix,iy,iz+1), kz_matrix(ix,iy,iz+1)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
                            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
                            r2 = cross(k3,k1) / vT; 
                            r3 = cross(k1,k2) / vT;
                            grad_E = (Ek(ix+1,iy,iz,n) - Ek(ix,iy,iz,n))*r1 + (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n))*r2 + (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n))*r3;

                            % Define DOS and velocities in correct units
                            Vx_k = q0/hbar * grad_E(1);
                            Vy_k = q0/hbar * grad_E(2);
                            Vz_k = q0/hbar * grad_E(3);
                            
                            vx_field = [vx_field, Vx_k];
                            vy_field = [vy_field, Vy_k];
                            vz_field = [vz_field, Vz_k];
                            V_field = [ V_field, norm([Vx_k,Vy_k,Vz_k]) ];
                            vT_array = [vT_array, vT] ;
                                
                            DOS_field = [DOS_field, dSk / norm( grad_E )]; % dSk is set to one at the beginning
                            
                            mass_tensor = kron(grad_E,grad_E') ; % / vT ;
                            m_xx_field = [m_xx_field, dSk / norm( grad_E ) * mass_tensor(1,1) ];
                            m_yy_field = [m_yy_field, dSk / norm( grad_E ) * mass_tensor(2,2) ];
                            m_zz_field = [m_zz_field, dSk / norm( grad_E ) * mass_tensor(3,3) ];
                            m_xy_field = [m_xy_field, dSk / norm( grad_E ) * mass_tensor(1,2) ];
                            m_yz_field = [m_yz_field, dSk / norm( grad_E ) * mass_tensor(2,3) ];
                            m_xz_field = [m_xz_field, dSk / norm( grad_E ) * mass_tensor(1,3) ];

                        end
                        
                        if kz_condition % +1 along kz
                            % define the k point
                            k1x = kx_matrix(ix,iy,iz);  
                            k1y = ky_matrix(ix,iy,iz); 
                            k1z = kz_matrix(ix,iy,iz) + (kz_matrix(ix,iy,iz+1)-kz_matrix(ix,iy,iz)) * ((Etmp-Ek(ix,iy,iz,n)) / (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n)));
                            knorm = norm([k1x,k1y,k1z]);
                            % put the point in the state_ID_temp of the state
                            kx_field = [kx_field, k1x];
                            ky_field = [ky_field, k1y];
                            kz_field = [kz_field, k1z];
                            knorm_field = [knorm_field, knorm];
                            
                            
                             % variation from Lehmann 1972 - ATTEMPT
    
                            k1 = [kx_matrix(ix+1,iy,iz), ky_matrix(ix+1,iy,iz), kz_matrix(ix+1,iy,iz)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            k2 = [kx_matrix(ix,iy+1,iz), ky_matrix(ix,iy+1,iz), kz_matrix(ix,iy+1,iz)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            k3 = [kx_matrix(ix,iy,iz+1), ky_matrix(ix,iy,iz+1), kz_matrix(ix,iy,iz+1)] - [kx_matrix(ix,iy,iz), ky_matrix(ix,iy,iz), kz_matrix(ix,iy,iz)];
                            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
                            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
                            r2 = cross(k3,k1) / vT; 
                            r3 = cross(k1,k2) / vT;
                            grad_E = (Ek(ix+1,iy,iz,n) - Ek(ix,iy,iz,n))*r1 + (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n))*r2 + (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n))*r3;

                            % Define DOS and velocities in correct units
                        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
                            Vx_k = q0/hbar * grad_E(1);
                            Vy_k = q0/hbar * grad_E(2);
                            Vz_k = q0/hbar * grad_E(3);


                            vx_field = [vx_field, Vx_k];
                            vy_field = [vy_field, Vy_k];
                            vz_field = [vz_field, Vz_k];
                            V_field = [ V_field, norm([Vx_k,Vy_k,Vz_k]) ];
                            vT_array = [vT_array, vT] ;
                                
                            DOS_field = [DOS_field, dSk / norm( grad_E )]; % dSk is set to one at the beginning
                            
                            mass_tensor = kron(grad_E,grad_E') ; % / vT ;
                            m_xx_field = [m_xx_field, dSk / norm( grad_E ) * mass_tensor(1,1) ];
                            m_yy_field = [m_yy_field, dSk / norm( grad_E ) * mass_tensor(2,2) ];
                            m_zz_field = [m_zz_field, dSk / norm( grad_E ) * mass_tensor(3,3) ];
                            m_xy_field = [m_xy_field, dSk / norm( grad_E ) * mass_tensor(1,2) ];
                            m_yz_field = [m_yz_field, dSk / norm( grad_E ) * mass_tensor(2,3) ];
                            m_xz_field = [m_xz_field, dSk / norm( grad_E ) * mass_tensor(1,3) ];

                        end                                 
                                                              
                    end
                end
            end
            
            
        end
         
        
        NNan=isnan(DOS_field); DOS_field(NNan)=0;
        NInf=isinf(DOS_field); DOS_field(NInf)=0;
        NNan=isnan(vx_field);  vx_field(NNan)=0;
        NNan=isnan(vy_field);  vy_field(NNan)=0;
        NNan=isnan(vz_field);  vz_field(NNan)=0;
        NNan=isnan(V_field);   V_field(NNan)=0;
        
        NNan=isnan(m_xx_field); m_xx_field(NNan)=0;
        NInf=isinf(m_xx_field); m_xx_field(NInf)=0;
        NNan=isnan(m_yy_field); m_yy_field(NNan)=0;
        NInf=isinf(m_yy_field); m_yy_field(NInf)=0;
        NNan=isnan(m_zz_field); m_zz_field(NNan)=0;
        NInf=isinf(m_zz_field); m_zz_field(NInf)=0;
        NNan=isnan(m_xy_field); m_xy_field(NNan)=0;
        NInf=isinf(m_xy_field); m_xy_field(NInf)=0;
        NNan=isnan(m_yz_field); m_yz_field(NNan)=0;
        NInf=isinf(m_yz_field); m_yz_field(NInf)=0;
        NNan=isnan(m_xz_field); m_xz_field(NNan)=0;
        NInf=isinf(m_xz_field); m_xz_field(NInf)=0;
        
        
        
        % integrals calculations for each band and each energy,
        % the 2/((2*pi)^3) factor is introduced inthe surface integral for
        % the DOS, it is NOT in the state DOS, that is barely dAk/|v|
        
        k_points_number = size(kx_field,2);
        
        if not(size(vx_field,2)) == 0   % the state is not empty
            vT_eff = mean(abs(vT_array));  
            for ik = 1 : k_points_number

               delta_k_array = sqrt((kx_field-kx_field(ik)).^2+(ky_field-ky_field(ik)).^2+(kz_field-kz_field(ik)).^2);
               id_nn =  delta_k_array < ( sqrt(2)+0.001234 ) * vT_eff^(1/3)  ; % ( sqrt(2)+0.01) * vT^(1/3) ) ;  % *dk_eff );  %  (sqrt(2)+0.01)*dk_eff); % closest n.n.
               delta_k_nn = delta_k_array(id_nn); % distances of the closest n.n.
               k_circle = mean(delta_k_nn)/2; % avreage semi-distance % it was k_s that was the static dielectric constant as well in Phytos' definitions - ALL CALC. wrong at the GiTe
               
               dA = pi*k_circle^2;
               
               surface_field = [surface_field, dA];
                
               DOS_field(ik) = DOS_field(ik) * abs(dA); % dA is the actual dSk element for the surface integration
               
               m_xx_field(ik) = m_xx_field(ik) * dA ;
               m_yy_field(ik) = m_yy_field(ik) * dA ;
               m_zz_field(ik) = m_zz_field(ik) * dA ;
               m_xy_field(ik) = m_xy_field(ik) * dA ;
               m_yz_field(ik) = m_yz_field(ik) * dA ;
               m_xz_field(ik) = m_xz_field(ik) * dA ;
            end
        end
        
        
        state_ID_temp = struct();
        
        state_ID_temp.kx = kx_field ;
        state_ID_temp.ky = ky_field ;
        state_ID_temp.kz = kz_field ;
        state_ID_temp.knorm = knorm_field ;
        
        state_ID_temp.v_x = vx_field ;
        state_ID_temp.v_y = vy_field ;
        state_ID_temp.v_z = vz_field ;
        state_ID_temp.V = V_field;         
        
        state_ID_temp.DOS = DOS_field ;
        state_ID_temp.surface = surface_field ;
        state_ID_temp.E = Etmp;
        
        V = sum(state_ID_temp.V) / k_points_number ; % <v> ?  line 842 obiavtes to NaN issues

        DOS = BZ_factor*(sd/(8*pi^3))*sum(state_ID_temp.DOS); % Surface integration, the dAk element is in the DOS of the individual states
        
       
        mass_tensor = struct() ;
        mass_tensor.xx = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_xx_field) * q0/hbar^2 ) * DOS ;
        mass_tensor.yy = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_yy_field) * q0/hbar^2 ) * DOS;
        mass_tensor.zz = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_zz_field) * q0/hbar^2 ) * DOS;
        mass_tensor.xy = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_xy_field) * q0/hbar^2 ) * DOS;
        mass_tensor.xz = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_xz_field) * q0/hbar^2 ) * DOS;
        mass_tensor.yz = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_yz_field) * q0/hbar^2 ) * DOS;
                
end