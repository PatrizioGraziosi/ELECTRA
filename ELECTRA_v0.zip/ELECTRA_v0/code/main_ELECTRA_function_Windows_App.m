% Copyright 2021 Patrizio Graziosi and Neophytos Neophytou                %
% Written and developed by:                                               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, under the supervision of:  %
% Neophytos Neiphytou, n.neophytou@warwick.ac.uk                          %
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% When publishing results on bipolar transport, please cite also:         %
% ACS Appl. Energy Mater. 2020, 3, 6, 5913–5926
% https://doi.org/10.1021/acsaem.0c00825
%                                                                         %
% ----------------------------------------------------------------------- %

function main_ELECTRA_function_Windows_App % #codegen

%----- INPUT -------------
addpath('..\','-end');
load('Inputs_app.mat');
addpath('..\','-frozen');
[T_grid, EF_grid] = meshgrid(T_array, EF_array); %#ok<ASGLU>
%------------------------


%------ PARALLELIZATION ------

% if isempty(gcp('nocreate')) == 0
%     delete(gcp('nocreate'))
% end
if strcmp(type_of_parallelization,'local') 
%     cluster = parallel.cluster.Local(); % commentato per vedere se le
%     linee di errore vanno via, e se serve davvero, it works!
if isempty(gcp('nocreate')) ~= 0
    cluster.NumWorkers = max_number_of_cpu;
%     ppp = parpool('local',max_number_of_cpu);
    ppp = parpool(max_number_of_cpu);
    ppp.IdleTimeout = 30000; % minutes of parpool working, 500 hours, 3 weeks
end
end
if strcmp(type_of_parallelization,'Generic')
    disp('not yet developed, turned into local');
    cluster = parallel.cluster.Generic; % https://hpcc.usc.edu/support/documentation/matlab/parallel-matlab-r2018/
    cluster.NumWorkers = max_number_of_cpu;
    ppp = parpool('local',max_number_of_cpu);    
    ppp.IdleTimeout = 30000; % minutes of parpool working, 500 hours, 3 weeks
end
if strcmp(type_of_parallelization,'MATLAB Parallel Cloud')
    disp('not yet developed, turned into local');
    cluster.NumWorkers = max_number_of_cpu;
    ppp = parpool('local',max_number_of_cpu);    
    ppp.IdleTimeout = 30000; % minutes of parpool working, 500 hours, 3 weeks
end
%------------------------------

% The file needs of a 4D matrix named Ek, and the k axes vectors named
% kx_array, ky_array, kz_array, as input data, pi/a units
% This are in the Loaded file named Load_filename as below

% lines for semimetal option, added 30 March 2020

%---------------- Load files ----------------------
% addpath('..\Data\','-end');
Load_filename = ['Data\Ek_',material_name,'.mat'];   % this file contains the Ek and the k matrixes
load(Load_filename);

scatt_filename = ['Data\scattering_parameters_',material_name,'_',dimensionality,'.m'];   % this file contains the scattering parameters
if strcmp(constant_tau,'no') && exist(scatt_filename,'file')
    run(scatt_filename);
elseif strcmp(constant_tau,'no')
    scatt_filename = ['scattering_parameters_',material_name,'_',dimensionality,'.mat'];
    load(scatt_filename);
end
%------------ % Physical Constants -----------------
hbar=(6.6261e-34)/(2*pi); % [J-sec]
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
eps_0=8.85e-12;           % [F/m]
%----------------------------------------------------
% addpath('..\Data\','-frozen');
%----------------------------------------------------


% flip holes into electrons
if strcmp(carriers,'holes')
    Ek_original = Ek;
    Ek = -Ek;
%     EF_array=-EF_array;
%     Emin_flipped=-Emax;
%     Emax_flipped=-Emin;
%     Emin=Emin_flipped;
%     Emax=Emax_flipped;
end


Emin = -5*Estep;
if max(EF_array) > 0 
    Emax = max(EF_array)+7*kB*max(T_array)/q0;
else 
    Emax = 6.4*kB*max(T_array)/q0; % The bands will be shifted to zero
end

if ( strcmp(metal,'yes') || strcmp(metallic,'yes') ) && strcmp(semimetal,'yes')
    semimetal='no';
    disp('metal and semimetal both selected, it has been set to as metal ');
end
if strcmp(metal,'yes') || strcmp(metallic,'yes') || strcmp(semimetal,'yes')
    Emin = min(EF_array) - 6.4*kB*max(T_array)/q0;
    bipolar_transport='no'; % goes together with the if clause at line 131
    carriers = 'electrons';
    if strcmp(metal,'yes') || strcmp(metallic,'yes') 
        IIS = 'no';
    end
end

if size(EF_array,2) == 1
    EF_array = [EF_array(1),EF_array(1)+Estep];
%     single_Fermi_inputted = 'yes';
% else
%     single_Fermi_inputted = 'no';
end


% composition of the E_array and check of the T_array
E_array = Emin:Estep:Emax ;
nE = size(E_array,2) ;
T_array = abs(T_array);

% display what is done
disp(carriers); disp(' '); disp(material_name); disp(' '); disp(scan_type); disp(' ');



% the code starts; this is the Main script that manages all the functions
if strcmp(dimensionality,'3D')
    
        disp('shifting bands ') ; disp(' ');
        [pseudoconduction_bands, pseudovalence_bands, Ek] = shifting_bands_ELECTRA(Ek) ;
    % this sets the band edge to zero to allow the Fermi array to be generic
    % it gives also the arrays pseudoconduction_bands (majority bands
    % indexes) and pseudovalence_bands (minority bands indexes)


    
% E(k) --> k(E) step

     % the code composes the k_matrixes if not present
    if exist('kx_matrix','var') == 0 
        for id_z = size(kz_array,2) : -1 : 1
            for id_y = 1:size(ky_array,2)
                for id_x = 1:size(kx_array,2)
                    kx_matrix(id_x,id_y,id_z) = kx_array(id_x); 
                    ky_matrix(id_x,id_y,id_z) = ky_array(id_y);
                    kz_matrix(id_x,id_y,id_z) = kz_array(id_z);
                    a=[1 0 0]; b=[0 1 0]; c=[0 0 1];
                end
            end
        end 
    end
    if strcmp(k_units_pi_a,'yes')
        kx_matrix=kx_matrix/1e-9; ky_matrix=ky_matrix/1e-9; kz_matrix=kz_matrix/1e-9; 
%         kx=kx_array/1e-9; ky=ky_array/1e-9; kz=kz_array/1e-9;
    end
    if exist('sd','var')
    else
        sd = 2; %#ok<NASGU>
    end
    
    
    
    % this function forms the carriers state_ID, DOS(E) and v(E)
    
    % Initializations
    counter=1;  % filtering of the bands according whether they have values 
    % inside the provided Energy range
    bands_transp=ones(1);
    n_bands=size(Ek,4);
    for n=1:n_bands

        Emin_temp = min(min(min((Ek(:,:,:,n)))));
        Emax_temp = max(max(max((Ek(:,:,:,n)))));

        if Emin_temp < Emin && Emax_temp > Emin % crosses the lower boundary
            bands_transp(counter)=n; %vector with the number of the involved bands
            counter=counter+1;
        elseif Emin_temp < Emax && Emax_temp > Emax %crosses the upper boundary
            bands_transp(counter)=n;
            counter=counter+1;
        elseif Emin_temp > Emin && Emax_temp < Emax % is inbetween the bounderies
            bands_transp(counter)=n;
            counter=counter+1;
        end
    end
    n_bands_transp=size(bands_transp,2); % how many bands are involved in the transport

    if strcmp(spin_resolved,'yes') % spin degeneracy
        sd = 1;
    else
        sd = 2;
    end

    DOS=zeros(nE,n_bands_transp);
    V=zeros(nE,n_bands_transp);
    
    total_number_iteration = nE*n_bands_transp ;
    % "rolled" variables, running over both energy and band
    state_ID_rolled = struct();
    for ii=1:total_number_iteration
            state_ID_rolled(ii).kx=[];
            state_ID_rolled(ii).ky=[];
            state_ID_rolled(ii).kz=[];
            state_ID_rolled(ii).knorm=[];
            state_ID_rolled(ii).v_x=[];
            state_ID_rolled(ii).v_y=[];
            state_ID_rolled(ii).v_z=[];
            state_ID_rolled(ii).V=[];
            state_ID_rolled(ii).DOS=[];
            state_ID_rolled(ii).surface=[];
            state_ID_rolled(ii).E=[];            
    end
    DOS_rolled = zeros(1,total_number_iteration);
    V_rolled = zeros(1,total_number_iteration);
     % unroll the state_ID
    state_ID = struct();
    for id_c = 1:total_number_iteration
        id_E = floor( (id_c-1)/n_bands_transp)+1 ;
        n_band = id_c - (id_E-1)*n_bands_transp ;
        state_ID(id_E,n_band).kx = state_ID_rolled(id_c).kx ;
        state_ID(id_E,n_band).ky = state_ID_rolled(id_c).ky ;
        state_ID(id_E,n_band).kz = state_ID_rolled(id_c).kz ;
        state_ID(id_E,n_band).knorm = state_ID_rolled(id_c).knorm ;
        state_ID(id_E,n_band).v_x = state_ID_rolled(id_c).v_x ;
        state_ID(id_E,n_band).v_y = state_ID_rolled(id_c).v_y ;
        state_ID(id_E,n_band).v_z = state_ID_rolled(id_c).v_z ;
        state_ID(id_E,n_band).V = state_ID_rolled(id_c).V ;
        state_ID(id_E,n_band).DOS = state_ID_rolled(id_c).DOS ;
        state_ID(id_E,n_band).surface = state_ID_rolled(id_c).surface ;
        state_ID(id_E,n_band).E = state_ID_rolled(id_c).E;
        DOS(id_E,n_band) = DOS_rolled(id_c) ;
        V(id_E,n_band) = V_rolled(id_c) ;        
    end
%     mass_xx = DOS; mass_yy = mass_xx; mass_zz = mass_xx; 
%     mass_xy = mass_xx; mass_xz = mass_xx; mass_yz = mass_xx;
   
    disp('k(E) '); disp(' ');
    tic
    % proper k(E) extraction, parallelized
    if strcmp(scan_type,'kScan')
        parfor id_E = 1:nE  % id_c = 1:total_number_iteration
            for n_band = 1:n_bands_transp
%                 id_E = floor( (id_c-1)/n_bands_transp)+1 ;
%                 id_n = id_c - (id_E-1)*n_bands_transp ;

                [state_ID_temp,DOS_temp,V_temp] = kE_extraction_3D_kScan_ELECTRA_v0(id_E, n_band, E_array, bands_transp, Ek, kx_matrix, ky_matrix, kz_matrix, sd, 1) ;            

                
                state_ID(id_E,n_band) = state_ID_temp ;
                DOS(id_E,n_band) = DOS_temp ;
                V(id_E,n_band) = V_temp ;
                
%                 mass_xx(id_E,n_band) = effective_mass_temp.xx ; % symmetric effective mass tensor averaged over the occupied states
%                 mass_yy(id_E,n_band) = effective_mass_temp.yy ; 
%                 mass_zz(id_E,n_band) = effective_mass_temp.zz ; 
%                 mass_xy(id_E,n_band) = effective_mass_temp.xy ; 
%                 mass_xz(id_E,n_band) = effective_mass_temp.xz ; 
%                 mass_yz(id_E,n_band) = effective_mass_temp.yz ; 
            end
        end
   elseif strcmp(scan_type,'DT')
       parfor id_E = 1:nE  % id_c = 1:total_number_iteration
            for n_band = 1:n_bands_transp
                [state_ID_temp,DOS_temp,V_temp] = kE_extraction_3D_DT_ELECTRA_v0(id_E, n_band, E_array, bands_transp, Ek, kx_matrix, ky_matrix, kz_matrix, sd, 1) ;            
                state_ID(id_E,n_band) = state_ID_temp ;
                DOS(id_E,n_band) = DOS_temp ;
                V(id_E,n_band) = V_temp ;      
                
            end
       end
    end
    
    DOS_tot(:) = sum(DOS,2);
    
    NV=isnan(V); V(NV)=0;
    n_bands_E = zeros(nE,1);
    for id_E = 1 : nE
        n_bands_E(id_E) = size(find(V(id_E,:)),2);
    end
    V_tot(:) = sum(V,2) ./ n_bands_E(:); % <v> over the bands, for that certain energy
    NV_tot=isnan(V_tot); V_tot(NV_tot)=0;

    toc



    if strcmp(bipolar_transport,'yes') || strcmp(semimetal,'yes')
        % control operations for the possible new band gap
        if strcmp(change_band_gap, 'yes') && exist('new_band_gap','var') == 0
            change_band_gap = 'no';
        end
        if exist('new_band_gap','var') == 0
            new_band_gap = 0;
        end
        %
        disp('Fermi check and possible definition of the new band gap '); disp(' ');
        tic
        [EF_array, EF_intrinsic, Ek, valence_edge, midgap] = Fermi_doublecheck_ELECTRA(EF_array, Estep, T_array, Ek, pseudoconduction_bands, pseudovalence_bands, kx_matrix, ky_matrix, kz_matrix, semimetal, new_band_gap, change_band_gap, bipolar_one_carrier);
        % this control that none of the Fermi elevels inputed is below the midgap, if so, it rescales the negative Fermi values, the ones in the gap, 
        % so that the lowest Fermi corresponds to the intrinsic Fermi and the highest <=0 Fermi stays there 
        % This function also "doubles" the Fermi array in the case the calculations are for both type of carriers
        toc
    end
    
    if strcmp(bipolar_transport,'no') 
        if strcmp(Fermi_shift_flag,'yes')
            if strcmp(semimetal,'no')                
                [EF_matrix, N_imp_matrix] = Fermi_shift_unipolar_ELECTRA( EF_array, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd, bands_transp ) ;
            elseif strcmp(semimetal,'yes') % this flag should not be here anymore, semimetal are like normal unipolar
                [EF_matrix, N_imp_matrix] = Fermi_shift_bipolar_ELECTRA( EF_array, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd ) ;
            end
        elseif strcmp(Fermi_shift_flag,'no')
            EF_matrix = zeros(size(EF_array,2),size(T_array,2));
            N_imp_matrix = EF_matrix ;
            [EF_matrix_temp, N_imp_matrix_temp] = Fermi_shift_unipolar_ELECTRA( EF_array, T_array(1), Ek, kx_matrix, ky_matrix, kz_matrix, sd, bands_transp ) ;
            for iT = size(T_array,2) : -1 : 1
                EF_matrix(:,iT) = EF_matrix_temp ;
                N_imp_matrix(:,iT) = N_imp_matrix_temp ;  % total charge carrier concentration in m^(-3) 
            end
        end
    % calculation ot the Fermi array at each temperature (Fermi shift upon T)
    % considering the carriers' density to be constant, i.e. in the extrinsic
    % region
    elseif strcmp(bipolar_transport,'yes')
        if strcmp(Fermi_shift_flag,'yes')
            [EF_matrix, N_imp_matrix] = Fermi_shift_bipolar_ELECTRA( EF_array, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd, pseudoconduction_bands, pseudovalence_bands  ) ;
            % same as above but considering both CBs and VBs
            EF_array=EF_matrix(:,1)'; 
    %         an intrinsic semiconductor has the same number of thermally
    %         generated electrons and holes so that the intrinsic Fermi level
    %         can be not in the midgap.
        elseif strcmp(Fermi_shift_flag,'no')
                [EF_matrix_temp, N_imp_matrix_temp] = Fermi_shift_bipolar_ELECTRA( EF_array, T_array(1), Ek, kx_matrix, ky_matrix, kz_matrix, sd, pseudoconduction_bands, pseudovalence_bands  ) ;
                EF_matrix = zeros(size(EF_array,2),size(T_array,2));
                N_imp_matrix = EF_matrix ;
                for iT = size(T_array,2) : -1 : 1
                    EF_matrix(:,iT) = EF_matrix_temp;
                    N_imp_matrix(:,iT) = N_imp_matrix_temp;
                end
        end
        
 

        % extraction of the minority carriers k(E) and DOS to consider it
        % in the LD calc. of the majority carriers

        % saving of the useful quantities
        % NOTE the state_ID file is NOT saved as it requires too much memory
        % all the quantities of interest shall be saved now
        % it however remains in the WorkSpace
        Ek_majority = Ek; 
        Emin_majority = Emin; Emax_majority = Emax; E_array_majority = E_array;
        EF_matrix_majority = EF_matrix; EF_array_majority = EF_array;
        bands_transp_majority = bands_transp;
        n_bands_transp_majority = n_bands_transp;

        DOS_tot_majority = DOS_tot; DOS_majority = DOS;
        V_tot_majority = V_tot; V_majority = V;
        state_ID_majority = state_ID;
        clear state_ID

        % swap the energies and define the new limits
        disp('swap for bipolar '); disp(' ');
        Ek = -Ek; % the code flips the bandstructure but does NOT shift it
        minority_band_edge = min(min(min(min(Ek(:,:,:,pseudovalence_bands))))); % this is a positive number that is the bandgap value
        Emin = minority_band_edge - 5*Estep;
        if strcmp(bipolar_one_carrier,'yes')
            Emax = minority_band_edge + 6*kB*max(T_array)/q0;
        elseif strcmp(bipolar_one_carrier,'no')
            Emax =  -min(EF_matrix(:,1))+7*kB*max(T_array)/q0 ; % - minority_band_edge;
        end
        Emax_minority = Emax;
        Emin_minority = Emin;
        E_array_minority = Emin:Estep:Emax;
        E_array = E_array_minority;
        

        % extraction of the k(E) for the minority - a new state_ID file starts to
        % being written
        clear DOS_tot V_tot DOS  V bands_transp
        
        bands_transp=ones(1);
        n_bands=size(Ek,4);
        counter=1;
        for n=1:n_bands

            Emin_temp = min(min(min((Ek(:,:,:,n)))));
            Emax_temp = max(max(max((Ek(:,:,:,n)))));

            if Emin_temp < Emin && Emax_temp > Emin % crosses the lower boundary
                bands_transp(counter)=n; %vector with the number of the involved bands
                counter=counter+1;
            elseif Emin_temp < Emax && Emax_temp > Emax %crosses the upper boundary
                bands_transp(counter)=n;
                counter=counter+1;
            elseif Emin_temp > Emin && Emax_temp < Emax % is inbetween the bounderies
                bands_transp(counter)=n;
                counter=counter+1;
            end
        end
        n_bands_transp=size(bands_transp,2); % how many bands are involved in the transport

        DOS=zeros(size(E_array,2),n_bands_transp);
        V=zeros(size(E_array,2),n_bands_transp);
    
        total_number_iteration = size(E_array,2)*n_bands_transp ;
        state_ID_rolled = struct();
        for ii=1:total_number_iteration
                state_ID_rolled(ii).kx=[];
                state_ID_rolled(ii).ky=[];
                state_ID_rolled(ii).kz=[];
                state_ID_rolled(ii).knorm=[];
                state_ID_rolled(ii).v_x=[];
                state_ID_rolled(ii).v_y=[];
                state_ID_rolled(ii).v_z=[];
                state_ID_rolled(ii).V=[];
                state_ID_rolled(ii).DOS=[];
                state_ID_rolled(ii).surface=[];
                state_ID_rolled(ii).E=[];
        end
        DOS_rolled = zeros(1,total_number_iteration);
        V_rolled = zeros(1,total_number_iteration);
        
         % unroll the state_ID
        state_ID = struct();
        for id_c = 1:total_number_iteration
            id_E = floor( (id_c-1)/n_bands_transp)+1 ;
            n_band = id_c - (id_E-1)*n_bands_transp ;
            state_ID(id_E,n_band).kx = state_ID_rolled(id_c).kx ;
            state_ID(id_E,n_band).ky = state_ID_rolled(id_c).ky ;
            state_ID(id_E,n_band).kz = state_ID_rolled(id_c).kz ;
            state_ID(id_E,n_band).knorm = state_ID_rolled(id_c).knorm ;
            state_ID(id_E,n_band).v_x = state_ID_rolled(id_c).v_x ;
            state_ID(id_E,n_band).v_y = state_ID_rolled(id_c).v_y ;
            state_ID(id_E,n_band).v_z = state_ID_rolled(id_c).v_z ;
            state_ID(id_E,n_band).V = state_ID_rolled(id_c).V ;
            state_ID(id_E,n_band).DOS = state_ID_rolled(id_c).DOS ;
            state_ID(id_E,n_band).surface = state_ID_rolled(id_c).surface ;
            state_ID(id_E,n_band).E = state_ID_rolled(id_c).E;
            DOS(id_E,n_band) = DOS_rolled(id_c) ;
            V(id_E,n_band) = V_rolled(id_c) ;
        end
%         mass_xx = DOS; mass_yy = mass_xx; mass_zz = mass_xx; 
%         mass_xy = mass_xx; mass_xz = mass_xx; mass_yz = mass_xx;
        
        tic
        disp('k(E) minority '); disp(' ');
        if strcmp(scan_type,'kScan')
            parfor id_E = 1:size(E_array,2)  % id_c = 1:total_number_iteration
                for n_band = 1:n_bands_transp
 
                    [state_ID_temp,DOS_temp,V_temp] = kE_extraction_3D_kScan_ELECTRA_v0(id_E, n_band, E_array, bands_transp, Ek, kx_matrix, ky_matrix, kz_matrix, sd, 1) ;            

                    state_ID(id_E,n_band) = state_ID_temp ;
                    DOS(id_E,n_band) = DOS_temp ;
                    V(id_E,n_band) = V_temp ;      
                    
                end
            end
       elseif strcmp(scan_type,'DT')
           parfor id_E = 1:size(E_array,2)  % id_c = 1:total_number_iteration
                for n_band = 1:n_bands_transp
                    [state_ID_temp,DOS_temp,V_temp] = kE_extraction_3D_DT_ELECTRA_v0(id_E, n_band, E_array, bands_transp, Ek, kx_matrix, ky_matrix, kz_matrix, sd, 1) ;            
                    state_ID(id_E,n_band) = state_ID_temp ;
                    DOS(id_E,n_band) = DOS_temp ;
                    V(id_E,n_band) = V_temp ; 
                    
                end
           end
        end
        
        DOS_tot(:) = sum(DOS,2);
    
        NV=isnan(V); V(NV)=0;
        n_bands_E = zeros( size(E_array,2),1);
        for id_E = 1 : size(E_array,2)
            n_bands_E(id_E) = size(find(V(id_E,:)),2);
        end
        V_tot(:) = sum(V,2) ./ n_bands_E(:); % <v> over the bands, for that certain energy
        NV_tot=isnan(V_tot); V_tot(NV_tot)=0;
        toc

        
        % save the useful energies as minority ones
        DOS_tot_minority = DOS_tot; DOS_minority = DOS;
        V_tot_minority = V_tot; V_minority = V;

        E_array_minority = E_array;
        bands_transp_minority = bands_transp;
        n_bands_transp_minority = n_bands_transp;
        save('state_ID_minority','state_ID','-v7.3','-nocompression')
        clear state_ID %to save memory

        % swap back the quantities and the energies
        Ek = Ek_majority; 
        Emin = Emin_majority ; Emax = Emax_majority ;  
        E_array = E_array_majority; nE = size(E_array,2);
%         EF_matrix = EF_matrix_majority; EF_array = EF_array_majority;
        bands_transp = bands_transp_majority;
        n_bands_transp = n_bands_transp_majority;
        DOS_tot = DOS_tot_majority; DOS = DOS_majority;
        V_tot = V_tot_majority; V = V_majority;
        state_ID = state_ID_majority;
        clear state_ID_majority
    end
    

    
    
    
% Preparation of the instruction for the calculation of the scattering rates
% or TDF directly
    if strcmp(constant_tau,'yes')
        disp(' CRT approximation') ; disp(' ');
        n_scatt=1;
        taus=struct();
        taus_matth=struct();
        taus_IIS=struct();
        taus_POP=struct();
        for id_E = size(E_array,2):-1:1
            for id_n = n_bands_transp:-1:1
                taus(id_E,id_n).x=[];
                taus(id_E,id_n).y=[];
                taus(id_E,id_n).z=[];
                taus_IIS(id_E,id_n).x=[];
                taus_IIS(id_E,id_n).y=[];
                taus_IIS(id_E,id_n).z=[];
                taus_POP(id_E,id_n).x=[];
                taus_POP(id_E,id_n).y=[];
                taus_POP(id_E,id_n).z=[];
                 
                for id_T = 1:size(T_array,2)
                        taus_matth(id_E,id_n).x(:,id_T)=tau_const;
                        taus_matth(id_E,id_n).y(:,id_T)=tau_const;
                        taus_matth(id_E,id_n).z(:,id_T)=tau_const;
                end
                
            end
        end
        
        
            
        WF=ones(1,n_bands_transp);
        if strcmp(WF_provided,'yes')
            addpath('Data\');
            WF_filename=['WF_',material_name,'_',dimensionality,'.mat'];   % this file contains the Wave forms factors == 1 for parabolic bands
                                                                   % named in
                                                                   % the file
                                                                   % WF(:,id_n)
            load(WF_filename);
            addpath('Data\','-frozen');
        end
        
        % spin degeneracy 
        if strcmp(spin_resolved,'no') % spin degeneracy array
            sd_array = zeros(1,n_bands_transp);
        end
        
        ADP = 'no'; ADP_IVS = 'no'; IVS = 'no'; ODP = 'no'; Alloy = 'no'; 
        POP = 'no'; IIS = 'no'; remove_matth = 'no'; save_RTstruct = 'yes';
        k_restriction = 'no'; overlap_integral_analytical = 'no' ;
        multivalley = 'no';
        
        save('WorkSpace4','-v7.3','-nocompression');
        WorkSpace4 = load('WorkSpace4.mat');


    else % tau NOT constant
        
        if strcmp(ADP,'no') && strcmp(ADP_IVS,'no') && strcmp(ODP,'no') && strcmp(IVS,'no') && strcmp(Alloy,'no') && (strcmp(POP,'no') || (strcmp(POP,'yes') && strcmp(screening_POP,'yes')) ) 
            ADP = 'yes';
            D_adp = 1;
            remove_matth = 'yes';
        else
            remove_matth = 'no';
        end
        if strcmp(POP,'no')
            screening_POP = 'no';
        end
        
        n_scatt = 0; % counting n_scatt and launching tau calculation
        if strcmp(SRS,'yes')
           n_scatt = n_scatt+1;
           tau_pos_SRS = n_scatt;
           disp('SRS');
        end
        if strcmp(Alloy,'yes')
           n_scatt = n_scatt+1;
           tau_pos_Alloy = n_scatt;
           disp('Alloy');
        end
        if strcmp(ee,'yes')
           n_scatt = n_scatt+1;
           tau_pos_ee = n_scatt;
           disp('ee');
        end

        if strcmp(phonon_dispersions,'no')
            if strcmp(ADP,'yes') && strcmp(ADP_IVS,'yes') % ADP and ADP_IVS are mutually exclusive
                disp('you have selected both ADP and ADP_IVS processes, only ADP_IVS will be kept');
                ADP = 'no';
            end
            if strcmp(ADP,'yes')
                n_scatt = n_scatt+1;
                tau_pos_ADP = n_scatt;
                disp('ADP');
            end
            if strcmp(ADP_IVS,'yes')
                n_scatt = n_scatt+1;
                tau_pos_ADP = n_scatt; % ADP and ADP_IVS are mutually exclusive
                disp('ADP_IVS');
            end
            if strcmp(Piezo,'yes')
                n_scatt = n_scatt+1;
                tau_pos_Piezo = n_scatt;
            end
            if strcmp(ODP,'yes')
                n_scatt = n_scatt+1;
                tau_pos_ODP = n_scatt;
                disp('ODP');
            end
            if strcmp(IVS,'yes')
                n_scatt = n_scatt+1;
                tau_pos_IVS = n_scatt;
                disp('IVS');
            end
            if strcmp(POP,'yes')
                n_scatt = n_scatt+1;
                tau_pos_POP = n_scatt;
                disp('POP');
            end


        elseif strcmp(phonon_dispersions,'yes')
            if strcmp(OPT_Npolar,'yes')
                n_scatt=n_scatt+1;
                tau_pos_OPT_Npolar=n_scatt;
            end
            if strcmp(OPT_polar,'yes')
                n_scatt=n_scatt+1;
                tau_pos_OPT_polar=n_scatt;
            end
            if strcmp(ACO,'yes')
                n_scatt=n_scatt+1;
                tau_pos_ACO=n_scatt;
            end
            if strcmp(phph,'yes')
                n_scatt=n_scatt+1;
                tau_pos_phph=n_scatt;
            end
            if strcmp(Alloy_ph,'yes')
                n_scatt=n_scatt+1;
                tau_pos_Alloy_ph=n_scatt;
            end
        end

        if strcmp(IIS,'yes') 
            n_scatt = n_scatt+1;
            disp('IIS');
        end
                
        
       
        
        
% -------------------- core TRANSPORT module -----------------------------
%      calculation of the TDF or of the explicite scattering rates
% ------------------------------------------------------------------------



% --------------------- Preliminar operations ----------------------------


        % Wave Functions - this is still to be developed
        WF=ones(1,n_bands_transp);
        if strcmp(WF_provided,'yes')
        addpath('Data\');
        WF_filename=['WF_',material_name,'_',dimensionality,'.mat'];   % this file contains the Wave forms factors == 1 for parabolic bands
                                                                       % named in
                                                                       % the file
                                                                       % WF(:,id_n)
        load(WF_filename);
        addpath('Data\','-frozen');
        end
        
        
        % spin degeneracy 
        if strcmp(spin_resolved,'no') % spin degeneracy array
            sd_array = zeros(1,n_bands_transp);
        end
        
        
        % eventually, multivalley labels       
        if strcmp(multivalley,'yes')
            valley_type = valley_type(bands_transp);
        end
        
        
        
        
        % screening parameters and others related to IIS        
        if strcmp(IIS,'yes') || strcmp(POP,'yes') || strcmp(Alloy,'yes') || strcmp(k_restriction,'yes') 

            delta_eV = 0.001; % in eV, step for the calculation of the dn/dEF

            [~, nT]=min(T_array-300);

            if strcmp(bipolar_transport,'no') && strcmp(semimetal,'no')
                N_imp_array = N_imp_matrix(:,1);
                for iEF = size(EF_array,2):-1:1 % FD calculation
                    FD_imp(:,iEF) = 1./(exp((E_array-EF_matrix(iEF,nT))./(kB*T_array(nT)/q0))+1); 
                    NNan = isnan(FD_imp(:,iEF));
                    FD_imp(NNan,iEF) = 0;

                    for iT=1:size(T_array,2) % for the LD calc.
                        EF_array = EF_matrix(:,iT)';
                        FD_shifted(:,iEF,iT) = 1./(exp((E_array-EF_array(iEF)-delta_eV)./(kB*T_array(iT)/q0))+1);
                        FD(:,iEF,iT) = 1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1);
                    end

                end
                
            elseif strcmp(bipolar_transport,'yes')
                
                N_imp_array = N_imp_matrix(:,1);
                
                for iEF = size(EF_array,2):-1:1 % 

                    for iT=1:size(T_array,2) % for the LD calc.
                        EF_array = EF_matrix(:,iT)';
                        FD_shifted_majority(:,iEF,iT) = 1./(exp((E_array_majority-EF_array(iEF)-delta_eV)./(kB*T_array(iT)/q0))+1);
                        FD_shifted_minority(:,iEF,iT) = 1-1./(exp((-E_array_minority-EF_array(iEF)-delta_eV)./(kB*T_array(iT)/q0))+1);
                        FD_majority(:,iEF,iT) = 1./(exp((E_array_majority-EF_array(iEF))./(kB*T_array(iT)/q0))+1);
                        FD_minority(:,iEF,iT) = 1-1./(exp((-E_array_minority-EF_array(iEF))./(kB*T_array(iT)/q0))+1);
                        %
                        % EF_arrays are defined on the same energy grid of E_array total
                        % NOT possible to be done here, the difference is
                        % nelgigible until extremely degenerate
                        % conditions, and only for LD_min
                    end 

                end
            elseif strcmp(semimetal,'yes')
                % ----------------------- k space volume element -------------------------
                dkx_v = [kx_matrix(2,1,1) ky_matrix(2,1,1) kz_matrix(2,1,1)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
                dky_v = [kx_matrix(1,2,1) ky_matrix(1,2,1) kz_matrix(1,2,1)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
                dkz_v = [kx_matrix(1,1,2) ky_matrix(1,1,2) kz_matrix(1,1,2)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
                dVk = dot(cross(dkx_v,dky_v),dkz_v);
                % ------------------------------------------------------------------------
                for iEF = size(EF_array,2):-1:1 % N_imp array calculation
                    for iT=1:size(T_array,2) % for the LD calc.
                        EF_array = EF_matrix(:,iT)';

                        N_carrier_non_shifted(iEF,iT) = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek - EF_array(iEF))./(kB*T_array(iT)/q0))+1))))) - 2/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek-EF_array(iEF))./(kB*0/q0))+1)))));

                        N_carrier_shifted(iEF,iT) = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek - EF_array(iEF) - delta_eV )./(kB*T_array(iT)/q0))+1))))) - 2/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek - EF_array(iEF) - delta_eV )./(kB*0/q0))+1)))));

                        delta_carriers(iEF,iT) = abs( N_carrier_non_shifted(iEF,iT) - N_carrier_shifted(iEF,iT) );                 
                    end
                end
                N_imp_array = N_carrier_non_shifted(:,1) ;
                N_imp_matrix = N_carrier_non_shifted ;
            end
            
            if strcmp(bipolar_transport,'no') && strcmp(semimetal,'no')
                for i_Temp = size(T_array,2):-1:1  % LD matrix calculation, contains the T dependence of the IIS mechanism            
                    EF_array = EF_matrix(:,i_Temp)';

                    for i_EF = size(EF_array,2):-1:1
                         delta_carriers(i_EF,i_Temp) = abs( trapz(E_array,DOS_tot.*FD_shifted(:,i_EF,i_Temp)') - trapz(E_array,DOS_tot.*FD(:,i_EF,i_Temp)') ); % in units of 1/m3
                    end

                    LD(:,i_Temp) = sqrt( k_s*eps_0/q0 .* delta_eV ./ delta_carriers(:,i_Temp) );
                end

            elseif strcmp(bipolar_transport,'yes')

                for i_Temp = size(T_array,2):-1:1  % LD matrix calculation, contains the T dependence of the IIS mechanism
                    EF_array = EF_matrix(:,i_Temp)';

                    for i_EF = size(EF_array,2):-1:1
                        
                         delta_carriers_maj(i_EF,i_Temp) = abs( trapz(E_array_majority,DOS_tot_majority.*FD_shifted_majority(:,i_EF,i_Temp)') - trapz(E_array_majority,DOS_tot_majority.*FD_majority(:,i_EF,i_Temp)'));
                         delta_carriers_min(i_EF,i_Temp) = abs( trapz(-E_array_minority,DOS_tot_minority.*FD_shifted_minority(:,i_EF,i_Temp)') - trapz(-E_array_minority,DOS_tot_minority.*FD_minority(:,i_EF,i_Temp)') ); % in units of 1/m3
                    
                    end

                    LD_maj(:,i_Temp) = sqrt( k_s*eps_0/q0 .* delta_eV ./ delta_carriers_maj(:,i_Temp) );
                    LD_min(:,i_Temp) = sqrt( k_s*eps_0/q0 .* delta_eV ./ delta_carriers_min(:,i_Temp) );
                    
                end
                
                LD = 1./sqrt(1./LD_maj.^2+1./LD_min.^2); % M. Combescot et al 1986 EPL 2 31 and Nag's book

            elseif strcmp(semimetal,'yes')
                for i_Temp = size(T_array,2):-1:1

                    LD(:,i_Temp) = sqrt( k_s*eps_0/q0 .* delta_eV ./ delta_carriers(:,i_Temp) ); % the delta_carriers for semimetals is computed above, lines 60 - 70

                end 
            end


                    if exist('alat','var') == 0 
                        nkx = size(Ek,1) ;  nky = size(Ek,2) ;  nkz = size(Ek,3) ; 
                        alat = pi/(abs(kx_matrix(nkx,nky,nkx)+ky_matrix(nkx,nky,nkx)+kz_matrix(nkx,nky,nkx))/3)*1e9; % alat in nm assuming BZ extending from pi/a to -pi/a
                    end       
                    if exist('blat','var') == 0 
                        blat = alat;
                    end
                    if exist('clat','var') == 0 
                        clat = alat;
                    end
                    Ga = a*2*pi/(alat*1e-9); % reciprocal uc*  vectors
                    Gb = b*2*pi/(blat*1e-9);
                    Gc = c*2*pi/(clat*1e-9);

        end
        
        
        
        
        % TDF or taus calculation
        tic
        if  strcmp(save_RTstruct,'yes') % in this case the code computes large, tens of Gb, struct data with the relaxation times
            
            
            taus=struct();
            taus_matth=struct();
            taus_IIS=struct();
            taus_POP=struct();
            for id_E = 1:nE
                for id_n =1:n_bands_transp
                 taus(id_E,id_n).x=[];
                 taus(id_E,id_n).y=[];
                 taus(id_E,id_n).z=[];
                 taus_matth(id_E,id_n).x=[];
                 taus_matth(id_E,id_n).y=[];
                 taus_matth(id_E,id_n).z=[];

                 taus_IIS(id_E,id_n).x=[];
                 taus_IIS(id_E,id_n).y=[];
                 taus_IIS(id_E,id_n).z=[];

                 taus_POP(id_E,id_n).x=[];
                 taus_POP(id_E,id_n).y=[];
                 taus_POP(id_E,id_n).z=[];

                end
            end

                        
            save('WorkSpace4','-v7.3','-nocompression');
            WorkSpace4 = load('WorkSpace4.mat');
          

            DQ = parallel.pool.DataQueue;
            afterEach(DQ, @disp);
            
            disp('computing the Relaxation Times'); disp(' ');
            disp('total number of energy values'); disp(' '); disp(nE); disp(' ')
            if strcmp(multivalley,'no')
                parfor id_E = 1:nE
                    for id_n = 1:n_bands_transp


                       [tau_temp, tau_matth_temp, tau_IIS_temp, tau_POP_temp] = tau_calc_funct_ELECTRA_v0(id_E, id_n, WorkSpace4 ); % the big tau_calc routine, the actual tau_calc in the serial version


                        taus(id_E,id_n) = tau_temp;
                        taus_matth(id_E,id_n) = tau_matth_temp;
                        if strcmp(IIS,'yes')
                            taus_IIS(id_E,id_n) = tau_IIS_temp;
                        end
                        if strcmp(screening_POP,'yes')
                            taus_POP(id_E,id_n) = tau_POP_temp;
                        end

                    end

                    send(DQ,id_E);

                end
            elseif strcmp(multivalley,'yes')
                parfor id_E = 1:nE
                    for id_n = 1:n_bands_transp


                       [tau_temp, tau_matth_temp, tau_IIS_temp, tau_POP_temp] = tau_calc_funct_multivalley_ELECTRA_v0(id_E, id_n, WorkSpace4 ); % the big tau_calc routine, the actual tau_calc in the serial version


                        taus(id_E,id_n) = tau_temp;
                        taus_matth(id_E,id_n) = tau_matth_temp;
                        if strcmp(IIS,'yes')
                            taus_IIS(id_E,id_n) = tau_IIS_temp;
                        end
                        if strcmp(screening_POP,'yes')
                            taus_POP(id_E,id_n) = tau_POP_temp;
                        end

                    end

                    send(DQ,id_E);

                end
            end
            
            
        elseif  strcmp(save_RTstruct,'no')
            
            % these struct are different from the final ones like when the
            % taus are computed because these are (id_E,id_n) indexed, then
            % they will be reshaped, and smoothened, later on, after the parfor
            TDF=struct(); TDF_ph=struct(); TDF_sep=struct(); MFP=struct(); MFP_ph=struct(); MFP_sep=struct(); tauE=struct(); tauE_ph=struct(); tauE_sep=struct(); tauE_IIS=struct();
            
            % in these struct the data will be stored as id_EF, id_T
             for id_E = 1:nE
                for id_n =1:n_bands_transp
                 TDF(id_E,id_n).xx=[];
                 TDF(id_E,id_n).xy=[];
                 TDF(id_E,id_n).xz=[];
                 TDF(id_E,id_n).yx=[];
                 TDF(id_E,id_n).yy=[];
                 TDF(id_E,id_n).yz=[];
                 TDF(id_E,id_n).zx=[];
                 TDF(id_E,id_n).zy=[];
                 TDF(id_E,id_n).zz=[];
                 
                 TDF_ph(id_E,id_n).xx=[];
                 TDF_ph(id_E,id_n).xy=[];
                 TDF_ph(id_E,id_n).xz=[];
                 TDF_ph(id_E,id_n).yx=[];
                 TDF_ph(id_E,id_n).yy=[];
                 TDF_ph(id_E,id_n).yz=[];
                 TDF_ph(id_E,id_n).zx=[];
                 TDF_ph(id_E,id_n).zy=[];
                 TDF_ph(id_E,id_n).zz=[];
                 
                 TDF_sep(id_E,id_n).ADP.xx=[];
                 TDF_sep(id_E,id_n).ADP.xy=[];
                 TDF_sep(id_E,id_n).ADP.xz=[];
                 TDF_sep(id_E,id_n).ADP.yx=[];
                 TDF_sep(id_E,id_n).ADP.yy=[];
                 TDF_sep(id_E,id_n).ADP.yz=[];
                 TDF_sep(id_E,id_n).ADP.zx=[];
                 TDF_sep(id_E,id_n).ADP.zy=[];
                 TDF_sep(id_E,id_n).ADP.zz=[];
                 TDF_sep(id_E,id_n).ODP.xx=[];
                 TDF_sep(id_E,id_n).ODP.xy=[];
                 TDF_sep(id_E,id_n).ODP.xz=[];
                 TDF_sep(id_E,id_n).ODP.yx=[];
                 TDF_sep(id_E,id_n).ODP.yy=[];
                 TDF_sep(id_E,id_n).ODP.yz=[];
                 TDF_sep(id_E,id_n).ODP.zx=[];
                 TDF_sep(id_E,id_n).ODP.zy=[];
                 TDF_sep(id_E,id_n).ODP.zz=[];
                 TDF_sep(id_E,id_n).POP.xx=[];
                 TDF_sep(id_E,id_n).POP.xy=[];
                 TDF_sep(id_E,id_n).POP.xz=[];
                 TDF_sep(id_E,id_n).POP.yx=[];
                 TDF_sep(id_E,id_n).POP.yy=[];
                 TDF_sep(id_E,id_n).POP.yz=[];
                 TDF_sep(id_E,id_n).POP.zx=[];
                 TDF_sep(id_E,id_n).POP.zy=[];
                 TDF_sep(id_E,id_n).POP.zz=[];
                 TDF_sep(id_E,id_n).IVS.xx=[];
                 TDF_sep(id_E,id_n).IVS.xy=[];
                 TDF_sep(id_E,id_n).IVS.xz=[];
                 TDF_sep(id_E,id_n).IVS.yx=[];
                 TDF_sep(id_E,id_n).IVS.yy=[];
                 TDF_sep(id_E,id_n).IVS.yz=[];
                 TDF_sep(id_E,id_n).IVS.zx=[];
                 TDF_sep(id_E,id_n).IVS.zy=[];
                 TDF_sep(id_E,id_n).IVS.zz=[];
                 TDF_sep(id_E,id_n).Alloy.xx=[];
                 TDF_sep(id_E,id_n).Alloy.xy=[];
                 TDF_sep(id_E,id_n).Alloy.xz=[];
                 TDF_sep(id_E,id_n).Alloy.yx=[];
                 TDF_sep(id_E,id_n).Alloy.yy=[];
                 TDF_sep(id_E,id_n).Alloy.yz=[];
                 TDF_sep(id_E,id_n).Alloy.zx=[];
                 TDF_sep(id_E,id_n).Alloy.zy=[];
                 TDF_sep(id_E,id_n).Alloy.zz=[];
                 
                 tauE(id_E,id_n).x=[];
                 tauE(id_E,id_n).y=[];
                 tauE(id_E,id_n).z=[];
                 
                 tauE_ph(id_E,id_n).x=[];
                 tauE_ph(id_E,id_n).y=[];
                 tauE_ph(id_E,id_n).z=[];
                 
                 tauE_sep(id_E,id_n).ADP.x=[];
                 tauE_sep(id_E,id_n).ADP.y=[];
                 tauE_sep(id_E,id_n).ADP.z=[];
                 tauE_sep(id_E,id_n).IVS.x=[];
                 tauE_sep(id_E,id_n).IVS.y=[];
                 tauE_sep(id_E,id_n).IVS.z=[];
                 tauE_sep(id_E,id_n).ODP.x=[];
                 tauE_sep(id_E,id_n).ODP.y=[];
                 tauE_sep(id_E,id_n).ODP.z=[];
                 tauE_sep(id_E,id_n).POP.x=[];
                 tauE_sep(id_E,id_n).POP.y=[];
                 tauE_sep(id_E,id_n).POP.z=[];
                 tauE_sep(id_E,id_n).Alloy.x=[];
                 tauE_sep(id_E,id_n).Alloy.y=[];
                 tauE_sep(id_E,id_n).Alloy.z=[];
                 
                 tauE_IIS(id_E,id_n).x=[];
                 tauE_IIS(id_E,id_n).y=[];
                 tauE_IIS(id_E,id_n).z=[];
                 
                 MFP(id_E,id_n).x=[];
                 MFP(id_E,id_n).y=[];
                 MFP(id_E,id_n).z=[];
                 
                 MFP_ph(id_E,id_n).x=[];
                 MFP_ph(id_E,id_n).y=[];
                 MFP_ph(id_E,id_n).z=[];
                 
                 MFP_sep(id_E,id_n).ADP.x=[];
                 MFP_sep(id_E,id_n).ADP.y=[];
                 MFP_sep(id_E,id_n).ADP.z=[];
                 MFP_sep(id_E,id_n).IVS.x=[];
                 MFP_sep(id_E,id_n).IVS.y=[];
                 MFP_sep(id_E,id_n).IVS.z=[];
                 MFP_sep(id_E,id_n).ODP.x=[];
                 MFP_sep(id_E,id_n).ODP.y=[];
                 MFP_sep(id_E,id_n).ODP.z=[];
                 MFP_sep(id_E,id_n).POP.x=[];
                 MFP_sep(id_E,id_n).POP.y=[];
                 MFP_sep(id_E,id_n).POP.z=[];
                 MFP_sep(id_E,id_n).Alloy.x=[];
                 MFP_sep(id_E,id_n).Alloy.y=[];
                 MFP_sep(id_E,id_n).Alloy.z=[];                

                end
            end

                        
            save('WorkSpace4','-v7.3','-nocompression');
            WorkSpace4 = load('WorkSpace4.mat');
            
            DQ = parallel.pool.DataQueue;
            afterEach(DQ, @disp);

            disp('computing the TDFs '); disp(' ');
            disp('total number of energy values'); disp(' '); disp(nE); disp(' ')
            
            if strcmp(multivalley,'no')

                parfor id_E = 1:nE
                    for id_n = 1:n_bands_transp

                    [ TDF_n_temp, TDF_ph_n_temp, TDF_sep_n_temp, MFP_n_temp, MFP_ph_n_temp, MFP_sep_n_temp, tauE_n_temp, tauE_ph_n_temp, tauE_sep_n_temp, tauE_IIS_n_temp] ...
                            = TDF_calc_ELECTRA_v0(id_E, id_n, WorkSpace4 );
                        
                     TDF(id_E,id_n).xx = TDF_n_temp.xx;
                     TDF(id_E,id_n).xy = TDF_n_temp.xy;
                     TDF(id_E,id_n).xz = TDF_n_temp.xz;
                     TDF(id_E,id_n).yx = TDF_n_temp.yx;
                     TDF(id_E,id_n).yy = TDF_n_temp.yy;
                     TDF(id_E,id_n).yz = TDF_n_temp.yz;
                     TDF(id_E,id_n).zx = TDF_n_temp.zx;
                     TDF(id_E,id_n).zy = TDF_n_temp.zy;
                     TDF(id_E,id_n).zz = TDF_n_temp.zz;

                     TDF_ph(id_E,id_n).xx = TDF_ph_n_temp.xx;
                     TDF_ph(id_E,id_n).xy = TDF_ph_n_temp.xy;
                     TDF_ph(id_E,id_n).xz = TDF_ph_n_temp.xz;
                     TDF_ph(id_E,id_n).yx = TDF_ph_n_temp.yx;
                     TDF_ph(id_E,id_n).yy = TDF_ph_n_temp.yy;
                     TDF_ph(id_E,id_n).yz = TDF_ph_n_temp.yz;
                     TDF_ph(id_E,id_n).zx = TDF_ph_n_temp.zx;
                     TDF_ph(id_E,id_n).zy = TDF_ph_n_temp.zy;
                     TDF_ph(id_E,id_n).zz = TDF_ph_n_temp.zz;

                     TDF_sep(id_E,id_n).ADP.xx = TDF_sep_n_temp.ADP.xx;
                     TDF_sep(id_E,id_n).ADP.xy = TDF_sep_n_temp.ADP.xy;
                     TDF_sep(id_E,id_n).ADP.xz = TDF_sep_n_temp.ADP.xz;
                     TDF_sep(id_E,id_n).ADP.yx = TDF_sep_n_temp.ADP.yx;
                     TDF_sep(id_E,id_n).ADP.yy = TDF_sep_n_temp.ADP.yy;
                     TDF_sep(id_E,id_n).ADP.yz = TDF_sep_n_temp.ADP.yz;
                     TDF_sep(id_E,id_n).ADP.zx = TDF_sep_n_temp.ADP.zx;
                     TDF_sep(id_E,id_n).ADP.zy = TDF_sep_n_temp.ADP.zy;
                     TDF_sep(id_E,id_n).ADP.zz = TDF_sep_n_temp.ADP.zz;
                     TDF_sep(id_E,id_n).ODP.xx = TDF_sep_n_temp.ODP.xx;
                     TDF_sep(id_E,id_n).ODP.xy = TDF_sep_n_temp.ODP.xy;
                     TDF_sep(id_E,id_n).ODP.xz = TDF_sep_n_temp.ODP.xz;
                     TDF_sep(id_E,id_n).ODP.yx = TDF_sep_n_temp.ODP.yx;
                     TDF_sep(id_E,id_n).ODP.yy = TDF_sep_n_temp.ODP.yy;
                     TDF_sep(id_E,id_n).ODP.yz = TDF_sep_n_temp.ODP.yz;
                     TDF_sep(id_E,id_n).ODP.zx = TDF_sep_n_temp.ODP.zx;
                     TDF_sep(id_E,id_n).ODP.zy = TDF_sep_n_temp.ODP.zy;
                     TDF_sep(id_E,id_n).ODP.zz = TDF_sep_n_temp.ODP.zz;
                     TDF_sep(id_E,id_n).POP.xx = TDF_sep_n_temp.POP.xx;
                     TDF_sep(id_E,id_n).POP.xy = TDF_sep_n_temp.POP.xy;
                     TDF_sep(id_E,id_n).POP.xz = TDF_sep_n_temp.POP.xz;
                     TDF_sep(id_E,id_n).POP.yx = TDF_sep_n_temp.POP.yx;
                     TDF_sep(id_E,id_n).POP.yy = TDF_sep_n_temp.POP.yy;
                     TDF_sep(id_E,id_n).POP.yz = TDF_sep_n_temp.POP.yz;
                     TDF_sep(id_E,id_n).POP.zx = TDF_sep_n_temp.POP.zx;
                     TDF_sep(id_E,id_n).POP.zy = TDF_sep_n_temp.POP.zy;
                     TDF_sep(id_E,id_n).POP.zz = TDF_sep_n_temp.POP.zz;
                     TDF_sep(id_E,id_n).IVS.xx = TDF_sep_n_temp.IVS.xx;
                     TDF_sep(id_E,id_n).IVS.xy = TDF_sep_n_temp.IVS.xy;
                     TDF_sep(id_E,id_n).IVS.xz = TDF_sep_n_temp.IVS.xz;
                     TDF_sep(id_E,id_n).IVS.yx = TDF_sep_n_temp.IVS.yx;
                     TDF_sep(id_E,id_n).IVS.yy = TDF_sep_n_temp.IVS.yy;
                     TDF_sep(id_E,id_n).IVS.yz = TDF_sep_n_temp.IVS.yz;
                     TDF_sep(id_E,id_n).IVS.zx = TDF_sep_n_temp.IVS.zx;
                     TDF_sep(id_E,id_n).IVS.zy = TDF_sep_n_temp.IVS.zy;
                     TDF_sep(id_E,id_n).IVS.zz = TDF_sep_n_temp.IVS.zz;
                     TDF_sep(id_E,id_n).Alloy.xx = TDF_sep_n_temp.Alloy.xx;
                     TDF_sep(id_E,id_n).Alloy.xy = TDF_sep_n_temp.Alloy.xy;
                     TDF_sep(id_E,id_n).Alloy.xz = TDF_sep_n_temp.Alloy.xz;
                     TDF_sep(id_E,id_n).Alloy.yx = TDF_sep_n_temp.Alloy.yx;
                     TDF_sep(id_E,id_n).Alloy.yy = TDF_sep_n_temp.Alloy.yy;
                     TDF_sep(id_E,id_n).Alloy.yz = TDF_sep_n_temp.Alloy.yz;
                     TDF_sep(id_E,id_n).Alloy.zx = TDF_sep_n_temp.Alloy.zx;
                     TDF_sep(id_E,id_n).Alloy.zy = TDF_sep_n_temp.Alloy.zy;
                     TDF_sep(id_E,id_n).Alloy.zz = TDF_sep_n_temp.Alloy.zz;
                     

                     tauE(id_E,id_n).x = tauE_n_temp.x;
                     tauE(id_E,id_n).y = tauE_n_temp.y;
                     tauE(id_E,id_n).z = tauE_n_temp.z;

                     tauE_ph(id_E,id_n).x = tauE_ph_n_temp.x;
                     tauE_ph(id_E,id_n).y = tauE_ph_n_temp.y;
                     tauE_ph(id_E,id_n).z = tauE_ph_n_temp.z;
                     
                     tauE_sep(id_E,id_n) = tauE_sep_n_temp ;

                     tauE_IIS(id_E,id_n).x = tauE_IIS_n_temp.x;
                     tauE_IIS(id_E,id_n).y = tauE_IIS_n_temp.y;
                     tauE_IIS(id_E,id_n).z = tauE_IIS_n_temp.z;

                     MFP(id_E,id_n).x = MFP_n_temp.x;
                     MFP(id_E,id_n).y = MFP_n_temp.y;
                     MFP(id_E,id_n).z = MFP_n_temp.z;

                     MFP_ph(id_E,id_n).x = MFP_ph_n_temp.x;
                     MFP_ph(id_E,id_n).y = MFP_ph_n_temp.y;
                     MFP_ph(id_E,id_n).z = MFP_ph_n_temp.z;

                    MFP_sep(id_E,id_n) = MFP_sep_n_temp ;
                       
                   
                    end
                    send(DQ,id_E);
                end
                
                TDF_n_temp = TDF;
                % composing the above struct file in the final form
                [TDF, TDF_n, TDF_ph, TDF_ph_n, TDF_sep, TDF_sep_n, MFP, MFP_n, MFP_ph, MFP_ph_n, MFP_sep, MFP_sep_n, tauE, tauE_n, tauE_ph, tauE_ph_n, tauE_sep, tauE_sep_n, tauE_IIS, tauE_IIS_n] ...
                    = TDF_reshuffling_ELECTRA(TDF_n_temp, TDF_ph, TDF_sep, MFP, MFP_ph, MFP_sep, tauE, tauE_ph, tauE_sep, tauE_IIS, E_array, n_bands_transp, EF_matrix, T_array, IIS, POP, screening_POP, sd) ;
                
                
            elseif strcmp(multivalley,'yes')

                parfor id_E = 1:nE
                    for id_n = 1:n_bands_transp

                    [ TDF_n_temp, TDF_ph_n_temp, TDF_sep_n_temp, MFP_n_temp, MFP_ph_n_temp, MFP_sep_n_temp, tauE_n_temp, tauE_ph_n_temp, tauE_sep_n_temp, tauE_IIS_n_temp] ...
                            = TDF_calc_multivalley_ELECTRA_v0(id_E, id_n, WorkSpace4 );
                        
                     TDF(id_E,id_n).xx = TDF_n_temp.xx;
                     TDF(id_E,id_n).xy = TDF_n_temp.xy;
                     TDF(id_E,id_n).xz = TDF_n_temp.xz;
                     TDF(id_E,id_n).yx = TDF_n_temp.yx;
                     TDF(id_E,id_n).yy = TDF_n_temp.yy;
                     TDF(id_E,id_n).yz = TDF_n_temp.yz;
                     TDF(id_E,id_n).zx = TDF_n_temp.zx;
                     TDF(id_E,id_n).zy = TDF_n_temp.zy;
                     TDF(id_E,id_n).zz = TDF_n_temp.zz;

                     TDF_ph(id_E,id_n).xx = TDF_ph_n_temp.xx;
                     TDF_ph(id_E,id_n).xy = TDF_ph_n_temp.xy;
                     TDF_ph(id_E,id_n).xz = TDF_ph_n_temp.xz;
                     TDF_ph(id_E,id_n).yx = TDF_ph_n_temp.yx;
                     TDF_ph(id_E,id_n).yy = TDF_ph_n_temp.yy;
                     TDF_ph(id_E,id_n).yz = TDF_ph_n_temp.yz;
                     TDF_ph(id_E,id_n).zx = TDF_ph_n_temp.zx;
                     TDF_ph(id_E,id_n).zy = TDF_ph_n_temp.zy;
                     TDF_ph(id_E,id_n).zz = TDF_ph_n_temp.zz;

                     TDF_sep(id_E,id_n).ADP.xx = TDF_sep_n_temp.ADP.xx;
                     TDF_sep(id_E,id_n).ADP.xy = TDF_sep_n_temp.ADP.xy;
                     TDF_sep(id_E,id_n).ADP.xz = TDF_sep_n_temp.ADP.xz;
                     TDF_sep(id_E,id_n).ADP.yx = TDF_sep_n_temp.ADP.yx;
                     TDF_sep(id_E,id_n).ADP.yy = TDF_sep_n_temp.ADP.yy;
                     TDF_sep(id_E,id_n).ADP.yz = TDF_sep_n_temp.ADP.yz;
                     TDF_sep(id_E,id_n).ADP.zx = TDF_sep_n_temp.ADP.zx;
                     TDF_sep(id_E,id_n).ADP.zy = TDF_sep_n_temp.ADP.zy;
                     TDF_sep(id_E,id_n).ADP.zz = TDF_sep_n_temp.ADP.zz;
                     TDF_sep(id_E,id_n).ODP.xx = TDF_sep_n_temp.ODP.xx;
                     TDF_sep(id_E,id_n).ODP.xy = TDF_sep_n_temp.ODP.xy;
                     TDF_sep(id_E,id_n).ODP.xz = TDF_sep_n_temp.ODP.xz;
                     TDF_sep(id_E,id_n).ODP.yx = TDF_sep_n_temp.ODP.yx;
                     TDF_sep(id_E,id_n).ODP.yy = TDF_sep_n_temp.ODP.yy;
                     TDF_sep(id_E,id_n).ODP.yz = TDF_sep_n_temp.ODP.yz;
                     TDF_sep(id_E,id_n).ODP.zx = TDF_sep_n_temp.ODP.zx;
                     TDF_sep(id_E,id_n).ODP.zy = TDF_sep_n_temp.ODP.zy;
                     TDF_sep(id_E,id_n).ODP.zz = TDF_sep_n_temp.ODP.zz;
                     TDF_sep(id_E,id_n).POP.xx = TDF_sep_n_temp.POP.xx;
                     TDF_sep(id_E,id_n).POP.xy = TDF_sep_n_temp.POP.xy;
                     TDF_sep(id_E,id_n).POP.xz = TDF_sep_n_temp.POP.xz;
                     TDF_sep(id_E,id_n).POP.yx = TDF_sep_n_temp.POP.yx;
                     TDF_sep(id_E,id_n).POP.yy = TDF_sep_n_temp.POP.yy;
                     TDF_sep(id_E,id_n).POP.yz = TDF_sep_n_temp.POP.yz;
                     TDF_sep(id_E,id_n).POP.zx = TDF_sep_n_temp.POP.zx;
                     TDF_sep(id_E,id_n).POP.zy = TDF_sep_n_temp.POP.zy;
                     TDF_sep(id_E,id_n).POP.zz = TDF_sep_n_temp.POP.zz;
                     TDF_sep(id_E,id_n).IVS.xx = TDF_sep_n_temp.IVS.xx;
                     TDF_sep(id_E,id_n).IVS.xy = TDF_sep_n_temp.IVS.xy;
                     TDF_sep(id_E,id_n).IVS.xz = TDF_sep_n_temp.IVS.xz;
                     TDF_sep(id_E,id_n).IVS.yx = TDF_sep_n_temp.IVS.yx;
                     TDF_sep(id_E,id_n).IVS.yy = TDF_sep_n_temp.IVS.yy;
                     TDF_sep(id_E,id_n).IVS.yz = TDF_sep_n_temp.IVS.yz;
                     TDF_sep(id_E,id_n).IVS.zx = TDF_sep_n_temp.IVS.zx;
                     TDF_sep(id_E,id_n).IVS.zy = TDF_sep_n_temp.IVS.zy;
                     TDF_sep(id_E,id_n).IVS.zz = TDF_sep_n_temp.IVS.zz;
                     TDF_sep(id_E,id_n).Alloy.xx = TDF_sep_n_temp.Alloy.xx;
                     TDF_sep(id_E,id_n).Alloy.xy = TDF_sep_n_temp.Alloy.xy;
                     TDF_sep(id_E,id_n).Alloy.xz = TDF_sep_n_temp.Alloy.xz;
                     TDF_sep(id_E,id_n).Alloy.yx = TDF_sep_n_temp.Alloy.yx;
                     TDF_sep(id_E,id_n).Alloy.yy = TDF_sep_n_temp.Alloy.yy;
                     TDF_sep(id_E,id_n).Alloy.yz = TDF_sep_n_temp.Alloy.yz;
                     TDF_sep(id_E,id_n).Alloy.zx = TDF_sep_n_temp.Alloy.zx;
                     TDF_sep(id_E,id_n).Alloy.zy = TDF_sep_n_temp.Alloy.zy;
                     TDF_sep(id_E,id_n).Alloy.zz = TDF_sep_n_temp.Alloy.zz;
                     

                     tauE(id_E,id_n).x = tauE_n_temp.x;
                     tauE(id_E,id_n).y = tauE_n_temp.y;
                     tauE(id_E,id_n).z = tauE_n_temp.z;

                     tauE_ph(id_E,id_n).x = tauE_ph_n_temp.x;
                     tauE_ph(id_E,id_n).y = tauE_ph_n_temp.y;
                     tauE_ph(id_E,id_n).z = tauE_ph_n_temp.z;
                     
                     tauE_sep(id_E,id_n) = tauE_sep_n_temp ;

                     tauE_IIS(id_E,id_n).x = tauE_IIS_n_temp.x;
                     tauE_IIS(id_E,id_n).y = tauE_IIS_n_temp.y;
                     tauE_IIS(id_E,id_n).z = tauE_IIS_n_temp.z;

                     MFP(id_E,id_n).x = MFP_n_temp.x;
                     MFP(id_E,id_n).y = MFP_n_temp.y;
                     MFP(id_E,id_n).z = MFP_n_temp.z;

                     MFP_ph(id_E,id_n).x = MFP_ph_n_temp.x;
                     MFP_ph(id_E,id_n).y = MFP_ph_n_temp.y;
                     MFP_ph(id_E,id_n).z = MFP_ph_n_temp.z;

                    MFP_sep(id_E,id_n) = MFP_sep_n_temp ;
                       
                   
                    end
                    send(DQ,id_E);
                end
                
                TDF_n_temp = TDF;
                % composing the above struct file in the final form
                [TDF, TDF_n, TDF_ph, TDF_ph_n, TDF_sep, TDF_sep_n, MFP, MFP_n, MFP_ph, MFP_ph_n, MFP_sep, MFP_sep_n, tauE, tauE_n, tauE_ph, tauE_ph_n, tauE_sep, tauE_sep_n, tauE_IIS, tauE_IIS_n] ...
                    = TDF_reshuffling_ELECTRA(TDF_n_temp, TDF_ph, TDF_sep, MFP, MFP_ph, MFP_sep, tauE, tauE_ph, tauE_sep, tauE_IIS, E_array, n_bands_transp, EF_matrix, T_array, IIS, POP, screening_POP, sd) ;
                 
           
            
            end
            
            
        end
        toc

        
    end
    
    
    
   
    if strcmp(bipolar_transport,'no')
        
        if strcmp(save_RTstruct,'yes') % if 'no', TDF already computed, only integration is needed
            
            % struct data type
            [TDF, TDF_n, TDF_ph, TDF_ph_n, TDF_sep, TDF_sep_n, MFP, MFP_n, MFP_ph, MFP_ph_n, MFP_sep, MFP_sep_n, tauE, tauE_n, tauE_ph, tauE_ph_n, tauE_sep, tauE_sep_n, tauE_IIS, tauE_IIS_n] = ...
                TDF_composition_ELECTRA(WorkSpace4, taus, taus_matth, taus_IIS, taus_POP) ;
            
        end
            
            [sigma, sigma_ph, sigma_sep, S, S_ph, S_sep, PF, PF_ph, PF_sep, ke, ke_ph, ke_sep, mu, mu_ph, mu_sep, n_carrier, n_carrier_ph, EF_matrix_ph, N_imp_matrix_ph] = ...
            TDF_integration_ELECTRA(E_array, T_array, TDF, TDF_ph, TDF_sep, EF_matrix, DOS_tot, WorkSpace4) ;
        
        
        % Bipolar case, composing the electron/majority E-dependent quantities
    elseif strcmp(bipolar_transport,'yes')
        
        if strcmp(save_RTstruct,'yes')
            
            disp('composing the TDFs '); disp(' ');
            % struct data type

            [TDF_electron, TDF_n_electron, TDF_ph_electron, TDF_ph_n_electron, TDF_sep_electron, TDF_sep_n_electron, MFP_electron, MFP_n_electron, MFP_ph_electron, MFP_ph_n_electron, MFP_sep_electron, MFP_sep_n_electron, tauE_electron, tauE_n_electron, tauE_ph_electron, tauE_ph_n_electron, tauE_sep_electron, tauE_sep_n_electron, tauE_IIS_electron, tauE_IIS_n_electron] = ...
                TDF_composition_ELECTRA(WorkSpace4, taus, taus_matth, taus_IIS, taus_POP) ;        

        else
            TDF_electron = TDF ; TDF_n_electron = TDF_n ; TDF_ph_electron = TDF_ph ; TDF_ph_n_electron = TDF_ph_n ; TDF_sep_electron = TDF_sep ; TDF_sep_n_electron = TDF_sep_n ;
            MFP_electron = MFP ; MFP_n_electron = MFP_n ; MFP_ph_electron = MFP_ph ; MFP_ph_n_electron = MFP_ph_n ; MFP_sep_electron = MFP_sep ; MFP_sep_n_electron = MFP_sep_n ;
            tauE_electron = tauE ;  tauE_n_electron = tauE_n ; tauE_ph_electron = tauE_ph ; tauE_ph_n_electron = tauE_ph_n ; tauE_sep_electron = tauE_sep ; tauE_sep_n_electron = tauE_sep_n ; tauE_IIS_electron = tauE_IIS ; tauE_IIS_n_electron = tauE_IIS_n ;                
        end
        
        if strcmp(constant_tau,'yes')
            [TDF_electron_CMFP, TDF_n_electron_CMFP, tauE_electron_CMFP, tauE_n_electron_CMFP] = ...
                TDF_CMFP_ELECTRA(WorkSpace4) ;
        end
        
    end
    
    
    
    if strcmp(save_RTstruct,'yes') && strcmp(constant_tau,'no')
            save('RelaxTimes_separate','taus','-v7.3','-nocompression')
            save('RelaxTimes_matthiessen','taus_matth','-v7.3','-nocompression')
            if strcmp(IIS,'yes')
                save('RelaxTimes_IIS','taus_IIS','-v7.3','-nocompression')
            end
            if strcmp(screening_POP,'yes')
                save('RelaxTimes_screenedPOP','taus_POP','-v7.3','-nocompression')
            end            
    end
    clear taus taus_matth taus_IIS taus_POP DQ
    
    if strcmp(bipolar_transport,'no')
        if strcmp(constant_tau,'yes')
            save_filename=['TE_',material_name,'_crt_',scan_type,'_',carriers,'.mat'];
            save(save_filename, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
            'sigma', 'S', 'PF', 'ke','mu', 'n_carrier', ...
            'EF_matrix', 'N_imp_matrix',...
            'TDF', 'TDF_n', ...
            'MFP', 'MFP_n', ...
            'tauE', 'tauE_n', ...
            'state_ID', 'bands_transp', 'q0', 'hbar', 'material_name')
        else
            save_filename=['TE_',material_name,'_',scan_type,'_',carriers,'.mat'];
            if strcmp(IIS,'yes')
                save(save_filename, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
                    'sigma', 'sigma_ph', 'sigma_sep', 'S', 'S_ph', 'S_sep', ...
                    'PF', 'PF_ph', 'PF_sep', 'ke', 'ke_ph', 'ke_sep', ...
                    'mu', 'mu_ph', 'mu_sep', 'n_carrier', 'n_carrier_ph', ...
                    'EF_matrix', 'N_imp_matrix', 'EF_matrix_ph', 'N_imp_matrix_ph', ...
                    'TDF', 'TDF_n', 'TDF_ph', 'TDF_ph_n', 'TDF_sep', 'TDF_sep_n', ...
                    'MFP', 'MFP_n', 'MFP_ph', 'MFP_ph_n', 'MFP_sep', 'MFP_sep_n', ...
                    'tauE', 'tauE_n', 'tauE_ph', 'tauE_ph_n', 'tauE_sep', 'tauE_sep_n', 'tauE_IIS', 'tauE_IIS_n',...
                    'state_ID', 'bands_transp', 'n_scatt', 'LD', 'q0', 'hbar', 'material_name', ...
                     'ADP', 'ADP_IVS', 'ODP', 'IVS', 'IIS', 'POP', 'screening_POP', ...
                    'IIS_interband_flag', 'Alloy', 'overlap_integrals_analytical',...
                    'k_restriction', 'k_restriction_cutoff', 'multivalley')
            else
                save(save_filename, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
                    'sigma', 'sigma_ph', 'sigma_sep', 'S', 'S_ph', 'S_sep', ...
                    'PF', 'PF_ph', 'PF_sep', 'ke', 'ke_ph', 'ke_sep', ...
                    'mu', 'mu_ph', 'mu_sep', 'n_carrier', 'n_carrier_ph', ...
                    'EF_matrix', 'N_imp_matrix', 'EF_matrix_ph', 'N_imp_matrix_ph', ...
                    'TDF', 'TDF_n', 'TDF_ph', 'TDF_ph_n', 'TDF_sep', 'TDF_sep_n', ...
                    'MFP', 'MFP_n', 'MFP_ph', 'MFP_ph_n', 'MFP_sep', 'MFP_sep_n', ...
                    'tauE', 'tauE_n', 'tauE_ph', 'tauE_ph_n', 'tauE_sep', 'tauE_sep_n', ...
                    'state_ID', 'bands_transp', 'n_scatt', 'q0', 'hbar', 'material_name', ...
                     'ADP', 'ADP_IVS', 'ODP', 'IVS', 'IIS', 'POP', 'screening_POP', ...
                    'IIS_interband_flag', 'Alloy', 'overlap_integrals_analytical',...
                    'k_restriction', 'k_restriction_cutoff', 'multivalley')
            end
        end      
        
           

        save_state_ID_name=['state_ID_',material_name,'_',scan_type,'_',carriers,'.mat'];
        save(save_state_ID_name,'state_ID','-v7.3','-nocompression')


    elseif strcmp(bipolar_transport,'yes')
        
        save_state_ID_name=['state_ID_',material_name,'_',scan_type,'_',carriers,'.mat'];
        save(save_state_ID_name,'state_ID','-v7.3','-nocompression')
        % start of the bipolar consideration
        
        % what follows makes the swap in energies and carriers to get the Energy dependent quantities for the minority abd coputes the TE coefficients

        % swap the carriers
        if strcmp(carriers,'holes')
            carriers = 'electrons';
        elseif strcmp(carriers,'electrons')
            carriers = 'holes';
        end
        
        % swap the energies and define the new limits for the scattering rate calc.
        Ek = -Ek; % flip the bandstructure but does NOT shift them
        Emin = Emin_minority;  Emax = Emax_majority;
        E_array = E_array_minority; 
        nE = size(E_array,2);
        EF_matrix = -EF_matrix; 
        bands_transp = bands_transp_minority;
        n_bands_transp = n_bands_transp_minority;
        % NOTE the state_ID file for majority is NOT saved as it requires too much memory
        DOS_tot = DOS_tot_minority; DOS = DOS_minority;
        V_tot = V_tot_minority; V = V_minority;
        clear state_ID
        load('state_ID_minority')

        % calculation of the scattering rates - double check if this is fine
        if strcmp(constant_tau,'yes')
            n_scatt=1;
            taus=struct();
            taus_matth=struct();
            taus_IIS=struct();
            taus_POP=struct();
            for id_E = size(E_array,2):-1:1
                for id_n = n_bands_transp:-1:1
                    taus(id_E,id_n).x=[];
                    taus(id_E,id_n).y=[];
                    taus(id_E,id_n).z=[];
                    taus_IIS(id_E,id_n).x=[];
                    taus_IIS(id_E,id_n).y=[];
                    taus_IIS(id_E,id_n).z=[];
                    taus_POP(id_E,id_n).x=[];
                    taus_POP(id_E,id_n).y=[];
                    taus_POP(id_E,id_n).z=[];

                    for id_T = 1:size(T_array,2)
                            taus_matth(id_E,id_n).x(:,id_T)=tau_const;
                            taus_matth(id_E,id_n).y(:,id_T)=tau_const;
                            taus_matth(id_E,id_n).z(:,id_T)=tau_const;
                    end

                end
                
            end
        end
        
  
        
            % preliminary side variables declation
            % Wave Functions - this is still to be developed
                if strcmp(WF_provided,'yes')
                    addpath('Data\');
                    WF_filename=['WF_',material_name,'_',dimensionality,'.mat'];   % this file contains the Wave forms factors == 1 for parabolic bands
                                                                           % named in
                                                                           % the file
                                                                           % WF(:,id_n)
                    load(WF_filename);
                    addpath('Data\','-frozen');
                else
                    WF=ones(1,n_bands_transp);
                end                
              
                % spin degeneracy 
                if strcmp(spin_resolved,'no') % spin degeneracy array
                    sd_array = zeros(1,n_bands_transp);
                end

                % eventually, multivalley labels       
                if strcmp(multivalley,'yes')
                    valley_type = valley_type(bands_transp);
                end
                
                
                
                
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------


        % Core calculation of the valence bands / minority carriers 
        % transport functions
            tic 
            if strcmp(constant_tau,'yes')
                save('WorkSpace4_minority','-v7.3','-nocompression');
                WorkSpace4_minority = load('WorkSpace4_minority.mat');
            end
            if  strcmp(save_RTstruct,'yes') && strcmp(constant_tau,'no') % in this case the code computes large, tens of Gb, struct data with the relaxation times
            
                taus=struct();
                taus_matth=struct();
                taus_IIS=struct();
                taus_POP=struct();
                for id_E = 1:nE
                    for id_n =1:n_bands_transp
                     taus(id_E,id_n).x=[];
                     taus(id_E,id_n).y=[];
                     taus(id_E,id_n).z=[];
                     taus_matth(id_E,id_n).x=[];
                     taus_matth(id_E,id_n).y=[];
                     taus_matth(id_E,id_n).z=[];

                     taus_IIS(id_E,id_n).x=[];
                     taus_IIS(id_E,id_n).y=[];
                     taus_IIS(id_E,id_n).z=[];

                     taus_POP(id_E,id_n).x=[];
                     taus_POP(id_E,id_n).y=[];
                     taus_POP(id_E,id_n).z=[];

                    end
                end

                clear id_E id_n
                clear DQ ans % for Matlab version before than 2017
                
                
                save('WorkSpace4_minority','-v7.3','-nocompression');
                WorkSpace4_minority = load('WorkSpace4_minority.mat');

                DQ = parallel.pool.DataQueue;
                afterEach(DQ, @disp);

                disp('computing the Relaxation Times for the minority/valence bands'); disp(' ');
                disp('total number of energy values'); disp(' '); disp(nE); disp(' ')
                if strcmp(multivalley,'no')
                    parfor id_E = 1:nE
                        for id_n = 1:n_bands_transp


                           [tau_temp, tau_matth_temp, tau_IIS_temp, tau_POP_temp] = tau_calc_funct_ELECTRA_v0(id_E, id_n, WorkSpace4_minority ); % the big tau_calc routine, the actual tau_calc in the serial version


                            taus(id_E,id_n) = tau_temp;
                            taus_matth(id_E,id_n) = tau_matth_temp;
                            if strcmp(IIS,'yes')
                                taus_IIS(id_E,id_n) = tau_IIS_temp;
                            end
                            if strcmp(screening_POP,'yes')
                                taus_POP(id_E,id_n) = tau_POP_temp;
                            end

                        end

                        send(DQ,id_E);

                    end
                elseif strcmp(multivalley,'yes')
                    parfor id_E = 1:nE
                        for id_n = 1:n_bands_transp


                           [tau_temp, tau_matth_temp, tau_IIS_temp, tau_POP_temp] = tau_calc_funct_multivalley_ELECTRA_v0(id_E, id_n, WorkSpace4_minority ); % the big tau_calc routine, the actual tau_calc in the serial version


                            taus(id_E,id_n) = tau_temp;
                            taus_matth(id_E,id_n) = tau_matth_temp;
                            if strcmp(IIS,'yes')
                                taus_IIS(id_E,id_n) = tau_IIS_temp;
                            end
                            if strcmp(screening_POP,'yes')
                                taus_POP(id_E,id_n) = tau_POP_temp;
                            end

                        end

                        send(DQ,id_E);

                    end
                end


            elseif  strcmp(save_RTstruct,'no')

                % these struct are different from the final ones like when the
                % taus are computed because these are (id_E,id_n) indexed, then
                % they will be reshaped, and smoothened, later on, after the parfor
                TDF_hole=struct(); TDF_ph_hole=struct(); TDF_sep_hole=struct(); MFP_hole=struct(); MFP_ph_hole=struct(); MFP_sep_hole=struct(); tauE_hole=struct(); tauE_ph_hole=struct(); tauE_sep_hole=struct(); tauE_IIS_hole=struct();

                % in these struct the data will be stored as id_EF, id_T
                 for id_E = 1:nE
                    for id_n =1:n_bands_transp
                     TDF_hole(id_E,id_n).xx=[];
                     TDF_hole(id_E,id_n).xy=[];
                     TDF_hole(id_E,id_n).xz=[];
                     TDF_hole(id_E,id_n).yx=[];
                     TDF_hole(id_E,id_n).yy=[];
                     TDF_hole(id_E,id_n).yz=[];
                     TDF_hole(id_E,id_n).zx=[];
                     TDF_hole(id_E,id_n).zy=[];
                     TDF_hole(id_E,id_n).zz=[];

                     TDF_ph_hole(id_E,id_n).xx=[];
                     TDF_ph_hole(id_E,id_n).xy=[];
                     TDF_ph_hole(id_E,id_n).xz=[];
                     TDF_ph_hole(id_E,id_n).yx=[];
                     TDF_ph_hole(id_E,id_n).yy=[];
                     TDF_ph_hole(id_E,id_n).yz=[];
                     TDF_ph_hole(id_E,id_n).zx=[];
                     TDF_ph_hole(id_E,id_n).zy=[];
                     TDF_ph_hole(id_E,id_n).zz=[];

                     TDF_sep_hole(id_E,id_n).ADP.xx=[];
                     TDF_sep_hole(id_E,id_n).ADP.xy=[];
                     TDF_sep_hole(id_E,id_n).ADP.xz=[];
                     TDF_sep_hole(id_E,id_n).ADP.yx=[];
                     TDF_sep_hole(id_E,id_n).ADP.yy=[];
                     TDF_sep_hole(id_E,id_n).ADP.yz=[];
                     TDF_sep_hole(id_E,id_n).ADP.zx=[];
                     TDF_sep_hole(id_E,id_n).ADP.zy=[];
                     TDF_sep_hole(id_E,id_n).ADP.zz=[];
                     TDF_sep_hole(id_E,id_n).ODP.xx=[];
                     TDF_sep_hole(id_E,id_n).ODP.xy=[];
                     TDF_sep_hole(id_E,id_n).ODP.xz=[];
                     TDF_sep_hole(id_E,id_n).ODP.yx=[];
                     TDF_sep_hole(id_E,id_n).ODP.yy=[];
                     TDF_sep_hole(id_E,id_n).ODP.yz=[];
                     TDF_sep_hole(id_E,id_n).ODP.zx=[];
                     TDF_sep_hole(id_E,id_n).ODP.zy=[];
                     TDF_sep_hole(id_E,id_n).ODP.zz=[];
                     TDF_sep_hole(id_E,id_n).POP.xx=[];
                     TDF_sep_hole(id_E,id_n).POP.xy=[];
                     TDF_sep_hole(id_E,id_n).POP.xz=[];
                     TDF_sep_hole(id_E,id_n).POP.yx=[];
                     TDF_sep_hole(id_E,id_n).POP.yy=[];
                     TDF_sep_hole(id_E,id_n).POP.yz=[];
                     TDF_sep_hole(id_E,id_n).POP.zx=[];
                     TDF_sep_hole(id_E,id_n).POP.zy=[];
                     TDF_sep_hole(id_E,id_n).POP.zz=[];
                     TDF_sep_hole(id_E,id_n).IVS.xx=[];
                     TDF_sep_hole(id_E,id_n).IVS.xy=[];
                     TDF_sep_hole(id_E,id_n).IVS.xz=[];
                     TDF_sep_hole(id_E,id_n).IVS.yx=[];
                     TDF_sep_hole(id_E,id_n).IVS.yy=[];
                     TDF_sep_hole(id_E,id_n).IVS.yz=[];
                     TDF_sep_hole(id_E,id_n).IVS.zx=[];
                     TDF_sep_hole(id_E,id_n).IVS.zy=[];
                     TDF_sep_hole(id_E,id_n).IVS.zz=[];
                     TDF_sep_hole(id_E,id_n).Alloy.xx=[];
                     TDF_sep_hole(id_E,id_n).Alloy.xy=[];
                     TDF_sep_hole(id_E,id_n).Alloy.xz=[];
                     TDF_sep_hole(id_E,id_n).Alloy.yx=[];
                     TDF_sep_hole(id_E,id_n).Alloy.yy=[];
                     TDF_sep_hole(id_E,id_n).Alloy.yz=[];
                     TDF_sep_hole(id_E,id_n).Alloy.zx=[];
                     TDF_sep_hole(id_E,id_n).Alloy.zy=[];
                     TDF_sep_hole(id_E,id_n).Alloy.zz=[];

                     tauE_hole(id_E,id_n).x=[];
                     tauE_hole(id_E,id_n).y=[];
                     tauE_hole(id_E,id_n).z=[];

                     tauE_ph_hole(id_E,id_n).x=[];
                     tauE_ph_hole(id_E,id_n).y=[];
                     tauE_ph_hole(id_E,id_n).z=[];

                     tauE_sep_hole(id_E,id_n).ADP.x=[];
                     tauE_sep_hole(id_E,id_n).ADP.y=[];
                     tauE_sep_hole(id_E,id_n).ADP.z=[];
                     tauE_sep_hole(id_E,id_n).IVS.x=[];
                     tauE_sep_hole(id_E,id_n).IVS.y=[];
                     tauE_sep_hole(id_E,id_n).IVS.z=[];
                     tauE_sep_hole(id_E,id_n).ODP.x=[];
                     tauE_sep_hole(id_E,id_n).ODP.y=[];
                     tauE_sep_hole(id_E,id_n).ODP.z=[];
                     tauE_sep_hole(id_E,id_n).POP.x=[];
                     tauE_sep_hole(id_E,id_n).POP.y=[];
                     tauE_sep_hole(id_E,id_n).POP.z=[];
                     tauE_sep_hole(id_E,id_n).Alloy.x=[];
                     tauE_sep_hole(id_E,id_n).Alloy.y=[];
                     tauE_sep_hole(id_E,id_n).Alloy.z=[];

                     tauE_IIS_hole(id_E,id_n).x=[];
                     tauE_IIS_hole(id_E,id_n).y=[];
                     tauE_IIS_hole(id_E,id_n).z=[];

                     MFP_hole(id_E,id_n).x=[];
                     MFP_hole(id_E,id_n).y=[];
                     MFP_hole(id_E,id_n).z=[];

                     MFP_ph_hole(id_E,id_n).x=[];
                     MFP_ph_hole(id_E,id_n).y=[];
                     MFP_ph_hole(id_E,id_n).z=[];

                     MFP_sep_hole(id_E,id_n).ADP.x=[];
                     MFP_sep_hole(id_E,id_n).ADP.y=[];
                     MFP_sep_hole(id_E,id_n).ADP.z=[];
                     MFP_sep_hole(id_E,id_n).IVS.x=[];
                     MFP_sep_hole(id_E,id_n).IVS.y=[];
                     MFP_sep_hole(id_E,id_n).IVS.z=[];
                     MFP_sep_hole(id_E,id_n).ODP.x=[];
                     MFP_sep_hole(id_E,id_n).ODP.y=[];
                     MFP_sep_hole(id_E,id_n).ODP.z=[];
                     MFP_sep_hole(id_E,id_n).POP.x=[];
                     MFP_sep_hole(id_E,id_n).POP.y=[];
                     MFP_sep_hole(id_E,id_n).POP.z=[];
                     MFP_sep_hole(id_E,id_n).Alloy.x=[];
                     MFP_sep_hole(id_E,id_n).Alloy.y=[];
                     MFP_sep_hole(id_E,id_n).Alloy.z=[];                

                    end
                end

                clear id_E id_n
                clear DQ ans % for Matlab version before than 2017


                save('WorkSpace4_minority','-v7.3','-nocompression');
                WorkSpace4_minority = load('WorkSpace4_minority.mat');

                DQ = parallel.pool.DataQueue;
                afterEach(DQ, @disp);

                disp('computing the TDFs for the minority/valence bands '); disp(' ');
                disp('total number of energy values'); disp(' '); disp(nE); disp(' ')
                
                if strcmp(multivalley,'no')
                    parfor id_E = 1:nE
                        for id_n = 1:n_bands_transp

                        [ TDF_n_temp, TDF_ph_n_temp, TDF_sep_n_temp, MFP_n_temp, MFP_ph_n_temp, MFP_sep_n_temp, tauE_n_temp, tauE_ph_n_temp, tauE_sep_n_temp, tauE_IIS_n_temp] ...
                                = TDF_calc_ELECTRA_v0(id_E, id_n, WorkSpace4_minority );

                         TDF_hole(id_E,id_n).xx = TDF_n_temp.xx;
                         TDF_hole(id_E,id_n).xy = TDF_n_temp.xy;
                         TDF_hole(id_E,id_n).xz = TDF_n_temp.xz;
                         TDF_hole(id_E,id_n).yx = TDF_n_temp.yx;
                         TDF_hole(id_E,id_n).yy = TDF_n_temp.yy;
                         TDF_hole(id_E,id_n).yz = TDF_n_temp.yz;
                         TDF_hole(id_E,id_n).zx = TDF_n_temp.zx;
                         TDF_hole(id_E,id_n).zy = TDF_n_temp.zy;
                         TDF_hole(id_E,id_n).zz = TDF_n_temp.zz;

                         TDF_ph_hole(id_E,id_n).xx = TDF_ph_n_temp.xx;
                         TDF_ph_hole(id_E,id_n).xy = TDF_ph_n_temp.xy;
                         TDF_ph_hole(id_E,id_n).xz = TDF_ph_n_temp.xz;
                         TDF_ph_hole(id_E,id_n).yx = TDF_ph_n_temp.yx;
                         TDF_ph_hole(id_E,id_n).yy = TDF_ph_n_temp.yy;
                         TDF_ph_hole(id_E,id_n).yz = TDF_ph_n_temp.yz;
                         TDF_ph_hole(id_E,id_n).zx = TDF_ph_n_temp.zx;
                         TDF_ph_hole(id_E,id_n).zy = TDF_ph_n_temp.zy;
                         TDF_ph_hole(id_E,id_n).zz = TDF_ph_n_temp.zz;

                         TDF_sep_hole(id_E,id_n).ADP.xx = TDF_sep_n_temp.ADP.xx;
                         TDF_sep_hole(id_E,id_n).ADP.xy = TDF_sep_n_temp.ADP.xy;
                         TDF_sep_hole(id_E,id_n).ADP.xz = TDF_sep_n_temp.ADP.xz;
                         TDF_sep_hole(id_E,id_n).ADP.yx = TDF_sep_n_temp.ADP.yx;
                         TDF_sep_hole(id_E,id_n).ADP.yy = TDF_sep_n_temp.ADP.yy;
                         TDF_sep_hole(id_E,id_n).ADP.yz = TDF_sep_n_temp.ADP.yz;
                         TDF_sep_hole(id_E,id_n).ADP.zx = TDF_sep_n_temp.ADP.zx;
                         TDF_sep_hole(id_E,id_n).ADP.zy = TDF_sep_n_temp.ADP.zy;
                         TDF_sep_hole(id_E,id_n).ADP.zz = TDF_sep_n_temp.ADP.zz;
                         TDF_sep_hole(id_E,id_n).ODP.xx = TDF_sep_n_temp.ODP.xx;
                         TDF_sep_hole(id_E,id_n).ODP.xy = TDF_sep_n_temp.ODP.xy;
                         TDF_sep_hole(id_E,id_n).ODP.xz = TDF_sep_n_temp.ODP.xz;
                         TDF_sep_hole(id_E,id_n).ODP.yx = TDF_sep_n_temp.ODP.yx;
                         TDF_sep_hole(id_E,id_n).ODP.yy = TDF_sep_n_temp.ODP.yy;
                         TDF_sep_hole(id_E,id_n).ODP.yz = TDF_sep_n_temp.ODP.yz;
                         TDF_sep_hole(id_E,id_n).ODP.zx = TDF_sep_n_temp.ODP.zx;
                         TDF_sep_hole(id_E,id_n).ODP.zy = TDF_sep_n_temp.ODP.zy;
                         TDF_sep_hole(id_E,id_n).ODP.zz = TDF_sep_n_temp.ODP.zz;
                         TDF_sep_hole(id_E,id_n).POP.xx = TDF_sep_n_temp.POP.xx;
                         TDF_sep_hole(id_E,id_n).POP.xy = TDF_sep_n_temp.POP.xy;
                         TDF_sep_hole(id_E,id_n).POP.xz = TDF_sep_n_temp.POP.xz;
                         TDF_sep_hole(id_E,id_n).POP.yx = TDF_sep_n_temp.POP.yx;
                         TDF_sep_hole(id_E,id_n).POP.yy = TDF_sep_n_temp.POP.yy;
                         TDF_sep_hole(id_E,id_n).POP.yz = TDF_sep_n_temp.POP.yz;
                         TDF_sep_hole(id_E,id_n).POP.zx = TDF_sep_n_temp.POP.zx;
                         TDF_sep_hole(id_E,id_n).POP.zy = TDF_sep_n_temp.POP.zy;
                         TDF_sep_hole(id_E,id_n).POP.zz = TDF_sep_n_temp.POP.zz;
                         TDF_sep_hole(id_E,id_n).IVS.xx = TDF_sep_n_temp.IVS.xx;
                         TDF_sep_hole(id_E,id_n).IVS.xy = TDF_sep_n_temp.IVS.xy;
                         TDF_sep_hole(id_E,id_n).IVS.xz = TDF_sep_n_temp.IVS.xz;
                         TDF_sep_hole(id_E,id_n).IVS.yx = TDF_sep_n_temp.IVS.yx;
                         TDF_sep_hole(id_E,id_n).IVS.yy = TDF_sep_n_temp.IVS.yy;
                         TDF_sep_hole(id_E,id_n).IVS.yz = TDF_sep_n_temp.IVS.yz;
                         TDF_sep_hole(id_E,id_n).IVS.zx = TDF_sep_n_temp.IVS.zx;
                         TDF_sep_hole(id_E,id_n).IVS.zy = TDF_sep_n_temp.IVS.zy;
                         TDF_sep_hole(id_E,id_n).IVS.zz = TDF_sep_n_temp.IVS.zz;
                         TDF_sep_hole(id_E,id_n).Alloy.xx = TDF_sep_n_temp.Alloy.xx;
                         TDF_sep_hole(id_E,id_n).Alloy.xy = TDF_sep_n_temp.Alloy.xy;
                         TDF_sep_hole(id_E,id_n).Alloy.xz = TDF_sep_n_temp.Alloy.xz;
                         TDF_sep_hole(id_E,id_n).Alloy.yx = TDF_sep_n_temp.Alloy.yx;
                         TDF_sep_hole(id_E,id_n).Alloy.yy = TDF_sep_n_temp.Alloy.yy;
                         TDF_sep_hole(id_E,id_n).Alloy.yz = TDF_sep_n_temp.Alloy.yz;
                         TDF_sep_hole(id_E,id_n).Alloy.zx = TDF_sep_n_temp.Alloy.zx;
                         TDF_sep_hole(id_E,id_n).Alloy.zy = TDF_sep_n_temp.Alloy.zy;
                         TDF_sep_hole(id_E,id_n).Alloy.zz = TDF_sep_n_temp.Alloy.zz;


                         tauE_hole(id_E,id_n).x = tauE_n_temp.x;
                         tauE_hole(id_E,id_n).y = tauE_n_temp.y;
                         tauE_hole(id_E,id_n).z = tauE_n_temp.z;

                         tauE_ph_hole(id_E,id_n).x = tauE_ph_n_temp.x;
                         tauE_ph_hole(id_E,id_n).y = tauE_ph_n_temp.y;
                         tauE_ph_hole(id_E,id_n).z = tauE_ph_n_temp.z;

                         tauE_sep_hole(id_E,id_n) = tauE_sep_n_temp ;

                         tauE_IIS_hole(id_E,id_n).x = tauE_IIS_n_temp.x;
                         tauE_IIS_hole(id_E,id_n).y = tauE_IIS_n_temp.y;
                         tauE_IIS_hole(id_E,id_n).z = tauE_IIS_n_temp.z;

                         MFP_hole(id_E,id_n).x = MFP_n_temp.x;
                         MFP_hole(id_E,id_n).y = MFP_n_temp.y;
                         MFP_hole(id_E,id_n).z = MFP_n_temp.z;

                         MFP_ph_hole(id_E,id_n).x = MFP_ph_n_temp.x;
                         MFP_ph_hole(id_E,id_n).y = MFP_ph_n_temp.y;
                         MFP_ph_hole(id_E,id_n).z = MFP_ph_n_temp.z;

                         MFP_sep_hole(id_E,id_n) = MFP_sep_n_temp ;


                        end
                        send(DQ,id_E);
                    end

                    TDF_n_temp_hole = TDF_hole;
                    % re-shuffling the above struct file in the final form
                    [TDF_hole, TDF_n_hole, TDF_ph_hole, TDF_ph_n_hole, TDF_sep_hole, TDF_sep_n_hole, MFP_hole, MFP_n_hole, MFP_ph_hole, MFP_ph_n_hole, MFP_sep_hole, MFP_sep_n_hole, tauE_hole, tauE_n_hole, tauE_ph_hole, tauE_ph_n_hole, tauE_sep_hole, tauE_sep_n_hole, tauE_IIS_hole, tauE_IIS_n_hole] ...
                        = TDF_reshuffling_ELECTRA(TDF_n_temp_hole, TDF_ph_hole, TDF_sep_hole, MFP_hole, MFP_ph_hole, MFP_sep_hole, tauE_hole, tauE_ph_hole, tauE_sep_hole, tauE_IIS_hole, E_array, n_bands_transp, EF_matrix, T_array, IIS, POP, screening_POP, sd) ;

                  
                elseif strcmp(multivalley,'yes')
                    parfor id_E = 1:nE
                        for id_n = 1:n_bands_transp

                        [ TDF_n_temp, TDF_ph_n_temp, TDF_sep_n_temp, MFP_n_temp, MFP_ph_n_temp, MFP_sep_n_temp, tauE_n_temp, tauE_ph_n_temp, tauE_sep_n_temp, tauE_IIS_n_temp] ...
                                = TDF_calc_multivalley_ELECTRA_v0(id_E, id_n, WorkSpace4_minority );

                         TDF_hole(id_E,id_n).xx = TDF_n_temp.xx;
                         TDF_hole(id_E,id_n).xy = TDF_n_temp.xy;
                         TDF_hole(id_E,id_n).xz = TDF_n_temp.xz;
                         TDF_hole(id_E,id_n).yx = TDF_n_temp.yx;
                         TDF_hole(id_E,id_n).yy = TDF_n_temp.yy;
                         TDF_hole(id_E,id_n).yz = TDF_n_temp.yz;
                         TDF_hole(id_E,id_n).zx = TDF_n_temp.zx;
                         TDF_hole(id_E,id_n).zy = TDF_n_temp.zy;
                         TDF_hole(id_E,id_n).zz = TDF_n_temp.zz;

                         TDF_ph_hole(id_E,id_n).xx = TDF_ph_n_temp.xx;
                         TDF_ph_hole(id_E,id_n).xy = TDF_ph_n_temp.xy;
                         TDF_ph_hole(id_E,id_n).xz = TDF_ph_n_temp.xz;
                         TDF_ph_hole(id_E,id_n).yx = TDF_ph_n_temp.yx;
                         TDF_ph_hole(id_E,id_n).yy = TDF_ph_n_temp.yy;
                         TDF_ph_hole(id_E,id_n).yz = TDF_ph_n_temp.yz;
                         TDF_ph_hole(id_E,id_n).zx = TDF_ph_n_temp.zx;
                         TDF_ph_hole(id_E,id_n).zy = TDF_ph_n_temp.zy;
                         TDF_ph_hole(id_E,id_n).zz = TDF_ph_n_temp.zz;

                         TDF_sep_hole(id_E,id_n).ADP.xx = TDF_sep_n_temp.ADP.xx;
                         TDF_sep_hole(id_E,id_n).ADP.xy = TDF_sep_n_temp.ADP.xy;
                         TDF_sep_hole(id_E,id_n).ADP.xz = TDF_sep_n_temp.ADP.xz;
                         TDF_sep_hole(id_E,id_n).ADP.yx = TDF_sep_n_temp.ADP.yx;
                         TDF_sep_hole(id_E,id_n).ADP.yy = TDF_sep_n_temp.ADP.yy;
                         TDF_sep_hole(id_E,id_n).ADP.yz = TDF_sep_n_temp.ADP.yz;
                         TDF_sep_hole(id_E,id_n).ADP.zx = TDF_sep_n_temp.ADP.zx;
                         TDF_sep_hole(id_E,id_n).ADP.zy = TDF_sep_n_temp.ADP.zy;
                         TDF_sep_hole(id_E,id_n).ADP.zz = TDF_sep_n_temp.ADP.zz;
                         TDF_sep_hole(id_E,id_n).ODP.xx = TDF_sep_n_temp.ODP.xx;
                         TDF_sep_hole(id_E,id_n).ODP.xy = TDF_sep_n_temp.ODP.xy;
                         TDF_sep_hole(id_E,id_n).ODP.xz = TDF_sep_n_temp.ODP.xz;
                         TDF_sep_hole(id_E,id_n).ODP.yx = TDF_sep_n_temp.ODP.yx;
                         TDF_sep_hole(id_E,id_n).ODP.yy = TDF_sep_n_temp.ODP.yy;
                         TDF_sep_hole(id_E,id_n).ODP.yz = TDF_sep_n_temp.ODP.yz;
                         TDF_sep_hole(id_E,id_n).ODP.zx = TDF_sep_n_temp.ODP.zx;
                         TDF_sep_hole(id_E,id_n).ODP.zy = TDF_sep_n_temp.ODP.zy;
                         TDF_sep_hole(id_E,id_n).ODP.zz = TDF_sep_n_temp.ODP.zz;
                         TDF_sep_hole(id_E,id_n).POP.xx = TDF_sep_n_temp.POP.xx;
                         TDF_sep_hole(id_E,id_n).POP.xy = TDF_sep_n_temp.POP.xy;
                         TDF_sep_hole(id_E,id_n).POP.xz = TDF_sep_n_temp.POP.xz;
                         TDF_sep_hole(id_E,id_n).POP.yx = TDF_sep_n_temp.POP.yx;
                         TDF_sep_hole(id_E,id_n).POP.yy = TDF_sep_n_temp.POP.yy;
                         TDF_sep_hole(id_E,id_n).POP.yz = TDF_sep_n_temp.POP.yz;
                         TDF_sep_hole(id_E,id_n).POP.zx = TDF_sep_n_temp.POP.zx;
                         TDF_sep_hole(id_E,id_n).POP.zy = TDF_sep_n_temp.POP.zy;
                         TDF_sep_hole(id_E,id_n).POP.zz = TDF_sep_n_temp.POP.zz;
                         TDF_sep_hole(id_E,id_n).IVS.xx = TDF_sep_n_temp.IVS.xx;
                         TDF_sep_hole(id_E,id_n).IVS.xy = TDF_sep_n_temp.IVS.xy;
                         TDF_sep_hole(id_E,id_n).IVS.xz = TDF_sep_n_temp.IVS.xz;
                         TDF_sep_hole(id_E,id_n).IVS.yx = TDF_sep_n_temp.IVS.yx;
                         TDF_sep_hole(id_E,id_n).IVS.yy = TDF_sep_n_temp.IVS.yy;
                         TDF_sep_hole(id_E,id_n).IVS.yz = TDF_sep_n_temp.IVS.yz;
                         TDF_sep_hole(id_E,id_n).IVS.zx = TDF_sep_n_temp.IVS.zx;
                         TDF_sep_hole(id_E,id_n).IVS.zy = TDF_sep_n_temp.IVS.zy;
                         TDF_sep_hole(id_E,id_n).IVS.zz = TDF_sep_n_temp.IVS.zz;
                         TDF_sep_hole(id_E,id_n).Alloy.xx = TDF_sep_n_temp.Alloy.xx;
                         TDF_sep_hole(id_E,id_n).Alloy.xy = TDF_sep_n_temp.Alloy.xy;
                         TDF_sep_hole(id_E,id_n).Alloy.xz = TDF_sep_n_temp.Alloy.xz;
                         TDF_sep_hole(id_E,id_n).Alloy.yx = TDF_sep_n_temp.Alloy.yx;
                         TDF_sep_hole(id_E,id_n).Alloy.yy = TDF_sep_n_temp.Alloy.yy;
                         TDF_sep_hole(id_E,id_n).Alloy.yz = TDF_sep_n_temp.Alloy.yz;
                         TDF_sep_hole(id_E,id_n).Alloy.zx = TDF_sep_n_temp.Alloy.zx;
                         TDF_sep_hole(id_E,id_n).Alloy.zy = TDF_sep_n_temp.Alloy.zy;
                         TDF_sep_hole(id_E,id_n).Alloy.zz = TDF_sep_n_temp.Alloy.zz;


                         tauE_hole(id_E,id_n).x = tauE_n_temp.x;
                         tauE_hole(id_E,id_n).y = tauE_n_temp.y;
                         tauE_hole(id_E,id_n).z = tauE_n_temp.z;

                         tauE_ph_hole(id_E,id_n).x = tauE_ph_n_temp.x;
                         tauE_ph_hole(id_E,id_n).y = tauE_ph_n_temp.y;
                         tauE_ph_hole(id_E,id_n).z = tauE_ph_n_temp.z;

                         tauE_sep_hole(id_E,id_n) = tauE_sep_n_temp ;

                         tauE_IIS_hole(id_E,id_n).x = tauE_IIS_n_temp.x;
                         tauE_IIS_hole(id_E,id_n).y = tauE_IIS_n_temp.y;
                         tauE_IIS_hole(id_E,id_n).z = tauE_IIS_n_temp.z;

                         MFP_hole(id_E,id_n).x = MFP_n_temp.x;
                         MFP_hole(id_E,id_n).y = MFP_n_temp.y;
                         MFP_hole(id_E,id_n).z = MFP_n_temp.z;

                         MFP_ph_hole(id_E,id_n).x = MFP_ph_n_temp.x;
                         MFP_ph_hole(id_E,id_n).y = MFP_ph_n_temp.y;
                         MFP_ph_hole(id_E,id_n).z = MFP_ph_n_temp.z;

                        MFP_sep_hole(id_E,id_n) = MFP_sep_n_temp ;


                        end
                        send(DQ,id_E);
                    end

                    TDF_n_temp_hole = TDF_hole;
                    % re-shuffling the above struct file in the final form
                    [TDF_hole, TDF_n_hole, TDF_ph_hole, TDF_ph_n_hole, TDF_sep_hole, TDF_sep_n_hole, MFP_hole, MFP_n_hole, MFP_ph_hole, MFP_ph_n_hole, MFP_sep_hole, MFP_sep_n_hole, tauE_hole, tauE_n_hole, tauE_ph_hole, tauE_ph_n_hole, tauE_sep_hole, tauE_sep_n_hole, tauE_IIS_hole, tauE_IIS_n_hole] ...
                        = TDF_reshuffling_ELECTRA(TDF_n_temp_hole, TDF_ph_hole, TDF_sep_hole, MFP_hole, MFP_ph_hole, MFP_sep_hole, tauE_hole, tauE_ph_hole, tauE_sep_hole, tauE_IIS_hole, E_array, n_bands_transp, EF_matrix, T_array, IIS, POP, screening_POP, sd) ;

                    
                    
                end
            
            
            end 
            
            toc
            clear DQ ans
            
            
            if strcmp(save_RTstruct,'yes')         
                disp('composing the TDFs '); disp(' ');
                % struct data type

                [TDF_hole, TDF_n_hole, TDF_ph_hole, TDF_ph_n_hole, TDF_sep_hole, TDF_sep_n_hole, MFP_hole, MFP_n_hole, MFP_ph_hole, MFP_ph_n_hole, MFP_sep_hole, MFP_sep_n_hole, tauE_hole, tauE_n_hole, tauE_ph_hole, tauE_ph_n_hole, tauE_sep_hole, tauE_sep_n_hole, tauE_IIS_hole, tauE_IIS_n_hole] = ...
                    TDF_composition_ELECTRA(WorkSpace4_minority, taus, taus_matth, taus_IIS, taus_POP) ;        
               
            end
            
            if strcmp(constant_tau,'yes')
%                 TDF_constant_mfp_bipolar_minority % CRT CMFP
                [TDF_hole_CMFP, TDF_n_hole_CMFP, tauE_hole_CMFP, tauE_n_hole_CMFP] = ...
                    TDF_CMFP_ELECTRA(WorkSpace4_minority) ;
            end
            
            
            
            
            % SWAP BACK the Fermi levels and the bandstructure
            EF_matrix = -EF_matrix;
            Ek = -Ek;
            % SWAP BACK the carriers
            if strcmp(carriers,'holes')
                carriers = 'electrons';
            elseif strcmp(carriers,'electrons')
                carriers = 'holes';
            end
            
            
            % Definition of the variables to compose unique E_dependent
            % quantities
            [~,relative_pos_minority_band_edge] = min( abs(E_array_minority - minority_band_edge));
            [~,relative_pos_majority_band_edge] = min( abs(E_array_majority));
            E_array_majority_part = E_array_majority(relative_pos_majority_band_edge:size(E_array_majority,2)) ;
            E_array_minority_part = flip( -E_array_minority(relative_pos_minority_band_edge:size(E_array_minority,2) ) );
            bandgap_points = floor(abs(2*midgap)/Estep);
            if min(E_array_majority_part) > max(E_array_minority_part) % normal band gap
                E_array_bandgap_part = (E_array_minority_part(size(E_array_minority_part,2)) + Estep) : (abs(2*midgap) - 2*Estep ) / bandgap_points : (E_array_majority_part(1) - Estep);
                E_array = unique( [E_array_minority_part,E_array_bandgap_part,E_array_majority_part] );
            elseif min(E_array_majority_part) == max(E_array_minority_part) % gapless
                E_array_bandgap_part = [];
                E_array = unique( [E_array_minority_part,E_array_bandgap_part,E_array_majority_part] );
            else                                                       % negative gap
                E_array = -max(E_array_minority):Estep:Emax_majority;
            end
            
            
            % Composition of the unique E-dependent quantities
            % this takes the _majority and _minority TDF and others
            % and compose unique arrays spanning the energy 
            % -Emax_minority:Estep:Emax_majority 
            % in order to have a comprehensive integral in energy
      
           
            [ TDF, TDF_ph, TDF_sep, MFP, MFP_ph, MFP_sep, tauE, tauE_ph, tauE_sep, tauE_IIS, DOS_tot, V_tot ] = ...
                TDF_bipolar_composition_ELECTRA_v0( ...
                TDF_electron, TDF_ph_electron, TDF_sep_electron, ...
                MFP_electron, MFP_ph_electron, MFP_sep_electron, ...
                tauE_electron, tauE_ph_electron, tauE_sep_electron, tauE_IIS_electron, ...
                TDF_hole, TDF_ph_hole, TDF_sep_hole, ...
                MFP_hole, MFP_ph_hole, MFP_sep_hole, ...
                tauE_hole, tauE_ph_hole, tauE_sep_hole, tauE_IIS_hole, ...
                E_array, E_array_majority, E_array_minority, ...
                DOS_tot_majority, DOS_tot_minority, ...
                V_tot_majority, V_tot_minority, ...
                EF_matrix, minority_band_edge, WorkSpace4 ) ;
            
            
            
            disp('integrating the TDFs '); disp(' ');
            tic
            % Integration of the TDFs
            [sigma, sigma_ph, sigma_sep, S, S_ph, S_sep, PF, PF_ph, PF_sep, ke, ke_ph, ke_sep, mu, mu_ph, mu_sep, n_carrier, n_carrier_ph, EF_matrix_ph, N_imp_matrix_ph] = ...
            TDF_integration_ELECTRA(E_array, T_array, TDF, TDF_ph, TDF_sep, EF_matrix, DOS_tot, WorkSpace4) ;
            if strcmp(constant_tau,'yes')
                [ TDF_CMFP, tauE_CMFP, DOS_tot, V_tot ] =   ...
                    TDF_CMFP_bipolar_composition( ...
                TDF_electron_CMFP, TDF_hole_CMFP,...
                tauE_electron_CMFP, tauE_hole_CMFP, ...
                E_array_majority, E_array_minority, ...
                DOS_tot_majority, DOS_tot_minority, ...
                V_tot_majority, V_tot_minority, ...
                E_array, minority_band_edge) ;

            
                [sigma_CMFP, S_CMFP, PF_CMFP, ke_CMFP, mu_CMFP, n_carrier_CMFP ] = ...
                    TDF_CMFP_integration(E_array, T_array, TDF_CMFP, EF_matrix, DOS_tot, carriers) ;
            end
            toc
            
            
%         end
        
        
        
        
        if strcmp(save_RTstruct,'yes') && strcmp(constant_tau,'no')
            save('RelaxTimes_separate_minority','taus','-v7.3','-nocompression')
            save('RelaxTimes_matthiessen_minority','taus_matth','-v7.3','-nocompression')
            save('RelaxTimes_IIS_minority','taus_IIS','-v7.3','-nocompression')
        end
        clear taus taus_matth taus_IIS
        
        if strcmp(constant_tau,'yes')
            if strcmp(bipolar_one_carrier, 'no')
                E_array = E_array - EF_intrinsic ;
                EF_matrix = EF_matrix - EF_intrinsic ;
                save_filename=['TE_',material_name,'_constant_time_',scan_type,'_',carriers,'_full_bipolar.mat'];   % CRT CMFP
            elseif strcmp(bipolar_one_carrier, 'yes')
                save_filename=['TE_',material_name,'_constant_time_',scan_type,'_',carriers,'_bipolar.mat'];   % CRT CMFP
            end
        elseif strcmp(bipolar_one_carrier, 'yes')
                save_filename=['TE_',material_name,'_',scan_type,'_',carriers,'_bipolar.mat'];
        else
            if strcmp(bipolar_one_carrier, 'no')
                E_array = E_array - EF_intrinsic ;
                EF_matrix = EF_matrix - EF_intrinsic ;
                if strcmp(IIS,'yes')
                        EF_matrix_ph = EF_matrix_ph - EF_intrinsic ;
                end
            end
            save_filename=['TE_',material_name,'_',scan_type,'_full_bipolar.mat'];
        end
        clear DQ
        TDF_majority = TDF_electron; 
        TDF_n_majority = TDF_n_electron;
        TDF_ph_majority = TDF_ph_electron; 
        TDF_ph_n_majority = TDF_ph_n_electron;
        TDF_sep_majority = TDF_sep_electron; 
        TDF_sep_n_majority = TDF_sep_n_electron;
        MFP_majority = MFP_electron; 
        MFP_n_majority = MFP_n_electron;
        MFP_ph_majority = MFP_ph_electron; 
        MFP_ph_n_majority = MFP_ph_n_electron;
        MFP_sep_majority = MFP_sep_electron; 
        MFP_sep_n_majority = MFP_sep_n_electron;
        tauE_majority = tauE_electron; 
        tauE_n_majority = tauE_n_electron;
        tauE_ph_majority = tauE_ph_electron; 
        tauE_ph_n_majority = tauE_ph_n_electron;
        tauE_sep_majority = tauE_sep_electron; 
        tauE_sep_n_majority = tauE_sep_n_electron;
        TDF_minority = TDF_hole; 
        TDF_n_minority = TDF_n_hole;
        TDF_ph_minority = TDF_ph_hole; 
        TDF_ph_n_minority = TDF_ph_n_hole;
        TDF_sep_minority = TDF_sep_hole; 
        TDF_sep_n_minority = TDF_sep_n_hole;
        MFP_minority = MFP_hole; 
        MFP_n_minority = MFP_n_hole;
        MFP_ph_minority = MFP_ph_hole; 
        MFP_ph_n_minority = MFP_ph_n_hole;
        MFP_sep_minority = MFP_sep_hole; 
        MFP_sep_n_minority = MFP_sep_n_hole;
        tauE_minority = tauE_hole; 
        tauE_n_minority = tauE_n_hole;
        tauE_ph_minority = tauE_ph_hole; 
        tauE_ph_n_minority = tauE_ph_n_hole;
        tauE_sep_minority = tauE_sep_hole; 
        tauE_sep_n_minority = tauE_sep_n_hole;
        
        if strcmp(IIS, 'yes')
            save(save_filename, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
                'sigma', 'sigma_ph', 'sigma_sep', 'S', 'S_ph', 'S_sep', ...
                'PF', 'PF_ph', 'PF_sep', 'ke', 'ke_ph', 'ke_sep', ...
                'mu', 'mu_ph', 'mu_sep', 'n_carrier', 'n_carrier_ph', ...
                'EF_matrix', 'N_imp_matrix', 'EF_matrix_ph', 'N_imp_matrix_ph', ...
                'TDF', 'TDF_ph', 'TDF_sep', ...
                'MFP', 'MFP_ph', 'MFP_sep', ...
                'tauE', 'tauE_ph', 'tauE_sep', 'tauE_IIS', ...
                'state_ID', 'bands_transp', 'n_scatt', 'LD', 'q0', 'hbar', 'material_name', ...
                'valence_edge', 'midgap', 'EF_intrinsic', ...
                ...
                'E_array_majority', 'E_array_minority',...
                'DOS_tot_majority', 'DOS_tot_majority',  ...
                'V_tot_majority', 'V_tot_majority', ...
                'TDF_majority', 'TDF_minority', 'TDF_n_majority', 'TDF_n_minority', ...
                'TDF_ph_majority', 'TDF_ph_minority', 'TDF_ph_n_majority', 'TDF_ph_n_minority', ...
                'TDF_sep_majority', 'TDF_sep_minority', 'TDF_sep_n_majority',  'TDF_sep_n_minority', ...
                'MFP_majority', 'MFP_minority', 'MFP_n_majority', 'MFP_n_minority', ...
                'MFP_ph_majority', 'MFP_ph_minority', 'MFP_ph_n_majority', 'MFP_ph_n_minority', ...
                'MFP_sep_majority', 'MFP_sep_minority', 'MFP_sep_n_majority', 'MFP_sep_n_minority', ...
                'tauE_majority', 'tauE_minority', 'tauE_n_majority', 'tauE_n_minority',...
                'tauE_ph_majority', 'tauE_ph_minority', 'tauE_ph_n_majority', 'tauE_ph_n_minority',...
                'tauE_sep_majority', 'tauE_sep_minority', 'tauE_sep_n_majority', 'tauE_sep_n_minority' , ...
                 'ADP', 'ADP_IVS', 'ODP', 'IVS', 'IIS', 'POP', 'screening_POP', ...
                'IIS_interband_flag', 'Alloy', 'overlap_integrals_analytical',...
                'k_restriction', 'k_restriction_cutoff', 'multivalley'...
                )
        else
            save(save_filename, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
                'sigma', 'sigma_ph', 'sigma_sep', 'S', 'S_ph', 'S_sep', ...
                'PF', 'PF_ph', 'PF_sep', 'ke', 'ke_ph', 'ke_sep', ...
                'mu', 'mu_ph', 'mu_sep', 'n_carrier', 'n_carrier_ph', ...
                'EF_matrix', 'N_imp_matrix', 'EF_matrix_ph', 'N_imp_matrix_ph', ...
                'TDF', 'TDF_ph', 'TDF_sep', ...
                'MFP', 'MFP_ph', 'MFP_sep', ...
                'tauE', 'tauE_ph', 'tauE_sep', ...
                'state_ID', 'bands_transp', 'n_scatt',  'q0', 'hbar', 'material_name', ...
                'valence_edge', 'midgap', 'EF_intrinsic', ...
                ...
                'E_array_majority', 'E_array_minority',...
                'DOS_tot_majority', 'DOS_tot_majority',  ...
                'V_tot_majority', 'V_tot_majority', ...
                'TDF_majority', 'TDF_minority', 'TDF_n_majority', 'TDF_n_minority', ...
                'TDF_ph_majority', 'TDF_ph_minority', 'TDF_ph_n_majority', 'TDF_ph_n_minority', ...
                'TDF_sep_majority', 'TDF_sep_minority', 'TDF_sep_n_majority',  'TDF_sep_n_minority', ...
                'MFP_majority', 'MFP_minority', 'MFP_n_majority', 'MFP_n_minority', ...
                'MFP_ph_majority', 'MFP_ph_minority', 'MFP_ph_n_majority', 'MFP_ph_n_minority', ...
                'MFP_sep_majority', 'MFP_sep_minority', 'MFP_sep_n_majority', 'MFP_sep_n_minority', ...
                'tauE_majority', 'tauE_minority', 'tauE_n_majority', 'tauE_n_minority',...
                'tauE_ph_majority', 'tauE_ph_minority', 'tauE_ph_n_majority', 'tauE_ph_n_minority',...
                'tauE_sep_majority', 'tauE_sep_minority', 'tauE_sep_n_majority', 'tauE_sep_n_minority' , ...
                 'ADP', 'ADP_IVS', 'ODP', 'IVS', 'IIS', 'POP', 'screening_POP', ...
                'IIS_interband_flag', 'Alloy', 'overlap_integrals_analytical',...
                'k_restriction', 'k_restriction_cutoff', 'multivalley'...
                )
        end
        if strcmp(bipolar_one_carrier,'no')
            save_state_ID_name=['state_ID_',material_name,'_',scan_type,'_holes.mat'];
            save(save_state_ID_name,'state_ID','-v7.3','-nocompression')
        else
            save_state_ID_name=['state_ID_',material_name,'_',scan_type,'_minority.mat'];
            save(save_state_ID_name,'state_ID','-v7.3','-nocompression')
        end
        
    else
        disp('bipolar transport not setted')
    end

    % final instructions to compute and/or save CMFP calc. when CRT
    if strcmp(constant_tau,'yes') && strcmp(bipolar_transport,'no')
        [TDF_CMFP, TDF_n_CMFP, tauE_CMFP, tauE_n_CMFP] = ...
                    TDF_CMFP_ELECTRA(WorkSpace4) ;

        [sigma_CMFP, S_CMFP, PF_CMFP, ke_CMFP, mu_CMFP, n_carrier_CMFP ] = ...
                    TDF_CMFP_integration(E_array, T_array, TDF_CMFP, EF_matrix, DOS_tot, carriers) ;
                
        save_filename_mfp=['TE_',material_name,'_cmfp_',scan_type,'_',carriers,'.mat'];
        save(save_filename_mfp, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
            'sigma_CMFP', 'S_CMFP', 'PF_CMFP', 'ke_CMFP', ...
            'mu_CMFP', 'n_carrier_CMFP', 'EF_matrix', ...
            'TDF_CMFP', 'TDF_n_CMFP','tauE_CMFP', 'tauE_n_CMFP', ...
            'state_ID', 'bands_transp', 'q0', 'hbar', 'material_name')
        
                
    elseif strcmp(constant_tau,'yes') && strcmp(bipolar_transport,'yes')
        TDF_n_majority_CMFP = TDF_n_electron_CMFP;
        TDF_n_minority_CMFP = TDF_n_hole_CMFP;
        tauE_n_majority_CMFP = tauE_n_electron_CMFP;
        tauE_n_minority_CMFP = tauE_n_hole_CMFP;
        if strcmp(bipolar_one_carrier,'yes')
            save_filename_mfp=['TE_',material_name,'_cmfp_',scan_type,'_',carriers,'_bipolar.mat'];
        else            
            EF_matrix = EF_matrix-midgap ;
            save_filename_mfp=['TE_',material_name,'_cmfp_',scan_type,'_',carriers,'_bipolar.mat'];
        end
        
        save(save_filename_mfp, 'E_array', 'DOS', 'DOS_tot', 'V', 'V_tot','T_array',...
            'sigma_CMFP', 'S_CMFP', 'PF_CMFP', 'ke_CMFP', ...
            'mu_CMFP', 'n_carrier_CMFP', 'EF_matrix', ...
            'TDF_CMFP','tauE_CMFP', ...
            'TDF_n_majority_CMFP', 'TDF_n_minority_CMFP', ...
            'tauE_n_majority_CMFP', 'tauE_n_minority_CMFP', ...
            'state_ID', 'bands_transp', 'q0', 'hbar', 'material_name')    
    
    
    end

delete(gcp('nocreate'))

end