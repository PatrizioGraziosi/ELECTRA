
% The scattering parameters for Ge 


%----------- PHONONS ---------
rho_mass_density=5.32*1e-3/(1e-2)^3; % kg/m^3
% 
sl = 5.4e3;  % m/s , elasticity theory
st = 3.2e3;               % m/s , elasticity theory
us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975
% us_sound_vel=5.24*1e3;               % m/s


%------------ C.B. labels ----------
% They are labelled according to thier position for my clarity, L for L, G
% for Gamma, X for the Delta point close to X
valley_type = ['L','L','L','L','G','X','X','X','X','X','X'];
% ----------------------------------


% ELASTIC, INTRAVALLEY - ADP

% --------- electrons--------------
LL_D_adp_e = 10.5;  % 11 or 12
GG_D_adp_e = 5;
XX_D_adp_e = 9; % Jacoboni Reggiani 1979 say 9 eV, Fawcett Paige 1971 say 5.99

% ------------ holes---------------
D_adp_h = 4.6; % eV


% INELASTIC - INTRAVALLEY - ODP

% -------- electrons --------------
LL_D_odp_e = 5.5e10;
LL_hbar_w_odp_e = 0.0369;
LL_Z_f_odp_e = 1;

% --------------- holes ------------
D_odp_h = 9*1e10; % eV/m
hbar_w_odp_h = 0.037; % eV

% INELASTIC - INTERVALLY - IVS
% array of processes data
LL_D_ivs_e = 1.6e10;  % 1.6 or 3.0 in eV/m
LL_hbar_w_ivs_e = 0.0275;
LL_Z_f_ivs_e = 1;

LG_D_ivs_e = 2e10;
LG_hbar_w_ivs_e = 0.0275;
LG_Z_f_ivs_e = 1;
GL_D_ivs_e = LG_D_ivs_e; GL_hbar_w_ivs_e = LG_hbar_w_ivs_e; GL_Z_f_ivs_e = LG_Z_f_ivs_e;

LX_D_ivs_e = 5.5e10; % 5.5 or 4.0
LX_hbar_w_ivs_e = 0.0275;
LX_Z_f_ivs_e = 1;
XL_D_ivs_e = LX_D_ivs_e; XL_hbar_w_ivs_e = LX_hbar_w_ivs_e; XL_Z_f_ivs_e = LX_Z_f_ivs_e;

GX_D_ivs_e = 10e10;
GX_hbar_w_ivs_e = 0.0275;
GX_Z_f_ivs_e = 1;
XG_D_ivs_e = GX_D_ivs_e; XG_hbar_w_ivs_e = GX_hbar_w_ivs_e; XG_Z_f_ivs_e = GX_Z_f_ivs_e;

XX_D_ivs_e = [0.78e10, 9.4e10];  % in eV/m
XX_hbar_w_ivs_e = [0.0086, 0.0369];
XX_Z_f_ivs_e = [1, 1] ;

%--------------------------------------------------------

% for Coulomb scattering - screened
k_s=16;
k_inf = 16;


