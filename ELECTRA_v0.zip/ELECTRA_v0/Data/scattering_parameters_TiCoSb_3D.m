% The scattering parameters 

% RELEVANT SCATTERING for TiCoSb valence band
% ADP_IVS (both intra- and inter-valley) and ODP_Npolar (both intra- and
% inter-valley)

%----------- PHONONS ---------
rho_mass_density=   7.42*1e-3/(1e-2)^3; % kg/m^3   materialsproject.org/materials/mp-5967/
K_bulk_modulus = 142e9; % Pa
G_shear_modulus = 76e9; % Pa
sl = sqrt((K_bulk_modulus+4/3*G_shear_modulus)/rho_mass_density);  % m/s , elasticity theory
st = sqrt(G_shear_modulus/rho_mass_density);               % m/s , elasticity theory
us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975
% experimental sl = 5.69e3; st = 3.23e3;               % m/s     from
% Materials Transactions, Vol. 47, No. 6 (2006) pp. 1445,
% www.jstage.jst.go.jp/article/matertrans/47/6/47_6_1445/_pdf, very very
% close to the computed ones

% ------- for holes ------------------
D_adp_h=0.5; % eV, DOI: 10.1038/s41467-018-03866-w
% 
D_odp_h= 2.20e10; % eV/m, DOI: 10.1038/s41467-018-03866-w, multiplied by 1/5 of theBZ



% ------- for electrons ------------------

D_adp_e=1; % eV, DOI: 10.1038/s41467-018-03866-w

D_odp_e= 1.75e10; % eV/m, DOI: 10.1038/s41467-018-03866-w, multiplied by 1/5 of theBZ


hbar_w_odp= 0.036 ; %eV, materialsproject.org/materials/mp-5967/  from the centre of the LO  phonons DOS
Delta_Efi_odp=0;
Z_f_adp=1; % number of final available valleys
Z_f_odp=1; % to be defined as a row for every scattering mechanism, in any row an element for each available band

hbar_w_pop=0.038; % eV, materialsproject.org/materials/mp-5967/  value in Gamma

% ------- Coulomb scattering - screened  -------
k_s=19.09; % from Zhou (DOI: 10.1038/s41467-018-03866-w) private communication
k_inf=5; %  F.G. Aliev et al. Zh. Eksp. Teor. Fiz. 47 (t988) t5l
%LD=sqrt(eps_0*(eps_wire/eps_0)*kB*T/q0^2); % still need to divide by n0 in the sqrt



