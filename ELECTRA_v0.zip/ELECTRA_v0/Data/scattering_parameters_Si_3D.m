% The scattering parameters for Silicon - Jacoboni mostly...

% RELEVANT SCATTERING for Si conduction band
% ADP (intravalley) and IVS


%----------- PHONONS ---------
rho_mass_density=2.329*1e-3/(1e-2)^3; % kg/m^3
% us_sound_vel=9.04*1e3;               % m/s
sl=9.041e3;                % m/s
st=5.34*1e3;               % m/s
us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975


%------- for electrons ---------------
% ELASTIC - ADP
% D_adp_e=[9 9 9];                      % eV - NEED 3 because there are 3 valleys....each can have its own element, as for SRS
% D_adp_e=[14.6 14.6 14.6];             % from Fischetti
%D_adp_e=[5.39 5.39 5.39];             % test
% D_adp_e=[9.5 9.5 9.5];   
D_adp_e=9; % in eV,                                   % from table 2.1
                                                        % Lundstrom's book

% array of processes data: g, g, f, f, g, f processes
D_ivs=[0.5e10,0.8e10,0.15e10,3.4e10,3e10,4e10]; % TA, LA, TA, LA, LO, TO

hbar_w_ivs=[0.012,0.018,0.018,0.043,0.060,0.054]; % TA, LA, TA, LA, LO, TO

% Delta_Efi_ivs=[0,0,0,0,0,0]; % TA, LA, TA, LA, LO, TO

Z_f_ivs=[1,1,4,4,1,4]; % number of final available valleys, g, g, f, f, g, f

%X-L intervalley is ignored as L valleys are 1 eV above (fine for TE)
%--------------------------------------------------------


%-------- for holes ------------------
D_adp_h=5.39; %5;                            % eV
Do_if_h=13.24e10; %6e10;                         % eV/m % Fischetti '96 - JAP 80, 2234, 1996
hbar_w_if_h=0.062;                    % eV 
%--------------------------------------------------------


% for Coulomb scattering - screened
k_s = 11.7;
k_inf = 12; % Not used for Silicon but the code requires it to be enetered



