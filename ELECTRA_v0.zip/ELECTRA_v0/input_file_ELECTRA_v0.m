% INPUT file for main_VOMBATO code


% 1) GENERAL SETTINGS
material_name='TiNiSn';
dimensionality='3D'; % 1D, 2D, 3D

scan_type='kScan'; % kScan or DT . This is the way the k(E) is extracted
                   % kScan is the fast one

k_units_SI='yes'; % in 1/m      TE half Heuslers right now
k_units_pi_a='no'; % standard for numerically built bands liek Si, GaAs, etc. 

spin_resolved = 'no';




% 2) SCATTERING MECHANISMS
constant_tau = 'no'; % constant relax. time approx. (CRTA)
tau_const = 1e-14; % value of the scattering time in the CRTA

% scattering details
% go through them CAREFULLY
multivalley = 'no'; % different types of valleys with different Deformation Potentials
                  % if yes, the valleys shall be labelled in the scattering
                  % parameters file like A, B, etc. ...

ADP = 'no'; % Acoustic Deformation Potential, INTRAvalley
ADP_IVS = 'yes';  % INTRA- and INTER- valley
k_restriction = 'no'; % only for the ADP_IVS TO BE EXTENDED WHEN VALIDATED
k_restriction_cutoff = 0.2; % Portion of the BZ to be considered

IVS = 'no'; % intervalley scattering

ODP = 'yes'; % Optical deformation potential

POP = 'no'; % polar optical phonon, constan freq., approx.
screening_POP = 'no'; % this is not necessary and makes the code much slower

IIS = 'yes'; % this flag makes the IIS calc. musch less RAM consuming but more time consuming
IIS_interband_flag = 'yes';

Alloy = 'no';

overlap_integrals_analytical = 'no'; 


save_RTstruct = 'no';




% 3) TRANSPORT CONDITIONS

 % 3.1) FERMI LEVELS AND TEMPERATURES
T_array = 300 :150: 900; % in K
EF_array = [-0.2,-0.1,-0.06:0.02:0.14,0.2];  % in eV
% Fermi array is in respect to the band edge that will be set to zero, 
% negative values mean Fermi into the gap, positive, into the band (degen.)
Fermi_shift_flag = 'yes';
Estep = 0.002 ; % energy step in eV, 2 meV is largely sufficient thanks to the trapezoidal integration of the TDF

 % 3.2) CARRIERS AND ENERGY CONSTRAINS
carriers = 'electrons'; % 'holes' or 'electrons'

bipolar_transport = 'yes';

bipolar_one_carrier_only = 'no' ;

change_band_gap = 'no' ;
new_band_gap = 1 ; % in eV

metal = 'no'; % proper metal with Fermi in the bands free carriers without impurities




% 4) PARALLELIZATION instructions
type_of_parallelization = 'local'; % 'local' for one node only, 'Generic' for a generic multinode operation, 'MATLAB Parallel Cloud' for using the Matlab cloud
max_number_of_cpu = 6 ; % maximum number of cpu


% --------------- end of the input instructions --------------------------
% ------------------------------------------------------------------------



bipolar_one_carrier = bipolar_one_carrier_only ;
if strcmp(bipolar_one_carrier_only, 'no' ) && strcmp(bipolar_transport,'yes') && strcmp(carriers,'holes')
    carriers = 'electrons';
    disp('carrier corrected as in this setting the majority always refers to the conduction bands')
end
% for future releases
WF_provided='no'; % for the calculations of the overlap integral, at first, it can be approximated to a 1D array with the dimensions of the number of the bands, a more refined version in the future can be a n_band * n_band matrix with the overlap intagrals between the two bands, generally, if possible...
BZ_factor=1; % inverse of the part of the BZ that is explored
BZ_reduction='no';
semimetal = 'no'; % Fermi in the bands (no transport band gap like Tin) but is doped with impurities - 
% findvalleys = 'no'; % to find the local minima (valleys) in the same band, not yet implemented
% extended_IIS = 'no'; % faster but requires at least 30-40 Gb of available RAM
% if strcmp(IIS,'yes') && strcmp(extended_IIS,'yes') % you cannot run both, they would overwrite each other
%     disp('You have selected two mutually exclusive approaches to IIS, not correct!');
%     stop
% end
ee='no';
Piezo='no';
SRS='no';
phonon_dispersions='no'; % is the phonon bandstructure given as well?
OPT_Npolar='no'; %  polar optic in low wave vector, constan freq., approx.
OPT_polar='no';
ACO='no';
phph='no';
Alloy_ph='no'; % lattice thermal conductivity scattering from mass differences

save Inputs
