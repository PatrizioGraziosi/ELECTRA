addpath('code_C\','-end');
disp('running the main function'); disp(' ');
main_ELECTRA_function_Linux
addpath('code_C\','-frozen');