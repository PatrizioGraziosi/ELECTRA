n_i = 1; % doping index inthe N_imp_matrix


% ----------------------------------------------------------------------- %
% ----------------------------------------------------------------------- %


Ex = [ 1  0  0 ]' ;

q0 = 1.6e-19; % in C

for iT = size(T_array,2):-1:1

    if max(size(T_array)) ~= 1

        sigma_tensor = [...
        sigma.xx(n_i,iT), sigma.xy(n_i,iT), sigma.xz(n_i,iT);...
        sigma.yx(n_i,iT), sigma.yy(n_i,iT), sigma.yz(n_i,iT);...
        sigma.zx(n_i,iT), sigma.zy(n_i,iT), sigma.zz(n_i,iT)] ;

        n_c = N_imp_matrix(n_i,iT);
        
    else % one T only
        sigma_tensor = [...
        sigma.xx(iT,n_i), sigma.xy(iT,n_i), sigma.xz(iT,n_i);...
        sigma.yx(iT,n_i), sigma.yy(iT,n_i), sigma.yz(iT,n_i);...
        sigma.zx(iT,n_i), sigma.zy(iT,n_i), sigma.zz(iT,n_i)] ;

        n_c = N_imp_matrix(iT,n_i);
    end

    

nq = (q0*n_c) ;

clear mu_r Th_r

for i_r = 2e6:-1:1

    E_r = rand(3,1)*2-1;

    J_r = sigma_tensor * E_r;

    mu_r(i_r) = norm(J_r) / norm(E_r) / nq;

    Th_r(i_r) = acos( dot(E_r,Ex)/norm(E_r) ) ;
end

% figure(89); hold on ; box on ;
% fig = plot(Th_r, mu_r*1e4,'.');
% set(fig,'linewidth',2,'MarkerSize',7);
% set(gca,'Fontsize',15,'LineWidth',1) ;
% xlabel( ' {\it\Theta_x} [rad] ');
% ylabel(' \mu_{r} [cm^2/V\cdots] ' );


mu_ave_eff = mean(mu_r);

disp(max(mu_r)*1e4)
disp(mu_ave_eff *1e4)

mu_r_T(iT) = mu_ave_eff;

end

figure(88); hold on ; box on ;
fig = plot(T_array, mu_r_T*1e4,'.-.');
set(fig,'linewidth',2.5341,'MarkerSize',40);
set(gca,'Fontsize',20,'LineWidth',1) ;
xlabel( ' T [K] ');
ylabel(' \mu_{r} [cm^2/V\cdots] ' );
