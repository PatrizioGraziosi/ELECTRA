% This script returns the electrical conductivity sigma, the mobility mu,
% the Seebeck coefficient S, in the ab plane of the unit cell, for a
% selected temperature and doping index
% starting from the TE coefficients computed by ELECTRA and the unit cell
% axes, contained in the txt file 'file_name', which can be extracted from
% QE or VASP calculation using the specific 'get' scripts in the same
% folder.

% The quantities are saved as sigma_a, sigma_b, sigma_c, S_a, S_b, S_c,
% mu_a, mu_b, mu_c, as matrixes where the first index runs over the Fermi
% levels and the second index runs over the temperatures

% ------ copyright Patrizio Graziosi 2024, patrizio.graziosi@cnr.it ----- %

file_name = 'A_matrix' ;   % txt file with the cell axes

var_plot = 'mu' ; % variable to plot, mu, sigma, S, PF
T_p = 300; % in K, temperature to which compute and plot the results
n_i = 2; % doping index, same as in the matrixes outputted by ELECTRA

phonons_only = 'no';


% ----------------------------------------------------------------------- %
% ----------------------------------------------------------------------- %


A = importdata([file_name,'.txt']) ;

[~,nT] = min(abs(T_array-T_p));


if max(size(T_array)) ~= 1 % more T values

    if strcmp(phonons_only,'yes')
            sigma_tensor = [...
            sigma_ph.xx(n_i,nT), sigma_ph.xy(n_i,nT), sigma_ph.xz(n_i,nT);...
            sigma_ph.yx(n_i,nT), sigma_ph.yy(n_i,nT), sigma_ph.yz(n_i,nT);...
            sigma_ph.zx(n_i,nT), sigma_ph.zy(n_i,nT), sigma_ph.zz(n_i,nT)] ;
    
            S_tenstor = [...
            S_ph.xx(n_i,nT), S_ph.xy(n_i,nT), S_ph.xz(n_i,nT);...
            S_ph.yx(n_i,nT), S_ph.yy(n_i,nT), S_ph.yz(n_i,nT);...
            S_ph.zx(n_i,nT), S_ph.zy(n_i,nT), S_ph.zz(n_i,nT)] ;

            n_c = N_imp_matrix_ph(n_i,nT);
    else
            sigma_tensor = [...
            sigma.xx(n_i,nT), sigma.xy(n_i,nT), sigma.xz(n_i,nT);...
            sigma.yx(n_i,nT), sigma.yy(n_i,nT), sigma.yz(n_i,nT);...
            sigma.zx(n_i,nT), sigma.zy(n_i,nT), sigma.zz(n_i,nT)] ;
    
            S_tensor = [...
            S.xx(n_i,nT), S.xy(n_i,nT), S.xz(n_i,nT);...
            S.yx(n_i,nT), S.yy(n_i,nT), S.yz(n_i,nT);...
            S.zx(n_i,nT), S.zy(n_i,nT), S.zz(n_i,nT)] ;

            n_c = N_imp_matrix(n_i,nT);
    end
else % one T value
    if strcmp(phonons_only,'yes')
            sigma_tensor = [...
            sigma_ph.xx(nT,n_i), sigma_ph.xy(nT,n_i), sigma_ph.xz(nT,n_i);...
            sigma_ph.yx(nT,n_i), sigma_ph.yy(nT,n_i), sigma_ph.yz(nT,n_i);...
            sigma_ph.zx(nT,n_i), sigma_ph.zy(nT,n_i), sigma_ph.zz(nT,n_i)] ;
    
            S_tenstor = [...
            S_ph.xx(nT,n_i), S_ph.xy(nT,n_i), S_ph.xz(nT,n_i);...
            S_ph.yx(nT,n_i), S_ph.yy(nT,n_i), S_ph.yz(nT,n_i);...
            S_ph.zx(nT,n_i), S_ph.zy(nT,n_i), S_ph.zz(nT,n_i)] ;

            n_c = N_imp_matrix_ph(nT,n_i);
    else
            sigma_tensor = [...
            sigma.xx(nT,n_i), sigma.xy(nT,n_i), sigma.xz(nT,n_i);...
            sigma.yx(nT,n_i), sigma.yy(nT,n_i), sigma.yz(nT,n_i);...
            sigma.zx(nT,n_i), sigma.zy(nT,n_i), sigma.zz(nT,n_i)] ;
    
            S_tensor = [...
            S.xx(nT,n_i), S.xy(nT,n_i), S.xz(nT,n_i);...
            S.yx(nT,n_i), S.yy(nT,n_i), S.yz(nT,n_i);...
            S.zx(nT,n_i), S.zy(nT,n_i), S.zz(nT,n_i)] ;

            n_c = N_imp_matrix(nT,n_i);
    end
end



Ex = [ 1  0  0 ]' ;

E_b = [0 1 0] / A;
E_c = [0 0 1] / A;
E_b = E_b/norm(E_b);
E_c = E_c/norm(E_c);
E_b = E_b';
E_c = E_c';
E_a = Ex' / A;   % Ex;
    E_a = E_a/norm(E_a);
    E_a = E_a';


q0 = 1.6e-19; % in C


nq = (q0*n_c) ;

clear mu_r Th_r

for i_r = 2e6:-1:1

    r = rand(3,1)*2-1;

    E_r = r(1)*E_a + r(2)*E_b + 0*E_c ;


    J_r = sigma_tensor * E_r;

    mu_r(i_r) = norm(J_r) / norm(E_r) / nq;
    sigma_r(i_r) = mu_r(i_r) * nq;

    JT_r = sigma_tensor.*S_tensor * E_r;
        
    S_r(i_r) = norm(JT_r) / norm(E_r) / sigma_r(i_r);


    Th_r(i_r) = atan2d(sign(dot(cross(E_r,Ex), [0 0 1]))*norm(cross(E_r,Ex)) ...
        , dot(E_r,Ex));
end
PF_r = sigma_r.*S_r.^2;


y_plot = eval([var_plot,'_r']);
if strcmp(var_plot,'mu')
    f_p = 1e4;
    y_l = ' \mu_{\itab} [cm^2/V\cdots] ';
elseif strcmp(var_plot,'sigma')
    f_p = 1;
    y_l = ' \sigma_{\itab} [S/m] ';
elseif strcmp(var_plot,'S')
    f_p = 1e6;
    y_l = ' S_{\itab} [\muV/K] ';
elseif strcmp(var_plot,'PF')
    f_p = 1e3;
    y_l = ' PF_{\itab} [mW/K\cdotm] ';
else
    disp('')
    disp('variable to be plotted wrongly setted')
    disp('')
end


figure(89); hold on ; box on ;
fig = plot(Th_r, y_plot*f_p,'.');
set(fig,'linewidth',2,'MarkerSize',7);
set(gca,'Fontsize',15,'LineWidth',1) ;
xlabel( ' {\it\Theta_a} [rad] ');
ylabel(y_l);

mu_ave_eff = mean(mu_r);

disp('average effective mobility')
disp(mu_ave_eff *1e4)
disp('mobility ratio')
disp(max(mu_r)/min(mu_r))

% mu_r_T(iT) = mu_ave_eff;

% end

% figure(89); hold on ; box on ;
% fig = plot(T_array, mu_r_T*1e4,'.-.');
% set(fig,'linewidth',2,'MarkerSize',7);
% set(gca,'Fontsize',15,'LineWidth',1) ;
% xlabel( ' T [K] ');
% ylabel(' \mu_{r} [cm^2/V\cdots] ' );
