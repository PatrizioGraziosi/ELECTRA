% This script returns the electrical conductivity sigma, the mobility mu,
% the Seebeck coefficient S, the power factor PF, along the a, b, and c 
% axes of the unit cell, starting from the TE coefficients computed by 
% ELECTRA and the unit cell axes, contained in the txt file 'file_name', 
% which can be extracted from QE or VASP calculation using the specific 
% 'get' scripts in the same folder.

% The quantities are saved as sigma_a, sigma_b, sigma_c, S_a, S_b, S_c,
% mu_a, mu_b, mu_c, PF_a, PF_b, PF_c, as matrixes where the first index 
% runs over the Fermi level and the second index runs over the temperature

% ------ copyright Patrizio Graziosi 2024, patrizio.graziosi@cnr.it ----- %


file_name = 'A_phBTBT_herringbone' ;   % txt file with the cell axes

phonons_only = 'no';



% ----------------------------------------------------------------------- %
% ----------------------------------------------------------------------- %


A = importdata([file_name,'.txt']) ;

E_a = [1 0 0] / A;
E_b = [0 1 0] / A;
E_c = [0 0 1] / A;

E_a = E_a/norm(E_a);
E_b = E_b/norm(E_b);
E_c = E_c/norm(E_c);
E_a = E_a';
E_b = E_b';
E_c = E_c';

if strcmp(phonons_only,'yes')
    EF_matrix_to_use = EF_matrix_ph;
    N_imp_matrix_to_use = N_imp_matrix_ph;
else
    EF_matrix_to_use = EF_matrix;
    N_imp_matrix_to_use = N_imp_matrix;
end


for iF = size(EF_matrix_to_use,1):-1:1
    for iT = max(size(T_array)):-1:1

        if strcmp(phonons_only,'yes')
            sigma_tensor = [...
            sigma_ph.xx(iF,iT), sigma_ph.xy(iF,iT), sigma_ph.xz(iF,iT);...
            sigma_ph.yx(iF,iT), sigma_ph.yy(iF,iT), sigma_ph.yz(iF,iT);...
            sigma_ph.zx(iF,iT), sigma_ph.zy(iF,iT), sigma_ph.zz(iF,iT)] ;

            S_tenstor = [...
            S_ph.xx(iF,iT), S_ph.xy(iF,iT), S_ph.xz(iF,iT);...
            S_ph.yx(iF,iT), S_ph.yy(iF,iT), S_ph.yz(iF,iT);...
            S_ph.zx(iF,iT), S_ph.zy(iF,iT), S_ph.zz(iF,iT)] ;
        else
            sigma_tensor = [...
            sigma.xx(iF,iT), sigma.xy(iF,iT), sigma.xz(iF,iT);...
            sigma.yx(iF,iT), sigma.yy(iF,iT), sigma.yz(iF,iT);...
            sigma.zx(iF,iT), sigma.zy(iF,iT), sigma.zz(iF,iT)] ;

            S_tensor = [...
            S.xx(iF,iT), S.xy(iF,iT), S.xz(iF,iT);...
            S.yx(iF,iT), S.yy(iF,iT), S.yz(iF,iT);...
            S.zx(iF,iT), S.zy(iF,iT), S.zz(iF,iT)] ;
        end
    
        n_c = N_imp_matrix_to_use(iF,iT);
    
        nq = (q0*n_c) ;


        J_a = sigma_tensor * E_a;
    
        mu_a(iF,iT) = norm(J_a) / norm(E_a) / nq;
        sigma_a(iF,iT) = mu_a(iF,iT) * nq;

    
        J_b = sigma_tensor * E_b;
    
        mu_b(iF,iT) = norm(J_b) / norm(E_b) / nq;
        sigma_b(iF,iT) = mu_b(iF,iT) * nq;


        J_c = sigma_tensor * E_c;

        mu_c(iF,iT) = norm(J_c) / norm(E_c) / nq;
        sigma_c(iF,iT) = mu_c(iF,iT) * nq;

        
        
        % gradT parallel to the axis, normalized, as for the electric field
        JT_a = sigma_tensor.*S_tensor * E_a;

        S_a(iF,iT) = norm(JT_a) / norm(E_a) / sigma_a(iF,iT);

    
        JT_b = sigma_tensor.*S_tensor * E_b;
    
        S_b(iF,iT) = norm(JT_b) / norm(E_b) / sigma_b(iF,iT);
        

        JT_c = sigma_tensor.*S_tensor * E_c;

        S_c(iF,iT) = norm(JT_c) / norm(E_c) / sigma_c(iF,iT);


    end
end

PF_a = sigma_a.*S_a.^2;
PF_b = sigma_b.*S_b.^2;
PF_c = sigma_c.*S_c.^2;

 
% v_xx = eval([varname,'.xx']); v_xy = eval([varname,'.xy']); v_xz = eval([varname,'.xz']);
% v_yx = eval([varname,'.yx']); v_yy = eval([varname,'.yy']); v_yz = eval([varname,'.yz']);
% v_zx = eval([varname,'.zx']); v_zy = eval([varname,'.zy']); v_zz = eval([varname,'.zz']);