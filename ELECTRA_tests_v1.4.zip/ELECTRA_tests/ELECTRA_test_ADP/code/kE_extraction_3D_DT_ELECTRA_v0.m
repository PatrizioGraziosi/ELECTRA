% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %




function [state_ID_temp,DOS,V] = kE_extraction_3D_DT_ELECTRA_v0(id_E,n_band,E_array,bands_transp,Ek,kx_matrix,ky_matrix,kz_matrix,sd,BZ_factor)  %#codegen

%------------------- Initializations ---------------------------------
nkx=size(Ek,1); nky=size(Ek,2); nkz=size(Ek,3);
Etmp = E_array(id_E);
n = bands_transp(n_band); %the band index, that does not correponsd to the position in the bands_transp array, but in the E(k) matrix
hbar=(6.6261e-34)/(2*pi); % [J-sec]
q0=1.609e-19;             % [col]
%--------------------------------------------------------------------


% ---------------------- Declaration --------------------------------
kx_field =  [] ; % double.empty(1,0);
coder.varsize('kx_field');
ky_field =  [] ; % double.empty(1,0);
coder.varsize('ky_field');
kz_field =  [] ; % double.empty(1,0);
coder.varsize('kz_field');
knorm_field =  [] ; %  double.empty(1,0);
coder.varsize('knorm_field');

vx_field =  [] ; % double.empty(1,0);
coder.varsize('vx_field');
vy_field =  [] ; %  double.empty(1,0);
coder.varsize('vy_field');
vz_field =  [] ; %  double.empty(1,0);
coder.varsize('vz_field');
V_field =   [] ; % double.empty(1,0);
coder.varsize('V_field');

DOS_field =  [] ; % double.empty(1,0);
coder.varsize('DOS_field');

dkS_field =  [] ; % double.empty(1,0);
coder.varsize('dkS_field');

% -------------------------------------------------------------------


% construction of the matrix that contains the relative numeric indexes of
% vertexes of the the six tetrahedra to divide each 3D mesh element
P = [ 1     1     1
      1     1     2
      1     2     1
      1     2     2
      2     1     1
      2     1     2
      2     2     1
      2     2     2 ] ;
% connettivity matrix between vertexes DT matrix
DT_matrix = [   2     1     3     5
                4     2     3     5
                4     6     2     5
                4     7     6     5
                4     3     7     5
                4     8     6     7   ] ;





        Emin_temp=min(min(min((Ek(:,:,:,n)))));
        Emax_temp=max(max(max((Ek(:,:,:,n)))));
        
        if Emin_temp<Etmp && Emax_temp>Etmp % select only the band if crossing that E value
            
            for ix = 1 : (nkx-1) % nkx is the number of k points in the x axis, y and z m.m.
                for iy = 1 : (nky-1)
                    for iz = 1 : (nkz-1)
                        
                        kx_cond1 = ( Ek(ix,iy,iz,n) <= Etmp && Ek(ix+1,iy,iz,n) > Etmp || Ek(ix,iy,iz,n) >= Etmp && Ek(ix+1,iy,iz,n) < Etmp );
                        kx_cond2 = ( Ek(ix,iy+1,iz,n) <= Etmp && Ek(ix+1,iy+1,iz,n) > Etmp || Ek(ix,iy+1,iz,n) >= Etmp && Ek(ix+1,iy+1,iz,n) < Etmp );
                        kx_cond3 = ( Ek(ix,iy,iz+1,n) <= Etmp && Ek(ix+1,iy,iz+1,n) > Etmp || Ek(ix,iy,iz+1,n) >= Etmp && Ek(ix+1,iy,iz+1,n) < Etmp );
                        kx_cond4 = ( Ek(ix,iy+1,iz+1,n) <= Etmp && Ek(ix+1,iy+1,iz+1,n) > Etmp || Ek(ix,iy+1,iz+1,n) >= Etmp && Ek(ix+1,iy+1,iz+1,n) < Etmp );
                        
                        ky_cond1 = ( Ek(ix,iy,iz,n) <= Etmp && Ek(ix,iy+1,iz,n) > Etmp || Ek(ix,iy,iz,n) >= Etmp && Ek(ix,iy+1,iz,n) < Etmp );
                        ky_cond2 = ( Ek(ix+1,iy,iz,n) <= Etmp && Ek(ix+1,iy+1,iz,n) > Etmp || Ek(ix+1,iy,iz,n) >= Etmp && Ek(ix+1,iy+1,iz,n) < Etmp );
                        ky_cond3 = ( Ek(ix,iy,iz+1,n) <= Etmp && Ek(ix,iy+1,iz+1,n) > Etmp || Ek(ix,iy,iz+1,n) >= Etmp && Ek(ix,iy+1,iz+1,n) < Etmp );
                        ky_cond4 = ( Ek(ix+1,iy,iz+1,n) <= Etmp && Ek(ix+1,iy+1,iz+1,n) > Etmp || Ek(ix+1,iy,iz+1,n) >= Etmp && Ek(ix+1,iy+1,iz+1,n) < Etmp );
                        
                        kz_cond1 = ( Ek(ix,iy,iz,n) <= Etmp && Ek(ix,iy,iz+1,n) > Etmp || Ek(ix,iy,iz,n) >= Etmp && Ek(ix,iy,iz+1,n) < Etmp );
                        kz_cond2 = ( Ek(ix+1,iy,iz,n) <= Etmp && Ek(ix+1,iy,iz+1,n) > Etmp || Ek(ix+1,iy,iz,n) >= Etmp && Ek(ix+1,iy,iz+1,n) < Etmp );
                        kz_cond3 = ( Ek(ix,iy+1,iz,n) <= Etmp && Ek(ix,iy+1,iz+1,n) > Etmp || Ek(ix,iy+1,iz,n) >= Etmp && Ek(ix,iy+1,iz+1,n) < Etmp );
                        kz_cond4 = ( Ek(ix+1,iy+1,iz,n) <= Etmp && Ek(ix+1,iy+1,iz+1,n) > Etmp || Ek(ix+1,iy+1,iz,n) >= Etmp && Ek(ix+1,iy+1,iz+1,n) < Etmp );
                        
                        % is the 3D mesh element crossed by the surface?
                        if kx_cond1 || ky_cond1 || kz_cond1 || kx_cond2 || ky_cond2 || kz_cond2 || kx_cond3 || ky_cond3 || kz_cond3 || kx_cond4 || ky_cond4 || kz_cond4
                            
                            for iP = 1:6 % this identfy the pyramid iP
                                Pyr = DT_matrix(iP,:); % this gives the four points that are the Pyramid vertexes
                                
                                Axn = ix + P(Pyr(1),1) - 1;  % identification of the vertex coordinates, Vin is the point index, Vi is its i-coordinate in k-space
                                Ayn = iy + P(Pyr(1),2) - 1; 
                                Azn = iz + P(Pyr(1),3) - 1; 
                                Ax = kx_matrix(Axn,Ayn,Azn);
                                Ay = ky_matrix(Axn,Ayn,Azn);
                                Az = kz_matrix(Axn,Ayn,Azn);
                                E_A = Ek(Axn,Ayn,Azn,n); % Energy value corresponding at the Vertex

                                Bxn = ix + P(Pyr(2),1) - 1; 
                                Byn = iy + P(Pyr(2),2) - 1; 
                                Bzn = iz + P(Pyr(2),3) - 1; 
                                Bx = kx_matrix(Bxn,Byn,Bzn);
                                By = ky_matrix(Bxn,Byn,Bzn);
                                Bz = kz_matrix(Bxn,Byn,Bzn);
                                E_B = Ek(Bxn,Byn,Bzn,n);

                                Cxn = ix + P(Pyr(3),1) - 1; 
                                Cyn = iy + P(Pyr(3),2) - 1;
                                Czn = iz + P(Pyr(3),3) - 1;
                                Cx = kx_matrix(Cxn,Cyn,Czn);
                                Cy = ky_matrix(Cxn,Cyn,Czn);
                                Cz = kz_matrix(Cxn,Cyn,Czn);
                                E_C = Ek(Cxn,Cyn,Czn,n);

                                Dxn = ix + P(Pyr(4),1) - 1; 
                                Dyn = iy + P(Pyr(4),2) - 1;
                                Dzn = iz + P(Pyr(4),3) - 1;
                                Dx = kx_matrix(Dxn,Dyn,Dzn);
                                Dy = ky_matrix(Dxn,Dyn,Dzn);
                                Dz = kz_matrix(Dxn,Dyn,Dzn);                
                                E_D = Ek(Dxn,Dyn,Dzn,n);
                
%                                 Evtmp=[Ek(i,j,l,n);Ek(i+1,j,l,n);Ek(i,j+1,l,n);Ek(i,j,l+1,n)]; % 1st pyramid P1, ABCD
                                Evtmp = [E_A;E_B;E_C;E_D]; % iP pyramid , generically ABCD
                                EminP = min(Evtmp); 
                                EmaxP = max(Evtmp);
                                
                                
                                % is the tethraedron crossed by the surface?
                                if EminP<Etmp && EmaxP>Etmp % then the code considers the generic ABCD Pyramid (numbered iP)

                                    [kx, ky, kz,knorm, Vx, Vy, Vz, V, DOS, dkS] = Pyramid_explore_Lehmann_variation(Ax, Ay, Az, Bx, By, Bz, Cx, Cy, Cz, Dx, Dy, Dz, E_A, E_B, E_C, E_D, Etmp) ;
                                    
                                    
                                    kx_field = [kx_field, kx];
                                    ky_field = [ky_field, ky];
                                    kz_field = [kz_field, kz];
                                    knorm_field = [knorm_field, knorm];
                                    
                                    vx_field = [vx_field, Vx];
                                    vy_field = [vy_field, Vy];
                                    vz_field = [vz_field, Vz];
                                    V_field = [ V_field, V];
                                    
                                    DOS_field = [ DOS_field, DOS];
                                    
                                    dkS_field = [ dkS_field, dkS];

                                end

                            end
                        end
                        
                    end
                end
            end
        end
                   
        
        % integrals calculations for each band and each energy, the
        % 2/(8*pi^3) factor is introduced here
        NNan=isnan(DOS_field); DOS_field(NNan)=0;
        NInf=isinf(DOS_field); DOS_field(NInf)=0;
        NNan=isnan(vx_field);  vx_field(NNan)=0;
        NNan=isnan(vy_field);  vy_field(NNan)=0;
        NNan=isnan(vz_field);  vz_field(NNan)=0;
        NNan=isnan(V_field);   V_field(NNan)=0;
        
        k_points_number = size(kx_field,2);
         
        
        
        state_ID_temp = struct();
        
        state_ID_temp.kx = kx_field ;
        state_ID_temp.ky = ky_field ;
        state_ID_temp.kz = kz_field ;
        state_ID_temp.knorm = knorm_field ;
        
        state_ID_temp.v_x = vx_field ;
        state_ID_temp.v_y = vy_field ;
        state_ID_temp.v_z = vz_field ;
        state_ID_temp.V = V_field;         
        
        state_ID_temp.DOS = DOS_field ;
        state_ID_temp.surface = dkS_field ;
        state_ID_temp.E = Etmp;
        
        
        V = sum(state_ID_temp.V) / k_points_number ; % <v> ?  line 842 obiavtes to NaN issues
        
        DOS = BZ_factor*(sd/(8*pi^3))*sum( state_ID_temp.DOS); % Surface integration, the dAk element is in the DOS of the individual states





% subfunction pyramid_explore Lehamnn's and Taut's On the Numerical
% Calculation of the Density of Sates abd Related Properties, phys. stat.
% sol. (b) 54, 469 (1972)

    function [kx, ky, kz,knorm, Vx, Vy, Vz, V, DOS, dkS] = Pyramid_explore_Lehmann_variation(Ax, Ay, Az, Bx, By, Bz, Cx, Cy, Cz, Dx, Dy, Dz, E_A, E_B, E_C, E_D, Etmp)   %#codegen

        Av_cond = ( E_A < Etmp && E_B > Etmp && E_C > Etmp && E_D > Etmp ) || ( E_A > Etmp && E_B < Etmp && E_C < Etmp && E_D < Etmp );
        Bv_cond = ( E_B < Etmp && E_A > Etmp && E_C > Etmp && E_D > Etmp ) || ( E_B > Etmp && E_A < Etmp && E_C < Etmp && E_D < Etmp );
        Cv_cond = ( E_C < Etmp && E_A > Etmp && E_B > Etmp && E_D > Etmp ) || ( E_C > Etmp && E_A < Etmp && E_B < Etmp && E_D < Etmp );
        Dv_cond = ( E_D < Etmp && E_A > Etmp && E_B > Etmp && E_C > Etmp ) || ( E_D > Etmp && E_A < Etmp && E_B < Etmp && E_C < Etmp );
        ABv_cond = ( E_A < Etmp && E_B < Etmp && E_C > Etmp && E_D > Etmp ) || ( E_A > Etmp && E_B > Etmp && E_C < Etmp && E_D < Etmp );
        ACv_cond = ( E_A < Etmp && E_C < Etmp && E_B > Etmp && E_D > Etmp ) || ( E_A > Etmp && E_C > Etmp && E_B < Etmp && E_D < Etmp );
        ADv_cond = ( E_A < Etmp && E_D < Etmp && E_B > Etmp && E_C > Etmp ) || ( E_A > Etmp && E_D > Etmp && E_B < Etmp && E_C < Etmp ); 

        kx = [] ; %  single.empty(1,0); 
        coder.varsize('kx');
        ky = [] ; %  single.empty(1,0); 
        coder.varsize('ky');
        kz = [] ; %  single.empty(1,0); 
        coder.varsize('kz');
        knorm = [] ; % single.empty(1,0);
        coder.varsize('knorm');
        Vx = [] ; %  single.empty(1,0);
        coder.varsize('Vx');
        Vy = [] ; %  single.empty(1,0); 
        coder.varsize('Vy');
        Vz = [] ; %  single.empty(1,0);
        coder.varsize('Vz');
        V = [] ; %  single.empty(1,0);
        coder.varsize('V');
        DOS = [] ; %  single.empty(1,0);
        coder.varsize('DOS');
        dkS = [] ; %  single.empty(1,0);
        coder.varsize('dkS');

        if Av_cond % A vertex

            k1x = Ax + (Bx-Ax) * abs((Etmp-E_A) / (E_B-E_A));  %A-B
            k1y = Ay + (By-Ay) * abs((Etmp-E_A) / (E_B-E_A));
            k1z = Az + (Bz-Az) * abs((Etmp-E_A) / (E_B-E_A));
            k2x = Ax + (Cx-Ax) * abs((Etmp-E_A) / (E_C-E_A)); %A-C
            k2y = Ay + (Cy-Ay) * abs((Etmp-E_A) / (E_C-E_A));
            k2z = Az + (Cz-Az) * abs((Etmp-E_A) / (E_C-E_A));
            k3x = Ax + (Dx-Ax) * abs((Etmp-E_A) / (E_D-E_A)); %A-D
            k3y = Ay + (Dy-Ay) * abs((Etmp-E_A) / (E_D-E_A));
            k3z = Az + (Dz-Az) * abs((Etmp-E_A) / (E_D-E_A));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x+k3x)/3 ] ;
            ky = [ky, (k1y+k2y+k3y)/3 ] ;
            kz = [kz, (k1z+k2z+k3z)/3 ];
            knorm = [knorm, norm([(k1x+k2x+k3x)/3,(k1y+k2y+k3y)/3,(k1z+k2z+k3z)/3]) ];

            % composition of the DOS(E)
            % DOS(E) is the average of the bandstructure DOS at the k points above defined, a sort of linear interpolation of the DOS versus k along the pyramid edges 
            k12 = norm([k2x-k1x,k2y-k1y,k2z-k1z]);
            k13 = norm([k3x-k1x,k3y-k1y,k3z-k1z]);
            k23 = norm([k3x-k2x,k3y-k2y,k3z-k2z]);
            sp = (k12+k13+k23)/2;
            dkS = real(sqrt((sp*(sp-k12)*(sp-k13)*(sp-k23)))); % surface element for the integration, Heron's formula

            % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Bx, By, Bz] - [Ax, Ay, Az];
            k2 = [Cx, Cy, Cz] - [Ax, Ay, Az];
            k3 = [Dx, Dy, Dz] - [Ax, Ay, Az];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 + (E_D-E_A)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ]; 


        elseif Bv_cond % B vertex

            k1x = Bx + (Ax-Bx) * abs((Etmp-E_B) / (E_A-E_B)); %B-A
            k1y = By + (Ay-By) * abs((Etmp-E_B) / (E_A-E_B));
            k1z = Bz + (Az-Bz) * abs((Etmp-E_B) / (E_A-E_B));
            k2x = Bx + (Cx-Bx) * abs((Etmp-E_B) / (E_C-E_B)); % B-C
            k2y = By + (Cy-By) * abs((Etmp-E_B) / (E_C-E_B));
            k2z = Bz + (Cz-Bz) * abs((Etmp-E_B) / (E_C-E_B));
            k3x = Bx + (Dx-Bx) * abs((Etmp-E_B) / (E_D-E_B)); % B-D
            k3y = By + (Dy-By) * abs((Etmp-E_B) / (E_D-E_B));
            k3z = Bz + (Dz-Bz) * abs((Etmp-E_B) / (E_D-E_B));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x+k3x)/3 ] ;
            ky = [ky, (k1y+k2y+k3y)/3 ] ;
            kz = [kz, (k1z+k2z+k3z)/3 ];
            knorm = [knorm, norm([(k1x+k2x+k3x)/3,(k1y+k2y+k3y)/3,(k1z+k2z+k3z)/3]) ];

            k12 = norm([k2x-k1x,k2y-k1y,k2z-k1z]);
            k13 = norm([k3x-k1x,k3y-k1y,k3z-k1z]);
            k23 = norm([k3x-k2x,k3y-k2y,k3z-k2z]);
            sp = (k12+k13+k23)/2;
            dkS = real(sqrt(sp*(sp-k12)*(sp-k13)*(sp-k23)));

        % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Ax, Ay, Az] - [Bx, By, Bz];
            k2 = [Cx, Cy, Cz] - [Bx, By, Bz];
            k3 = [Dx, Dy, Dz] - [Bx, By, Bz];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_A - E_B)*r1 + (E_C-E_B)*r2 + (E_D-E_B)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];



        elseif Cv_cond % C vertex

            k1x = Cx + (Ax-Cx) * abs((Etmp-E_C) / (E_A-E_C)); %C-A
            k1y = Cy + (Ay-Cy) * abs((Etmp-E_C) / (E_A-E_C));
            k1z = Cz + (Az-Cz) * abs((Etmp-E_C) / (E_A-E_C));
            k2x = Cx + (Bx-Cx) * abs((Etmp-E_C) / (E_B-E_C)); % C-B
            k2y = Cy + (By-Cy) * abs((Etmp-E_C) / (E_B-E_C));
            k2z = Cz + (Bz-Cz) * abs((Etmp-E_C) / (E_B-E_C));
            k3x = Cx + (Dx-Cx) * abs((Etmp-E_C) / (E_D-E_C)); % C-D
            k3y = Cy + (Dy-Cy) * abs((Etmp-E_C) / (E_D-E_C));
            k3z = Cz + (Dz-Cz) * abs((Etmp-E_C) / (E_B-E_C));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x+k3x)/3 ] ;
            ky = [ky, (k1y+k2y+k3y)/3 ] ;
            kz = [kz, (k1z+k2z+k3z)/3 ];
            knorm = [knorm, norm([(k1x+k2x+k3x)/3,(k1y+k2y+k3y)/3,(k1z+k2z+k3z)/3]) ];

            k12 = norm([k2x-k1x,k2y-k1y,k2z-k1z]);
            k13 = norm([k3x-k1x,k3y-k1y,k3z-k1z]);
            k23 = norm([k3x-k2x,k3y-k2y,k3z-k2z]);
            sp = (k12+k13+k23)/2;
            dkS = real(sqrt(sp*(sp-k12)*(sp-k13)*(sp-k23)));


          % Define the DOS at the intermediate points 
            % variation from Lehmann 1972    
            k1 = [Ax, Ay, Az] - [Cx, Cy, Cz];
            k2 = [Bx, By, Bz] - [Cx, Cy, Cz];
            k3 = [Dx, Dy, Dz] - [Cx, Cy, Cz];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_A - E_C)*r1 + (E_B-E_C)*r2 + (E_D-E_C)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];



        elseif Dv_cond % D vertex

            k1x = Dx + (Ax-Dx) * abs((Etmp-E_D) / (E_A-E_D)); % D-A
            k1y = Dy + (Ay-Dy) * abs((Etmp-E_D) / (E_A-E_D));
            k1z = Dz + (Az-Dz) * abs((Etmp-E_D) / (E_A-E_D));
            k2x = Dx + (Bx-Dx) * abs((Etmp-E_D) / (E_B-E_D)); % D-B
            k2y = Dy + (By-Dy) * abs((Etmp-E_D) / (E_B-E_D));
            k2z = Dz + (Bz-Dz) * abs((Etmp-E_D) / (E_B-E_D));
            k3x = Dx + (Cx-Dx) * abs((Etmp-E_D) / (E_C-E_D)); % D-C
            k3y = Dy + (Cy-Dy) * abs((Etmp-E_D) / (E_C-E_D));
            k3z = Dz + (Cz-Dz) * abs((Etmp-E_D) / (E_C-E_D));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x+k3x)/3 ] ;
            ky = [ky, (k1y+k2y+k3y)/3 ] ;
            kz = [kz, (k1z+k2z+k3z)/3 ];
            knorm = [knorm, norm([(k1x+k2x+k3x)/3,(k1y+k2y+k3y)/3,(k1z+k2z+k3z)/3]) ];


            k12 = norm([k2x-k1x,k2y-k1y,k2z-k1z]);
            k13 = norm([k3x-k1x,k3y-k1y,k3z-k1z]);
            k23 = norm([k3x-k2x,k3y-k2y,k3z-k2z]);
            sp = (k12+k13+k23)/2;
            dkS = real(sqrt(sp*(sp-k12)*(sp-k13)*(sp-k23)));


            % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Ax, Ay, Az] - [Dx, Dy, Dz];
            k2 = [Bx, By, Bz] - [Dx, Dy, Dz];
            k3 = [Cx, Cy, Cz] - [Dx, Dy, Dz];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_A - E_D)*r1 + (E_B-E_D)*r2 + (E_C-E_D)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];
        end 


        if ABv_cond % A,B vertexes, Lehamnn scheme always from A vertex

            k1x = Ax + (Cx-Ax) * abs((Etmp-E_A) / (E_C-E_A)); % A-C
            k1y = Ay + (Cy-Ay) * abs((Etmp-E_A) / (E_C-E_A));
            k1z = Az + (Cz-Az) * abs((Etmp-E_A) / (E_C-E_A));
            k2x = Ax + (Dx-Ax) * abs((Etmp-E_A) / (E_D-E_A)); % A-D
            k2y = Ay + (Dy-Ay) * abs((Etmp-E_A) / (E_D-E_A));
            k2z = Az + (Dz-Az) * abs((Etmp-E_A) / (E_D-E_A));
            k3x = Bx + (Cx-Bx) * abs((Etmp-E_B) / (E_C-E_B)); % B-C
            k3y = By + (Cy-By) * abs((Etmp-E_B) / (E_C-E_B)); 
            k3z = Bz + (Cz-Bz) * abs((Etmp-E_B) / (E_C-E_B)); 
            k4x = Bx + (Dx-Bx) * abs((Etmp-E_B) / (E_D-E_B)); % B-D
            k4y = By + (Dy-By) * abs((Etmp-E_B) / (E_D-E_B));
            k4z = Bz + (Dz-Bz) * abs((Etmp-E_B) / (E_D-E_B));

            %  put the point in the state_ID of the state
            kx = [kx, (k1x+k2x+k3x+k4x)/4 ] ;
            ky = [ky, (k1y+k2y+k3y+k4y)/4 ] ;
            kz = [kz, (k1z+k2z+k3z+k4z)/4 ];
            knorm = [knorm, norm([(k1x+k2x+k3x+k4x)/4,(k1y+k2y+k3y+k4y)/4,(k1z+k2z+k3z+k4z)/4]) ];

            k12 = norm([k2x-k1x,k2y-k1y,k2z-k1z]); % four dk vectors that define a tethragon (could be intersecting, be careful), if intersect maybe average 4 cross product ...
            k13 = norm([k3x-k1x,k3y-k1y,k3z-k1z]);
            k42 = norm([k2x-k4x,k2y-k4y,k2z-k4z]);
            k43 = norm([k3x-k4x,k3y-k4y,k3z-k4z]);
            k14 = norm([k1x-k4x,k1y-k4y,k1z-k4z]);
            k23 = norm([k3x-k2x,k3y-k2y,k3z-k2z]);
        %                             % dkS=sqrt(norm(k12)*norm(k13)*norm(k42)*norm(k43)); % irregular surface element with four dk vectors as bounderies, area approx. as product of the boundaries
        %                             dkS=(norm(cross(k12,k13))+norm(cross(k42,k43)))/2; % irregular surfacen element, area approx. to the average of the area 
        %                             dkS=(norm(cross(k12,k13))+norm(cross(k42,k43))+norm(cross(k12,k42))+norm(cross(k13,k43)))/4; % this to obviate to the possibility to have intersecting vectors
            sp1 = (k12+k42+k14)/2; % 124 triangle
            sp2 = (k13+k43+k14)/2; % 134 triangle
            sp3 = (k23+k43+k42)/2; % 234 triangle
            sp4 = (k12+k13+k23)/2; % 123 triangle
            dkS =  real(sqrt(sp1*(sp1-k12)*(sp1-k42)*(sp1-k14)) + sqrt(sp2*(sp2-k13)*(sp2-k43)*(sp2-k14)) + sqrt(sp3*(sp3-k23)*(sp3-k43)*(sp3-k42)) + sqrt(sp4*(sp4-k12)*(sp4-k13)*(sp4-k23))) /2;


            % Define the DOS at the intermediate points 
            % variation from Lehmann 1972    
            k1 = [Bx, By, Bz] - [Ax, Ay, Az];
            k2 = [Cx, Cy, Cz] - [Ax, Ay, Az];
            k3 = [Dx, Dy, Dz] - [Ax, Ay, Az];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 + (E_D-E_A)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];


        elseif ACv_cond % A,C vertexes

            k1x = Ax + (Bx-Ax) * abs((Etmp-E_A) / (E_B-E_A));  % A-B
            k1y = Ay + (By-Ay) * abs((Etmp-E_A) / (E_B-E_A));
            k1z = Az + (Bz-Az) * abs((Etmp-E_A) / (E_B-E_A));
            k2x = Ax + (Dx-Ax) * abs((Etmp-E_A) / (E_D-E_A)); % A-D
            k2y = Ay + (Dy-Ay) * abs((Etmp-E_A) / (E_D-E_A));
            k2z = Az + (Dz-Az) * abs((Etmp-E_A) / (E_D-E_A));
            k3x = Cx + (Bx-Cx) * abs((Etmp-E_C) / (E_B-E_C)); % C-B
            k3y = Cy + (By-Cy) * abs((Etmp-E_C) / (E_B-E_C));
            k3z = Cz + (Bz-Cz) * abs((Etmp-E_C) / (E_B-E_C));
            k4x = Cx + (Dx-Cx) * abs((Etmp-E_C) / (E_D-E_C)); % C-D
            k4y = Cy + (Dy-Cy) * abs((Etmp-E_C) / (E_D-E_C));
            k4z = Cz + (Dz-Cz) * abs((Etmp-E_C) / (E_D-E_C));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x+k3x+k4x)/4 ] ;
            ky = [ky, (k1y+k2y+k3y+k4y)/4 ] ;
            kz = [kz, (k1z+k2z+k3z+k4z)/4 ];
            knorm = [knorm, norm([(k1x+k2x+k3x+k4x)/4,(k1y+k2y+k3y+k4y)/4,(k1z+k2z+k3z+k4z)/4]) ];


            k12 = norm([k2x-k1x, k2y-k1y, k2z-k1z]); % four dk vectors that define a tethragon (could be intersecting, be careful), if intersect maybe average 4 cross product ...
            k13 = norm([k3x-k1x, k3y-k1y, k3z-k1z]);
            k42 = norm([k2x-k4x, k2y-k4y, k2z-k4z]);
            k43 = norm([k3x-k4x, k3y-k4y, k3z-k4z]);
            k14 = norm([k1x-k4x, k1y-k4y, k1z-k4z]);
            k23 = norm([k3x-k2x, k3y-k2y, k3z-k2z]);
            sp1 = (k12+k42+k14)/2; % 124 triangle
            sp2 = (k13+k43+k14)/2; % 134 triangle
            sp3 = (k23+k43+k42)/2; % 234 triangle
            sp4 = (k12+k13+k23)/2; % 123 triangle
            dkS =  real(sqrt(sp1*(sp1-k12)*(sp1-k42)*(sp1-k14)) + sqrt(sp2*(sp2-k13)*(sp2-k43)*(sp2-k14)) + sqrt(sp3*(sp3-k23)*(sp3-k43)*(sp3-k42)) + sqrt(sp4*(sp4-k12)*(sp4-k13)*(sp4-k23))) /2;



            % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Bx, By, Bz] - [Ax, Ay, Az];
            k2 = [Cx, Cy, Cz] - [Ax, Ay, Az];
            k3 = [Dx, Dy, Dz] - [Ax, Ay, Az];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 + (E_D-E_A)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];



        elseif ADv_cond % A,D vertexes

            k1x = Ax + (Bx-Ax) * abs((Etmp-E_A) / (E_B-E_A)); % A-B
            k1y = Ay + (By-Ay) * abs((Etmp-E_A) / (E_B-E_A));
            k1z = Az + (Bz-Az) * abs((Etmp-E_A) / (E_B-E_A));
            k2x = Ax + (Cx-Ax) * abs((Etmp-E_A) / (E_C-E_A)); % A-C
            k2y = Ay + (Cy-Ay) * abs((Etmp-E_A) / (E_C-E_A));
            k2z = Az + (Cz-Az) * abs((Etmp-E_A) / (E_C-E_A));
            k3x = Dx + (Bx-Dx) * abs((Etmp-E_D) / (E_B-E_D)); % D-B
            k3y = Dy + (By-Dy) * abs((Etmp-E_D) / (E_B-E_D));
            k3z = Dz + (Bz-Dz) * abs((Etmp-E_D) / (E_B-E_D));
            k4x = Dx + (Cx-Dx) * abs((Etmp-E_D) / (E_C-E_D)); % D-C
            k4y = Dy + (Cy-Dy) * abs((Etmp-E_D) / (E_C-E_D));
            k4z = Dz + (Cz-Dz) * abs((Etmp-E_D) / (E_C-E_D));

            %  put the point in the state_ID of the state
            kx = [kx, (k1x+k2x+k3x+k4x)/4 ] ;
            ky = [ky, (k1y+k2y+k3y+k4y)/4 ] ;
            kz = [kz, (k1z+k2z+k3z+k4z)/4 ];
            knorm = [knorm, norm([(k1x+k2x+k3x+k4x)/4,(k1y+k2y+k3y+k4y)/4,(k1z+k2z+k3z+k4z)/4]) ];


            k12 = norm([k2x-k1x,k2y-k1y,k2z-k1z]); % four dk vectors that define a tethragon (could be intersecting, be careful), if intersect maybe average 4 cross product ...
            k13 = norm([k3x-k1x,k3y-k1y,k3z-k1z]);
            k42 = norm([k2x-k4x,k2y-k4y,k2z-k4z]);
            k43 = norm([k3x-k4x,k3y-k4y,k3z-k4z]);
            k14 = norm([k1x-k4x,k1y-k4y,k1z-k4z]);
            k23 = norm([k3x-k2x,k3y-k2y,k3z-k2z]);
            sp1 = (k12+k42+k14)/2; % 124 triangle
            sp2 = (k13+k43+k14)/2; % 134 triangle
            sp3 = (k23+k43+k42)/2; % 234 triangle
            sp4 = (k12+k13+k23)/2; % 123 triangle
            dkS =  real(sqrt(sp1*(sp1-k12)*(sp1-k42)*(sp1-k14)) + sqrt(sp2*(sp2-k13)*(sp2-k43)*(sp2-k14)) + sqrt(sp3*(sp3-k23)*(sp3-k43)*(sp3-k42)) + sqrt(sp4*(sp4-k12)*(sp4-k13)*(sp4-k23))) /2;


            % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Bx, By, Bz] - [Ax, Ay, Az];
            k2 = [Cx, Cy, Cz] - [Ax, Ay, Az];
            k3 = [Dx, Dy, Dz] - [Ax, Ay, Az];
            vT = dot(k1,cross(k2,k3)); % "volume of the tethraedron times six" (?)
            r1 = cross(k2,k3) / vT; % contragradient, Lehmann 1972
            r2 = cross(k3,k1) / vT; 
            r3 = cross(k1,k2) / vT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 + (E_D-E_A)*r3;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            Vz_k = q0/hbar * grad_E(3);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkS / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            Vz = [Vz, Vz_k ];
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];

        end

    end


end
