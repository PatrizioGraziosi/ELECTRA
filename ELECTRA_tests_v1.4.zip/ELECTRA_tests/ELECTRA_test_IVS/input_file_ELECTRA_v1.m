% INPUT file for main_ELECTRA code


% 1) GENERAL SETTINGS
material_name = 'Si_test' ; 
file_type = 'bxsf'; % bxsf or mat
% for .bxsf files
bxsf_file_name = 'Si_test.bxsf'; %'Co_hcp_noSOC.bxsf'; % 'Co_fcc_uspp_angle2_90_alat_6538Bohr.bxsf'; % 'Co_hcp_angle2_90_alat_45679Bohr_uspp.bxsf'; 
alat = 0.54; % in nm
SOC_not_magn = 'no'; % yes or no % yes ONLY if use SOC but system is not ferromagnetic
interpolation_factor = 2;
%

dimensionality='3D'; % 2D, 3D

scan_type='kScan'; % kScan or DT . This is the way the k(E) is extracted

spin_resolved = 'no';

k_units_SI = 'yes'; % in 1/m , as extracted from bxsf, okay for DFT bands
k_units_pi_a = 'no'; % usable for numerically built bands 

%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% 2) SCATTERING MECHANISMS
ADP = 'no'; % Acoustic Deformation Potential, INTRAvalley
ADP_IVS = 'no';  % INTRA- and INTER- valley
k_restriction = 'no'; % only for the ADP_IVS TO BE EXTENDED WHEN VALIDATED
k_restriction_cutoff = 0.2; % Portion of the BZ to be considered

IVS = 'yes'; % intervalley scattering

ODP = 'no'; % Optical deformation potential

POP = 'no'; % polar optical phonon, constan freq., approx.
screening_POP = 'no'; % this is not necessary and makes the code much slower

IIS = 'no'; % this flag makes the IIS calc. musch less RAM consuming but more time consuming
IIS_interband_flag = 'no';

Alloy = 'no';

overlap_integrals_analytical = 'no'; 


save_RTstruct = 'yes';


multivalley = 'no'; % different types of valleys with different Deformation Potentials


constant_tau = 'no'; % constant relax. time approx. (CRTA)
tau_const = 1e-14; % in s; value of the scattering time in the CRTA
                  
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% 3) TRANSPORT CONDITIONS

% 3.1) FERMI LEVELS AND TEMPERATURES
EF_array = [-0.2,-0.1,-0.06:0.02:0.14,0.2];  % in eV
% Fermi array is in respect to the band edge that will be set to zero, 
% negative values mean Fermi into the gap, positive, into the band (degen.)

T_array = 300:100:400; % in K
Fermi_shift_flag = 'yes'; % to shift the Fermi level with the temperature

% 3.2) CARRIERS AND ENERGY
carriers = 'electrons'; % 'holes' or 'electrons'

bipolar_transport = 'no';

bipolar_single_carrier = 'no' ;

change_band_gap = 'no' ;
new_band_gap = 1 ; % in eV

metallic = 'no'; % proper metal with Fermi in the bands free carriers without impurities

Estep = 0.002 ; % energy step in eV, 2 meV is often largely sufficient 

%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% 4) PARALLELIZATION 
type_of_parallelization = 'local'; % 'local' (one node) or 'cluster' (more than one node), 'MATLAB Parallel Cloud' is forecasted
max_number_of_cpu = 4 ; % maximum number of cpu in the single node
% only for cluster10; % number of requested nodes
cluster_name = 'galileo100 R2020b';
account_name = 'IscrC_sd-FRAME';
queue_name = 'g100_usr_prod';
wall_time = '03:40:00';

%--------------------------------------------------------------------------
% --------------- end of the input instructions --------------------------
% ------------------------------------------------------------------------


save Inputs