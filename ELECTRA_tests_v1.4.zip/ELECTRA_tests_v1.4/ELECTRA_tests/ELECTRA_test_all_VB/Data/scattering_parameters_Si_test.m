% The scattering parameters for Silicon - Jacoboni mostly...

% RELEVANT SCATTERING for Si 

bands_type = [1,2,3,1,2] ;


%----------- PHONONS ---------
rho_mass_density=2.329*1e-3/(1e-2)^3; % kg/m^3
% us_sound_vel=9.04*1e3;               % m/s
sl=9.041e3;                % m/s
st=5.34*1e3;               % m/s
us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975



%------- for electrons ---------------
D_adp_e = 9.5 ;

D_ivs = [ 3.86e10, 2.86e10,  3.6e10 ] ; % g f f

hbar_w_ivs =  [ 0.061, 0.047, 0.056 ] ; % g f f

Z_f_ivs=[1, 4, 4] / 6; % number of final available valleys, g, g, f, f, g, f

%X-L intervalley is ignored as L valleys are 1 eV above (fine for TE)
%--------------------------------------------------------



%-------- for holes, multivalleys ------------------
D_adp_h_M = [ 5.39, 5.39, 4 ; 5.39, 5.39, 4 ; 4, 4, 4] ;

D_odp_h_M = [ 6, 6, 3] *1e10 ;

D_ivs_h_M = [ 0, 6, 3 ; 6, 0, 3 ; 3, 3, 0] ;

hbar_w_odp_h_M = [ 0.063, 0.063, 0.063] ;

hbar_w_ivs_h_M =  [ 0, 0.063, 0.063 ; 0.063, 0, 0.063 ; 0.063, 0.063, 0] ;
%--------------------------------------------------------


% for Coulomb scattering - screened
k_s = 11.7;
k_inf = 0; % Not used for Silicon but the code requires it to be enetered

Z_i = 1 ; % ionize dimpurity charge