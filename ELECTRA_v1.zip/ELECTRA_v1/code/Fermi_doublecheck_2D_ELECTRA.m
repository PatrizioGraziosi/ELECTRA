% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

% it comes after the
% shifting_bands_VOMBATO code
% that sets the edge of the pseudoconduction bands to zero

function [EF_array, EF_intrinsic, Ek, valence_edge, midgap] = Fermi_doublecheck_2D_ELECTRA(EF_array, Estep, T_array, Ek, pseudoconduction_bands, pseudovalence_bands, kx_matrix, ky_matrix, semimetal, new_band_gap, change_band_gap, bipolar_one_carrier)

% physical constants
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]

valence_edge = max(max(max(max(Ek(:,:,pseudovalence_bands))))); % defined in the script shifting_bands
midgap = 0.5*valence_edge;
% this step is done for both semiconductors and semimetals

if strcmp(change_band_gap,'yes')
    Ek(:,:,pseudovalence_bands) = Ek(:,:,pseudovalence_bands) - valence_edge - new_band_gap ;
    valence_edge = - new_band_gap ;
    midgap = - new_band_gap/2;
end

EF_array_entered = EF_array;



% ----------------------- k space surface element -------------------------
dkx_s = [kx_matrix(2,1) ky_matrix(2,1) 0] - [kx_matrix(1,1) ky_matrix(1,1) 0];
dky_s = [kx_matrix(1,2) ky_matrix(1,2) 0] - [kx_matrix(1,1) ky_matrix(1,1) 0];
dSk = norm(cross(dkx_s,dky_s));
% ------------------------------------------------------------------------
if exist('sd','var')
else
    sd = 2;
end
[~, nT]=min(T_array-300);

if strcmp(semimetal,'no')

    Fermi_dummy = midgap;
    % charge neutrality condition, at T = 0
    N0 = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek-midgap)./(kB*0/q0))+1))));

    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-Fermi_dummy)./(kB*T_array(nT)/q0))+1))))) - N0;
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-Fermi_dummy)./(kB*T_array(nT)/q0))+1))));
    Delta_Ndummy = ((abs(n_cond)-abs(n_val))/abs(max([abs(n_val),abs(n_cond)])));
    EF1 = Fermi_dummy;
    EF2 = Fermi_dummy - sign(Delta_Ndummy)*midgap; % midgap is negative as the CB edge has been set at zero
    EF0 = Fermi_dummy + sign(Delta_Ndummy)*midgap;
    
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF0)./(kB*T_array(nT)/q0))+1)))) - N0;
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF0)./(kB*T_array(nT)/q0))+1))));
    n0 = abs(n_cond) - abs(n_val);
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF1)./(kB*T_array(nT)/q0))+1)))) - N0;
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF1)./(kB*T_array(nT)/q0))+1))));
    n1 = abs(n_cond) - abs(n_val);
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF2)./(kB*T_array(nT)/q0))+1)))) - N0;
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF2)./(kB*T_array(nT)/q0))+1))));
    n2 = abs(n_cond) - abs(n_val);
    iF = 1;
    
    while n1*n2 > 0 && n0*n1 > 0
        iF = iF+1;
        EF2 = Fermi_dummy - iF * sign(Delta_Ndummy)*midgap; % midgap is negative as the CB edge has been set at zero
        EF0 = Fermi_dummy + iF * sign(Delta_Ndummy)*midgap;

        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF0)./(kB*T_array(nT)/q0))+1)))) - N0;
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF0)./(kB*T_array(nT)/q0))+1))));
        n0 = abs(n_cond) - abs(n_val);
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF2)./(kB*T_array(nT)/q0))+1)))) - N0;
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF2)./(kB*T_array(nT)/q0))+1))));
        n2 = abs(n_cond) - abs(n_val);        
    end
    
    while ( abs(Delta_Ndummy) > 0.01 || Delta_Ndummy < 0 ) && ( abs(EF1-EF0)>1e-5 && abs(EF2-EF1)>1e-5 )
                       
        if n2*n1 < 0 
            EFa = EF2;
            EFb = EF1;
            EFc = (EF2 + EF1)/2;
            v_EF = [EFa, EFb, EFc];
            EF2 = max( v_EF );
            EF0 = min( v_EF );
            for idd = 1:3
                if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                    EF1 = v_EF(idd);
                end
            end
%             v_EF(v_EF == EF0) = [];
%             v_EF(v_EF == EF2) = [];
%             EF1 = v_EF;
        elseif n1*n0 < 0 && abs(EF1-EF0)>1e-5 && abs(EF2-EF1)>1e-5
            EFa = EF1;
            EFb = EF0;
            EFc = (EF1 + EF0)/2;
            v_EF = [EFa, EFb, EFc];
            EF2 = max( v_EF );
            EF0 = min( v_EF );

            for idd = 1:3
                if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                    EF1 = v_EF(idd);
                end
            end
        end
        
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF0)./(kB*T_array(nT)/q0))+1)))) - N0;
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF0)./(kB*T_array(nT)/q0))+1))));
        n0 = abs(n_cond) - abs(n_val);
        
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF1)./(kB*T_array(nT)/q0))+1)))) - N0;
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF1)./(kB*T_array(nT)/q0))+1))));
        n1 = abs(n_cond) - abs(n_val);
        Delta_Ndummy = ((abs(n_cond)-abs(n_val))/abs(max([abs(n_val),abs(n_cond)])));
        
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudovalence_bands)-EF2)./(kB*T_array(nT)/q0))+1)))) - N0;        
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF2)./(kB*T_array(nT)/q0))+1))));
        n2 = abs(n_cond) - abs(n_val);
            
    end
    EF_intrinsic = EF1;

    if min(EF_array) < EF_intrinsic && EF_intrinsic < 0
        max_Fermi_ingap = max(EF_array(EF_array <= 0));
        if max_Fermi_ingap < EF_intrinsic && strcmp(single_Fermi_inputted,'yes')
            EF_array = [EF_intrinsic+Estep, EF_intrinsic+2*Estep];

        end
        max_Fermi_ingap = max(EF_array(EF_array <= 0));
        Fermi_spread = max_Fermi_ingap - (EF_intrinsic+Estep);
        n_Fermi_ingap = size(EF_array(EF_array <= 0) , 2);
        step_Fermi_ingap = Fermi_spread/(n_Fermi_ingap-1);
        if step_Fermi_ingap == 0
            step_Fermi_ingap = 1;
        end        
        EF_array(EF_array <= 0) = (EF_intrinsic+Estep):step_Fermi_ingap:max_Fermi_ingap;
    end
    
    if strcmp(bipolar_one_carrier,'yes')
        if min(EF_array) < EF_intrinsic && EF_intrinsic > 0 && midgap <= 0
            max_Fermi_ingap = min(EF_array(EF_array > EF_intrinsic+0.0001));
            Fermi_spread = max_Fermi_ingap - EF_intrinsic;
            n_Fermi_ingap = size(EF_array(EF_array <= EF_intrinsic) , 2);
            step_Fermi_ingap = Fermi_spread/(n_Fermi_ingap-1);
            EF_array(EF_array <= EF_intrinsic) = EF_intrinsic:step_Fermi_ingap:max_Fermi_ingap;
        end
        if min(EF_array) < EF_intrinsic && EF_intrinsic > 0 && midgap > 0
            EF_mean = 0.5*( max(EF_array) + min(EF_array) ); %0.5*( max(EF_array) - min(EF_array) );
            EF_delta = EF_intrinsic - EF_mean;
            EF_array = EF_array + EF_delta;
        end
        
        
    elseif strcmp(bipolar_one_carrier,'no') && valence_edge <= 0 % most common case
        
        if min(EF_array) > EF_intrinsic && valence_edge-min(EF_array) < EF_intrinsic
            EF_array = [ -flip(EF_array)+valence_edge , EF_intrinsic, EF_array];
        elseif min(EF_array) > EF_intrinsic && valence_edge-min(EF_array) > EF_intrinsic
            EF_electrons = EF_array ;
            EF_holes = -flip(EF_electrons)+valence_edge ;
            EF_array = [ EF_holes(EF_holes < EF_intrinsic) , EF_intrinsic, EF_electrons];
        elseif min(EF_array) < EF_intrinsic && valence_edge-min(EF_array) < EF_intrinsic
            EF_electrons = EF_array(EF_array > EF_intrinsic) ;
            EF_array = [ -flip(EF_array)+valence_edge , EF_intrinsic, EF_electrons];
        elseif min(EF_array) < EF_intrinsic && valence_edge-min(EF_array) > EF_intrinsic
            EF_electrons = EF_array(EF_array > EF_intrinsic) ;
            EF_holes = -flip(EF_electrons)+valence_edge ;
            EF_array = [ EF_holes(EF_holes < EF_intrinsic) , EF_intrinsic, EF_electrons];
        end
        
    elseif strcmp(bipolar_one_carrier,'no') && valence_edge > 0 % negative gap semimetal, CB edge always set to zero
        
        if min(EF_array) > EF_intrinsic          
            EF_array = [ -flip(EF_array)+EF_intrinsic , EF_intrinsic, EF_array];             
        
        elseif min(EF_array) < EF_intrinsic && max(EF_array) > EF_intrinsic
            EF_electrons = EF_array(EF_array > EF_intrinsic) ;
            EF_holes = -flip(EF_electrons)+EF_intrinsic ;
            n_h = size(EF_holes,2);
            n_e = size(EF_electrons,2);
            Delta1 = abs(min(EF_array)-EF_intrinsic);
            Delta2 = abs(max(EF_array-EF_intrinsic));
            if Delta1 > Delta2
                EF_th = min(EF_array):(EF_intrinsic-min(EF_array))/n_h:EF_intrinsic;
                EF_te = EF_intrinsic:(max(EF_array)-EF_intrinsic)/n_e:(EF_intrinsic+Delta1);
            else
                EF_th = (min(EF_array)-Delta2):(EF_intrinsic-min(EF_array))/n_h:EF_intrinsic;
                EF_te = EF_intrinsic:(max(EF_array)-EF_intrinsic)/n_e:(EF_intrinsic);
            end
            EF_array =  unique([EF_th,EF_te]) ; %[ EF_holes(EF_holes < EF_intrinsic) , EF_intrinsic, EF_electrons];
        else
            EF_electrons = EF_array + EF_intrinsic ;
%             EF_holes = -flip(EF_electrons) ;
            n_e = size(EF_electrons,2);
            n_h = n_e;
%             Delta_low = abs(min(EF_electrons)-EF_intrinsic);
%             Delta_high = abs(max(EF_electrons-EF_intrinsic));
%             if Delta_high > Delta_low
            EF_th = min(EF_array):(EF_intrinsic-min(EF_array))/n_h:EF_intrinsic;
            EF_te = EF_intrinsic:(max(EF_electrons)-EF_intrinsic)/n_e:max(EF_electrons);
%             else
%                 EF_th = (min(EF_array)-Delta_low):(EF_intrinsic-min(EF_array))/n_h:EF_intrinsic;
%                 EF_te = EF_intrinsic:(max(EF_array)-EF_intrinsic)/n_e:(EF_intrinsic+Delta_high);
%             end
            EF_array =  unique([EF_th,EF_te]) ; %EF_array =  unique( [ EF_holes, EF_intrinsic, EF_electrons] );
        end
        
    end
    
    
    
elseif strcmp(semimetal,'yes')
    
    Fermi_dummy = midgap;
    
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+Fermi_dummy)./(kB*T_array(nT)/q0))+1))));
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-Fermi_dummy)./(kB*T_array(nT)/q0))+1))));
    Delta_Ndummy = ((abs(n_cond)-abs(n_val))/abs(max([abs(n_val),abs(n_cond)])));
    EF1 = Fermi_dummy;
    EF2 = Fermi_dummy + 10*kB*T_array(nT)/q0; % midgap is negative as the CB edge has been set at zero
    EF0 = Fermi_dummy - 10*kB*T_array(nT)/q0;
    
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF0)./(kB*T_array(nT)/q0))+1))));
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF0)./(kB*T_array(nT)/q0))+1))));
    n0 = abs(n_cond) - abs(n_val);
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF1)./(kB*T_array(nT)/q0))+1))));
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF1)./(kB*T_array(nT)/q0))+1))));
    n1 = abs(n_cond) - abs(n_val);
    n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF2)./(kB*T_array(nT)/q0))+1))));
    n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF2)./(kB*T_array(nT)/q0))+1))));
    n2 = abs(n_cond) - abs(n_val);
    iF = 1;
    
    while n1*n2 > 0 && n0*n1 > 0
        iF = iF+1;
        EF2 = Fermi_dummy - iF * sign(Delta_Ndummy)*midgap; % midgap is negative as the CB edge has been set at zero
        EF0 = Fermi_dummy + iF * sign(Delta_Ndummy)*midgap;

        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF0)./(kB*T_array(nT)/q0))+1))));
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF0)./(kB*T_array(nT)/q0))+1))));
        n0 = abs(n_cond) - abs(n_val);
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF2)./(kB*T_array(nT)/q0))+1))));
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF2)./(kB*T_array(nT)/q0))+1))));
        n2 = abs(n_cond) - abs(n_val);        
    end
    
    while abs(Delta_Ndummy) > 0.01 || Delta_Ndummy < 0
                       
        if n2*n1 < 0
            EFa = EF2;
            EFb = EF1;
            EFc = (EF2 + EF1)/2;
            v_EF = [EFa, EFb, EFc];
            EF2 = max( v_EF );
            EF0 = min( v_EF );
            for idd = 1:3
                if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                    EF1 = v_EF(idd);
                end
            end

            
        elseif n1*n0 < 0
            EFa = EF1;
            EFb = EF0;
            EFc = (EF1 + EF0)/2;
            v_EF = [EFa, EFb, EFc];
            EF2 = max( v_EF );
            EF0 = min( v_EF );
            for idd = 1:3
                if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                    EF1 = v_EF(idd);
                end
            end
%             v_EF(v_EF == EF0) = [];
%             v_EF(v_EF == EF2) = [];
%             EF1 = v_EF;
        end
        
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF0)./(kB*T_array(nT)/q0))+1)))) ;
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF0)./(kB*T_array(nT)/q0))+1))));
        n0 = abs(n_cond) - abs(n_val);
        
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF1)./(kB*T_array(nT)/q0))+1)))) ;
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF1)./(kB*T_array(nT)/q0))+1))));
        n1 = abs(n_cond) - abs(n_val);
        Delta_Ndummy = ((abs(n_cond)-abs(n_val))/abs(max([abs(n_val),abs(n_cond)])));
        
        n_val = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF2)./(kB*T_array(nT)/q0))+1)))) ;        
        n_cond = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF2)./(kB*T_array(nT)/q0))+1))));
        n2 = abs(n_cond) - abs(n_val);
            
    end
    EF_intrinsic = EF1;
    
    % add by force this level into the EF_array
    EF_array = [ EF_array(EF_array < EF_intrinsic) , EF_intrinsic, EF_array(EF_array > EF_intrinsic) ];
    
end


% control for peculiar band structures
if size(EF_array,2) == 1 
    if abs(EF_array) > max(abs(EF_array_entered)) % this should be the only case
        if size(EF_array_entered,2) < 3
            if EF_intrinsic > 0
                EF_array = [EF_array_entered, EF_array(1)-Estep,EF_array(1),EF_array(1)-Estep];
            else
                EF_array = [EF_array(1)-Estep,EF_array(1),EF_array(1)-Estep, EF_array_entered];
            end
        else
            if EF_intrinsic > 0
                EF_array = [EF_array_entered, EF_array_entered + EF_intrinsic];
            else
                EF_array = [ EF_array_entered + EF_intrinsic , EF_array_entered ];
            end
        end
    else
        if size(EF_array_entered,2) < 3
            EF_array = [EF_array(1)-Estep,EF_array(1),EF_array(1)-Estep];
        else
            EF_array = EF_array_entered + EF_array;
        end
    end
end

end