% Copyright 2022 Patrizio Graziosi, Neophytos Neophytou                   %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source and the author when publishing results      %
% obtained  using the present  code                                       %
%                                                                         %
% ----------------------------------------------------------------------- %


% this code computes the TDF properties


% in the first dimension, the E values run, 
% in the second dimension, the EF values run,
% in the third dimension, the T values run

% optionally, the band index runs in the second dimension and the rest is
% shifted

% NOTE 
% on 08/05/2019 I added some lines to consider the EF shift imposing that 
% EF_array becomes the EF_matrix column that corresponds at each 
% temperature, and other lines to consider that the maximum EF can be in the gap



function [TDF, TDF_n, TDF_ph, TDF_ph_n, TDF_sep, TDF_sep_n, MFP, MFP_n, MFP_ph, MFP_ph_n, MFP_sep, MFP_sep_n, tauE, tauE_n, tauE_ph, tauE_ph_n, tauE_sep, tauE_sep_n, tauE_IIS, tauE_IIS_n] =...
    TDF_composition_2D_ELECTRA(WorkSpace4, taus, taus_matth, taus_IIS, taus_POP) %#codegen
        
    % extraction of the data from the WorkSpace4 struct file
    state_ID = WorkSpace4.state_ID ;           % state ID struct and quantities
    Ek = WorkSpace4.Ek ;
    E_array = WorkSpace4.E_array ;
    T_array = WorkSpace4.T_array ;
    EF_array = WorkSpace4.EF_array ;
    EF_matrix = WorkSpace4.EF_matrix ;
    
    t = WorkSpace4.t ;

    n_bands_transp = WorkSpace4.n_bands_transp ;
    bands_transp = WorkSpace4.bands_transp ;

    ADP = WorkSpace4.ADP ;                          % scattering instructions
    ADP_IVS = WorkSpace4.ADP_IVS ;
    Alloy = WorkSpace4.Alloy ;
    ODP = WorkSpace4.ODP ;
    POP = WorkSpace4.POP ;
    screening_POP = WorkSpace4.screening_POP ;
    IVS = WorkSpace4.IVS ;
    IIS = WorkSpace4.IIS ;

    remove_matth = WorkSpace4.remove_matth ;

    sd = WorkSpace4.sd ;
    
    if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes') % scattering parameters, def. pot. e scatt. rate
        tau_pos_ADP = WorkSpace4.tau_pos_ADP ;  
    end
    if strcmp(ODP,'yes')
        tau_pos_ODP = WorkSpace4.tau_pos_ODP ;
    end
    if strcmp(IVS,'yes')
        tau_pos_IVS = WorkSpace4.tau_pos_IVS ;
    end
    if strcmp(POP,'yes')
        tau_pos_POP = WorkSpace4.tau_pos_POP ;
    end
    if strcmp(Alloy,'yes')
        tau_pos_Alloy = WorkSpace4.tau_pos_Alloy ;
    end
    

    q0=1.609e-19;             % [col]
    kB=1.38e-23;              % [J/K]
    
    
    % ---------------------------------------------------------------------
    
    
    % Inizialization of the output variables and struct data
    nE = size(E_array,2) ;
    
       
    TDF_n=struct(); TDF_ph_n=struct(); TDF_sep_n=struct(); MFP_n=struct(); MFP_ph_n=struct(); MFP_sep_n=struct(); tauE_n=struct(); tauE_ph_n=struct(); tauE_sep_n=struct(); tauE_IIS_n=struct();
    TDF=struct(); TDF_ph=struct(); TDF_sep=struct(); MFP=struct(); MFP_ph=struct(); MFP_sep=struct(); tauE=struct(); tauE_ph=struct(); tauE_sep=struct(); tauE_IIS=struct();
    
    
    % fields with the different bands
    TDF_n.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
    TDF_n.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_n.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));  
    MFP_n.x= zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
    tauE_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
    tauE_IIS_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_IIS_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
    
    TDF_sep_n.ADP=struct(); TDF_sep_n.ODP=struct(); TDF_sep_n.POP=struct(); TDF_sep_n.IVS=struct(); TDF_sep_n.Alloy=struct();
    TDF_sep.ADP=struct(); TDF_sep.ODP=struct(); TDF_sep.POP=struct(); TDF_sep.IVS=struct(); TDF_sep.Alloy=struct();
    tauE_sep_n.ADP=struct(); tauE_sep_n.ODP=struct(); tauE_sep_n.POP=struct(); tauE_sep_n.IVS=struct(); tauE_sep_n.Alloy=struct();
    tauE_sep.ADP=struct(); tauE_sep.ODP=struct(); tauE_sep.POP=struct(); tauE_sep.IVS=struct(); tauE_sep.Alloy=struct();
    MFP_sep_n.ADP=struct(); MFP_sep_n.ODP=struct(); MFP_sep_n.POP=struct(); MFP_sep_n.IVS=struct(); MFP_sep_n.Alloy=struct();
    MFP_sep.ADP=struct(); MFP_sep.ODP=struct(); MFP_sep.POP=struct(); MFP_sep.IVS=struct(); MFP_sep.Alloy=struct();
    
    TDF_sep_n.ADP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.yy = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ADP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ADP.yx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.ODP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.yy = zeros(nE,n_bands_transp,size(T_array,2)); 
    TDF_sep_n.ODP.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.ODP.yx = zeros(nE,n_bands_transp,size(T_array,2)); 
    TDF_sep_n.IVS.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.yy = zeros(nE,n_bands_transp,size(T_array,2)); 
    TDF_sep_n.IVS.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.IVS.yx = zeros(nE,n_bands_transp,size(T_array,2));
    TDF_sep_n.Alloy.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.yy = zeros(nE,n_bands_transp,size(T_array,2)); 
    TDF_sep_n.Alloy.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.Alloy.yx = zeros(nE,n_bands_transp,size(T_array,2)); 
    
    MFP_sep_n.ADP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ADP.y = zeros(nE,n_bands_transp,size(T_array,2)); 
    MFP_sep_n.ODP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.ODP.y = zeros(nE,n_bands_transp,size(T_array,2)); 
    MFP_sep_n.IVS.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.IVS.y = zeros(nE,n_bands_transp,size(T_array,2));
    MFP_sep_n.Alloy.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.Alloy.y = zeros(nE,n_bands_transp,size(T_array,2));
    
    tauE_sep_n.ADP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ADP.y = zeros(nE,n_bands_transp,size(T_array,2)); 
    tauE_sep_n.ODP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.ODP.y = zeros(nE,n_bands_transp,size(T_array,2)); 
    tauE_sep_n.IVS.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.IVS.y = zeros(nE,n_bands_transp,size(T_array,2)); 
    tauE_sep_n.Alloy.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.Alloy.y = zeros(nE,n_bands_transp,size(T_array,2)); 
    
    
    % fields after summed for the bands
    TDF.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.yy = zeros(nE,size(EF_array,2),size(T_array,2)); 
    TDF.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF.yx = zeros(nE,size(EF_array,2),size(T_array,2)); 
    MFP.x= zeros(nE,size(EF_array,2),size(T_array,2)); MFP.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
    tauE.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
    tauE_IIS.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_IIS.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
    
    TDF_sep.ADP.xx = zeros(nE,size(T_array,2)); TDF_sep.ADP.yy = zeros(nE,size(T_array,2)); 
    TDF_sep.ADP.xy = zeros(nE,size(T_array,2)); TDF_sep.ADP.yx = zeros(nE,size(T_array,2)); 
    TDF_sep.ODP.xx = zeros(nE,size(T_array,2)); TDF_sep.ODP.yy = zeros(nE,size(T_array,2)); 
    TDF_sep.ODP.xy = zeros(nE,size(T_array,2)); TDF_sep.ODP.yx = zeros(nE,size(T_array,2));
    TDF_sep.IVS.xx = zeros(nE,size(T_array,2)); TDF_sep.IVS.yy = zeros(nE,size(T_array,2)); 
    TDF_sep.IVS.xy = zeros(nE,size(T_array,2)); TDF_sep.IVS.yx = zeros(nE,size(T_array,2)); 
    TDF_sep.Alloy.xx = zeros(nE,size(T_array,2)); TDF_sep.Alloy.yy = zeros(nE,size(T_array,2));
    TDF_sep.Alloy.xy = zeros(nE,size(T_array,2)); TDF_sep.Alloy.yx = zeros(nE,size(T_array,2)); 
    
    MFP_sep.ADP.x = zeros(nE,size(T_array,2)); MFP_sep.ADP.y = zeros(nE,size(T_array,2)); 
    MFP_sep.ODP.x = zeros(nE,size(T_array,2)); MFP_sep.ODP.y = zeros(nE,size(T_array,2)); 
    MFP_sep.IVS.x = zeros(nE,size(T_array,2)); MFP_sep.IVS.y = zeros(nE,size(T_array,2)); 
    MFP_sep.Alloy.x = zeros(nE,size(T_array,2)); MFP_sep.Alloy.y = zeros(nE,size(T_array,2)); 
    
    tauE_sep.ADP.x = zeros(nE,size(T_array,2)); tauE_sep.ADP.y = zeros(nE,size(T_array,2)); 
    tauE_sep.ODP.x = zeros(nE,size(T_array,2)); tauE_sep.ODP.y = zeros(nE,size(T_array,2)); 
    tauE_sep.IVS.x = zeros(nE,size(T_array,2)); tauE_sep.IVS.y = zeros(nE,size(T_array,2)); 
    tauE_sep.Alloy.x = zeros(nE,size(T_array,2)); tauE_sep.Alloy.y = zeros(nE,size(T_array,2)); 
    
    
    % now, idem as above for POP and all but IIS (ph), separating according
    % if POP is screened or not
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_sep_n.POP.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
        TDF_sep_n.POP.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_sep_n.POP.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
        MFP_sep_n.POP.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_sep_n.POP.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
        tauE_sep_n.POP.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_sep_n.POP.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
               
        TDF_sep.POP.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.yy = zeros(nE,size(EF_array,2),size(T_array,2)); 
        TDF_sep.POP.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_sep.POP.yx = zeros(nE,size(EF_array,2),size(T_array,2)); 
        MFP_sep.POP.x = zeros(nE,size(EF_array,2),size(T_array,2)); MFP_sep.POP.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
        tauE_sep.POP.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_sep.POP.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
        
        TDF_ph_n.xx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.yy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
        TDF_ph_n.xy = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); TDF_ph_n.yx = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));
        MFP_ph_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); MFP_ph_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); 
        tauE_ph_n.x = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2)); tauE_ph_n.y = zeros(nE,n_bands_transp,size(EF_array,2),size(T_array,2));

        TDF_ph.xx = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.yy = zeros(nE,size(EF_array,2),size(T_array,2));
        TDF_ph.xy = zeros(nE,size(EF_array,2),size(T_array,2)); TDF_ph.yx = zeros(nE,size(EF_array,2),size(T_array,2)); 
        MFP_ph.x= zeros(nE,size(EF_array,2),size(T_array,2)); MFP_ph.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
        tauE_ph.x = zeros(nE,size(EF_array,2),size(T_array,2)); tauE_ph.y = zeros(nE,size(EF_array,2),size(T_array,2)); 
           
    else
        
        TDF_sep_n.POP.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.yy = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_sep_n.POP.xy = zeros(nE,n_bands_transp,size(T_array,2)); 
        TDF_sep_n.POP.yx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_sep_n.POP.zx = zeros(nE,n_bands_transp,size(T_array,2));
        MFP_sep_n.POP.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.POP.y = zeros(nE,n_bands_transp,size(T_array,2)); MFP_sep_n.POP.z = zeros(nE,n_bands_transp,size(T_array,2));
        tauE_sep_n.POP.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.POP.y = zeros(nE,n_bands_transp,size(T_array,2)); tauE_sep_n.POP.z = zeros(nE,n_bands_transp,size(T_array,2));
        
        TDF_sep.POP.xx = zeros(nE,size(T_array,2)); TDF_sep.POP.yy = zeros(nE,size(T_array,2)); 
        TDF_sep.POP.xy = zeros(nE,size(T_array,2)); TDF_sep.POP.yx = zeros(nE,size(T_array,2)); 
        MFP_sep.POP.x = zeros(nE,size(T_array,2)); MFP_sep.POP.y = zeros(nE,size(T_array,2)); 
        tauE_sep.POP.x = zeros(nE,size(T_array,2)); tauE_sep.POP.y = zeros(nE,size(T_array,2)); 
        
        TDF_ph_n.xx = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.yy = zeros(nE,n_bands_transp,size(T_array,2));
        TDF_ph_n.xy = zeros(nE,n_bands_transp,size(T_array,2)); TDF_ph_n.yx = zeros(nE,n_bands_transp,size(T_array,2));
        MFP_ph_n.x = zeros(nE,n_bands_transp,size(T_array,2)); MFP_ph_n.y = zeros(nE,n_bands_transp,size(T_array,2)); 
        tauE_ph_n.x = zeros(nE,n_bands_transp,size(T_array,2)); tauE_ph_n.y = zeros(nE,n_bands_transp,size(T_array,2)); 

        TDF_ph.xx = zeros(nE,size(T_array,2)); TDF_ph.yy = zeros(nE,size(T_array,2));
        TDF_ph.xy = zeros(nE,size(T_array,2)); TDF_ph.yx = zeros(nE,size(T_array,2)); 
        MFP_ph.x= zeros(nE,size(T_array,2)); MFP_ph.y = zeros(nE,size(T_array,2));
        tauE_ph.x = zeros(nE,size(T_array,2)); tauE_ph.y = zeros(nE,size(T_array,2)); 
        
    end
    
    
    % ---------------------------------------------------------------------
    % End of the inizialitions of all the output struct data types etc. 
    
    
    
    
%     Calculation of the Transport Density Fnction, 1D array with the TDF values,
%     the size is the same of the E_array
%     if strcmp(dimensionality,'3D')

        if strcmp(IIS,'yes')
            for id_E=1:size(E_array,2) %parfor
                for id_n=1:n_bands_transp 
                    for id_EF = 1:size(EF_array,2)
                        for id_T = 1:size(T_array,2)
                            EF_array = EF_matrix(:,id_T)';
    %                         if E_array(id_E) < max(EF_array)+6*kB*T_array(iT)/q0
                            if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0 ) || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 ) 
                               % it takes all the energies for which a value has been calculated
                    % contribution of each k point with energy E, for all the bands
                    % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                    % length corresponding to the number of points in that state,
                    % each array state_ID(id_E,id_n) have different length
                                if not(size(taus_IIS(id_E,id_n).x)) == 0 % the state is not empty
                                    if size(T_array,2) == 1

                                        tau_IIS_x_temp = squeeze(taus_IIS(id_E,id_n).x(id_EF,:)) ;
                                        tau_IIS_y_temp = squeeze(taus_IIS(id_E,id_n).y(id_EF,:)) ;
                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                                tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                                tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                                [~,Nzero] = find(~tau_POP_x_temp) ;
                                                tau_POP_x_temp(Nzero) = Inf ;
                                                [~,Nzero] = find(~tau_POP_y_temp) ;
                                                tau_POP_y_temp(Nzero) = Inf ;
                                        end
                                    else
                                        tau_IIS_x_temp = smooth( squeeze(taus_IIS(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                        tau_IIS_y_temp = smooth( squeeze(taus_IIS(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                            
                                                tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                                tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                                [~,Nzero] = find(~tau_POP_x_temp) ;
                                                tau_POP_x_temp(Nzero) = Inf ;
                                                [~,Nzero] = find(~tau_POP_y_temp) ;
                                                tau_POP_y_temp(Nzero) = Inf ;
                                        end
                                    end
                                    [~,Nzero] = find(~tau_IIS_x_temp) ;
                                    tau_IIS_x_temp(Nzero) = Inf ;
                                    [~,Nzero] = find(~tau_IIS_y_temp) ;
                                    tau_IIS_y_temp(Nzero) = Inf ;
                                else
                                    tau_IIS_x_temp = [];
                                    tau_IIS_y_temp = [];
                                    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            tau_POP_x_temp = [];
                                            tau_POP_y_temp = [];
                                    end
                                end


                                if not(size(taus_matth(id_E,id_n).x)) == 0  % the state is involved in the transport (not empty)                                
                                    if strcmp(remove_matth,'yes') % "neutralize" the taus_matth in the case it is not needed
                                        if size(T_array,2) == 1
                                            taus_matth(id_E,id_n).x(:) = Inf; 
                                            taus_matth(id_E,id_n).y(:) = Inf; 
                                        else
                                            taus_matth(id_E,id_n).x(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).y(:,id_T) = Inf ; 
                                        end
                                    end

                                    if size(T_array,2) == 1

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF) = ( sum( tau_IIS_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                            tauE_IIS_n.y(id_E,id_n,id_EF) = ( sum( tau_IIS_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );


                                        else

                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF) = ( sum( tau_IIS_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) ); % 1./sum( 1./(tau_IIS_x_temp .* state_ID(id_E,id_n).DOS )) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_IIS_n.y(id_E,id_n,id_EF) = ( sum( tau_IIS_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );


                                        end                                    


                                    else % more than one T

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')

                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                1./tau_IIS_x_temp + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                1./tau_IIS_y_temp + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF,id_T) = ( sum( tau_IIS_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                            tauE_IIS_n.y(id_E,id_n,id_EF,id_T) = ( sum( tau_IIS_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );


                                        else

                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_IIS_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_IIS_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                1./tau_IIS_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                1./tau_IIS_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_IIS_n.x(id_E,id_n,id_EF,id_T) = ( sum( tau_IIS_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                            tauE_IIS_n.y(id_E,id_n,id_EF,id_T) = ( sum( tau_IIS_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS) );

                                        end
                                    end
                                end
                            end
                        end
                    end
                end           
            end
            TDF.xx = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.xx,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            TDF.yy = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.yy,2)); % TDF = TDF(E,EF,T)
            TDF.xy = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.xy,2));
            TDF.yx = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.yx,2));


            MFP.x = squeeze(mean(abs(MFP_n.x),2));
            MFP.y = squeeze(mean(abs(MFP_n.y),2));

            tauE.x = squeeze(sum(tauE_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE.y = squeeze(sum(tauE_n.y,2)); % tauE = tauE(E,EF,T)
            tauE_IIS.x = squeeze(sum(tauE_IIS_n.x,2)); 
            tauE_IIS.y = squeeze(sum(tauE_IIS_n.y,2)); 

            % controls over TDFs
            Ninf = isinf(TDF.xx); TDF.xx(Ninf) = 0; NNan = isnan(TDF.xx); TDF.xx(NNan) = 0;
            Ninf = isinf(TDF.yy); TDF.yy(Ninf) = 0; NNan = isnan(TDF.yy); TDF.yy(NNan) = 0;
            Ninf = isinf(TDF.xy); TDF.xy(Ninf) = 0; NNan = isnan(TDF.xy); TDF.xy(NNan) = 0;
            Ninf = isinf(TDF.yx); TDF.yx(Ninf) = 0; NNan = isnan(TDF.yx); TDF.yx(NNan) = 0;


        else % no IIS 

            for id_E=1:size(E_array,2) %parfor
                for id_n=1:n_bands_transp 
                    for id_EF = 1:size(EF_array,2)
                        for id_T = 1:size(T_array,2)
                            EF_array = EF_matrix(:,id_T)';
                            if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )
                                % it takes all the energies for which a value has been calculated
                    % contribution of each k point with energy E, for all the bands
                    % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                    % length corresponding to the number of points in that state,
                    % each array state_ID(id_E,id_n) have different length
                    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                        
                        if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                    if size(T_array,2) == 1
                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                    else                                            
                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                    end
                                    [~,Nzero] = find(~tau_POP_x_temp) ;
                                    tau_POP_x_temp(Nzero) = Inf ;
                                    [~,Nzero] = find(~tau_POP_y_temp) ;
                                    tau_POP_y_temp(Nzero) = Inf ;
                        else
                                    tau_POP_x_temp = [];
                                    tau_POP_y_temp = [];
                        end
                    end


                                if not(size(taus_matth(id_E,id_n).x)) == 0  % the state is involved in the transport
                                    if strcmp(remove_matth,'yes') % "neutralize" the taus_matth in the case it is not needed
                                        if size(T_array,2) == 1
                                            taus_matth(id_E,id_n).x(:) = Inf; 
                                            taus_matth(id_E,id_n).y(:) = Inf; 
                                            taus_matth(id_E,id_n).z(:) = Inf; 
                                        else
                                            taus_matth(id_E,id_n).x(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).y(:,id_T) = Inf ; 
                                            taus_matth(id_E,id_n).z(:,id_T) = Inf ; 
                                        end
                                    end

                                    if size(T_array,2) == 1

                                         if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                               + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                            tauE_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                         else     
                                             
                                            NInf=isinf(taus_matth(id_E,id_n).x); % remove the points to avoid TDF = 0
                                            taus_matth(id_E,id_n).x(NInf)=0;
                                            NInf=isinf(taus_matth(id_E,id_n).y);
                                            taus_matth(id_E,id_n).y(NInf)=0;

                                            TDF_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x ...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y ...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x ...
                                                .*state_ID(id_E,id_n).DOS);

                                            MFP_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.x(id_E,id_n,id_EF) = sum( taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            tauE_n.y(id_E,id_n,id_EF) = sum( taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                         end

                                    else % more temperature values

                                        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                        
                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                      


                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                        else
                                            
                                            NInf=isinf(taus_matth(id_E,id_n).x); % remove the points to avoid TDF = 0
                                            taus_matth(id_E,id_n).x(NInf)=0;
                                            NInf=isinf(taus_matth(id_E,id_n).y);
                                            taus_matth(id_E,id_n).y(NInf)=0;

                                            TDF_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)'...
                                            .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)'...
                                                .* state_ID(id_E,id_n).DOS); 

                                            TDF_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            TDF_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x(:,id_T)' ...
                                                .*state_ID(id_E,id_n).DOS);

                                            MFP_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                            MFP_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                            tauE_n.x(id_E,id_n,id_EF,id_T) = sum( taus_matth(id_E,id_n).x(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            tauE_n.y(id_E,id_n,id_EF,id_T) = sum( taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                        end   
                                    end
                                end
                            end
                        end
                    end
                end           
            end
            TDF.xx = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.xx,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            TDF.yy = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.yy,2));
            TDF.xy = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.xy,2));
            TDF.yx = 1/t * (sd/((2*pi)^2)).*squeeze(sum(TDF_n.yx,2));


            MFP.x = squeeze(mean(abs(MFP_n.x),2));
            MFP.y = squeeze(mean(abs(MFP_n.y),2));

            tauE.x = squeeze(sum(tauE_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE.y = squeeze(sum(tauE_n.y,2)); % tauE = tauE(E,EF,T)

            % controls over TDFs
            Ninf = isinf(TDF.xx); TDF.xx(Ninf) = 0; NNan = isnan(TDF.xx); TDF.xx(NNan) = 0;
            Ninf = isinf(TDF.yy); TDF.yy(Ninf) = 0; NNan = isnan(TDF.yy); TDF.yy(NNan) = 0;
            Ninf = isinf(TDF.xy); TDF.xy(Ninf) = 0; NNan = isnan(TDF.xy); TDF.xy(NNan) = 0;
            Ninf = isinf(TDF.yx); TDF.yx(Ninf) = 0; NNan = isnan(TDF.yx); TDF.yx(NNan) = 0;
        end

% Denoising the E-dependent quantities
        for ii_EF = 1:size(EF_array,2)
            for ii_T = 1:size(T_array,2)
                    
                    A = abs( TDF.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yy(:,ii_EF,ii_T) = A1 ;                    
                    A = abs( TDF.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.xy(:,ii_EF,ii_T) = A1 ;                    
                    A = abs( TDF.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF.yx(:,ii_EF,ii_T) = A1 ;                    
                    
                    A = abs( MFP.x(:,ii_EF,ii_T) ) ;
                    A1 = MFP.x(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP.y(:,ii_EF,ii_T) ) ;
                    A1 = MFP.y(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP.y(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( tauE.x(:,ii_EF,ii_T) ) ;
                    A1 = tauE.x(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end                    
                    tauE.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE.y(:,ii_EF,ii_T) ) ;
                    A1 = tauE.y(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE.y(:,ii_EF,ii_T) = A1 ;                    
                    if strcmp(IIS,'yes')
                        A = abs( tauE_IIS.x(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.x(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.x(:,ii_EF,ii_T) = A1 ;
                        A = abs( tauE_IIS.y(:,ii_EF,ii_T) ) ;
                        A1 = tauE_IIS.y(:,ii_EF,ii_T) ;
                        for ii = 5:size(A,1)-5
                        if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                            A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                        end
                        end
                        tauE_IIS.y(:,ii_EF,ii_T) = A1 ;                        
                    end
                    
            end
        end



    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------


    
    % ---------------------------------------------------------------------
    % ------------------- WITHOUT IMPURITIES ------------------------------
    % for the calculations without impurities I use a different Fermi array
        
   
    
    % -------------  ADP only ---------------------------------------------
    if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes')
        
 
        for id_E = size(E_array,2):-1:1 
            for id_n = n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauADP ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).x(tau_pos_ADP,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ADP,NNan,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_ADP,:,id_T)); % for the other scatt. mech. this control is into the subfunctions
                    taus(id_E,id_n).x(tau_pos_ADP,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_ADP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ADP,NInf,id_T)=0;               
                    %------------------------------------------
                        TDF_sep_n.ADP.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ADP.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ADP.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_ADP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS

                        MFP_sep_n.ADP.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_ADP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.ADP.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_ADP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.ADP.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ADP.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_ADP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                end
                    end

                end
            end            
        end
        TDF_sep.ADP.xx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ADP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.ADP.yy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ADP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ADP.xy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ADP.xy,2)); % it sums the contribution of the bands
        TDF_sep.ADP.yx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ADP.yx,2)); % it sums the contribution of the bands
        Ninf = isinf(TDF_sep.ADP.xx); TDF_sep.ADP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xx); TDF_sep.ADP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yy); TDF_sep.ADP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yy); TDF_sep.ADP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.xy); TDF_sep.ADP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.xy); TDF_sep.ADP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep.ADP.yx); TDF_sep.ADP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep.ADP.yx); TDF_sep.ADP.yx(NNan) = 0;

        MFP_sep.ADP.x = squeeze(mean(abs(MFP_sep_n.ADP.x),2));
        MFP_sep.ADP.y = squeeze(mean(abs(MFP_sep_n.ADP.y),2));

        tauE_sep.ADP.x = squeeze(sum(tauE_sep_n.ADP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.ADP.y = squeeze(sum(tauE_sep_n.ADP.y,2)); % tauE = tauE(E,EF,T)


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.ADP.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ADP.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yy(:,ii_T) = A1 ;           
            A = abs( TDF_sep.ADP.xy(:,ii_T) ) ;
            A1 = TDF_sep.ADP.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.xy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.ADP.yx(:,ii_T) ) ;
            A1 = TDF_sep.ADP.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ADP.yx(:,ii_T) = A1 ;
                       
            A = abs( MFP_sep.ADP.x(:,ii_T) ) ;
            A1 = MFP_sep.ADP.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.ADP.x(:,ii_T) = A1 ;
            A = abs( MFP_sep.ADP.y(:,ii_T) ) ;
            A1 = MFP_sep.ADP.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.ADP.y(:,ii_T) = A1 ;
            
            A = abs( tauE_sep.ADP.x(:,ii_T) ) ;
            A1 = tauE_sep.ADP.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.ADP.x(:,ii_T) = A1 ;
            A = abs( tauE_sep.ADP.y(:,ii_T) ) ;
            A1 = tauE_sep.ADP.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.ADP.y(:,ii_T) = A1 ;            

        end

    end
    % --------------------------------------------------------------------------------------------------------


    % ---------  ODP only -----------------------------------------------------
    if strcmp(ODP,'yes')


        for id_E=size(E_array,2):-1:1 %parfor
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauODP ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).x(tau_pos_ODP,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ODP,NNan,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).x(tau_pos_ODP,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_ODP,:,id_T));
                    taus(id_E,id_n).y(tau_pos_ODP,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.ODP.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.ODP.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.ODP.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_ODP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS

                        MFP_sep_n.ODP.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_ODP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.ODP.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_ODP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.ODP.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.ODP.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_ODP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.ODP.xx); TDF_sep_n.ODP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.xx); TDF_sep_n.ODP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.yy); TDF_sep_n.ODP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.yy); TDF_sep_n.ODP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.ODP.xy); TDF_sep_n.ODP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.xy); TDF_sep_n.ODP.xy(NNan) = 0;        
        Ninf = isinf(TDF_sep_n.ODP.yx); TDF_sep_n.ODP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.ODP.yx); TDF_sep_n.ODP.yx(NNan) = 0;
        TDF_sep.ODP.xx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ODP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.ODP.yy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ODP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.ODP.xy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ODP.xy,2)); % it sums the contribution of the bands
        TDF_sep.ODP.yx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.ODP.yx,2)); % it sums the contribution of the bands
        
        MFP_sep.ODP.x = squeeze(mean(abs(MFP_sep_n.ODP.x),2));
        MFP_sep.ODP.y = squeeze(mean(abs(MFP_sep_n.ODP.y),2));

        tauE_sep.ODP.x = squeeze(sum(tauE_sep_n.ODP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.ODP.y = squeeze(sum(tauE_sep_n.ODP.y,2)); % tauE = tauE(E,EF,T)


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.ODP.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.ODP.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.ODP.xy(:,ii_T) ) ;
            A1 = TDF_sep.ODP.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.xy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.ODP.yx(:,ii_T) ) ;
            A1 = TDF_sep.ODP.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.ODP.yx(:,ii_T) = A1 ;            

            A = abs( MFP_sep.ODP.x(:,ii_T) ) ;
            A1 = MFP_sep.ODP.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.ODP.x(:,ii_T) = A1 ;
            A = abs( MFP_sep.ODP.y(:,ii_T) ) ;
            A1 = MFP_sep.ODP.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.ODP.y(:,ii_T) = A1 ;
           
            A = abs( tauE_sep.ODP.x(:,ii_T) ) ;
            A1 = tauE_sep.ODP.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.ODP.x(:,ii_T) = A1 ;
            A = abs( tauE_sep.ODP.y(:,ii_T) ) ;
            A1 = tauE_sep.ODP.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.ODP.y(:,ii_T) = A1 ;            

        end
        
    end
    % --------------------------------------------------------------------------------

    % ---------  IVS only -----------------------------------------------------
    if strcmp(IVS,'yes')
       
        
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauIVS ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).x(tau_pos_IVS,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).y(tau_pos_IVS,NNan,id_T)=0;             
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).x(tau_pos_IVS,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_IVS,:,id_T));
                    taus(id_E,id_n).y(tau_pos_IVS,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.IVS.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.IVS.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.IVS.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS);
                        TDF_sep_n.IVS.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_IVS,:,id_T).*state_ID(id_E,id_n).DOS); 

                        MFP_sep_n.IVS.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_IVS,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.IVS.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_IVS,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.IVS.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.IVS.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_IVS,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.IVS.xx); TDF_sep_n.IVS.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.xx); TDF_sep_n.IVS.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.yy); TDF_sep_n.IVS.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.yy); TDF_sep_n.IVS.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.xy); TDF_sep_n.IVS.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.xy); TDF_sep_n.IVS.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.IVS.yx); TDF_sep_n.IVS.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.IVS.yx); TDF_sep_n.IVS.yx(NNan) = 0;
        TDF_sep.IVS.xx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.IVS.xx ,2)); % it sums the contribution of the bands
        TDF_sep.IVS.yy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.IVS.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.IVS.xy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.IVS.xy,2)); % it sums the contribution of the bands
        TDF_sep.IVS.yx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.IVS.yx,2)); 
        
        MFP_sep.IVS.x = squeeze(mean(abs(MFP_sep_n.IVS.x),2));
        MFP_sep.IVS.y = squeeze(mean(abs(MFP_sep_n.IVS.y),2));

        tauE_sep.IVS.x = squeeze(sum(tauE_sep_n.IVS.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.IVS.y = squeeze(sum(tauE_sep_n.IVS.y,2)); % tauE = tauE(E,EF,T)


        for ii_T = 1:size(T_array,2)
            
            A = abs( TDF_sep.IVS.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.IVS.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.IVS.xy(:,ii_T) ) ;
            A1 = TDF_sep.IVS.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.xy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.IVS.yx(:,ii_T) ) ;
            A1 = TDF_sep.IVS.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.IVS.yx(:,ii_T) = A1 ;
                        
            
            A = abs( MFP_sep.IVS.x(:,ii_T) ) ;
            A1 = MFP_sep.IVS.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.IVS.x(:,ii_T) = A1 ;
            A = abs( MFP_sep.IVS.y(:,ii_T) ) ;
            A1 = MFP_sep.IVS.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.IVS.y(:,ii_T) = A1 ;
            
            A = abs( tauE_sep.IVS.x(:,ii_T) ) ;
            A1 = tauE_sep.IVS.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.IVS.x(:,ii_T) = A1 ;
            A = abs( tauE_sep.IVS.y(:,ii_T) ) ;
            A1 = tauE_sep.IVS.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.IVS.y(:,ii_T) = A1 ;
            
        end
       

    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  POP only -----------------------------------------------------
    if strcmp(POP,'yes') 
        if strcmp(screening_POP,'no')
            
            for id_E=size(E_array,2):-1:1 %parfor
                for id_n=n_bands_transp:-1:1
                    if not(size(taus(id_E,id_n).x)) == 0
                        for id_T = size(T_array,2):-1:1
                            EF_array = EF_matrix(:,id_T)';
                                    if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )

                        % ------------------------- add a control over tauPOP ------
                        NNan=isnan(taus(id_E,id_n).x(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).x(tau_pos_POP,NNan,id_T)=0;
                        NNan=isnan(taus(id_E,id_n).y(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).y(tau_pos_POP,NNan,id_T)=0;
                        NInf=isinf(taus(id_E,id_n).x(tau_pos_POP,:,id_T)); % for the other scatt. mech. this control is into the subfunctions
                        taus(id_E,id_n).x(tau_pos_POP,NInf,id_T)=0;
                        NInf=isinf(taus(id_E,id_n).y(tau_pos_POP,:,id_T));
                        taus(id_E,id_n).y(tau_pos_POP,NInf,id_T)=0;
                        %------------------------------------------
                        TDF_sep_n.POP.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_POP,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS

                        MFP_sep_n.POP.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_POP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.POP.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_POP,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.POP.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_POP,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);   
                        
                                    end
                        end
                    end
                end            
            end
            Ninf = isinf(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(NNan) = 0;
            Ninf = isinf(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(Ninf) = 0;
            NNan = isnan(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(NNan) = 0;
            TDF_sep.POP.xx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.xx ,2)); % it sums the contribution of the bands
            TDF_sep.POP.yy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.yy ,2)); % the dSk elemnts is already in the DOS
            TDF_sep.POP.xy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.xy,2));
            TDF_sep.POP.yx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.yx,2));

            MFP_sep.POP.x = squeeze(mean(abs(MFP_sep_n.POP.x),2));
            MFP_sep.POP.y = squeeze(mean(abs(MFP_sep_n.POP.y),2));

            tauE_sep.POP.x = squeeze(sum(tauE_sep_n.POP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
            tauE_sep.POP.y = squeeze(sum(tauE_sep_n.POP.y,2)); % tauE = tauE(E,EF,T)


           for ii_T = 1:size(T_array,2)
                    
                A = abs( TDF_sep.POP.xx(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  3 * ( A(ii-4) + A(ii+4) )/2
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.xx(:,ii_T) = A1 ;
                A = abs( TDF_sep.POP.yy(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.yy(:,ii_T) = A1 ;                
                A = abs( TDF_sep.POP.xy(:,ii_T) ) ;
                A1 = TDF_sep.POP.xy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.xy(:,ii_T) = A1 ;                
                A = abs( TDF_sep.POP.yx(:,ii_T) ) ;
                A1 = TDF_sep.POP.yx(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_sep.POP.yx(:,ii_T) = A1 ;
                                
                A = abs( MFP_sep.POP.x(:,ii_T) ) ;
                A1 = MFP_sep.POP.x(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                MFP_sep.POP.x(:,ii_T) = A1 ;
                A = abs( MFP_sep.POP.y(:,ii_T) ) ;
                A1 = MFP_sep.POP.y(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                MFP_sep.POP.y(:,ii_T) = A1 ;
                
                A = abs( tauE_sep.POP.x(:,ii_T) ) ;
                A1 = tauE_sep.POP.x(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                tauE_sep.POP.x(:,ii_T) = A1 ;
                A = abs( tauE_sep.POP.y(:,ii_T) ) ;
                A1 = tauE_sep.POP.y(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                tauE_sep.POP.y(:,ii_T) = A1 ;
                
            end            


        elseif strcmp(screening_POP,'yes')

          
        for id_E=size(E_array,2):-1:1 %parfor
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_EF = 1:size(EF_array,2)
                        for id_T = size(T_array,2):-1:1
                            EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauPOP ------
                    if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                if size(T_array,2) == 1
                                    tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                    tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                else                                            
                                    tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                    tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                end
                                NNan=isnan(tau_POP_x_temp);
                                tau_POP_x_temp(NNan)=0;
                                NNan=isnan(tau_POP_y_temp);
                                tau_POP_y_temp(NNan)=0;
                                NInf=isinf(tau_POP_x_temp);
                                tau_POP_x_temp(NInf)=0;
                                NInf=isinf(tau_POP_y_temp);
                                tau_POP_y_temp(NInf)=0;
                    else
                                tau_POP_x_temp = [];
                                tau_POP_y_temp = [];
                    end
                    %------------------------------------------
                        TDF_sep_n.POP.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.POP.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*tau_POP_y_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.POP.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*tau_POP_x_temp .*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS

                        MFP_sep_n.POP.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* tau_POP_x_temp ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.POP.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* tau_POP_y_temp ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.POP.x(id_E,id_n,id_EF,id_T) = sum( tau_POP_x_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.POP.y(id_E,id_n,id_EF,id_T) = sum( tau_POP_y_temp .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        

                                end
                        end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.xx); TDF_sep_n.POP.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.yy); TDF_sep_n.POP.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.xy); TDF_sep_n.POP.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.POP.yx); TDF_sep_n.POP.yx(NNan) = 0;
        
        TDF_sep.POP.xx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.xx ,2)); % it sums the contribution of the bands
        TDF_sep.POP.yy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.POP.xy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.xy,2));
        TDF_sep.POP.yx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.POP.yx,2));


        MFP_sep.POP.x = squeeze(mean(abs(MFP_sep_n.POP.x),2));
        MFP_sep.POP.y = squeeze(mean(abs(MFP_sep_n.POP.y),2));

        tauE_sep.POP.x = squeeze(sum(tauE_sep_n.POP.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.POP.y = squeeze(sum(tauE_sep_n.POP.y,2)); % tauE = tauE(E,EF,T)

        for ii_T = 1:size(T_array,2)
            for ii_EF = 1:size(EF_array,2)
                
                 
                    A = abs( TDF_sep.POP.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_sep.POP.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yy(:,ii_EF,ii_T) = A1 ;                    
                    A = abs( TDF_sep.POP.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.xy(:,ii_EF,ii_T) = A1 ;                    
                    A = abs( TDF_sep.POP.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_sep.POP.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_sep.POP.yx(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( MFP_sep.POP.x(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP_sep.POP.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP_sep.POP.y(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP_sep.POP.y(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( tauE_sep.POP.x(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE_sep.POP.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE_sep.POP.y(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE_sep.POP.y(:,ii_EF,ii_T) = A1 ;
                
            end
        end


        end
        
    end
    % --------------------------------------------------------------------------------------------------------

    % ---------  Alloy only -----------------------------------------------------
    if strcmp(Alloy,'yes')
       
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                if not(size(taus(id_E,id_n).x)) == 0
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )

                    % ------------------------- add a control over tauAlloy ------
                    NNan=isnan(taus(id_E,id_n).x(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).x(tau_pos_Alloy,NNan,id_T)=0;
                    NNan=isnan(taus(id_E,id_n).y(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).y(tau_pos_Alloy,NNan,id_T)=0;             
                    NInf=isinf(taus(id_E,id_n).x(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).x(tau_pos_Alloy,NInf,id_T)=0;
                    NInf=isinf(taus(id_E,id_n).y(tau_pos_Alloy,:,id_T));
                    taus(id_E,id_n).y(tau_pos_Alloy,NInf,id_T)=0;
                    %------------------------------------------
                        TDF_sep_n.Alloy.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_x.*taus(id_E,id_n).x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y.*state_ID(id_E,id_n).v_y.*taus(id_E,id_n).y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the dSk element is already in the DOS
                        TDF_sep_n.Alloy.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).y(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS
                        TDF_sep_n.Alloy.yx(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .*taus(id_E,id_n).x(tau_pos_Alloy,:,id_T).*state_ID(id_E,id_n).DOS); % the sum is the surface integral on the ellipsoid(E) for the n_band as the dSk element is included in the DOS

                        MFP_sep_n.Alloy.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus(id_E,id_n).x(tau_pos_Alloy,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                        MFP_sep_n.Alloy.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus(id_E,id_n).y(tau_pos_Alloy,:,id_T) ) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                        tauE_sep_n.Alloy.x(id_E,id_n,id_T) = sum( taus(id_E,id_n).x(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                        tauE_sep_n.Alloy.y(id_E,id_n,id_T) = sum( taus(id_E,id_n).y(tau_pos_Alloy,:,id_T) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                end
                    end
                end
            end            
        end
        Ninf = isinf(TDF_sep_n.Alloy.xx); TDF_sep_n.Alloy.xx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.xx); TDF_sep_n.Alloy.xx(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.yy); TDF_sep_n.Alloy.yy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.yy); TDF_sep_n.Alloy.yy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.xy); TDF_sep_n.Alloy.xy(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.xy); TDF_sep_n.Alloy.xy(NNan) = 0;
        Ninf = isinf(TDF_sep_n.Alloy.yx); TDF_sep_n.Alloy.yx(Ninf) = 0;
        NNan = isnan(TDF_sep_n.Alloy.yx); TDF_sep_n.Alloy.yx(NNan) = 0;
        TDF_sep.Alloy.xx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.Alloy.xx ,2)); % it sums the contribution of the bands
        TDF_sep.Alloy.yy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.Alloy.yy ,2)); % the dSk elemnts is already in the DOS
        TDF_sep.Alloy.xy = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.Alloy.xy,2));
        TDF_sep.Alloy.yx = 1/t * (sd/(4*pi^2))*squeeze(sum(TDF_sep_n.Alloy.yx,2));         

        MFP_sep.Alloy.x = squeeze(mean(abs(MFP_sep_n.Alloy.x),2));
        MFP_sep.Alloy.y = squeeze(mean(abs(MFP_sep_n.Alloy.y),2));

        tauE_sep.Alloy.x = squeeze(sum(tauE_sep_n.Alloy.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_sep.Alloy.y = squeeze(sum(tauE_sep_n.Alloy.y,2)); % tauE = tauE(E,EF,T)
        
        
         for ii_T = 1:size(T_array,2)
            A = abs( TDF_sep.Alloy.xx(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xx(:,ii_T) = A1 ;
            A = abs( TDF_sep.Alloy.yy(:,ii_T) ) ;
            A1 = A;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.Alloy.xy(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.xy(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.xy(:,ii_T) = A1 ;            
            A = abs( TDF_sep.Alloy.yx(:,ii_T) ) ;
            A1 = TDF_sep.Alloy.yx(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            TDF_sep.Alloy.yx(:,ii_T) = A1 ;
            
            A = abs( MFP_sep.Alloy.x(:,ii_T) ) ;
            A1 = MFP_sep.Alloy.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.Alloy.x(:,ii_T) = A1 ;
            A = abs( MFP_sep.Alloy.y(:,ii_T) ) ;
            A1 = MFP_sep.Alloy.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            MFP_sep.Alloy.y(:,ii_T) = A1 ;
            
            A = abs( tauE_sep.Alloy.x(:,ii_T) ) ;
            A1 = tauE_sep.Alloy.x(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.Alloy.x(:,ii_T) = A1 ;
            A = abs( tauE_sep.Alloy.y(:,ii_T) ) ;
            A1 = tauE_sep.Alloy.y(:,ii_T) ;
            for ii = 5:size(A,1)-5
            if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                A1(ii) = ( A(ii-4) + A(ii+4) )/2;
            end
            end
            tauE_sep.Alloy.y(:,ii_T) = A1 ;
            
        end
        

    end
    % ---------------------------------------------------------------------
    % ---------------------------------------------------------------------

    
    
    % ---------  phonons (all) only @ all T--------------------------------
    % ---------------------------------------------------------------------
         
        for id_E=size(E_array,2):-1:1 
            for id_n=n_bands_transp:-1:1
                    for id_T = size(T_array,2):-1:1
                        EF_array = EF_matrix(:,id_T)';
                                if ( E_array(id_E) < max(EF_array)+6*kB*max(T_array)/q0)  || ( max(EF_array) < min(min(Ek(:,:,bands_transp(id_n)))) && E_array(id_E) < min(min(Ek(:,:,bands_transp(id_n)))) + 6*kB*max(T_array)/q0 )
                                    % it takes all the energies for which a value has been calculated
                        % contribution of each k point with energy E, for all the bands
                        % the state_ID(id_E,id_n) is an array of DOS, v, etc. having a
                        % length corresponding to the number of points in that state,
                        % each array state_ID(id_E,id_n) have different length
                                    if not(size(taus_matth(id_E,id_n).x)) == 0   % the state is involved in the transport

                                        if size(T_array,2) == 1

                                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')                                            

                                                for id_EF = size(EF_array,2):-1:1
                                                    
                                                    if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,:)) ,2)' ;
                                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,:)) ,2)' ;
                                                    else
                                                        tau_POP_x_temp = [];
                                                        tau_POP_y_temp = [];
                                                    end

                                                    TDF_ph_n.xx(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                       + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yy(id_E,id_n,id_EF) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);                                                     

                                                    TDF_ph_n.xy(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);
                                                    
                                                    TDF_ph_n.yx(id_E,id_n,id_EF) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                                    MFP_ph_n.x(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    MFP_ph_n.y(id_E,id_n,id_EF) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);


                                                    tauE_ph_n.x(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).x +...
                                                        + 1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_ph_n.y(id_E,id_n,id_EF) = sum( (1./taus_matth(id_E,id_n).y +...
                                                        + 1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                end
                                            else
                                                
                                                NInf=isinf(taus_matth(id_E,id_n).x); % remove the points to avoid TDF = 0
                                                taus_matth(id_E,id_n).x(NInf)=0;
                                                NInf=isinf(taus_matth(id_E,id_n).y);
                                                taus_matth(id_E,id_n).y(NInf)=0;
                                                
                                                TDF_ph_n.xx(id_E,id_n) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.yy(id_E,id_n) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y ...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.xy(id_E,id_n) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS);
                                                TDF_ph_n.yx(id_E,id_n) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS);


                                                MFP_ph_n.x(id_E,id_n) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                MFP_ph_n.y(id_E,id_n) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                tauE_ph_n.x(id_E,id_n) = sum( taus_matth(id_E,id_n).x .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_ph_n.y(id_E,id_n) = sum( taus_matth(id_E,id_n).y .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            end
                                        else % more T values
                                            if strcmp(POP,'yes') && strcmp(screening_POP,'yes')  

                                                for id_EF = size(EF_array,2):-1:1
                                                    
                                                    if not(size(taus_POP(id_E,id_n).x)) == 0   % the state is not empty
                                                        tau_POP_x_temp = smooth( squeeze(taus_POP(id_E,id_n).x(id_EF,id_T,:)) ,2)' ;
                                                        tau_POP_y_temp = smooth( squeeze(taus_POP(id_E,id_n).y(id_EF,id_T,:)) ,2)' ;
                                                    else
                                                        tau_POP_x_temp = [];
                                                        tau_POP_y_temp = [];
                                                    end

                                                    TDF_ph_n.xx(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yy(id_E,id_n,id_EF,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.xy(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS);

                                                    TDF_ph_n.yx(id_E,id_n,id_EF,id_T) = sum( state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS);


                                                    MFP_ph_n.x(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* (1./taus_matth(id_E,id_n).x(:,id_T)'+...
                                                        1./tau_POP_x_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    MFP_ph_n.y(id_E,id_n,id_EF,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* (1./taus_matth(id_E,id_n).y(:,id_T)'+...
                                                        1./tau_POP_y_temp).^(-1)) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                     

                                                    tauE_ph_n.x(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).x(:,id_T)' +...
                                                        1./tau_POP_x_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                    tauE_ph_n.y(id_E,id_n,id_EF,id_T) = sum( (1./taus_matth(id_E,id_n).y(:,id_T)' +...
                                                        1./tau_POP_y_temp).^(-1) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                end

                                            else
                                                
                                                NInf=isinf(taus_matth(id_E,id_n).x); % remove the points to avoid TDF = 0
                                                taus_matth(id_E,id_n).x(NInf)=0;
                                                NInf=isinf(taus_matth(id_E,id_n).y);
                                                taus_matth(id_E,id_n).y(NInf)=0;
                                            
                                                TDF_ph_n.xx(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_x .* state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)'...
                                                    .* state_ID(id_E,id_n).DOS); 

                                                TDF_ph_n.yy(id_E,id_n,id_T) = sum(state_ID(id_E,id_n).v_y .* state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)'...
                                                    .* state_ID(id_E,id_n).DOS); 
                                                
                                                TDF_ph_n.xy(id_E,id_n,id_T) = sum( state_ID(id_E,id_n).v_x.*state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS);

                                                MFP_ph_n.x(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_x .* taus_matth(id_E,id_n).x(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                                MFP_ph_n.y(id_E,id_n,id_T) = sum( abs(state_ID(id_E,id_n).v_y .* taus_matth(id_E,id_n).y(:,id_T)') .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);

                                                tauE_ph_n.x(id_E,id_n,id_T) = sum( taus_matth(id_E,id_n).x(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                                tauE_ph_n.y(id_E,id_n,id_T) = sum( taus_matth(id_E,id_n).y(:,id_T)' .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);                                        
                                            end
                                        end
                                    end
                                end                
                    end
            end            
        end

        Ninf = isinf(TDF_ph_n.xx); TDF_ph_n.xx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xx); TDF_ph_n.xx(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yy); TDF_ph_n.yy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yy); TDF_ph_n.yy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.xy); TDF_ph_n.xy(Ninf) = 0;
        NNan = isnan(TDF_ph_n.xy); TDF_ph_n.xy(NNan) = 0;
        Ninf = isinf(TDF_ph_n.yx); TDF_ph_n.yx(Ninf) = 0;
        NNan = isnan(TDF_ph_n.yx); TDF_ph_n.yx(NNan) = 0;
        TDF_ph.xx = 1/t * (sd/(4*pi^2)).*squeeze(sum(TDF_ph_n.xx,2)); % it sums the contribution of the bands
        TDF_ph.yy = 1/t * (sd/(4*pi^2)).*squeeze(sum(TDF_ph_n.yy,2)); % the dSk elemnts is already in the DOS
        TDF_ph.xy = 1/t * (sd/(4*pi^2)).*squeeze(sum(TDF_ph_n.xy,2));
        TDF_ph.yx = 1/t * (sd/(4*pi^2)).*squeeze(sum(TDF_ph_n.yx,2));    

        MFP_ph.x = squeeze(mean(abs(MFP_ph_n.x),2));
        MFP_ph.y = squeeze(mean(abs(MFP_ph_n.y),2));

        tauE_ph.x = squeeze(sum(tauE_ph_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE_ph.y = squeeze(sum(tauE_ph_n.y,2)); % tauE = tauE(E,EF,T)


        % denoising the TDF
        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
            for ii_T = 1:size(T_array,2)
                for ii_EF = 1:size(EF_array,2)
                                         
                    A = abs( TDF_ph.xx(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xx(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yy(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yy(:,ii_EF,ii_T) = A1 ;                    
                    A = abs( TDF_ph.xy(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.xy(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.xy(:,ii_EF,ii_T) = A1 ;
                    A = abs( TDF_ph.yx(:,ii_EF,ii_T) ) ;
                    A1 = TDF_ph.yx(:,ii_EF,ii_T) ;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    TDF_ph.yx(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( MFP_ph.x(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP_ph.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( MFP_ph.y(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    MFP_ph.y(:,ii_EF,ii_T) = A1 ;
                    
                    A = abs( tauE_ph.x(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE_ph.x(:,ii_EF,ii_T) = A1 ;
                    A = abs( tauE_ph.y(:,ii_EF,ii_T) ) ;
                    A1 = A;
                    for ii = 5:size(A,1)-5
                    if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                        A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                    end
                    end
                    tauE_ph.y(:,ii_EF,ii_T) = A1 ;
                                       
                end
            end
        else
            for ii_T = 1:size(T_array,2)

                A = abs( TDF_ph.xx(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xx(:,ii_T) = A1 ;
                A = abs( TDF_ph.yy(:,ii_T) ) ;
                A1 = A;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yy(:,ii_T) = A1 ;                
                A = abs( TDF_ph.xy(:,ii_T) ) ;
                A1 = TDF_ph.xy(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.xy(:,ii_T) = A1 ;
                A = abs( TDF_ph.yx(:,ii_T) ) ;
                A1 = TDF_ph.yx(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) ) 
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                TDF_ph.yx(:,ii_T) = A1 ;
                
                A = abs( MFP_ph.x(:,ii_T) ) ;
                A1 = MFP_ph.x(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                MFP_ph.x(:,ii_T) = A1 ;
                A = abs( MFP_ph.y(:,ii_T) ) ;
                A1 = MFP_ph.y(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                MFP_ph.y(:,ii_T) = A1 ;
               
                A = abs( tauE_ph.x(:,ii_T) ) ;
                A1 = tauE_ph.x(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                tauE_ph.x(:,ii_T) = A1 ;
                A = abs( tauE_ph.y(:,ii_T) ) ;
                A1 = tauE_ph.y(:,ii_T) ;
                for ii = 5:size(A,1)-5
                if  A(ii) >  1.5 * mean( A([ii-4:ii-1,ii+1:ii+4]) )
                    A1(ii) = ( A(ii-4) + A(ii+4) )/2;
                end
                end
                tauE_ph.y(:,ii_T) = A1 ;

            end
        end

    % ------------------------------------------------------------------------


%     end % end of the dimensionality check
    
end