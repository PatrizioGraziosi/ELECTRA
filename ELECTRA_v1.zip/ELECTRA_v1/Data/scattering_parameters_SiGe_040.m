% Scattering parameters for the SiGe alloy with 0.40 molar fraction of Ge

% Because the number of IVS scattering processes between the valleys in
% Delta is different between Si and Ge, in order to interpolate the 
% scattering parameters for the compositions we must use the same number of
% processes. To do that, we consided the two dominant processes in Silicon
% and modified them to get the same silicon lattice mobility. Then we used
% these processes for the alloy with Ge.

fraction = 0.40;
x = fraction;
Delta_gap = 1.13-0.661; % eV
% Vcell = ( (47.8 - 40.9) * x + 40.9 ) * 1e-30; % in m^3 
Vcell = ( (47.8^(1/3) - 40.9^(1/3)) * x + 40.9^(1/3) ).^3 * 1e-30; % in m^3
atoms_cell = 2;

% The scattering parameters for Ge and Si

%----------- PHONONS ---------
rho_mass_density_Ge = 5.32e3; % kg/m^3
% 
sl_Ge = 5.4e3;  % m/s , elasticity theory
st_Ge = 3.2e3;               % m/s , elasticity theory
%
rho_mass_density_Si = 2.329e3; % kg/m^3
%
sl_Si=9.041e3;                % m/s
st_Si=5.34*1e3;               % m/s


rho_mass_density = ( rho_mass_density_Ge - rho_mass_density_Si ) * x + rho_mass_density_Si;
%
sl = ( sl_Ge - sl_Si ) * x + sl_Si;
st = ( st_Ge - st_Si ) * x + st_Si;
us_sound_vel = 1/3*sl+2/3*st;               % m/s   Ottaviani 1975


%------------ C.B. labels ----------
% They are labelled according to thier position for my clarity, L for L, G
% for Gamma, X for the Delta point close to X
% valley_type = ['G','X','X','X','X','X','X, 'L','L','L','L','];

bands_type_CB =  [ 1,  2, 2, 2, 2, 2, 2, 3,  3,  3,  3 , 3,  3, 3, 3  ];
% ----------------------------------


% ELASTIC, INTRAVALLEY - ADP

% --------- electrons--------------
LL_D_adp_e = 11;  % 11 or 12
GG_D_adp_e = 5;
XX_D_adp_e = 9; % Jacoboni Reggiani 1979 say 9 eV, Fawcett Paige 1971 say 5.99


D_adp_e_M = [ 5, 0, 0 ; 0, 9, 0 ; 0, 0, 11];

% INELASTIC - INTRAVALLEY - ODP 
% for Si the value are taken from Lundstrom's book 

% -------- electrons --------------
LL_D_odp_e = ( 5.5e10 - 2e10 ) * x + 2e10 ;
LL_hbar_w_odp_e = ( 0.0369 - 0.050 ) * x + 0.050 ;
LL_Z_f_odp_e = 1;


D_odp_e_M = [ 0, 0, LL_D_odp_e];
hbar_w_odp_e_M = [ LL_hbar_w_odp_e, 0, 0];
Z_f_odp_e_M = [1,1,1];

% INELASTIC - INTERVALLY - IVS


% values
LL_D_ivs_e = ( 1.6e10 + 2e10 ) * x + 2e10 ; 
LL_hbar_w_ivs_e = ( 0.0275 + 0.050 ) * x + 0.050 ;
LL_Z_f_ivs_e = 1;

LG_D_ivs_e = 2e10;
LG_hbar_w_ivs_e = 0.0275;
LG_Z_f_ivs_e = 1;
GL_D_ivs_e = LG_D_ivs_e; GL_hbar_w_ivs_e = LG_hbar_w_ivs_e; GL_Z_f_ivs_e = LG_Z_f_ivs_e;

LX_D_ivs_e = 5.5e10; % 5.5 or 4.0
LX_hbar_w_ivs_e = 0.0275;
LX_Z_f_ivs_e = 1;
XL_D_ivs_e = LX_D_ivs_e; XL_hbar_w_ivs_e = LX_hbar_w_ivs_e; XL_Z_f_ivs_e = LX_Z_f_ivs_e;

GX_D_ivs_e = 10e10;
GX_hbar_w_ivs_e = 0.0275;
GX_Z_f_ivs_e = 1;
XG_D_ivs_e = GX_D_ivs_e; XG_hbar_w_ivs_e = GX_hbar_w_ivs_e; XG_Z_f_ivs_e = GX_Z_f_ivs_e;

XX_D_ivs_e = ( [0.78e10, 9.4e10] - [0.8e10, 3.5e10] ) .* x + [0.5e10, 3.5e10]; 
XX_hbar_w_ivs_e = ( [0.0086, 0.0369] - [0.018, 0.044] ) .* x + [0.018, 0.044];
XX_Z_f_ivs = [1,1];


% matrixes of scattering processes data
D_ivs_e_M(:,:,1) = [ 0, XG_D_ivs_e, LG_D_ivs_e ; XG_D_ivs_e, XX_D_ivs_e(1), LX_D_ivs_e ; LG_D_ivs_e, LX_D_ivs_e, LL_D_ivs_e ] ;
D_ivs_e_M(:,:,2) = [ 0, 0, 0 ; 0, XX_D_ivs_e(2), 0 ; 0, 0, 0 ] ;

hbar_w_ivs_e_M(:,:,1) = [ 0, XG_hbar_w_ivs_e, LG_hbar_w_ivs_e ; XG_hbar_w_ivs_e, XX_hbar_w_ivs_e(1), LX_hbar_w_ivs_e ; LG_hbar_w_ivs_e, LX_hbar_w_ivs_e, LL_hbar_w_ivs_e ] ;
hbar_w_ivs_e_M(:,:,2) = [ 0, 0, 0 ; 0, XX_hbar_w_ivs_e(2), 0 ; 0, 0, 0 ] ;

Z_f_ivs_e_M = ones(3,3,2) ;

%--------------------------------------------------------

% for Coulomb scattering - screened
k_s = (16-12)*x + 12;
k_inf = k_s;