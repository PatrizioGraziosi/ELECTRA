materials_list = { 'Mg3Sb2', 'TiNiSn' } ; 
% alat = [0.46,0.42] ; % in nm, only needed for .bxsf type files