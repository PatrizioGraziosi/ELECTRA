% Copyright 2022 Patrizio Graziosi and Neopohytos Neophytou               %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, 
% under the supervision of Prof. Neophytos Neophytou, during the          %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
%                                                                         %
% ----------------------------------------------------------------------- %


function [state_ID_temp,DOS,V,mass_tensor] = kE_extraction_2D_kScan_ELECTRA_v1(id_E,n_band,E_array,bands_transp,Ek,kx_matrix,ky_matrix,sd,BZ_factor)  %#codegen

%------------------- Initializations ---------------------------------
nkx=size(Ek,1); nky=size(Ek,2); nkz=size(Ek,3);
Etmp = E_array(id_E);
n = bands_transp(n_band); %the band index, that does not correponsd to the position in the bands_transp array, but in the E(k) matrix
dLk=1; % dSn=(dkx*dky)^(1/2); % temporary set to one, asjusted later to dA, used only to keep the reasoning
hbar=(6.6261e-34)/(2*pi); % [J-sec]
q0=1.609e-19;             % [col]
%--------------------------------------------------------------------

% ---------------------- Declaration --------------------------------
kx_field =  [] ; % double.empty(1,0);
coder.varsize('kx_field');
ky_field =  [] ; % double.empty(1,0);
coder.varsize('ky_field');
knorm_field =  [] ; %  double.empty(1,0);
coder.varsize('knorm_field');

vx_field =  [] ; % double.empty(1,0);
coder.varsize('vx_field');
vy_field =  [] ; %  double.empty(1,0);
coder.varsize('vy_field');
V_field =   [] ; % double.empty(1,0);
coder.varsize('V_field');

DOS_field =  [] ; % double.empty(1,0);
coder.varsize('DOS_field');
line_field =  [] ; %  double.empty(1,0);
coder.varsize('line_field');

m_xx_field = [] ; 
coder.varsize('m_xx_field');
m_yy_field = [] ; 
coder.varsize('m_zz_field');
m_xy_field = [] ; 
coder.varsize('m_xy_field');

sT_array = [] ; coder.varsize('sT_array');
% -------------------------------------------------------------------
         
        Emin_temp = min(min(min((Ek(:,:,n)))));
        Emax_temp = max(max(max((Ek(:,:,n)))));
        
        if Emin_temp < Etmp && Emax_temp > Etmp % select only the bands that cross that E value
                       
            for ix = 1 : (nkx-1) % nkx is the number of k points in the x axis, y and z m.m.
                for iy = 1 : (nky-1)
                        
                        kx_condition = ( Ek(ix,iy,n) <= Etmp && Ek(ix+1,iy,n) > Etmp || Ek(ix,iy,n) >= Etmp && Ek(ix+1,iy,n) < Etmp );
                        ky_condition = ( Ek(ix,iy,n) <= Etmp && Ek(ix,iy+1,n) > Etmp || Ek(ix,iy,n) >= Etmp && Ek(ix,iy+1,n) < Etmp );
                        
                        if kx_condition % +1 along x 
                            % define the k point
                            k1x = kx_matrix(ix,iy) + (kx_matrix(ix+1,iy)-kx_matrix(ix,iy)) * ((Etmp-Ek(ix,iy,n)) / (Ek(ix+1,iy,n)-Ek(ix,iy,n))); 
                            k1y = ky_matrix(ix,iy); 
                            knorm = norm([k1x,k1y]);
                            % put the point in the state_ID_temp of the state
                            kx_field = [kx_field, k1x];
                            ky_field = [ky_field, k1y];
                            knorm_field = [knorm_field, knorm];
  
                            
                            % variation from Lehmann 1972 
    
                            k1 = [kx_matrix(ix+1,iy) , ky_matrix(ix+1,iy), 0] - [kx_matrix(ix,iy), ky_matrix(ix,iy), 0];
                            k2 = [kx_matrix(ix,iy+1), ky_matrix(ix,iy+1), 0] - [kx_matrix(ix,iy), ky_matrix(ix,iy), 0];
                            sT = norm(cross(k1,k2)); % surface of the triasngular element times 2(?)
                            r1 = k1/sT;
                            r2 = k2/sT;
                            grad_E = (Ek(ix+1,iy,n) - Ek(ix,iy,n))*r1 + (Ek(ix,iy+1,n)-Ek(ix,iy,n))*r2 ;

                            % Define DOS and velocities in correct units
                            Vx_k = q0/hbar * grad_E(1);
                            Vy_k = q0/hbar * grad_E(2);
                           
                            vx_field = [vx_field, Vx_k];
                            vy_field = [vy_field, Vy_k];
                            V_field = [ V_field, norm([Vx_k,Vy_k]) ];
                            
                            sT_array = [sT_array, sT] ;
                                
                            DOS_field = [DOS_field, dLk / norm( grad_E )]; % dLk is set to one at the beginning
                            
                            mass_tensor = kron(grad_E,grad_E') ; % / vT ;
%                             mass_tensor = kron(grad_E,grad_E') / ( (  (Ek(ix+1,iy,iz,n) - Ek(ix,iy,iz,n)) + (Ek(ix,iy+1,iz,n)-Ek(ix,iy,iz,n)) + (Ek(ix,iy,iz+1,n)-Ek(ix,iy,iz,n)) ) /3 ) ;
                            m_xx_field = [m_xx_field, dLk / norm( grad_E ) * mass_tensor(1,1) ];
                            m_yy_field = [m_yy_field, dLk / norm( grad_E ) * mass_tensor(2,2) ];
                            m_xy_field = [m_xy_field, dLk / norm( grad_E ) * mass_tensor(1,2) ];

                        end
                        
                        if ky_condition % +1 along ky 
                            % define the k point
                            k1x = kx_matrix(ix,iy); 
                            k1y = ky_matrix(ix,iy) + (ky_matrix(ix,iy+1)-ky_matrix(ix,iy)) * ((Etmp-Ek(ix,iy,n)) / (Ek(ix,iy+1,n)-Ek(ix,iy,n)));
                            knorm = norm([k1x,k1y]);
                            % put the point in the state_ID_temp of the state
                            kx_field = [kx_field, k1x];
                            ky_field = [ky_field, k1y];
                            knorm_field = [knorm_field, knorm];
                                
                                 % variation from Lehmann 1972
    
                            k1 = [kx_matrix(ix+1,iy) , ky_matrix(ix+1,iy), 0] - [kx_matrix(ix,iy), ky_matrix(ix,iy), 0];
                            k2 = [kx_matrix(ix,iy+1), ky_matrix(ix,iy+1), 0] - [kx_matrix(ix,iy), ky_matrix(ix,iy), 0];
                            sT = norm(cross(k1,k2)); % surface of the triangular element times 2(?)
                            r1 = k1/sT;
                            r2 = k2/sT;
                            grad_E = (Ek(ix+1,iy,n) - Ek(ix,iy,n))*r1 + (Ek(ix,iy+1,n)-Ek(ix,iy,n))*r2 ;

                            % Define DOS and velocities in correct units
                            Vx_k = q0/hbar * grad_E(1);
                            Vy_k = q0/hbar * grad_E(2);
                            
                            vx_field = [vx_field, Vx_k];
                            vy_field = [vy_field, Vy_k];
                            V_field = [ V_field, norm([Vx_k,Vy_k]) ];
                            sT_array = [sT_array, sT] ;
                                
                            DOS_field = [DOS_field, dLk / norm( grad_E )]; % dSk is set to one at the beginning
                            
                            mass_tensor = kron(grad_E,grad_E') ; % / vT ;
                            m_xx_field = [m_xx_field, dLk / norm( grad_E ) * mass_tensor(1,1) ];
                            m_yy_field = [m_yy_field, dLk / norm( grad_E ) * mass_tensor(2,2) ];
                            m_xy_field = [m_xy_field, dLk / norm( grad_E ) * mass_tensor(1,2) ];

                        end
                        
                                                            
                end
            end
            
            
        end
         
        
        NNan=isnan(DOS_field); DOS_field(NNan)=0;
        NInf=isinf(DOS_field); DOS_field(NInf)=0;
        NNan=isnan(vx_field);  vx_field(NNan)=0;
        NNan=isnan(vy_field);  vy_field(NNan)=0;
        NNan=isnan(V_field);   V_field(NNan)=0;
        
        NNan=isnan(m_xx_field); m_xx_field(NNan)=0;
        NInf=isinf(m_xx_field); m_xx_field(NInf)=0;
        NNan=isnan(m_yy_field); m_yy_field(NNan)=0;
        NInf=isinf(m_yy_field); m_yy_field(NInf)=0;
        NNan=isnan(m_xy_field); m_xy_field(NNan)=0;
        NInf=isinf(m_xy_field); m_xy_field(NInf)=0;
        
        
        
        % integrals calculations for each band and each energy,
        % the 2/((2*pi)^3) factor is introduced inthe surface integral for
        % the DOS, it is NOT in the state DOS, that is barely dAk/|v|
        
        k_points_number = size(kx_field,2);
        
        if not(size(vx_field,2)) == 0   % the state is not empty
            sT_eff = mean(abs(sT_array));  
            for ik = 1 : k_points_number

               delta_k_array = sqrt((kx_field-kx_field(ik)).^2+(ky_field-ky_field(ik)).^2);
               id_nn =  delta_k_array < ( 1.26 + 0.0001234 ) * sT_eff^(1/2)  ; % ( sqrt(2)+0.0001234 ) % *dk_eff );  %  (sqrt(2)+0.01)*dk_eff); % closest n.n.
               delta_k_nn = delta_k_array(id_nn); % distances of the closest n.n.
               k_circle = mean(nonzeros(delta_k_nn)) ; % /2; % avreage semi-distance % it was k_s that was the static dielectric constant as well in Phytos' definitions - ALL CALC. wrong at the GiTe
               if isnan(k_circle)
                   k_circle = 0;
               end
               
%                dL = 0.9*k_circle;
               dL = k_circle;
               
               line_field = [line_field, dL];
                
               DOS_field(ik) = DOS_field(ik) * abs(dL); % sqrt(sT_eff); % abs(dL); % dA is the actual dSk element for the surface integration
               
               m_xx_field(ik) = m_xx_field(ik) * dL ;
               m_yy_field(ik) = m_yy_field(ik) * dL ;
               m_xy_field(ik) = m_xy_field(ik) * dL ;

            end
        end
        
        
        state_ID_temp = struct();
        
        state_ID_temp.kx = kx_field ;
        state_ID_temp.ky = ky_field ;
        state_ID_temp.knorm = knorm_field ;
        
        state_ID_temp.v_x = vx_field ;
        state_ID_temp.v_y = vy_field ;
        state_ID_temp.V = V_field;         
        
        state_ID_temp.DOS = DOS_field ;
        state_ID_temp.line = line_field ;
        state_ID_temp.E = Etmp;
        
        V = sum(state_ID_temp.V) / k_points_number ; % <v> ?  line 842 obiavtes to NaN issues

        DOS = BZ_factor*(sd/(4*pi^2))*sum(state_ID_temp.DOS); % Surface integration, the dLk element is in the DOS of the individual states
        
       
        mass_tensor = struct() ;
        mass_tensor.xx = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_xx_field) * q0/hbar^2 ) * DOS ;
        mass_tensor.yy = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_yy_field) * q0/hbar^2 ) * DOS;
        mass_tensor.xy = 1/( BZ_factor*(sd/(8*pi^3))*sum(m_xy_field) * q0/hbar^2 ) * DOS;
                
end