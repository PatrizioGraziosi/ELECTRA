% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% ACS Appl. Energy Mater. 2020, 3, 6, 5913–5926
% https://doi.org/10.1021/acsaem.0c00825
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

% this code extracts the TE properties
% for now, inputs are DOS_tot(E,DOS(E)), TDF_tau_ij_tot(E,sigma_ij_tot(E))
% that is vi*vj*DOS, tau

% NOTE 
% on 08/05/2019 I added some lines to consider the EF shift imposing 
% that EF_array becomes the EF_matrix column that corresponds at each 
% temperature, and other lines to consider that the maximum EF can be in the gap


function [ TDF, TDF_ph, TDF_sep, MFP, MFP_ph, MFP_sep, tauE, tauE_ph, tauE_sep, tauE_IIS, DOS_tot, V_tot ] = ...
    TDF_bipolar_composition_ELECTRA_v1( TDF_electron, TDF_ph_electron, TDF_sep_electron, ...
                MFP_electron, MFP_ph_electron, MFP_sep_electron, ...
                tauE_electron, tauE_ph_electron, tauE_sep_electron, tauE_IIS_electron, ...
                TDF_hole, TDF_ph_hole, TDF_sep_hole, ...
                MFP_hole, MFP_ph_hole, MFP_sep_hole, ...
                tauE_hole, tauE_ph_hole, tauE_sep_hole, tauE_IIS_hole, ...
                E_array, E_array_majority, E_array_minority, ...
                DOS_tot_majority, DOS_tot_minority, ...
                V_tot_majority, V_tot_minority, ...
                EF_matrix, minority_band_edge, WorkSpace4, negative_gap  ) %#codegen


if strcmp(negative_gap,'yes')
    disp(' The bandgap is negative, the material can be a metal or a semimetal ')
    disp(' ')
end

nE = size(E_array,2); 
nEF = size(EF_matrix,1);
% nEF_ph = size(EF_matrix_ph,1); % NOT used ?
nT = size(EF_matrix,2);



ADP = WorkSpace4.ADP ;                          % scattering instructions
ADP_IVS = WorkSpace4.ADP_IVS ;
Alloy = WorkSpace4.Alloy ;
ODP = WorkSpace4.ODP ;
POP = WorkSpace4.POP ;
screening_POP = WorkSpace4.screening_POP ;
IVS = WorkSpace4.IVS ;
IIS = WorkSpace4.IIS ;







% Initializations of the ovreall cmprehensive struct variables

    TDF=struct(); TDF_ph=struct(); TDF_sep=struct(); MFP=struct(); MFP_ph=struct(); MFP_sep=struct(); tauE=struct(); tauE_ph=struct(); tauE_sep=struct(); tauE_IIS=struct();
    
    % fields with the different bands
    TDF.xx = zeros(nE, nEF, nT ); TDF.yy = zeros(nE, nEF, nT ); TDF.zz = zeros(nE, nEF, nT );
    TDF.xy = zeros(nE, nEF, nT ); TDF.yz = zeros(nE, nEF, nT ); TDF.xz = zeros(nE, nEF, nT );
    TDF.yx = zeros(nE, nEF, nT ); TDF.zy = zeros(nE, nEF, nT ); TDF.zx = zeros(nE, nEF, nT );
    MFP.x= zeros(nE, nEF, nT ); MFP.y = zeros(nE, nEF, nT ); MFP.z = zeros(nE, nEF, nT );
    tauE.x = zeros(nE, nEF, nT ); tauE.y = zeros(nE, nEF, nT ); tauE.z = zeros(nE, nEF, nT );
    tauE_IIS.x = zeros(nE, nEF, nT ); tauE_IIS.y = zeros(nE, nEF, nT ); tauE_IIS.z = zeros(nE, nEF, nT );
    
    TDF_sep.ADP=struct(); TDF_sep.ODP=struct(); TDF_sep.POP=struct(); TDF_sep.IVS=struct(); TDF_sep.Alloy=struct();
    tauE_sep.ADP=struct(); tauE_sep.ODP=struct(); tauE_sep.POP=struct(); tauE_sep.IVS=struct(); tauE_sep.Alloy=struct();
    MFP_sep.ADP=struct(); MFP_sep.ODP=struct(); MFP_sep.POP=struct(); MFP_sep.IVS=struct(); MFP_sep.Alloy=struct();
    
    TDF_sep.ADP.xx = zeros( nE, nT ); TDF_sep.ADP.yy = zeros( nE, nT ); TDF_sep.ADP.zz = zeros( nE, nT );
    TDF_sep.ADP.xy = zeros( nE, nT ); TDF_sep.ADP.yz = zeros( nE, nT ); TDF_sep.ADP.xz = zeros( nE, nT );
    TDF_sep.ADP.yx = zeros( nE, nT ); TDF_sep.ADP.zy = zeros( nE, nT ); TDF_sep.ADP.zx = zeros( nE, nT );
    TDF_sep.ODP.xx = zeros( nE, nT ); TDF_sep.ODP.yy = zeros( nE, nT ); TDF_sep.ODP.zz = zeros( nE, nT );
    TDF_sep.ODP.xy = zeros( nE, nT ); TDF_sep.ODP.yz = zeros( nE, nT ); TDF_sep.ODP.xz = zeros( nE, nT );
    TDF_sep.ODP.yx = zeros( nE, nT ); TDF_sep.ODP.zy = zeros( nE, nT ); TDF_sep.ODP.zx = zeros( nE, nT );
    TDF_sep.IVS.xx = zeros( nE, nT ); TDF_sep.IVS.yy = zeros( nE, nT ); TDF_sep.IVS.zz = zeros( nE, nT );
    TDF_sep.IVS.xy = zeros( nE, nT ); TDF_sep.IVS.yz = zeros( nE, nT ); TDF_sep.IVS.xz = zeros( nE, nT );
    TDF_sep.IVS.yx = zeros( nE, nT ); TDF_sep.IVS.zy = zeros( nE, nT ); TDF_sep.IVS.zx = zeros( nE, nT );
    TDF_sep.Alloy.xx = zeros( nE, nT ); TDF_sep.Alloy.yy = zeros( nE, nT ); TDF_sep.Alloy.zz = zeros( nE, nT );
    TDF_sep.Alloy.xy = zeros( nE, nT ); TDF_sep.Alloy.yz = zeros( nE, nT ); TDF_sep.Alloy.xz = zeros( nE, nT );
    TDF_sep.Alloy.yx = zeros( nE, nT ); TDF_sep.Alloy.zy = zeros( nE, nT ); TDF_sep.Alloy.zx = zeros( nE, nT );
    
    MFP_sep.ADP.x = zeros( nE, nT ); MFP_sep.ADP.y = zeros( nE, nT ); MFP_sep.ADP.z = zeros( nE, nT );
    MFP_sep.ODP.x = zeros( nE, nT ); MFP_sep.ODP.y = zeros( nE, nT ); MFP_sep.ODP.z = zeros( nE, nT );
    MFP_sep.IVS.x = zeros( nE, nT ); MFP_sep.IVS.y = zeros( nE, nT ); MFP_sep.IVS.z = zeros( nE, nT );
    MFP_sep.Alloy.x = zeros( nE, nT ); MFP_sep.Alloy.y = zeros( nE, nT ); MFP_sep.Alloy.z = zeros( nE, nT );
    
    tauE_sep.ADP.x = zeros( nE, nT ); tauE_sep.ADP.y = zeros( nE, nT ); tauE_sep.ADP.z = zeros( nE, nT );
    tauE_sep.ODP.x = zeros( nE, nT ); tauE_sep.ODP.y = zeros( nE, nT ); tauE_sep.ODP.z = zeros( nE, nT );
    tauE_sep.IVS.x = zeros( nE, nT ); tauE_sep.IVS.y = zeros( nE, nT ); tauE_sep.IVS.z = zeros( nE, nT );
    tauE_sep.Alloy.x = zeros( nE, nT ); tauE_sep.Alloy.y = zeros( nE, nT ); tauE_sep.Alloy.z = zeros( nE, nT );
    
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_sep.POP.xx = zeros(nE, nEF, nT ); TDF_sep.POP.yy = zeros(nE, nEF, nT ); TDF_sep.POP.zz = zeros(nE, nEF, nT );
        TDF_sep.POP.xy = zeros(nE, nEF, nT ); TDF_sep.POP.yz = zeros(nE, nEF, nT ); TDF_sep.POP.xz = zeros(nE, nEF, nT );
        TDF_sep.POP.yx = zeros(nE, nEF, nT ); TDF_sep.POP.zy = zeros(nE, nEF, nT ); TDF_sep.POP.zx = zeros(nE, nEF, nT );
        MFP_sep.POP.x = zeros(nE, nEF, nT ); MFP_sep.POP.y = zeros(nE, nEF, nT ); MFP_sep.POP.z = zeros(nE, nEF, nT );
        tauE_sep.POP.x = zeros(nE, nEF, nT ); tauE_sep.POP.y = zeros(nE, nEF, nT ); tauE_sep.POP.z = zeros(nE, nEF, nT );
                       
        TDF_ph.xx = zeros(nE, nEF, nT ); TDF_ph.yy = zeros(nE, nEF, nT ); TDF_ph.zz = zeros(nE, nEF, nT );
        TDF_ph.xy = zeros(nE, nEF, nT ); TDF_ph.yz = zeros(nE, nEF, nT ); TDF_ph.xz = zeros(nE, nEF, nT );
        TDF_ph.yx = zeros(nE, nEF, nT ); TDF_ph.zy = zeros(nE, nEF, nT ); TDF_ph.zx = zeros(nE, nEF, nT );
        MFP_ph.x = zeros(nE, nEF, nT ); MFP_ph.y = zeros(nE, nEF, nT ); MFP_ph.z = zeros(nE, nEF, nT );
        tauE_ph.x = zeros(nE, nEF, nT ); tauE_ph.y = zeros(nE, nEF, nT ); tauE_ph.z = zeros(nE, nEF, nT );
           
    else
        
        TDF_sep.POP.xx = zeros( nE, nT ); TDF_sep.POP.yy = zeros( nE, nT ); TDF_sep.POP.zz = zeros( nE, nT );
        TDF_sep.POP.xy = zeros( nE, nT ); TDF_sep.POP.yz = zeros( nE, nT ); TDF_sep.POP.xz = zeros( nE, nT );
        TDF_sep.POP.yx = zeros( nE, nT ); TDF_sep.POP.zy = zeros( nE, nT ); TDF_sep.POP.zx = zeros( nE, nT );
        MFP_sep.POP.x = zeros( nE, nT ); MFP_sep.POP.y = zeros( nE, nT ); MFP_sep.POP.z = zeros( nE, nT );
        tauE_sep.POP.x = zeros( nE, nT ); tauE_sep.POP.y = zeros( nE, nT ); tauE_sep.POP.z = zeros( nE, nT );
        
        TDF_ph.xx = zeros( nE, nT ); TDF_ph.yy = zeros( nE, nT ); TDF_ph.zz = zeros( nE, nT );
        TDF_ph.xy = zeros( nE, nT ); TDF_ph.yz = zeros( nE, nT ); TDF_ph.xz = zeros( nE, nT );
        TDF_ph.yx = zeros( nE, nT ); TDF_ph.zy = zeros( nE, nT ); TDF_ph.zx = zeros( nE, nT );
        MFP_ph.x = zeros( nE, nT ); MFP_ph.y = zeros( nE, nT ); MFP_ph.z = zeros( nE, nT );
        tauE_ph.x = zeros( nE, nT ); tauE_ph.y = zeros( nE, nT ); tauE_ph.z = zeros( nE, nT );
       
    end
    
    TDF_xx=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_yy=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_zz=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    TDF_xy=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_yz=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_xz=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    TDF_yx=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_zy=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_zx=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    MFP_x=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); MFP_y=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); MFP_z=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    tauE_x=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); tauE_y=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); tauE_z=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    tauE_IIS_x=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); tauE_IIS_y=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); tauE_IIS_z=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    
    DOS_tot = zeros(1,size(E_array,2)); V_tot = zeros(1,size(E_array,2),1);


    % conversion of the entered struct data into temp matrixes
    
    TDF_xx_majority = TDF_electron.xx;
    TDF_yy_majority = TDF_electron.yy;
    TDF_zz_majority = TDF_electron.zz;
    TDF_xy_majority = TDF_electron.xy;
    TDF_yz_majority = TDF_electron.yz;
    TDF_xz_majority = TDF_electron.xz;
    TDF_yx_majority = TDF_electron.yx;
    TDF_zy_majority = TDF_electron.yz;
    TDF_zx_majority = TDF_electron.zx;
    
    TDF_xx_minority = TDF_hole.xx;
    TDF_yy_minority = TDF_hole.yy;
    TDF_zz_minority = TDF_hole.zz;
    TDF_xy_minority = TDF_hole.xy;
    TDF_yz_minority = TDF_hole.yz;
    TDF_xz_minority = TDF_hole.xz;
    TDF_yx_minority = TDF_hole.yx;
    TDF_zy_minority = TDF_hole.yz;
    TDF_zx_minority = TDF_hole.zx;
    
    MFP_x_majority = MFP_electron.x;
    MFP_y_majority = MFP_electron.y;
    MFP_z_majority = MFP_electron.z;
    
    MFP_x_minority = MFP_hole.x;
    MFP_y_minority = MFP_hole.y;
    MFP_z_minority = MFP_hole.z;
    
    tauE_x_majority = tauE_electron.x;
    tauE_y_majority = tauE_electron.y;
    tauE_z_majority = tauE_electron.z;
    
    tauE_x_minority = tauE_hole.x;
    tauE_y_minority = tauE_hole.y;
    tauE_z_minority = tauE_hole.z;
   
    
    if strcmp(IIS,'yes') || strcmp(Alloy,'yes')       
        tauE_IIS_x_majority = tauE_IIS_electron.x;
        tauE_IIS_y_majority = tauE_IIS_electron.y;
        tauE_IIS_z_majority = tauE_IIS_electron.z;

        tauE_IIS_x_minority = tauE_IIS_hole.x;
        tauE_IIS_y_minority = tauE_IIS_hole.y;
        tauE_IIS_z_minority = tauE_IIS_hole.z;
    end
    


    
    % composition of the Transport Density Functions TDF

    [~,pos_minority_band_edge] = min( abs(E_array - (-minority_band_edge)));
    [~,pos_majority_band_edge] = min( abs(E_array));
    
    [~,relative_pos_minority_band_edge] = min( abs(E_array_minority - minority_band_edge));
    [~,relative_pos_majority_band_edge] = min( abs(E_array_majority));
    
    if size(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge,2) < pos_minority_band_edge
        pos_minority_band_edge = pos_minority_band_edge-1;
    end
    if size(pos_majority_band_edge:size(TDF_xx,1),2) < size((relative_pos_majority_band_edge:size(TDF_xx_majority,1)),2) 
        relative_pos_majority_band_edge = relative_pos_majority_band_edge+1;
    end
    
    % additional control on 23 February 2022
    diff_1 = length(1:pos_minority_band_edge) - length(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge);
    if diff_1 ~= 0 
        disp(' adjustment at the TDF composition level in TDF_bipolar_composition_ELECTRA_v1, line 218 ');
        relative_pos_minority_band_edge = relative_pos_minority_band_edge - diff_1;
    end
    diff_2 = length(pos_majority_band_edge:size(TDF_xx,1)) - length(relative_pos_majority_band_edge:size(TDF_xx_majority,1));
    if diff_2 ~= 0 
        disp(' adjustment at the TDF composition level in TDF_bipolar_composition_ELECTRA_v1, line 223 ');
        relative_pos_majority_band_edge = relative_pos_majority_band_edge - diff_2;
    end
    
    TDF_xx(1:pos_minority_band_edge,:,:) = TDF_xx_minority(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_xx(pos_majority_band_edge:size(TDF_xx,1),:,:) = TDF_xx(pos_majority_band_edge:size(TDF_xx,1),:,:) + TDF_xx_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)),:,:);
    
    TDF_yy(1:pos_minority_band_edge,:,:) = TDF_yy_minority(size(TDF_yy_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_yy(pos_majority_band_edge:size(TDF_yy,1),:,:) = TDF_yy(pos_majority_band_edge:size(TDF_yy,1),:,:) + TDF_yy_majority((relative_pos_majority_band_edge:size(TDF_yy_majority,1)),:,:);
    
    TDF_zz(1:pos_minority_band_edge,:,:) = TDF_zz_minority(size(TDF_zz_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_zz(pos_majority_band_edge:size(TDF_zz,1),:,:) = TDF_zz(pos_majority_band_edge:size(TDF_zz,1),:,:) + TDF_zz_majority((relative_pos_majority_band_edge:size(TDF_zz_majority,1)),:,:);
    
    TDF_xy(1:pos_minority_band_edge,:,:) = TDF_xy_minority(size(TDF_xy_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_xy(pos_majority_band_edge:size(TDF_zz,1),:,:) = TDF_xy(pos_majority_band_edge:size(TDF_zz,1),:,:) + TDF_xy_majority((relative_pos_majority_band_edge:size(TDF_xy_majority,1)),:,:);
    
    TDF_yz(1:pos_minority_band_edge,:,:) = TDF_yz_minority(size(TDF_yz_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_yz(pos_majority_band_edge:size(TDF_yz,1),:,:) = TDF_yz(pos_majority_band_edge:size(TDF_yz,1),:,:) + TDF_yz_majority((relative_pos_majority_band_edge:size(TDF_yz_majority,1)),:,:);
    
    TDF_xz(1:pos_minority_band_edge,:,:) = TDF_xz_minority(size(TDF_xz_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_xz(pos_majority_band_edge:size(TDF_xz,1),:,:) = TDF_xz(pos_majority_band_edge:size(TDF_xz,1),:,:) + TDF_xz_majority((relative_pos_majority_band_edge:size(TDF_xz_majority,1)),:,:);
    
    TDF_yx(1:pos_minority_band_edge,:,:) = TDF_yx_minority(size(TDF_yx_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_yx(pos_majority_band_edge:size(TDF_yx,1),:,:) =  TDF_yx(pos_majority_band_edge:size(TDF_yx,1),:,:) +  TDF_yx_majority((relative_pos_majority_band_edge:size(TDF_yx_majority,1)),:,:);
    
    TDF_zy(1:pos_minority_band_edge,:,:) = TDF_zy_minority(size(TDF_yz_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_zy(pos_majority_band_edge:size(TDF_zy,1),:,:) = TDF_zy(pos_majority_band_edge:size(TDF_zy,1),:,:) + TDF_zy_majority((relative_pos_majority_band_edge:size(TDF_zy_majority,1)),:,:);
    
    TDF_zx(1:pos_minority_band_edge,:,:) = TDF_zx_minority(size(TDF_xz_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_zx(pos_majority_band_edge:size(TDF_zx,1),:,:) = TDF_zx(pos_majority_band_edge:size(TDF_zx,1),:,:) + TDF_zx_majority((relative_pos_majority_band_edge:size(TDF_zx_majority,1)),:,:);
    
    DOS_tot(1:pos_minority_band_edge) = DOS_tot_minority(size(DOS_tot_minority,2):-1:relative_pos_minority_band_edge);
    DOS_tot(pos_majority_band_edge:size(DOS_tot,2)) = DOS_tot(pos_majority_band_edge:size(DOS_tot,2)) + DOS_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    
    V_tot(1:pos_minority_band_edge) = V_tot_minority(size(V_tot_minority,2):-1:relative_pos_minority_band_edge);
    if strcmp(negative_gap,'yes')
        A = V_tot(pos_majority_band_edge:size(DOS_tot,2)); 
        B = V_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
        [na,ma] =  find( A );
        [nb,mb] =  find( B );
        C = A+B;
        C(intersect(ma,mb)) = ( A((intersect(ma,mb)))+B((intersect(ma,mb))) )/2 ;
        V_tot(pos_majority_band_edge:size(V_tot,2)) = C;
    else
        V_tot(pos_majority_band_edge:size(V_tot,2)) = V_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    end
    
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_majority); MFP_x_majority(NNan)=0;
    NNan = isnan(MFP_y_minority); MFP_y_minority(NNan)=0;
    NNan = isnan(MFP_y_majority); MFP_y_majority(NNan)=0;
    NNan = isnan(tauE_x_minority); tauE_x_minority(NNan)=0;
    NNan = isnan(tauE_x_majority); tauE_x_majority(NNan)=0;
    NNan = isnan(MFP_x_minority); MFP_x_minority(NNan)=0;
    NNan = isnan(MFP_z_majority); MFP_z_majority(NNan)=0;
    NNan = isnan(MFP_z_minority); MFP_z_minority(NNan)=0;
    NNan = isnan(tauE_y_majority); tauE_y_majority(NNan)=0;
    NNan = isnan(tauE_y_minority); tauE_y_minority(NNan)=0;
    NNan = isnan(tauE_z_majority); tauE_z_majority(NNan)=0;
    NNan = isnan(tauE_z_minority); tauE_z_minority(NNan)=0;
    if strcmp(IIS,'yes')        
        NNan = isnan(tauE_IIS_x_majority); tauE_IIS_x_majority(NNan)=0;
        NNan = isnan(tauE_IIS_x_minority); tauE_IIS_x_minority(NNan)=0;
        NNan = isnan(tauE_IIS_y_minority); tauE_IIS_y_minority(NNan)=0;
        NNan = isnan(tauE_IIS_y_majority); tauE_IIS_y_majority(NNan)=0;
        NNan = isnan(tauE_IIS_z_majority); tauE_IIS_z_majority(NNan)=0;
        NNan = isnan(tauE_IIS_z_minority); tauE_IIS_z_minority(NNan)=0;
    end
    if strcmp(negative_gap,'yes')
        MFP_x(1:pos_minority_band_edge,:,:) = MFP_x_minority(size(MFP_x_minority,1):-1:relative_pos_minority_band_edge,:,:);      
        MFP_x(pos_majority_band_edge:size(MFP_x,1),:,:) = merge_ave( MFP_x(pos_majority_band_edge:size(MFP_y,1),:,:) , MFP_x_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:) );

        MFP_y(1:pos_minority_band_edge,:,:) = MFP_y_minority(size(MFP_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) = merge_ave( MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) , MFP_y_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:) );

        MFP_z(1:pos_minority_band_edge,:,:) = MFP_z_minority(size(MFP_z_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_z(pos_majority_band_edge:size(MFP_z,1),:,:) = merge_ave(MFP_z(pos_majority_band_edge:size(MFP_z,1),:,:) , MFP_z_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:) );

        tauE_x(1:pos_minority_band_edge,:,:) = tauE_x_minority(size(tauE_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) = merge_ave(tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) , tauE_x_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:) );

        tauE_y(1:pos_minority_band_edge,:,:) = tauE_y_minority(size(tauE_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) = merge_ave(tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) , tauE_y_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:) );

        tauE_z(1:pos_minority_band_edge,:,:) = tauE_z_minority(size(tauE_z_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_z(pos_majority_band_edge:size(tauE_z,1),:,:) = merge_ave(tauE_z(pos_majority_band_edge:size(tauE_z,1),:,:) , tauE_z_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:) );


        if strcmp(IIS,'yes')
            tauE_IIS_x(1:pos_minority_band_edge,:,:) = tauE_IIS_x_minority(size(tauE_IIS_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) = merge_ave( tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) , tauE_IIS_x_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:) );

            tauE_IIS_y(1:pos_minority_band_edge,:,:) = tauE_IIS_y_minority(size(tauE_IIS_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) = merge_ave( tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) , tauE_IIS_y_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:) );

            tauE_IIS_z(1:pos_minority_band_edge,:,:) = tauE_IIS_z_minority(size(tauE_IIS_z_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_z(pos_majority_band_edge:size(tauE_IIS_z,1),:,:) = merge_ave( tauE_IIS_z(pos_majority_band_edge:size(tauE_IIS_z,1),:,:) , tauE_IIS_z_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:) );
        end
        
    else
        MFP_x(1:pos_minority_band_edge,:,:) = MFP_x_minority(size(MFP_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_x(pos_majority_band_edge:size(MFP_x,1),:,:) = MFP_x(pos_majority_band_edge:size(MFP_x,1),:,:) + MFP_x_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:);

        MFP_y(1:pos_minority_band_edge,:,:) = MFP_y_minority(size(MFP_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) = MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) + MFP_y_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:);

        MFP_z(1:pos_minority_band_edge,:,:) = MFP_z_minority(size(MFP_z_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_z(pos_majority_band_edge:size(MFP_z,1),:,:) = MFP_z(pos_majority_band_edge:size(MFP_z,1),:,:) + MFP_z_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:);

        tauE_x(1:pos_minority_band_edge,:,:) = tauE_x_minority(size(tauE_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) = tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) + tauE_x_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:);

        tauE_y(1:pos_minority_band_edge,:,:) = tauE_y_minority(size(tauE_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) = tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) + tauE_y_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:);

        tauE_z(1:pos_minority_band_edge,:,:) = tauE_z_minority(size(tauE_z_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_z(pos_majority_band_edge:size(tauE_z,1),:,:) = tauE_z(pos_majority_band_edge:size(tauE_z,1),:,:) + tauE_z_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:);


        if strcmp(IIS,'yes')
            tauE_IIS_x(1:pos_minority_band_edge,:,:) = tauE_IIS_x_minority(size(tauE_IIS_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) = tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) + tauE_IIS_x_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:);

            tauE_IIS_y(1:pos_minority_band_edge,:,:) = tauE_IIS_y_minority(size(tauE_IIS_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) = tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) + tauE_IIS_y_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:);

            tauE_IIS_z(1:pos_minority_band_edge,:,:) = tauE_IIS_z_minority(size(tauE_IIS_z_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_z(pos_majority_band_edge:size(tauE_IIS_z,1),:,:) = tauE_IIS_z(pos_majority_band_edge:size(tauE_IIS_z,1),:,:) + tauE_IIS_z_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:);
        end
    end
    
    TDF.xx = TDF_xx; TDF.xy = TDF_xy; TDF.xz = TDF_xz;
    TDF.yx = TDF_yx; TDF.yy = TDF_yy; TDF.yz = TDF_yz;
    TDF.zx = TDF_zx; TDF.zy = TDF_zy; TDF.zz = TDF_zz;
    
    MFP.x = MFP_x; MFP.y = MFP_y; MFP.z = MFP_z;
    tauE.x = tauE_x; tauE.y = tauE_y; tauE.z = tauE_z;
    if strcmp(IIS,'yes')
        tauE_IIS.x = tauE_IIS_x; tauE_IIS.y = tauE_IIS_y; tauE_IIS.z = tauE_IIS_z;
    end    
    
    
    
    
    % ---------  ADP only---------------------------------------------
if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes')
    
    TDF_xx_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zz_ADP=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_xy_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yz_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_xz_ADP=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_yx_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zy_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zx_ADP=zeros(size(E_array,2),size(EF_matrix,2));
    MFP_x_ADP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_ADP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_z_ADP=zeros(size(E_array,2),size(EF_matrix,2));
    tauE_x_ADP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_ADP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_z_ADP=zeros(size(E_array,2),size(EF_matrix,2));

    TDF_xx_ADP_majority = TDF_sep_electron.ADP.xx;
    TDF_yy_ADP_majority = TDF_sep_electron.ADP.yy;
    TDF_zz_ADP_majority = TDF_sep_electron.ADP.zz;
    TDF_xy_ADP_majority = TDF_sep_electron.ADP.xy;
    TDF_yz_ADP_majority = TDF_sep_electron.ADP.yz;
    TDF_xz_ADP_majority = TDF_sep_electron.ADP.xz;
    TDF_yx_ADP_majority = TDF_sep_electron.ADP.yx;
    TDF_zy_ADP_majority = TDF_sep_electron.ADP.yz;
    TDF_zx_ADP_majority = TDF_sep_electron.ADP.zx;
    
    TDF_xx_ADP_minority = TDF_sep_hole.ADP.xx;
    TDF_yy_ADP_minority = TDF_sep_hole.ADP.yy;
    TDF_zz_ADP_minority = TDF_sep_hole.ADP.zz;
    TDF_xy_ADP_minority = TDF_sep_hole.ADP.xy;
    TDF_yz_ADP_minority = TDF_sep_hole.ADP.yz;
    TDF_xz_ADP_minority = TDF_sep_hole.ADP.xz;
    TDF_yx_ADP_minority = TDF_sep_hole.ADP.yx;
    TDF_zy_ADP_minority = TDF_sep_hole.ADP.yz;
    TDF_zx_ADP_minority = TDF_sep_hole.ADP.zx;
    
    MFP_x_ADP_majority = MFP_sep_electron.ADP.x;
    MFP_y_ADP_majority = MFP_sep_electron.ADP.y;
    MFP_z_ADP_majority = MFP_sep_electron.ADP.z;
    
    MFP_x_ADP_minority = MFP_sep_hole.ADP.x;
    MFP_y_ADP_minority = MFP_sep_hole.ADP.y;
    MFP_z_ADP_minority = MFP_sep_hole.ADP.z;
    
    tauE_x_ADP_majority = tauE_sep_electron.ADP.x;
    tauE_y_ADP_majority = tauE_sep_electron.ADP.y;
    tauE_z_ADP_majority = tauE_sep_electron.ADP.z;
    
    tauE_x_ADP_minority = tauE_sep_hole.ADP.x;
    tauE_y_ADP_minority = tauE_sep_hole.ADP.y;
    tauE_z_ADP_minority = tauE_sep_hole.ADP.z;
    
    TDF_xx_ADP(1:pos_minority_band_edge,:) = TDF_xx_ADP_minority(size(TDF_xx_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_ADP(pos_majority_band_edge:size(TDF_xx_ADP,1),:) = TDF_xx_ADP(pos_majority_band_edge:size(TDF_xx_ADP,1),:) + TDF_xx_ADP_majority((relative_pos_majority_band_edge:size(TDF_xx_ADP_majority,1)),:);
    
    TDF_yy_ADP(1:pos_minority_band_edge,:) = TDF_yy_ADP_minority(size(TDF_yy_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_ADP(pos_majority_band_edge:size(TDF_yy_ADP,1),:) = TDF_yy_ADP(pos_majority_band_edge:size(TDF_yy_ADP,1),:) + TDF_yy_ADP_majority((relative_pos_majority_band_edge:size(TDF_xx_ADP_majority,1)),:);
    
    TDF_zz_ADP(1:pos_minority_band_edge,:) = TDF_zz_ADP_minority(size(TDF_zz_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zz_ADP(pos_majority_band_edge:size(TDF_zz_ADP,1),:) = TDF_zz_ADP(pos_majority_band_edge:size(TDF_zz_ADP,1),:) + TDF_zz_ADP_majority((relative_pos_majority_band_edge:size(TDF_xx_ADP_majority,1)),:);
    
    TDF_xy_ADP(1:pos_minority_band_edge,:) = TDF_xy_ADP_minority(size(TDF_xy_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_ADP(pos_majority_band_edge:size(TDF_xy_ADP,1),:) = TDF_xy_ADP(pos_majority_band_edge:size(TDF_xy_ADP,1),:) + TDF_xy_ADP_majority((relative_pos_majority_band_edge:size(TDF_xy_ADP_majority,1)),:);
    
    TDF_yz_ADP(1:pos_minority_band_edge,:) = TDF_yz_ADP_minority(size(TDF_yz_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yz_ADP(pos_majority_band_edge:size(TDF_yz_ADP,1),:) = TDF_yz_ADP(pos_majority_band_edge:size(TDF_yz_ADP,1),:) + TDF_yz_ADP_majority((relative_pos_majority_band_edge:size(TDF_yz_ADP_majority,1)),:);
    
    TDF_xz_ADP(1:pos_minority_band_edge,:) = TDF_xz_ADP_minority(size(TDF_xz_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xz_ADP(pos_majority_band_edge:size(TDF_xz_ADP,1),:) = TDF_xz_ADP(pos_majority_band_edge:size(TDF_xz_ADP,1),:) + TDF_xz_ADP_majority((relative_pos_majority_band_edge:size(TDF_xy_ADP_majority,1)),:);
    
    TDF_yx_ADP(1:pos_minority_band_edge,:) = TDF_yx_ADP_minority(size(TDF_yx_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_ADP(pos_majority_band_edge:size(TDF_yx_ADP,1),:) = TDF_yx_ADP(pos_majority_band_edge:size(TDF_yx_ADP,1),:) + TDF_yx_ADP_majority((relative_pos_majority_band_edge:size(TDF_yx_ADP_majority,1)),:);
    
    TDF_zy_ADP(1:pos_minority_band_edge,:) = TDF_zy_ADP_minority(size(TDF_zy_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zy_ADP(pos_majority_band_edge:size(TDF_zy_ADP,1),:) = TDF_zy_ADP(pos_majority_band_edge:size(TDF_zy_ADP,1),:) + TDF_zy_ADP_majority((relative_pos_majority_band_edge:size(TDF_zy_ADP_majority,1)),:);
    
    TDF_zx_ADP(1:pos_minority_band_edge,:) = TDF_zx_ADP_minority(size(TDF_xz_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zx_ADP(pos_majority_band_edge:size(TDF_zx_ADP,1),:) = TDF_zx_ADP(pos_majority_band_edge:size(TDF_zx_ADP,1),:) + TDF_zx_ADP_majority((relative_pos_majority_band_edge:size(TDF_zx_ADP_majority,1)),:);
    
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_ADP_majority); MFP_x_ADP_majority(NNan)=0;
    NNan = isnan(MFP_y_ADP_minority); MFP_y_ADP_minority(NNan)=0;
    NNan = isnan(MFP_y_ADP_majority); MFP_y_ADP_majority(NNan)=0;
    NNan = isnan(tauE_x_ADP_minority); tauE_x_ADP_minority(NNan)=0;
    NNan = isnan(tauE_x_ADP_majority); tauE_x_ADP_majority(NNan)=0;
    NNan = isnan(MFP_x_ADP_minority); MFP_x_ADP_minority(NNan)=0;
    NNan = isnan(MFP_z_ADP_majority); MFP_z_ADP_majority(NNan)=0;
    NNan = isnan(MFP_z_ADP_minority); MFP_z_ADP_minority(NNan)=0;
    NNan = isnan(tauE_y_ADP_majority); tauE_y_ADP_majority(NNan)=0;
    NNan = isnan(tauE_y_ADP_minority); tauE_y_ADP_minority(NNan)=0;
    NNan = isnan(tauE_z_ADP_majority); tauE_z_ADP_majority(NNan)=0;
    NNan = isnan(tauE_z_ADP_minority); tauE_z_ADP_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_ADP(1:pos_minority_band_edge,:) = MFP_x_ADP_minority(size(MFP_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) = merge_ave( MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) , MFP_x_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:) );

        MFP_y_ADP(1:pos_minority_band_edge,:) = MFP_y_ADP_minority(size(MFP_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) = merge_ave(MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) , MFP_y_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:) );

        MFP_z_ADP(1:pos_minority_band_edge,:) = MFP_z_ADP_minority(size(MFP_z_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_ADP(pos_majority_band_edge:size(MFP_z_ADP,1),:) = merge_ave(MFP_z_ADP(pos_majority_band_edge:size(MFP_z_ADP,1),:) , MFP_z_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:) );

        tauE_x_ADP(1:pos_minority_band_edge,:) = tauE_x_ADP_minority(size(tauE_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) = merge_ave(tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) , tauE_x_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:) );

        tauE_y_ADP(1:pos_minority_band_edge,:) = tauE_y_ADP_minority(size(tauE_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) = merge_ave(tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) , tauE_y_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:) );

        tauE_z_ADP(1:pos_minority_band_edge,:) = tauE_z_ADP_minority(size(tauE_z_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_ADP(pos_majority_band_edge:size(tauE_z_ADP,1),:) = merge_ave(tauE_z_ADP(pos_majority_band_edge:size(tauE_z_ADP,1),:) , tauE_z_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:) );
    else
        MFP_x_ADP(1:pos_minority_band_edge,:) = MFP_x_ADP_minority(size(MFP_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) = MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) + MFP_x_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:);

        MFP_y_ADP(1:pos_minority_band_edge,:) = MFP_y_ADP_minority(size(MFP_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) = MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) + MFP_y_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:);

        MFP_z_ADP(1:pos_minority_band_edge,:) = MFP_z_ADP_minority(size(MFP_z_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_ADP(pos_majority_band_edge:size(MFP_z_ADP,1),:) = MFP_z_ADP(pos_majority_band_edge:size(MFP_z_ADP,1),:) + MFP_z_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:);

        tauE_x_ADP(1:pos_minority_band_edge,:) = tauE_x_ADP_minority(size(tauE_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) = tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) + tauE_x_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:);

        tauE_y_ADP(1:pos_minority_band_edge,:) = tauE_y_ADP_minority(size(tauE_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) = tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) + tauE_y_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:);

        tauE_z_ADP(1:pos_minority_band_edge,:) = tauE_z_ADP_minority(size(tauE_z_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_ADP(pos_majority_band_edge:size(tauE_z_ADP,1),:) = tauE_z_ADP(pos_majority_band_edge:size(tauE_z_ADP,1),:) + tauE_z_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:);
    end
    
    TDF_sep.ADP.xx = TDF_xx_ADP; TDF_sep.ADP.xy = TDF_xy_ADP; TDF_sep.ADP.xz = TDF_xz_ADP;
    TDF_sep.ADP.yx = TDF_yx_ADP; TDF_sep.ADP.yy = TDF_yy_ADP; TDF_sep.ADP.yz = TDF_yz_ADP;
    TDF_sep.ADP.zx = TDF_zx_ADP; TDF_sep.ADP.zy = TDF_zy_ADP; TDF_sep.ADP.zz = TDF_zz_ADP;
    
    MFP_sep.ADP.x = MFP_x_ADP; MFP_sep.ADP.y = MFP_y_ADP; MFP_sep.ADP.z = MFP_z_ADP;
    tauE_sep.ADP.x = tauE_x_ADP; tauE_sep.ADP.y = tauE_y_ADP; tauE_sep.ADP.z = tauE_z_ADP;
    
    
end
    
    % ---------  ODP only---------------------------------------------
if strcmp(ODP,'yes') 
    
    TDF_xx_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zz_ODP=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_xy_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yz_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_xz_ODP=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_yx_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zy_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zx_ODP=zeros(size(E_array,2),size(EF_matrix,2));
    MFP_x_ODP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_ODP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_z_ODP=zeros(size(E_array,2),size(EF_matrix,2));
    tauE_x_ODP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_ODP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_z_ODP=zeros(size(E_array,2),size(EF_matrix,2));

    TDF_xx_ODP_majority = TDF_sep_electron.ODP.xx;
    TDF_yy_ODP_majority = TDF_sep_electron.ODP.yy;
    TDF_zz_ODP_majority = TDF_sep_electron.ODP.zz;
    TDF_xy_ODP_majority = TDF_sep_electron.ODP.xy;
    TDF_yz_ODP_majority = TDF_sep_electron.ODP.yz;
    TDF_xz_ODP_majority = TDF_sep_electron.ODP.xz;
    TDF_yx_ODP_majority = TDF_sep_electron.ODP.yx;
    TDF_zy_ODP_majority = TDF_sep_electron.ODP.yz;
    TDF_zx_ODP_majority = TDF_sep_electron.ODP.zx;
    
    TDF_xx_ODP_minority = TDF_sep_hole.ODP.xx;
    TDF_yy_ODP_minority = TDF_sep_hole.ODP.yy;
    TDF_zz_ODP_minority = TDF_sep_hole.ODP.zz;
    TDF_xy_ODP_minority = TDF_sep_hole.ODP.xy;
    TDF_yz_ODP_minority = TDF_sep_hole.ODP.yz;
    TDF_xz_ODP_minority = TDF_sep_hole.ODP.xz;
    TDF_yx_ODP_minority = TDF_sep_hole.ODP.yx;
    TDF_zy_ODP_minority = TDF_sep_hole.ODP.yz;
    TDF_zx_ODP_minority = TDF_sep_hole.ODP.zx;
    
    MFP_x_ODP_majority = MFP_sep_electron.ODP.x;
    MFP_y_ODP_majority = MFP_sep_electron.ODP.y;
    MFP_z_ODP_majority = MFP_sep_electron.ODP.z;
    
    MFP_x_ODP_minority = MFP_sep_hole.ODP.x;
    MFP_y_ODP_minority = MFP_sep_hole.ODP.y;
    MFP_z_ODP_minority = MFP_sep_hole.ODP.z;
    
    tauE_x_ODP_majority = tauE_sep_electron.ODP.x;
    tauE_y_ODP_majority = tauE_sep_electron.ODP.y;
    tauE_z_ODP_majority = tauE_sep_electron.ODP.z;
    
    tauE_x_ODP_minority = tauE_sep_hole.ODP.x;
    tauE_y_ODP_minority = tauE_sep_hole.ODP.y;
    tauE_z_ODP_minority = tauE_sep_hole.ODP.z;
    
    TDF_xx_ODP(1:pos_minority_band_edge,:) = TDF_xx_ODP_minority(size(TDF_xx_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) = TDF_xx_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) + TDF_xx_ODP_majority((relative_pos_majority_band_edge:size(TDF_xx_ODP_majority,1)),:);
    
    TDF_yy_ODP(1:pos_minority_band_edge,:) = TDF_yy_ODP_minority(size(TDF_yy_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_ODP(pos_majority_band_edge:size(TDF_yy_ODP,1),:) = TDF_yy_ODP(pos_majority_band_edge:size(TDF_yy_ODP,1),:) + TDF_yy_ODP_majority((relative_pos_majority_band_edge:size(TDF_xx_ODP_majority,1)),:);
    
    TDF_zz_ODP(1:pos_minority_band_edge,:) = TDF_zz_ODP_minority(size(TDF_zz_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zz_ODP(pos_majority_band_edge:size(TDF_zz_ODP,1),:) =  TDF_zz_ODP(pos_majority_band_edge:size(TDF_zz_ODP,1),:) + TDF_zz_ODP_majority((relative_pos_majority_band_edge:size(TDF_xx_ODP_majority,1)),:);
    
    TDF_xy_ODP(1:pos_minority_band_edge,:) = TDF_xy_ODP_minority(size(TDF_xy_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_ODP(pos_majority_band_edge:size(TDF_xy_ODP,1),:) = TDF_xy_ODP(pos_majority_band_edge:size(TDF_xy_ODP,1),:) + TDF_xy_ODP_majority((relative_pos_majority_band_edge:size(TDF_xy_ODP_majority,1)),:);
    
    TDF_yz_ODP(1:pos_minority_band_edge,:) = TDF_yz_ODP_minority(size(TDF_yz_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yz_ODP(pos_majority_band_edge:size(TDF_yz_ODP,1),:) = TDF_yz_ODP(pos_majority_band_edge:size(TDF_yz_ODP,1),:) + TDF_yz_ODP_majority((relative_pos_majority_band_edge:size(TDF_yz_ODP_majority,1)),:);
    
    TDF_xz_ODP(1:pos_minority_band_edge,:) = TDF_xz_ODP_minority(size(TDF_xz_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xz_ODP(pos_majority_band_edge:size(TDF_xz_ODP,1),:) = TDF_xz_ODP(pos_majority_band_edge:size(TDF_xz_ODP,1),:) + TDF_xz_ODP_majority((relative_pos_majority_band_edge:size(TDF_xy_ODP_majority,1)),:);
    
    TDF_yx_ODP(1:pos_minority_band_edge,:) = TDF_yx_ODP_minority(size(TDF_yx_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_ODP(pos_majority_band_edge:size(TDF_yx_ODP,1),:) = TDF_yx_ODP(pos_majority_band_edge:size(TDF_yx_ODP,1),:) + TDF_yx_ODP_majority((relative_pos_majority_band_edge:size(TDF_yx_ODP_majority,1)),:);
    
    TDF_zy_ODP(1:pos_minority_band_edge,:) = TDF_zy_ODP_minority(size(TDF_zy_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zy_ODP(pos_majority_band_edge:size(TDF_zy_ODP,1),:) = TDF_zy_ODP(pos_majority_band_edge:size(TDF_zy_ODP,1),:) + TDF_zy_ODP_majority((relative_pos_majority_band_edge:size(TDF_zy_ODP_majority,1)),:);
    
    TDF_zx_ODP(1:pos_minority_band_edge,:) = TDF_zx_ODP_minority(size(TDF_xz_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zx_ODP(pos_majority_band_edge:size(TDF_zx_ODP,1),:) = TDF_zx_ODP(pos_majority_band_edge:size(TDF_zx_ODP,1),:) + TDF_zx_ODP_majority((relative_pos_majority_band_edge:size(TDF_zx_ODP_majority,1)),:);
    
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_ODP_majority); MFP_x_ODP_majority(NNan)=0;
    NNan = isnan(MFP_y_ODP_minority); MFP_y_ODP_minority(NNan)=0;
    NNan = isnan(MFP_y_ODP_majority); MFP_y_ODP_majority(NNan)=0;
    NNan = isnan(tauE_x_ODP_minority); tauE_x_ODP_minority(NNan)=0;
    NNan = isnan(tauE_x_ODP_majority); tauE_x_ODP_majority(NNan)=0;
    NNan = isnan(MFP_x_ODP_minority); MFP_x_ODP_minority(NNan)=0;
    NNan = isnan(MFP_z_ODP_majority); MFP_z_ODP_majority(NNan)=0;
    NNan = isnan(MFP_z_ODP_minority); MFP_z_ODP_minority(NNan)=0;
    NNan = isnan(tauE_y_ODP_majority); tauE_y_ODP_majority(NNan)=0;
    NNan = isnan(tauE_y_ODP_minority); tauE_y_ODP_minority(NNan)=0;
    NNan = isnan(tauE_z_ODP_majority); tauE_z_ODP_majority(NNan)=0;
    NNan = isnan(tauE_z_ODP_minority); tauE_z_ODP_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_ODP(1:pos_minority_band_edge,:) = MFP_x_ODP_minority(size(MFP_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) = merge_ave( MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) , MFP_x_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:) );

        MFP_y_ODP(1:pos_minority_band_edge,:) = MFP_y_ODP_minority(size(MFP_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) = merge_ave(MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) , MFP_y_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:) );

        MFP_z_ODP(1:pos_minority_band_edge,:) = MFP_z_ODP_minority(size(MFP_z_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_ODP(pos_majority_band_edge:size(MFP_z_ODP,1),:) = merge_ave(MFP_z_ODP(pos_majority_band_edge:size(MFP_z_ODP,1),:) , MFP_z_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:) );

        tauE_x_ODP(1:pos_minority_band_edge,:) = tauE_x_ODP_minority(size(tauE_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) = merge_ave(tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) , tauE_x_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:) );

        tauE_y_ODP(1:pos_minority_band_edge,:) = tauE_y_ODP_minority(size(tauE_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) = merge_ave(tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) , tauE_y_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:) );

        tauE_z_ODP(1:pos_minority_band_edge,:) = tauE_z_ODP_minority(size(tauE_z_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_ODP(pos_majority_band_edge:size(tauE_z_ODP,1),:) = merge_ave(tauE_z_ODP(pos_majority_band_edge:size(tauE_z_ODP,1),:) , tauE_z_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:) );
    else
        MFP_x_ODP(1:pos_minority_band_edge,:) = MFP_x_ODP_minority(size(MFP_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) = MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) + MFP_x_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:);

        MFP_y_ODP(1:pos_minority_band_edge,:) = MFP_y_ODP_minority(size(MFP_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) = MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) + MFP_y_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:);

        MFP_z_ODP(1:pos_minority_band_edge,:) = MFP_z_ODP_minority(size(MFP_z_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_ODP(pos_majority_band_edge:size(MFP_z_ODP,1),:) = MFP_z_ODP(pos_majority_band_edge:size(MFP_z_ODP,1),:) + MFP_z_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:);

        tauE_x_ODP(1:pos_minority_band_edge,:) = tauE_x_ODP_minority(size(tauE_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) = tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) + tauE_x_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:);

        tauE_y_ODP(1:pos_minority_band_edge,:) = tauE_y_ODP_minority(size(tauE_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) = tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) + tauE_y_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:);

        tauE_z_ODP(1:pos_minority_band_edge,:) = tauE_z_ODP_minority(size(tauE_z_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_ODP(pos_majority_band_edge:size(tauE_z_ODP,1),:) = tauE_z_ODP(pos_majority_band_edge:size(tauE_z_ODP,1),:) + tauE_z_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:);
    end
    
    TDF_sep.ODP.xx = TDF_xx_ODP; TDF_sep.ODP.xy = TDF_xy_ODP; TDF_sep.ODP.xz = TDF_xz_ODP;
    TDF_sep.ODP.yx = TDF_yx_ODP; TDF_sep.ODP.yy = TDF_yy_ODP; TDF_sep.ODP.yz = TDF_yz_ODP;
    TDF_sep.ODP.zx = TDF_zx_ODP; TDF_sep.ODP.zy = TDF_zy_ODP; TDF_sep.ODP.zz = TDF_zz_ODP;
    
    MFP_sep.ODP.x = MFP_x_ODP; MFP_sep.ODP.y = MFP_y_ODP; MFP_sep.ODP.z = MFP_z_ODP;
    tauE_sep.ODP.x = tauE_x_ODP; tauE_sep.ODP.y = tauE_y_ODP; tauE_sep.ODP.z = tauE_z_ODP; 
    
    
end



    % ---------  IVS only---------------------------------------------
if strcmp(IVS,'yes')
    
    TDF_xx_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zz_IVS=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_xy_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yz_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_xz_IVS=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_yx_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zy_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zx_IVS=zeros(size(E_array,2),size(EF_matrix,2));
    MFP_x_IVS=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_IVS=zeros(size(E_array,2),size(EF_matrix,2)); MFP_z_IVS=zeros(size(E_array,2),size(EF_matrix,2));
    tauE_x_IVS=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_IVS=zeros(size(E_array,2),size(EF_matrix,2)); tauE_z_IVS=zeros(size(E_array,2),size(EF_matrix,2));

    TDF_xx_IVS_majority = TDF_sep_electron.IVS.xx;
    TDF_yy_IVS_majority = TDF_sep_electron.IVS.yy;
    TDF_zz_IVS_majority = TDF_sep_electron.IVS.zz;
    TDF_xy_IVS_majority = TDF_sep_electron.IVS.xy;
    TDF_yz_IVS_majority = TDF_sep_electron.IVS.yz;
    TDF_xz_IVS_majority = TDF_sep_electron.IVS.xz;
    TDF_yx_IVS_majority = TDF_sep_electron.IVS.yx;
    TDF_zy_IVS_majority = TDF_sep_electron.IVS.yz;
    TDF_zx_IVS_majority = TDF_sep_electron.IVS.zx;
    
    TDF_xx_IVS_minority = TDF_sep_hole.IVS.xx;
    TDF_yy_IVS_minority = TDF_sep_hole.IVS.yy;
    TDF_zz_IVS_minority = TDF_sep_hole.IVS.zz;
    TDF_xy_IVS_minority = TDF_sep_hole.IVS.xy;
    TDF_yz_IVS_minority = TDF_sep_hole.IVS.yz;
    TDF_xz_IVS_minority = TDF_sep_hole.IVS.xz;
    TDF_yx_IVS_minority = TDF_sep_hole.IVS.yx;
    TDF_zy_IVS_minority = TDF_sep_hole.IVS.yz;
    TDF_zx_IVS_minority = TDF_sep_hole.IVS.zx;
    
    MFP_x_IVS_majority = MFP_sep_electron.IVS.x;
    MFP_y_IVS_majority = MFP_sep_electron.IVS.y;
    MFP_z_IVS_majority = MFP_sep_electron.IVS.z;
    
    MFP_x_IVS_minority = MFP_sep_hole.IVS.x;
    MFP_y_IVS_minority = MFP_sep_hole.IVS.y;
    MFP_z_IVS_minority = MFP_sep_hole.IVS.z;
    
    tauE_x_IVS_majority = tauE_sep_electron.IVS.x;
    tauE_y_IVS_majority = tauE_sep_electron.IVS.y;
    tauE_z_IVS_majority = tauE_sep_electron.IVS.z;
    
    tauE_x_IVS_minority = tauE_sep_hole.IVS.x;
    tauE_y_IVS_minority = tauE_sep_hole.IVS.y;
    tauE_z_IVS_minority = tauE_sep_hole.IVS.z;
    
    TDF_xx_IVS(1:pos_minority_band_edge,:) = TDF_xx_IVS_minority(size(TDF_xx_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_IVS(pos_majority_band_edge:size(TDF_xx_IVS,1),:) = TDF_xx_IVS(pos_majority_band_edge:size(TDF_xx_IVS,1),:) + TDF_xx_IVS_majority((relative_pos_majority_band_edge:size(TDF_xx_IVS_majority,1)),:);
    
    TDF_yy_IVS(1:pos_minority_band_edge,:) = TDF_yy_IVS_minority(size(TDF_yy_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_IVS(pos_majority_band_edge:size(TDF_yy_IVS,1),:) = TDF_yy_IVS(pos_majority_band_edge:size(TDF_yy_IVS,1),:) + TDF_yy_IVS_majority((relative_pos_majority_band_edge:size(TDF_xx_IVS_majority,1)),:);
    
    TDF_zz_IVS(1:pos_minority_band_edge,:) = TDF_zz_IVS_minority(size(TDF_zz_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zz_IVS(pos_majority_band_edge:size(TDF_zz_IVS,1),:) = TDF_zz_IVS(pos_majority_band_edge:size(TDF_zz_IVS,1),:) + TDF_zz_IVS_majority((relative_pos_majority_band_edge:size(TDF_xx_IVS_majority,1)),:);
    
    TDF_xy_IVS(1:pos_minority_band_edge,:) = TDF_xy_IVS_minority(size(TDF_xy_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_IVS(pos_majority_band_edge:size(TDF_xy_IVS,1),:) = TDF_xy_IVS(pos_majority_band_edge:size(TDF_xy_IVS,1),:) + TDF_xy_IVS_majority((relative_pos_majority_band_edge:size(TDF_xy_IVS_majority,1)),:);
    
    TDF_yz_IVS(1:pos_minority_band_edge,:) = TDF_yz_IVS_minority(size(TDF_yz_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yz_IVS(pos_majority_band_edge:size(TDF_yz_IVS,1),:) = TDF_yz_IVS(pos_majority_band_edge:size(TDF_yz_IVS,1),:) + TDF_yz_IVS_majority((relative_pos_majority_band_edge:size(TDF_yz_IVS_majority,1)),:);
    
    TDF_xz_IVS(1:pos_minority_band_edge,:) = TDF_xz_IVS_minority(size(TDF_xz_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xz_IVS(pos_majority_band_edge:size(TDF_xz_IVS,1),:) = TDF_xz_IVS(pos_majority_band_edge:size(TDF_xz_IVS,1),:) + TDF_xz_IVS_majority((relative_pos_majority_band_edge:size(TDF_xy_IVS_majority,1)),:);
    
    TDF_yx_IVS(1:pos_minority_band_edge,:) = TDF_yx_IVS_minority(size(TDF_yx_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_IVS(pos_majority_band_edge:size(TDF_yx_IVS,1),:) = TDF_yx_IVS(pos_majority_band_edge:size(TDF_yx_IVS,1),:) + TDF_yx_IVS_majority((relative_pos_majority_band_edge:size(TDF_yx_IVS_majority,1)),:);
    
    TDF_zy_IVS(1:pos_minority_band_edge,:) = TDF_zy_IVS_minority(size(TDF_zy_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zy_IVS(pos_majority_band_edge:size(TDF_zy_IVS,1),:) = TDF_zy_IVS(pos_majority_band_edge:size(TDF_zy_IVS,1),:) + TDF_zy_IVS_majority((relative_pos_majority_band_edge:size(TDF_zy_IVS_majority,1)),:);
    
    TDF_zx_IVS(1:pos_minority_band_edge,:) = TDF_zx_IVS_minority(size(TDF_xz_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zx_IVS(pos_majority_band_edge:size(TDF_zx_IVS,1),:) = TDF_zx_IVS(pos_majority_band_edge:size(TDF_zx_IVS,1),:) + TDF_zx_IVS_majority((relative_pos_majority_band_edge:size(TDF_zx_IVS_majority,1)),:);
    
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_IVS_majority); MFP_x_IVS_majority(NNan)=0;
    NNan = isnan(MFP_y_IVS_minority); MFP_y_IVS_minority(NNan)=0;
    NNan = isnan(MFP_y_IVS_majority); MFP_y_IVS_majority(NNan)=0;
    NNan = isnan(tauE_x_IVS_minority); tauE_x_IVS_minority(NNan)=0;
    NNan = isnan(tauE_x_IVS_majority); tauE_x_IVS_majority(NNan)=0;
    NNan = isnan(MFP_x_IVS_minority); MFP_x_IVS_minority(NNan)=0;
    NNan = isnan(MFP_z_IVS_majority); MFP_z_IVS_majority(NNan)=0;
    NNan = isnan(MFP_z_IVS_minority); MFP_z_IVS_minority(NNan)=0;
    NNan = isnan(tauE_y_IVS_majority); tauE_y_IVS_majority(NNan)=0;
    NNan = isnan(tauE_y_IVS_minority); tauE_y_IVS_minority(NNan)=0;
    NNan = isnan(tauE_z_IVS_majority); tauE_z_IVS_majority(NNan)=0;
    NNan = isnan(tauE_z_IVS_minority); tauE_z_IVS_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_IVS(1:pos_minority_band_edge,:) = MFP_x_IVS_minority(size(MFP_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:) = merge_ave( MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:) , MFP_x_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:) );

        MFP_y_IVS(1:pos_minority_band_edge,:) = MFP_y_IVS_minority(size(MFP_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) = merge_ave(MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) , MFP_y_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:) );

        MFP_z_IVS(1:pos_minority_band_edge,:) = MFP_z_IVS_minority(size(MFP_z_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_IVS(pos_majority_band_edge:size(MFP_z_IVS,1),:) = merge_ave(MFP_z_IVS(pos_majority_band_edge:size(MFP_z_IVS,1),:) , MFP_z_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:) );

        tauE_x_IVS(1:pos_minority_band_edge,:) = tauE_x_IVS_minority(size(tauE_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) = merge_ave(tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) , tauE_x_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:) );

        tauE_y_IVS(1:pos_minority_band_edge,:) = tauE_y_IVS_minority(size(tauE_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) = merge_ave(tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) , tauE_y_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:) );

        tauE_z_IVS(1:pos_minority_band_edge,:) = tauE_z_IVS_minority(size(tauE_z_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_IVS(pos_majority_band_edge:size(tauE_z_IVS,1),:) = merge_ave(tauE_z_IVS(pos_majority_band_edge:size(tauE_z_IVS,1),:) , tauE_z_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:) );
    else
        MFP_x_IVS(1:pos_minority_band_edge,:) = MFP_x_IVS_minority(size(MFP_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:) = MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:)+ MFP_x_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:);

        MFP_y_IVS(1:pos_minority_band_edge,:) = MFP_y_IVS_minority(size(MFP_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) = MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) + MFP_y_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:);

        MFP_z_IVS(1:pos_minority_band_edge,:) = MFP_z_IVS_minority(size(MFP_z_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_IVS(pos_majority_band_edge:size(MFP_z_IVS,1),:) = MFP_z_IVS(pos_majority_band_edge:size(MFP_z_IVS,1),:) + MFP_z_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:);

        tauE_x_IVS(1:pos_minority_band_edge,:) = tauE_x_IVS_minority(size(tauE_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) = tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) + tauE_x_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:);

        tauE_y_IVS(1:pos_minority_band_edge,:) = tauE_y_IVS_minority(size(tauE_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) = tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) + tauE_y_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:);

        tauE_z_IVS(1:pos_minority_band_edge,:) = tauE_z_IVS_minority(size(tauE_z_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_IVS(pos_majority_band_edge:size(tauE_z_IVS,1),:) = tauE_z_IVS(pos_majority_band_edge:size(tauE_z_IVS,1),:) + tauE_z_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:);
    end
    
    TDF_sep.IVS.xx = TDF_xx_IVS; TDF_sep.IVS.xy = TDF_xy_IVS; TDF_sep.IVS.xz = TDF_xz_IVS;
    TDF_sep.IVS.yx = TDF_yx_IVS; TDF_sep.IVS.yy = TDF_yy_IVS; TDF_sep.IVS.yz = TDF_yz_IVS;
    TDF_sep.IVS.zx = TDF_zx_IVS; TDF_sep.IVS.zy = TDF_zy_IVS; TDF_sep.IVS.zz = TDF_zz_IVS;
    
    MFP_sep.IVS.x = MFP_x_IVS; MFP_sep.IVS.y = MFP_y_IVS; MFP_sep.IVS.z = MFP_z_IVS;
    tauE_sep.IVS.x = tauE_x_IVS; tauE_sep.IVS.y = tauE_y_IVS; tauE_sep.IVS.z = tauE_z_IVS;
    
    
end

 % ---------  POP only---------------------------------------------
if strcmp(POP,'yes')
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'no')
    
        TDF_xx_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zz_POP=zeros(size(E_array,2),size(EF_matrix,2));
        TDF_xy_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yz_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_xz_POP=zeros(size(E_array,2),size(EF_matrix,2));
        TDF_yx_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zy_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zx_POP=zeros(size(E_array,2),size(EF_matrix,2));
        MFP_x_POP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_POP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_z_POP=zeros(size(E_array,2),size(EF_matrix,2));
        tauE_x_POP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_POP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_z_POP=zeros(size(E_array,2),size(EF_matrix,2));

        TDF_xx_POP_majority = TDF_sep_electron.POP.xx;
        TDF_yy_POP_majority = TDF_sep_electron.POP.yy;
        TDF_zz_POP_majority = TDF_sep_electron.POP.zz;
        TDF_xy_POP_majority = TDF_sep_electron.POP.xy;
        TDF_yz_POP_majority = TDF_sep_electron.POP.yz;
        TDF_xz_POP_majority = TDF_sep_electron.POP.xz;
        TDF_yx_POP_majority = TDF_sep_electron.POP.yx;
        TDF_zy_POP_majority = TDF_sep_electron.POP.yz;
        TDF_zx_POP_majority = TDF_sep_electron.POP.zx;

        TDF_xx_POP_minority = TDF_sep_hole.POP.xx;
        TDF_yy_POP_minority = TDF_sep_hole.POP.yy;
        TDF_zz_POP_minority = TDF_sep_hole.POP.zz;
        TDF_xy_POP_minority = TDF_sep_hole.POP.xy;
        TDF_yz_POP_minority = TDF_sep_hole.POP.yz;
        TDF_xz_POP_minority = TDF_sep_hole.POP.xz;
        TDF_yx_POP_minority = TDF_sep_hole.POP.yx;
        TDF_zy_POP_minority = TDF_sep_hole.POP.yz;
        TDF_zx_POP_minority = TDF_sep_hole.POP.zx;

        MFP_x_POP_majority = MFP_sep_electron.POP.x;
        MFP_y_POP_majority = MFP_sep_electron.POP.y;
        MFP_z_POP_majority = MFP_sep_electron.POP.z;

        MFP_x_POP_minority = MFP_sep_hole.POP.x;
        MFP_y_POP_minority = MFP_sep_hole.POP.y;
        MFP_z_POP_minority = MFP_sep_hole.POP.z;

        tauE_x_POP_majority = tauE_sep_electron.POP.x;
        tauE_y_POP_majority = tauE_sep_electron.POP.y;
        tauE_z_POP_majority = tauE_sep_electron.POP.z;

        tauE_x_POP_minority = tauE_sep_hole.POP.x;
        tauE_y_POP_minority = tauE_sep_hole.POP.y;
        tauE_z_POP_minority = tauE_sep_hole.POP.z;

        TDF_xx_POP(1:pos_minority_band_edge,:) = TDF_xx_POP_minority(size(TDF_xx_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) =  TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) + TDF_xx_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:);

        TDF_yy_POP(1:pos_minority_band_edge,:) = TDF_yy_POP_minority(size(TDF_yy_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_yy_POP(pos_majority_band_edge:size(TDF_yy_POP,1),:) = TDF_yy_POP(pos_majority_band_edge:size(TDF_yy_POP,1),:) + TDF_yy_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:);

        TDF_zz_POP(1:pos_minority_band_edge,:) = TDF_zz_POP_minority(size(TDF_zz_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_zz_POP(pos_majority_band_edge:size(TDF_zz_POP,1),:) = TDF_zz_POP(pos_majority_band_edge:size(TDF_zz_POP,1),:) + TDF_zz_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:);

        TDF_xy_POP(1:pos_minority_band_edge,:) = TDF_xy_POP_minority(size(TDF_xy_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_xy_POP(pos_majority_band_edge:size(TDF_xy_POP,1),:) = TDF_xy_POP(pos_majority_band_edge:size(TDF_xy_POP,1),:) + TDF_xy_POP_majority((relative_pos_majority_band_edge:size(TDF_xy_POP_majority,1)),:);

        TDF_yz_POP(1:pos_minority_band_edge,:) = TDF_yz_POP_minority(size(TDF_yz_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_yz_POP(pos_majority_band_edge:size(TDF_yz_POP,1),:) = TDF_yz_POP(pos_majority_band_edge:size(TDF_yz_POP,1),:) + TDF_yz_POP_majority((relative_pos_majority_band_edge:size(TDF_yz_POP_majority,1)),:);

        TDF_xz_POP(1:pos_minority_band_edge,:) = TDF_xz_POP_minority(size(TDF_xz_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_xz_POP(pos_majority_band_edge:size(TDF_xz_POP,1),:) = TDF_xz_POP(pos_majority_band_edge:size(TDF_xz_POP,1),:) + TDF_xz_POP_majority((relative_pos_majority_band_edge:size(TDF_xy_POP_majority,1)),:);

        TDF_yx_POP(1:pos_minority_band_edge,:) = TDF_yx_POP_minority(size(TDF_yx_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_yx_POP(pos_majority_band_edge:size(TDF_yx_POP,1),:) = TDF_yx_POP(pos_majority_band_edge:size(TDF_yx_POP,1),:) + TDF_yx_POP_majority((relative_pos_majority_band_edge:size(TDF_yx_POP_majority,1)),:);

        TDF_zy_POP(1:pos_minority_band_edge,:) = TDF_zy_POP_minority(size(TDF_zy_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_zy_POP(pos_majority_band_edge:size(TDF_zy_POP,1),:) =  TDF_zy_POP(pos_majority_band_edge:size(TDF_zy_POP,1),:) + TDF_zy_POP_majority((relative_pos_majority_band_edge:size(TDF_zy_POP_majority,1)),:);

        TDF_zx_POP(1:pos_minority_band_edge,:) = TDF_zx_POP_minority(size(TDF_xz_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_zx_POP(pos_majority_band_edge:size(TDF_zx_POP,1),:) = TDF_zx_POP(pos_majority_band_edge:size(TDF_zx_POP,1),:) + TDF_zx_POP_majority((relative_pos_majority_band_edge:size(TDF_zx_POP_majority,1)),:);


        % composing the other energy dependent quantities
        NNan = isnan(MFP_x_POP_majority); MFP_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_y_POP_minority); MFP_y_POP_minority(NNan)=0;
        NNan = isnan(MFP_y_POP_majority); MFP_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_x_POP_minority); tauE_x_POP_minority(NNan)=0;
        NNan = isnan(tauE_x_POP_majority); tauE_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_x_POP_minority); MFP_x_POP_minority(NNan)=0;
        NNan = isnan(MFP_z_POP_majority); MFP_z_POP_majority(NNan)=0;
        NNan = isnan(MFP_z_POP_minority); MFP_z_POP_minority(NNan)=0;
        NNan = isnan(tauE_y_POP_majority); tauE_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_y_POP_minority); tauE_y_POP_minority(NNan)=0;
        NNan = isnan(tauE_z_POP_majority); tauE_z_POP_majority(NNan)=0;
        NNan = isnan(tauE_z_POP_minority); tauE_z_POP_minority(NNan)=0;
        if strcmp(negative_gap,'yes')
            MFP_x_POP(1:pos_minority_band_edge,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) = merge_ave( MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) , MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:) );

            MFP_y_POP(1:pos_minority_band_edge,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) = merge_ave(MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) , MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:) );

            MFP_z_POP(1:pos_minority_band_edge,:) = MFP_z_POP_minority(size(MFP_z_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:) = merge_ave(MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:) , MFP_z_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:) );

            tauE_x_POP(1:pos_minority_band_edge,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) = merge_ave(tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) , tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:) );

            tauE_y_POP(1:pos_minority_band_edge,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) = merge_ave(tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) , tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:) );

            tauE_z_POP(1:pos_minority_band_edge,:) = tauE_z_POP_minority(size(tauE_z_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:) = merge_ave(tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:) , tauE_z_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:) );
        else
            MFP_x_POP(1:pos_minority_band_edge,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) = MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) + MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:);

            MFP_y_POP(1:pos_minority_band_edge,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) = MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) + MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:);

            MFP_z_POP(1:pos_minority_band_edge,:) = MFP_z_POP_minority(size(MFP_z_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:) = MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:) + MFP_z_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:);

            tauE_x_POP(1:pos_minority_band_edge,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) = tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) + tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:);

            tauE_y_POP(1:pos_minority_band_edge,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) = tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) + tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:);

            tauE_z_POP(1:pos_minority_band_edge,:) = tauE_z_POP_minority(size(tauE_z_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:) = tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:) + tauE_z_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:);
        end
    
    elseif strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_xx_POP=zeros(nE, nEF, nT ); TDF_yy_POP=zeros(nE, nEF, nT ); TDF_zz_POP=zeros(nE, nEF, nT );
        TDF_xy_POP=zeros(nE, nEF, nT ); TDF_yz_POP=zeros(nE, nEF, nT ); TDF_xz_POP=zeros(nE, nEF, nT );
        TDF_yx_POP=zeros(nE, nEF, nT ); TDF_zy_POP=zeros(nE, nEF, nT ); TDF_zx_POP=zeros(nE, nEF, nT );
        MFP_x_POP=zeros(nE, nEF, nT ); MFP_y_POP=zeros(nE, nEF, nT ); MFP_z_POP=zeros(nE, nEF, nT );
        tauE_x_POP=zeros(nE, nEF, nT ); tauE_y_POP=zeros(nE, nEF, nT ); tauE_z_POP=zeros(nE, nEF, nT );

        TDF_xx_POP_majority = TDF_sep_electron.POP.xx;
        TDF_yy_POP_majority = TDF_sep_electron.POP.yy;
        TDF_zz_POP_majority = TDF_sep_electron.POP.zz;
        TDF_xy_POP_majority = TDF_sep_electron.POP.xy;
        TDF_yz_POP_majority = TDF_sep_electron.POP.yz;
        TDF_xz_POP_majority = TDF_sep_electron.POP.xz;
        TDF_yx_POP_majority = TDF_sep_electron.POP.yx;
        TDF_zy_POP_majority = TDF_sep_electron.POP.yz;
        TDF_zx_POP_majority = TDF_sep_electron.POP.zx;

        TDF_xx_POP_minority = TDF_sep_hole.POP.xx;
        TDF_yy_POP_minority = TDF_sep_hole.POP.yy;
        TDF_zz_POP_minority = TDF_sep_hole.POP.zz;
        TDF_xy_POP_minority = TDF_sep_hole.POP.xy;
        TDF_yz_POP_minority = TDF_sep_hole.POP.yz;
        TDF_xz_POP_minority = TDF_sep_hole.POP.xz;
        TDF_yx_POP_minority = TDF_sep_hole.POP.yx;
        TDF_zy_POP_minority = TDF_sep_hole.POP.yz;
        TDF_zx_POP_minority = TDF_sep_hole.POP.zx;

        MFP_x_POP_majority = MFP_sep_electron.POP.x;
        MFP_y_POP_majority = MFP_sep_electron.POP.y;
        MFP_z_POP_majority = MFP_sep_electron.POP.z;

        MFP_x_POP_minority = MFP_sep_hole.POP.x;
        MFP_y_POP_minority = MFP_sep_hole.POP.y;
        MFP_z_POP_minority = MFP_sep_hole.POP.z;

        tauE_x_POP_majority = tauE_sep_electron.POP.x;
        tauE_y_POP_majority = tauE_sep_electron.POP.y;
        tauE_z_POP_majority = tauE_sep_electron.POP.z;

        tauE_x_POP_minority = tauE_sep_hole.POP.x;
        tauE_y_POP_minority = tauE_sep_hole.POP.y;
        tauE_z_POP_minority = tauE_sep_hole.POP.z;

        TDF_xx_POP(1:pos_minority_band_edge,:,:) = TDF_xx_POP_minority(size(TDF_xx_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) = TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) + TDF_xx_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:,:);

        TDF_yy_POP(1:pos_minority_band_edge,:,:) = TDF_yy_POP_minority(size(TDF_yy_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_yy_POP(pos_majority_band_edge:size(TDF_yy_POP,1),:,:) = TDF_yy_POP(pos_majority_band_edge:size(TDF_yy_POP,1),:,:) + TDF_yy_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:,:);

        TDF_zz_POP(1:pos_minority_band_edge,:,:) = TDF_zz_POP_minority(size(TDF_zz_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_zz_POP(pos_majority_band_edge:size(TDF_zz_POP,1),:,:) = TDF_zz_POP(pos_majority_band_edge:size(TDF_zz_POP,1),:,:) + TDF_zz_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:,:);

        TDF_xy_POP(1:pos_minority_band_edge,:,:) = TDF_xy_POP_minority(size(TDF_xy_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_xy_POP(pos_majority_band_edge:size(TDF_xy_POP,1),:,:) = TDF_xy_POP(pos_majority_band_edge:size(TDF_xy_POP,1),:,:) + TDF_xy_POP_majority((relative_pos_majority_band_edge:size(TDF_xy_POP_majority,1)),:,:);

        TDF_yz_POP(1:pos_minority_band_edge,:,:) = TDF_yz_POP_minority(size(TDF_yz_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_yz_POP(pos_majority_band_edge:size(TDF_yz_POP,1),:,:) = TDF_yz_POP(pos_majority_band_edge:size(TDF_yz_POP,1),:,:) + TDF_yz_POP_majority((relative_pos_majority_band_edge:size(TDF_yz_POP_majority,1)),:,:);

        TDF_xz_POP(1:pos_minority_band_edge,:,:) = TDF_xz_POP_minority(size(TDF_xz_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_xz_POP(pos_majority_band_edge:size(TDF_xz_POP,1),:,:) = TDF_xz_POP(pos_majority_band_edge:size(TDF_xz_POP,1),:,:) + TDF_xz_POP_majority((relative_pos_majority_band_edge:size(TDF_xy_POP_majority,1)),:,:);

        TDF_yx_POP(1:pos_minority_band_edge,:,:) = TDF_yx_POP_minority(size(TDF_yx_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_yx_POP(pos_majority_band_edge:size(TDF_yx_POP,1),:,:) =  TDF_yx_POP(pos_majority_band_edge:size(TDF_yx_POP,1),:,:) + TDF_yx_POP_majority((relative_pos_majority_band_edge:size(TDF_yx_POP_majority,1)),:,:);

        TDF_zy_POP(1:pos_minority_band_edge,:,:) = TDF_zy_POP_minority(size(TDF_zy_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_zy_POP(pos_majority_band_edge:size(TDF_zy_POP,1),:,:) = TDF_zy_POP(pos_majority_band_edge:size(TDF_zy_POP,1),:,:) + TDF_zy_POP_majority((relative_pos_majority_band_edge:size(TDF_zy_POP_majority,1)),:,:);

        TDF_zx_POP(1:pos_minority_band_edge,:,:) = TDF_zx_POP_minority(size(TDF_xz_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_zx_POP(pos_majority_band_edge:size(TDF_zx_POP,1),:,:) = TDF_zx_POP(pos_majority_band_edge:size(TDF_zx_POP,1),:,:) + TDF_zx_POP_majority((relative_pos_majority_band_edge:size(TDF_zx_POP_majority,1)),:,:);


        % composing the other energy dependent quantities
        NNan = isnan(MFP_x_POP_majority); MFP_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_y_POP_minority); MFP_y_POP_minority(NNan)=0;
        NNan = isnan(MFP_y_POP_majority); MFP_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_x_POP_minority); tauE_x_POP_minority(NNan)=0;
        NNan = isnan(tauE_x_POP_majority); tauE_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_x_POP_minority); MFP_x_POP_minority(NNan)=0;
        NNan = isnan(MFP_z_POP_majority); MFP_z_POP_majority(NNan)=0;
        NNan = isnan(MFP_z_POP_minority); MFP_z_POP_minority(NNan)=0;
        NNan = isnan(tauE_y_POP_majority); tauE_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_y_POP_minority); tauE_y_POP_minority(NNan)=0;
        NNan = isnan(tauE_z_POP_majority); tauE_z_POP_majority(NNan)=0;
        NNan = isnan(tauE_z_POP_minority); tauE_z_POP_minority(NNan)=0;
        if strcmp(negative_gap,'yes')
            MFP_x_POP(1:pos_minority_band_edge,:,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) = merge_ave( MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) , MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:) );

            MFP_y_POP(1:pos_minority_band_edge,:,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) = merge_ave(MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) , MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:) );

            MFP_z_POP(1:pos_minority_band_edge,:,:) = MFP_z_POP_minority(size(MFP_z_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:,:) = merge_ave(MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:,:) , MFP_z_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:) );

            tauE_x_POP(1:pos_minority_band_edge,:,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) = merge_ave(tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) , tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:) );

            tauE_y_POP(1:pos_minority_band_edge,:,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) = merge_ave(tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) , tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:) );

            tauE_z_POP(1:pos_minority_band_edge,:,:) = tauE_z_POP_minority(size(tauE_z_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:,:) = merge_ave(tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:,:) , tauE_z_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:) );
        else
            MFP_x_POP(1:pos_minority_band_edge,:,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) = MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) + MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:);

            MFP_y_POP(1:pos_minority_band_edge,:,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) = MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) + MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:);

            MFP_z_POP(1:pos_minority_band_edge,:,:) = MFP_z_POP_minority(size(MFP_z_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:,:) = MFP_z_POP(pos_majority_band_edge:size(MFP_z_POP,1),:,:) + MFP_z_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:);

            tauE_x_POP(1:pos_minority_band_edge,:,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) = tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) + tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:);

            tauE_y_POP(1:pos_minority_band_edge,:,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) = tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) + tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:);

            tauE_z_POP(1:pos_minority_band_edge,:,:) = tauE_z_POP_minority(size(tauE_z_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:,:) = tauE_z_POP(pos_majority_band_edge:size(tauE_z_POP,1),:,:) + tauE_z_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:);
        end
        
    end

    TDF_sep.POP.xx = TDF_xx_POP; TDF_sep.POP.xy = TDF_xy_POP; TDF_sep.POP.xz = TDF_xz_POP;
    TDF_sep.POP.yx = TDF_yx_POP; TDF_sep.POP.yy = TDF_yy_POP; TDF_sep.POP.yz = TDF_yz_POP;
    TDF_sep.POP.zx = TDF_zx_POP; TDF_sep.POP.zy = TDF_zy_POP; TDF_sep.POP.zz = TDF_zz_POP;

    MFP_sep.POP.x = MFP_x_POP; MFP_sep.POP.y = MFP_y_POP; MFP_sep.POP.z = MFP_z_POP;
    tauE_sep.POP.x = tauE_x_POP; tauE_sep.POP.y = tauE_y_POP; tauE_sep.POP.z = tauE_z_POP;
    
end

 % ---------  Alloy only---------------------------------------------
if strcmp(Alloy,'yes')
    
    TDF_xx_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zz_Alloy=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_xy_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yz_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_xz_Alloy=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_yx_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zy_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_zx_Alloy=zeros(size(E_array,2),size(EF_matrix,2));
    MFP_x_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); MFP_z_Alloy=zeros(size(E_array,2),size(EF_matrix,2));
    tauE_x_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); tauE_z_Alloy=zeros(size(E_array,2),size(EF_matrix,2));

    TDF_xx_Alloy_majority = TDF_sep_electron.Alloy.xx;
    TDF_yy_Alloy_majority = TDF_sep_electron.Alloy.yy;
    TDF_zz_Alloy_majority = TDF_sep_electron.Alloy.zz;
    TDF_xy_Alloy_majority = TDF_sep_electron.Alloy.xy;
    TDF_yz_Alloy_majority = TDF_sep_electron.Alloy.yz;
    TDF_xz_Alloy_majority = TDF_sep_electron.Alloy.xz;
    TDF_yx_Alloy_majority = TDF_sep_electron.Alloy.yx;
    TDF_zy_Alloy_majority = TDF_sep_electron.Alloy.yz;
    TDF_zx_Alloy_majority = TDF_sep_electron.Alloy.zx;
    
    TDF_xx_Alloy_minority = TDF_sep_hole.Alloy.xx;
    TDF_yy_Alloy_minority = TDF_sep_hole.Alloy.yy;
    TDF_zz_Alloy_minority = TDF_sep_hole.Alloy.zz;
    TDF_xy_Alloy_minority = TDF_sep_hole.Alloy.xy;
    TDF_yz_Alloy_minority = TDF_sep_hole.Alloy.yz;
    TDF_xz_Alloy_minority = TDF_sep_hole.Alloy.xz;
    TDF_yx_Alloy_minority = TDF_sep_hole.Alloy.yx;
    TDF_zy_Alloy_minority = TDF_sep_hole.Alloy.yz;
    TDF_zx_Alloy_minority = TDF_sep_hole.Alloy.zx;
    
    MFP_x_Alloy_majority = MFP_sep_electron.Alloy.x;
    MFP_y_Alloy_majority = MFP_sep_electron.Alloy.y;
    MFP_z_Alloy_majority = MFP_sep_electron.Alloy.z;
    
    MFP_x_Alloy_minority = MFP_sep_hole.Alloy.x;
    MFP_y_Alloy_minority = MFP_sep_hole.Alloy.y;
    MFP_z_Alloy_minority = MFP_sep_hole.Alloy.z;
    
    tauE_x_Alloy_majority = tauE_sep_electron.Alloy.x;
    tauE_y_Alloy_majority = tauE_sep_electron.Alloy.y;
    tauE_z_Alloy_majority = tauE_sep_electron.Alloy.z;
    
    tauE_x_Alloy_minority = tauE_sep_hole.Alloy.x;
    tauE_y_Alloy_minority = tauE_sep_hole.Alloy.y;
    tauE_z_Alloy_minority = tauE_sep_hole.Alloy.z;
    
    TDF_xx_Alloy(1:pos_minority_band_edge,:) = TDF_xx_Alloy_minority(size(TDF_xx_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) = TDF_xx_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) + TDF_xx_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xx_Alloy_majority,1)),:);
    
    TDF_yy_Alloy(1:pos_minority_band_edge,:) = TDF_yy_Alloy_minority(size(TDF_yy_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_Alloy(pos_majority_band_edge:size(TDF_yy_Alloy,1),:) = TDF_yy_Alloy(pos_majority_band_edge:size(TDF_yy_Alloy,1),:) + TDF_yy_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xx_Alloy_majority,1)),:);
    
    TDF_zz_Alloy(1:pos_minority_band_edge,:) = TDF_zz_Alloy_minority(size(TDF_zz_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zz_Alloy(pos_majority_band_edge:size(TDF_zz_Alloy,1),:) = TDF_zz_Alloy(pos_majority_band_edge:size(TDF_zz_Alloy,1),:) + TDF_zz_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xx_Alloy_majority,1)),:);
    
    TDF_xy_Alloy(1:pos_minority_band_edge,:) = TDF_xy_Alloy_minority(size(TDF_xy_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_Alloy(pos_majority_band_edge:size(TDF_xy_Alloy,1),:) = TDF_xy_Alloy(pos_majority_band_edge:size(TDF_xy_Alloy,1),:) + TDF_xy_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xy_Alloy_majority,1)),:);
    
    TDF_yz_Alloy(1:pos_minority_band_edge,:) = TDF_yz_Alloy_minority(size(TDF_yz_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yz_Alloy(pos_majority_band_edge:size(TDF_yz_Alloy,1),:) = TDF_yz_Alloy(pos_majority_band_edge:size(TDF_yz_Alloy,1),:) + TDF_yz_Alloy_majority((relative_pos_majority_band_edge:size(TDF_yz_Alloy_majority,1)),:);
    
    TDF_xz_Alloy(1:pos_minority_band_edge,:) = TDF_xz_Alloy_minority(size(TDF_xz_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xz_Alloy(pos_majority_band_edge:size(TDF_xz_Alloy,1),:) = TDF_xz_Alloy(pos_majority_band_edge:size(TDF_xz_Alloy,1),:) + TDF_xz_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xy_Alloy_majority,1)),:);
    
    TDF_yx_Alloy(1:pos_minority_band_edge,:) = TDF_yx_Alloy_minority(size(TDF_yx_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_Alloy(pos_majority_band_edge:size(TDF_yx_Alloy,1),:) = TDF_yx_Alloy(pos_majority_band_edge:size(TDF_yx_Alloy,1),:) + TDF_yx_Alloy_majority((relative_pos_majority_band_edge:size(TDF_yx_Alloy_majority,1)),:);
    
    TDF_zy_Alloy(1:pos_minority_band_edge,:) = TDF_zy_Alloy_minority(size(TDF_zy_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zy_Alloy(pos_majority_band_edge:size(TDF_zy_Alloy,1),:) = TDF_zy_Alloy(pos_majority_band_edge:size(TDF_zy_Alloy,1),:) + TDF_zy_Alloy_majority((relative_pos_majority_band_edge:size(TDF_zy_Alloy_majority,1)),:);
    
    TDF_zx_Alloy(1:pos_minority_band_edge,:) = TDF_zx_Alloy_minority(size(TDF_xz_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_zx_Alloy(pos_majority_band_edge:size(TDF_zx_Alloy,1),:) = TDF_zx_Alloy(pos_majority_band_edge:size(TDF_zx_Alloy,1),:) + TDF_zx_Alloy_majority((relative_pos_majority_band_edge:size(TDF_zx_Alloy_majority,1)),:);
    
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_Alloy_majority); MFP_x_Alloy_majority(NNan)=0;
    NNan = isnan(MFP_y_Alloy_minority); MFP_y_Alloy_minority(NNan)=0;
    NNan = isnan(MFP_y_Alloy_majority); MFP_y_Alloy_majority(NNan)=0;
    NNan = isnan(tauE_x_Alloy_minority); tauE_x_Alloy_minority(NNan)=0;
    NNan = isnan(tauE_x_Alloy_majority); tauE_x_Alloy_majority(NNan)=0;
    NNan = isnan(MFP_x_Alloy_minority); MFP_x_Alloy_minority(NNan)=0;
    NNan = isnan(MFP_z_Alloy_majority); MFP_z_Alloy_majority(NNan)=0;
    NNan = isnan(MFP_z_Alloy_minority); MFP_z_Alloy_minority(NNan)=0;
    NNan = isnan(tauE_y_Alloy_majority); tauE_y_Alloy_majority(NNan)=0;
    NNan = isnan(tauE_y_Alloy_minority); tauE_y_Alloy_minority(NNan)=0;
    NNan = isnan(tauE_z_Alloy_majority); tauE_z_Alloy_majority(NNan)=0;
    NNan = isnan(tauE_z_Alloy_minority); tauE_z_Alloy_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_Alloy(1:pos_minority_band_edge,:,:) = MFP_x_Alloy_minority(size(MFP_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:,:) = merge_ave( MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:,:) , MFP_x_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:,:) );

        MFP_y_Alloy(1:pos_minority_band_edge,:,:) = MFP_y_Alloy_minority(size(MFP_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:,:) = merge_ave(MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:,:) , MFP_y_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:,:) );

        MFP_z_Alloy(1:pos_minority_band_edge,:,:) = MFP_z_Alloy_minority(size(MFP_z_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_z_Alloy(pos_majority_band_edge:size(MFP_z_Alloy,1),:,:) = merge_ave(MFP_z_Alloy(pos_majority_band_edge:size(MFP_z_Alloy,1),:,:) , MFP_z_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:,:) );

        tauE_x_Alloy(1:pos_minority_band_edge,:,:) = tauE_x_Alloy_minority(size(tauE_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:,:) = merge_ave(tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:,:) , tauE_x_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:,:) );

        tauE_y_Alloy(1:pos_minority_band_edge,:,:) = tauE_y_Alloy_minority(size(tauE_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:,:) = merge_ave(tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:,:) , tauE_y_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:,:) );

        tauE_z_Alloy(1:pos_minority_band_edge,:,:) = tauE_z_Alloy_minority(size(tauE_z_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_z_Alloy(pos_majority_band_edge:size(tauE_z_Alloy,1),:,:) = merge_ave(tauE_z_Alloy(pos_majority_band_edge:size(tauE_z_Alloy,1),:,:) , tauE_z_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:,:) );
    else   
        MFP_x_Alloy(1:pos_minority_band_edge,:) = MFP_x_Alloy_minority(size(MFP_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:) = MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:) + MFP_x_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:);

        MFP_y_Alloy(1:pos_minority_band_edge,:) = MFP_y_Alloy_minority(size(MFP_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:) = MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:) + MFP_y_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:);

        MFP_z_Alloy(1:pos_minority_band_edge,:) = MFP_z_Alloy_minority(size(MFP_z_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_z_Alloy(pos_majority_band_edge:size(MFP_z_Alloy,1),:) = MFP_z_Alloy(pos_majority_band_edge:size(MFP_z_Alloy,1),:) + MFP_z_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:);

        tauE_x_Alloy(1:pos_minority_band_edge,:) = tauE_x_Alloy_minority(size(tauE_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:) = tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:) + tauE_x_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:);

        tauE_y_Alloy(1:pos_minority_band_edge,:) = tauE_y_Alloy_minority(size(tauE_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:) = tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:) + tauE_y_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:);

        tauE_z_Alloy(1:pos_minority_band_edge,:) = tauE_z_Alloy_minority(size(tauE_z_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_z_Alloy(pos_majority_band_edge:size(tauE_z_Alloy,1),:) = tauE_z_Alloy(pos_majority_band_edge:size(tauE_z_Alloy,1),:) + tauE_z_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:);
    end
    
    TDF_sep.Alloy.xx = TDF_xx_Alloy; TDF_sep.Alloy.xy = TDF_xy_Alloy; TDF_sep.Alloy.xz = TDF_xz_Alloy;
    TDF_sep.Alloy.yx = TDF_yx_Alloy; TDF_sep.Alloy.yy = TDF_yy_Alloy; TDF_sep.Alloy.yz = TDF_yz_Alloy;
    TDF_sep.Alloy.zx = TDF_zx_Alloy; TDF_sep.Alloy.zy = TDF_zy_Alloy; TDF_sep.Alloy.zz = TDF_zz_Alloy;
    
    MFP_sep.Alloy.x = MFP_x_Alloy; MFP_sep.Alloy.y = MFP_y_Alloy; MFP_sep.Alloy.z = MFP_z_Alloy;
    tauE_sep.Alloy.x = tauE_x_Alloy; tauE_sep.Alloy.y = tauE_y_Alloy; tauE_sep.Alloy.z = tauE_z_Alloy;
    
    
end
    


    if strcmp(IIS,'yes') || strcmp(Alloy,'yes') % Da spostare più giù alla fine, occhio a IIS, anche per POP
        
        TDF_xx_ph_majority = TDF_ph_electron.xx;
        TDF_yy_ph_majority = TDF_ph_electron.yy;
        TDF_zz_ph_majority = TDF_ph_electron.zz;
        TDF_xy_ph_majority = TDF_ph_electron.xy;
        TDF_yz_ph_majority = TDF_ph_electron.yz;
        TDF_xz_ph_majority = TDF_ph_electron.xz;
        TDF_yx_ph_majority = TDF_ph_electron.yx;
        TDF_zy_ph_majority = TDF_ph_electron.yz;
        TDF_zx_ph_majority = TDF_ph_electron.zx;

        TDF_xx_ph_minority = TDF_ph_hole.xx;
        TDF_yy_ph_minority = TDF_ph_hole.yy;
        TDF_zz_ph_minority = TDF_ph_hole.zz;
        TDF_xy_ph_minority = TDF_ph_hole.xy;
        TDF_yz_ph_minority = TDF_ph_hole.yz;
        TDF_xz_ph_minority = TDF_ph_hole.xz;
        TDF_yx_ph_minority = TDF_ph_hole.yx;
        TDF_zy_ph_minority = TDF_ph_hole.yz;
        TDF_zx_ph_minority = TDF_ph_hole.zx;
        
        MFP_x_ph_majority = MFP_ph_electron.x;
        MFP_y_ph_majority = MFP_ph_electron.y;
        MFP_z_ph_majority = MFP_ph_electron.z;
        tauE_x_ph_majority = tauE_ph_electron.x;
        tauE_y_ph_majority = tauE_ph_electron.y;
        tauE_z_ph_majority = tauE_ph_electron.z;
        
        MFP_x_ph_minority = MFP_ph_hole.x;
        MFP_y_ph_minority = MFP_ph_hole.y;
        MFP_z_ph_minority = MFP_ph_hole.z;
        tauE_x_ph_minority = tauE_ph_hole.x;
        tauE_y_ph_minority = tauE_ph_hole.y;
        tauE_z_ph_minority = tauE_ph_hole.z;
        
        
        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
            
            TDF_xx_ph=zeros(nE, nEF, nT ); TDF_yy_ph=zeros(nE, nEF, nT ); TDF_zz_ph=zeros(nE, nEF, nT );
            TDF_xy_ph=zeros(nE, nEF, nT ); TDF_yz_ph=zeros(nE, nEF, nT ); TDF_xz_ph=zeros(nE, nEF, nT );
            TDF_yx_ph=zeros(nE, nEF, nT ); TDF_zy_ph=zeros(nE, nEF, nT ); TDF_zx_ph=zeros(nE, nEF, nT );
            MFP_x_ph=zeros(nE, nEF, nT ); MFP_y_ph=zeros(nE, nEF, nT ); MFP_z_ph=zeros(nE, nEF, nT );
            tauE_x_ph=zeros(nE, nEF, nT ); tauE_y_ph=zeros(nE, nEF, nT ); tauE_z_ph=zeros(nE, nEF, nT );
            

            TDF_xx_ph(1:pos_minority_band_edge,:,:) = TDF_xx_ph_minority(size(TDF_xx_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) = TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) + TDF_xx_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:,:);

            TDF_yy_ph(1:pos_minority_band_edge,:,:) = TDF_yy_ph_minority(size(TDF_yy_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_yy_ph(pos_majority_band_edge:size(TDF_yy_ph,1),:,:) = TDF_yy_ph(pos_majority_band_edge:size(TDF_yy_ph,1),:,:) + TDF_yy_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:,:);

            TDF_zz_ph(1:pos_minority_band_edge,:,:) = TDF_zz_ph_minority(size(TDF_zz_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_zz_ph(pos_majority_band_edge:size(TDF_zz_ph,1),:,:) = TDF_zz_ph(pos_majority_band_edge:size(TDF_zz_ph,1),:,:) + TDF_zz_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:,:);

            TDF_xy_ph(1:pos_minority_band_edge,:,:) = TDF_xy_ph_minority(size(TDF_xy_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_xy_ph(pos_majority_band_edge:size(TDF_xy_ph,1),:,:) = TDF_xy_ph(pos_majority_band_edge:size(TDF_xy_ph,1),:,:) + TDF_xy_ph_majority((relative_pos_majority_band_edge:size(TDF_xy_ph_majority,1)),:,:);

            TDF_yz_ph(1:pos_minority_band_edge,:,:) = TDF_yz_ph_minority(size(TDF_yz_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_yz_ph(pos_majority_band_edge:size(TDF_yz_ph,1),:,:) = TDF_yz_ph(pos_majority_band_edge:size(TDF_yz_ph,1),:,:) + TDF_yz_ph_majority((relative_pos_majority_band_edge:size(TDF_yz_ph_majority,1)),:,:);

            TDF_xz_ph(1:pos_minority_band_edge,:,:) = TDF_xz_ph_minority(size(TDF_xz_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_xz_ph(pos_majority_band_edge:size(TDF_xz_ph,1),:,:) = TDF_xz_ph(pos_majority_band_edge:size(TDF_xz_ph,1),:,:) + TDF_xz_ph_majority((relative_pos_majority_band_edge:size(TDF_xy_ph_majority,1)),:,:);

            TDF_yx_ph(1:pos_minority_band_edge,:,:) = TDF_yx_ph_minority(size(TDF_yx_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_yx_ph(pos_majority_band_edge:size(TDF_yx_ph,1),:,:) = TDF_yx_ph(pos_majority_band_edge:size(TDF_yx_ph,1),:,:) + TDF_yx_ph_majority((relative_pos_majority_band_edge:size(TDF_yx_ph_majority,1)),:,:);

            TDF_zy_ph(1:pos_minority_band_edge,:,:) = TDF_zy_ph_minority(size(TDF_zy_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_zy_ph(pos_majority_band_edge:size(TDF_zy_ph,1),:,:) = TDF_zy_ph(pos_majority_band_edge:size(TDF_zy_ph,1),:,:) + TDF_zy_ph_majority((relative_pos_majority_band_edge:size(TDF_zy_ph_majority,1)),:,:);

            TDF_zx_ph(1:pos_minority_band_edge,:,:) = TDF_zx_ph_minority(size(TDF_xz_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_zx_ph(pos_majority_band_edge:size(TDF_zx_ph,1),:,:) = TDF_zx_ph(pos_majority_band_edge:size(TDF_zx_ph,1),:,:) + TDF_zx_ph_majority((relative_pos_majority_band_edge:size(TDF_zx_ph_majority,1)),:,:);


            % composing the other energy dependent quantities
            NNan = isnan(MFP_x_ph_majority); MFP_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_y_ph_minority); MFP_y_ph_minority(NNan)=0;
            NNan = isnan(MFP_y_ph_majority); MFP_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_x_ph_minority); tauE_x_ph_minority(NNan)=0;
            NNan = isnan(tauE_x_ph_majority); tauE_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_x_ph_minority); MFP_x_ph_minority(NNan)=0;
            NNan = isnan(MFP_z_ph_majority); MFP_z_ph_majority(NNan)=0;
            NNan = isnan(MFP_z_ph_minority); MFP_z_ph_minority(NNan)=0;
            NNan = isnan(tauE_y_ph_majority); tauE_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_y_ph_minority); tauE_y_ph_minority(NNan)=0;
            NNan = isnan(tauE_z_ph_majority); tauE_z_ph_majority(NNan)=0;
            NNan = isnan(tauE_z_ph_minority); tauE_z_ph_minority(NNan)=0;
            if strcmp(negative_gap,'yes')
                MFP_x_ph(1:pos_minority_band_edge,:,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) = merge_ave( MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) , MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:) );

                MFP_y_ph(1:pos_minority_band_edge,:,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) = merge_ave(MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) , MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:) );

                MFP_z_ph(1:pos_minority_band_edge,:,:) = MFP_z_ph_minority(size(MFP_z_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:,:) = merge_ave(MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:,:) , MFP_z_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:) );

                tauE_x_ph(1:pos_minority_band_edge,:,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) = merge_ave(tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) , tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:) );

                tauE_y_ph(1:pos_minority_band_edge,:,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) = merge_ave(tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) , tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:) );

                tauE_z_ph(1:pos_minority_band_edge,:,:) = tauE_z_ph_minority(size(tauE_z_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:,:) = merge_ave(tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:,:) , tauE_z_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:) );
            else
                MFP_x_ph(1:pos_minority_band_edge,:,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) = MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) + MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:);

                MFP_y_ph(1:pos_minority_band_edge,:,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) = MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) + MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:);

                MFP_z_ph(1:pos_minority_band_edge,:,:) = MFP_z_ph_minority(size(MFP_z_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:,:) = MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:,:) + MFP_z_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:);

                tauE_x_ph(1:pos_minority_band_edge,:,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) = tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) + tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:);

                tauE_y_ph(1:pos_minority_band_edge,:,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) = tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) + tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:);

                tauE_z_ph(1:pos_minority_band_edge,:,:) = tauE_z_ph_minority(size(tauE_z_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:,:) = tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:,:) + tauE_z_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:);
            end
            
        else
            
            TDF_xx_ph=zeros(nE, nT ); TDF_yy_ph=zeros(nE, nT ); TDF_zz_ph=zeros(nE, nT );
            TDF_xy_ph=zeros(nE, nT ); TDF_yz_ph=zeros(nE, nT ); TDF_xz_ph=zeros(nE, nT );
            TDF_yx_ph=zeros(nE, nT ); TDF_zy_ph=zeros(nE, nT ); TDF_zx_ph=zeros(nE, nT );
            MFP_x_ph=zeros(nE, nT ); MFP_y_ph=zeros(nE, nT ); MFP_z_ph=zeros(nE, nT );
            tauE_x_ph=zeros(nE, nT ); tauE_y_ph=zeros(nE, nT ); tauE_z_ph=zeros(nE, nT );
            
            
            TDF_xx_ph(1:pos_minority_band_edge,:) = TDF_xx_ph_minority(size(TDF_xx_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) = TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) + TDF_xx_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:);

            TDF_yy_ph(1:pos_minority_band_edge,:) = TDF_yy_ph_minority(size(TDF_yy_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_yy_ph(pos_majority_band_edge:size(TDF_yy_ph,1),:) = TDF_yy_ph(pos_majority_band_edge:size(TDF_yy_ph,1),:) + TDF_yy_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:);

            TDF_zz_ph(1:pos_minority_band_edge,:) = TDF_zz_ph_minority(size(TDF_zz_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_zz_ph(pos_majority_band_edge:size(TDF_zz_ph,1),:) = TDF_zz_ph(pos_majority_band_edge:size(TDF_zz_ph,1),:) + TDF_zz_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:);

            TDF_xy_ph(1:pos_minority_band_edge,:) = TDF_xy_ph_minority(size(TDF_xy_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_xy_ph(pos_majority_band_edge:size(TDF_xy_ph,1),:) = TDF_xy_ph(pos_majority_band_edge:size(TDF_xy_ph,1),:) + TDF_xy_ph_majority((relative_pos_majority_band_edge:size(TDF_xy_ph_majority,1)),:);

            TDF_yz_ph(1:pos_minority_band_edge,:) = TDF_yz_ph_minority(size(TDF_yz_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_yz_ph(pos_majority_band_edge:size(TDF_yz_ph,1),:) = TDF_yz_ph(pos_majority_band_edge:size(TDF_yz_ph,1),:) + TDF_yz_ph_majority((relative_pos_majority_band_edge:size(TDF_yz_ph_majority,1)),:);

            TDF_xz_ph(1:pos_minority_band_edge,:) = TDF_xz_ph_minority(size(TDF_xz_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_xz_ph(pos_majority_band_edge:size(TDF_xz_ph,1),:) = TDF_xz_ph(pos_majority_band_edge:size(TDF_xz_ph,1),:) + TDF_xz_ph_majority((relative_pos_majority_band_edge:size(TDF_xy_ph_majority,1)),:);

            TDF_yx_ph(1:pos_minority_band_edge,:) = TDF_yx_ph_minority(size(TDF_yx_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_yx_ph(pos_majority_band_edge:size(TDF_yx_ph,1),:) = TDF_yx_ph(pos_majority_band_edge:size(TDF_yx_ph,1),:) + TDF_yx_ph_majority((relative_pos_majority_band_edge:size(TDF_yx_ph_majority,1)),:);

            TDF_zy_ph(1:pos_minority_band_edge,:) = TDF_zy_ph_minority(size(TDF_zy_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_zy_ph(pos_majority_band_edge:size(TDF_zy_ph,1),:) = TDF_zy_ph(pos_majority_band_edge:size(TDF_zy_ph,1),:) + TDF_zy_ph_majority((relative_pos_majority_band_edge:size(TDF_zy_ph_majority,1)),:);

            TDF_zx_ph(1:pos_minority_band_edge,:) = TDF_zx_ph_minority(size(TDF_xz_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_zx_ph(pos_majority_band_edge:size(TDF_zx_ph,1),:) = TDF_zx_ph(pos_majority_band_edge:size(TDF_zx_ph,1),:) + TDF_zx_ph_majority((relative_pos_majority_band_edge:size(TDF_zx_ph_majority,1)),:);


            % composing the other energy dependent quantities
            NNan = isnan(MFP_x_ph_majority); MFP_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_y_ph_minority); MFP_y_ph_minority(NNan)=0;
            NNan = isnan(MFP_y_ph_majority); MFP_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_x_ph_minority); tauE_x_ph_minority(NNan)=0;
            NNan = isnan(tauE_x_ph_majority); tauE_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_x_ph_minority); MFP_x_ph_minority(NNan)=0;
            NNan = isnan(MFP_z_ph_majority); MFP_z_ph_majority(NNan)=0;
            NNan = isnan(MFP_z_ph_minority); MFP_z_ph_minority(NNan)=0;
            NNan = isnan(tauE_y_ph_majority); tauE_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_y_ph_minority); tauE_y_ph_minority(NNan)=0;
            NNan = isnan(tauE_z_ph_majority); tauE_z_ph_majority(NNan)=0;
            NNan = isnan(tauE_z_ph_minority); tauE_z_ph_minority(NNan)=0;
            if strcmp(negative_gap,'yes')
                MFP_x_ph(1:pos_minority_band_edge,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) = merge_ave( MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) , MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:) );

                MFP_y_ph(1:pos_minority_band_edge,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) = merge_ave(MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) , MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:) );

                MFP_z_ph(1:pos_minority_band_edge,:) = MFP_z_ph_minority(size(MFP_z_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:) = merge_ave(MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:) , MFP_z_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:) );

                tauE_x_ph(1:pos_minority_band_edge,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) = merge_ave(tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) , tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:) );

                tauE_y_ph(1:pos_minority_band_edge,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) = merge_ave(tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) , tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:) );

                tauE_z_ph(1:pos_minority_band_edge,:) = tauE_z_ph_minority(size(tauE_z_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:) = merge_ave(tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:) , tauE_z_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:) );
            else
                MFP_x_ph(1:pos_minority_band_edge,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) =  MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) + MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:);

                MFP_y_ph(1:pos_minority_band_edge,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) = MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) + MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:);

                MFP_z_ph(1:pos_minority_band_edge,:) = MFP_z_ph_minority(size(MFP_z_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:) = MFP_z_ph(pos_majority_band_edge:size(MFP_z_ph,1),:) + MFP_z_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:);

                tauE_x_ph(1:pos_minority_band_edge,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) = tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) + tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:);

                tauE_y_ph(1:pos_minority_band_edge,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) = tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) + tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:);

                tauE_z_ph(1:pos_minority_band_edge,:) = tauE_z_ph_minority(size(tauE_z_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:) = tauE_z_ph(pos_majority_band_edge:size(tauE_z_ph,1),:) + tauE_z_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:);
            end
           
        end
        
        
        
        TDF_ph.xx = TDF_xx_ph; TDF_ph.xy = TDF_xy_ph; TDF_ph.xz = TDF_xz_ph;
        TDF_ph.yx = TDF_yx_ph; TDF_ph.yy = TDF_yy_ph; TDF_ph.yz = TDF_yz_ph;
        TDF_ph.zx = TDF_zx_ph; TDF_ph.zy = TDF_zy_ph; TDF_ph.zz = TDF_zz_ph;

        MFP_ph.x = MFP_x_ph; MFP_ph.y = MFP_y_ph; MFP_ph.z = MFP_z_ph;
        tauE_ph.x = tauE_x_ph; tauE_ph.y = tauE_y_ph; tauE_ph.z = tauE_z_ph;        
        
        
        
    end
    
     
    
end

function C = merge_ave(A,B)

    C = zeros(size(A,1),size(A,2),size(A,3));
    nv2 = size(A,2) ;
    nv3 = size(A,3) ;
    for i_v2 = 1:nv2
        for i_v3 = 1:nv3            
            A_t = A(:,i_v2,i_v3);
            B_t = B(:,i_v2,i_v3);
            [na,ma] =  find( A_t );
            [nb,mb] =  find( B_t );
            C(:,i_v2,i_v3) = A_t+B_t;
            C(intersect(ma,mb),i_v2,i_v3) = ( A_t((intersect(ma,mb)))+B_t((intersect(ma,mb))) )/2 ;
        end
    end
        
end