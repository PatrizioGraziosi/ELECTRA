% Copyright 2021 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

function [ TDF_CMFP, tauE_CMFP, DOS_tot, V_tot ] =   TDF_CMFP_bipolar_composition( ...
                TDF_electron_CMFP, TDF_hole_CMFP,...
                tauE_electron_CMFP, tauE_hole_CMFP, ...
                E_array_majority, E_array_minority, ...
                DOS_tot_majority, DOS_tot_minority, ...
                V_tot_majority, V_tot_minority, ...
                E_array, minority_band_edge, negative_gap)
            
                
nE = size(E_array,2); 
    
                
TDF_CMFP.xx = zeros( nE, 1 ); TDF_CMFP.yy = zeros( nE, 1 ); TDF_CMFP.zz = zeros( nE, 1 );
tauE_CMFP.x = zeros( nE, 1 ); tauE_CMFP.y = zeros( nE, 1 ); tauE_CMFP.z = zeros( nE, 1 );


TDF_xx=zeros(size(E_array,2), 1); TDF_yy=zeros(size(E_array,2), 1); TDF_zz=zeros(size(E_array,2), 1);
tauE_x=zeros(size(E_array,2), 1); tauE_y=zeros(size(E_array,2), 1); tauE_z=zeros(size(E_array,2), 1);

DOS_tot = zeros(1,size(E_array,2)); V_tot = zeros(1,size(E_array,2),1);
    
    
% conversion of the entered struct data into temp matrixes
    
    TDF_xx_majority = TDF_electron_CMFP.xx;
    TDF_yy_majority = TDF_electron_CMFP.yy;
    TDF_zz_majority = TDF_electron_CMFP.zz;
    
    TDF_xx_minority = TDF_hole_CMFP.xx;
    TDF_yy_minority = TDF_hole_CMFP.yy;
    TDF_zz_minority = TDF_hole_CMFP.zz;
    
    tauE_x_majority = tauE_electron_CMFP.x;
    tauE_y_majority = tauE_electron_CMFP.y;
    tauE_z_majority = tauE_electron_CMFP.z;
    
    tauE_x_minority = tauE_hole_CMFP.x;
    tauE_y_minority = tauE_hole_CMFP.y;
    tauE_z_minority = tauE_hole_CMFP.z;



   
    % composition of the Transport Density Functions TDF

    [~,pos_minority_band_edge] = min( abs(E_array - (-minority_band_edge)));
    [~,pos_majority_band_edge] = min( abs(E_array));
    
    [~,relative_pos_minority_band_edge] = min( abs(E_array_minority - minority_band_edge));
    [~,relative_pos_majority_band_edge] = min( abs(E_array_majority));
    
    if size(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge,2) < pos_minority_band_edge
        pos_minority_band_edge = pos_minority_band_edge-1;
    end
    if size(pos_majority_band_edge:size(TDF_xx,1),2) < size((relative_pos_majority_band_edge:size(TDF_xx_majority,1)),2) 
        relative_pos_majority_band_edge = relative_pos_majority_band_edge+1;
    end
    
    % additional control on 23 February 2022
    diff_1 = length(1:pos_minority_band_edge) - length(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge);
    if diff_1 ~= 0 
        disp(' adjustment at the TDF composition level in TDF_CMFP_bipolar_composition, line 85 ');
        relative_pos_minority_band_edge = relative_pos_minority_band_edge - diff_1;
    end
    diff_2 = length(pos_majority_band_edge:size(TDF_xx,1)) - length(relative_pos_majority_band_edge:size(TDF_xx_majority,1));
    if diff_2 ~= 0 
        disp(' adjustment at the TDF composition level in TDF_CMFP_bipolar_composition, line 85 ');
        relative_pos_majority_band_edge = relative_pos_majority_band_edge - diff_2;
    end
    
    DOS_tot(1:pos_minority_band_edge) = DOS_tot_minority(size(DOS_tot_minority,2):-1:relative_pos_minority_band_edge);
    DOS_tot(pos_majority_band_edge:size(DOS_tot,2)) = DOS_tot(pos_majority_band_edge:size(DOS_tot,2)) + DOS_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    
    V_tot(1:pos_minority_band_edge) = V_tot_minority(size(V_tot_minority,2):-1:relative_pos_minority_band_edge);
    A = V_tot(pos_majority_band_edge:size(DOS_tot,2)); 
    B = V_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    [na,ma] =  find( A );
    [nb,mb] =  find( B );
    C = A+B;
    C(intersect(ma,mb)) = ( A((intersect(ma,mb)))+B((intersect(ma,mb))) )/2 ;
    V_tot(pos_majority_band_edge:size(V_tot,2)) = V_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    
    
    
    TDF_xx(1:pos_minority_band_edge) = TDF_xx_minority(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge);
    TDF_xx(pos_majority_band_edge:size(TDF_xx,1)) = TDF_xx_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    
    TDF_yy(1:pos_minority_band_edge) = TDF_yy_minority(size(TDF_yy_minority,1):-1:relative_pos_minority_band_edge);
    TDF_yy(pos_majority_band_edge:size(TDF_yy,1)) = TDF_yy_majority((relative_pos_majority_band_edge:size(TDF_yy_majority,1)));
    
    TDF_zz(1:pos_minority_band_edge) = TDF_zz_minority(size(TDF_zz_minority,1):-1:relative_pos_minority_band_edge);
    TDF_zz(pos_majority_band_edge:size(TDF_zz,1)) = TDF_zz_majority((relative_pos_majority_band_edge:size(TDF_zz_majority,1)));
    
       
    % composing the other energy dependent quantities
        
    tauE_x(1:pos_minority_band_edge) = tauE_x_minority(size(tauE_x_minority,1):-1:relative_pos_minority_band_edge);
    tauE_x(pos_majority_band_edge:size(tauE_x,1)) = tauE_x_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)));
    
    tauE_y(1:pos_minority_band_edge) = tauE_y_minority(size(tauE_y_minority,1):-1:relative_pos_minority_band_edge);
    tauE_y(pos_majority_band_edge:size(tauE_y,1)) = tauE_y_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)));
    
    tauE_z(1:pos_minority_band_edge) = tauE_z_minority(size(tauE_z_minority,1):-1:relative_pos_minority_band_edge);
    tauE_z(pos_majority_band_edge:size(tauE_z,1)) = tauE_z_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)));
        

    
    
    TDF_CMFP.xx = TDF_xx; TDF_CMFP.yy = TDF_yy; TDF_CMFP.zz = TDF_zz;

    tauE_CMFP.x = tauE_x; tauE_CMFP.y = tauE_y; tauE_CMFP.z = tauE_z;    
    
    
end